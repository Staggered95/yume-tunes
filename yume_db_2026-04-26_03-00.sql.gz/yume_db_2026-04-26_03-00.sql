--
-- PostgreSQL database dump
--

\restrict Dyx7ZtOp0fgiAEadWukXSubQTRwaQ4EExf0wf9xJeRaYms9deKodXTxLzDsd7in

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.user_recommendations DROP CONSTRAINT user_recommendations_user_id_fkey;
ALTER TABLE ONLY public.user_recommendations DROP CONSTRAINT user_recommendations_song_id_fkey;
ALTER TABLE ONLY public.songs DROP CONSTRAINT songs_artist_id_fkey;
ALTER TABLE ONLY public.songs DROP CONSTRAINT songs_anime_id_fkey;
ALTER TABLE ONLY public.song_genres DROP CONSTRAINT song_genres_song_id_fkey;
ALTER TABLE ONLY public.song_genres DROP CONSTRAINT song_genres_genre_id_fkey;
ALTER TABLE ONLY public.playlists DROP CONSTRAINT playlists_user_id_fkey;
ALTER TABLE ONLY public.playlist_songs DROP CONSTRAINT playlist_songs_song_id_fkey;
ALTER TABLE ONLY public.playlist_songs DROP CONSTRAINT playlist_songs_playlist_id_fkey;
ALTER TABLE ONLY public.listening_history DROP CONSTRAINT listening_history_user_id_fkey;
ALTER TABLE ONLY public.listening_history DROP CONSTRAINT listening_history_song_id_fkey;
ALTER TABLE ONLY public.liked_songs DROP CONSTRAINT liked_songs_user_id_fkey;
ALTER TABLE ONLY public.liked_songs DROP CONSTRAINT liked_songs_song_id_fkey;
ALTER TABLE ONLY public.animes DROP CONSTRAINT albums_artist_id_fkey;
DROP INDEX public.idx_listening_history_user_song;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_username_key;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_key;
ALTER TABLE ONLY public.user_recommendations DROP CONSTRAINT user_recommendations_user_id_song_id_key;
ALTER TABLE ONLY public.user_recommendations DROP CONSTRAINT user_recommendations_pkey;
ALTER TABLE ONLY public.animes DROP CONSTRAINT unique_anime_per_artist;
ALTER TABLE ONLY public.songs DROP CONSTRAINT songs_pkey;
ALTER TABLE ONLY public.songs DROP CONSTRAINT songs_file_path_key;
ALTER TABLE ONLY public.song_genres DROP CONSTRAINT song_genres_pkey;
ALTER TABLE ONLY public.quotes DROP CONSTRAINT quotes_pkey;
ALTER TABLE ONLY public.playlists DROP CONSTRAINT playlists_pkey;
ALTER TABLE ONLY public.playlist_songs DROP CONSTRAINT playlist_songs_pkey;
ALTER TABLE ONLY public.listening_history DROP CONSTRAINT listening_history_pkey;
ALTER TABLE ONLY public.liked_songs DROP CONSTRAINT liked_songs_pkey;
ALTER TABLE ONLY public.hero_banners DROP CONSTRAINT hero_banners_pkey;
ALTER TABLE ONLY public.genres DROP CONSTRAINT genres_pkey;
ALTER TABLE ONLY public.genres DROP CONSTRAINT genres_name_key;
ALTER TABLE ONLY public.artists DROP CONSTRAINT artists_pkey;
ALTER TABLE ONLY public.artists DROP CONSTRAINT artists_name_key1;
ALTER TABLE ONLY public.artists DROP CONSTRAINT artists_name_key;
ALTER TABLE ONLY public.animes DROP CONSTRAINT animes_title_key;
ALTER TABLE ONLY public.animes DROP CONSTRAINT albums_title_artist_id_key;
ALTER TABLE ONLY public.animes DROP CONSTRAINT albums_pkey;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.user_recommendations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.songs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.quotes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.playlists ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.listening_history ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.hero_banners ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.genres ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.artists ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.animes ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.user_recommendations_id_seq;
DROP TABLE public.user_recommendations;
DROP SEQUENCE public.songs_id_seq;
DROP TABLE public.songs;
DROP TABLE public.song_genres;
DROP SEQUENCE public.quotes_id_seq;
DROP TABLE public.quotes;
DROP SEQUENCE public.playlists_id_seq;
DROP TABLE public.playlists;
DROP TABLE public.playlist_songs;
DROP SEQUENCE public.listening_history_id_seq;
DROP TABLE public.listening_history;
DROP TABLE public.liked_songs;
DROP SEQUENCE public.hero_banners_id_seq;
DROP TABLE public.hero_banners;
DROP SEQUENCE public.genres_id_seq;
DROP TABLE public.genres;
DROP SEQUENCE public.artists_id_seq;
DROP TABLE public.artists;
DROP SEQUENCE public.albums_id_seq;
DROP TABLE public.animes;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: animes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.animes (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    artist_id integer
);


--
-- Name: albums_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.albums_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: albums_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.albums_id_seq OWNED BY public.animes.id;


--
-- Name: artists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.artists (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


--
-- Name: artists_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.artists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: artists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.artists_id_seq OWNED BY public.artists.id;


--
-- Name: genres; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.genres (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


--
-- Name: genres_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.genres_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: genres_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.genres_id_seq OWNED BY public.genres.id;


--
-- Name: hero_banners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hero_banners (
    id integer NOT NULL,
    title character varying(255),
    subtitle text,
    image_path text NOT NULL,
    target_url text,
    banner_type character varying(50) DEFAULT 'home'::character varying,
    display_order integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: hero_banners_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hero_banners_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hero_banners_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hero_banners_id_seq OWNED BY public.hero_banners.id;


--
-- Name: liked_songs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.liked_songs (
    user_id integer NOT NULL,
    song_id integer NOT NULL,
    liked_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: listening_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.listening_history (
    id integer NOT NULL,
    user_id integer,
    song_id integer,
    listened_seconds integer NOT NULL,
    duration_seconds integer NOT NULL,
    was_skipped boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: listening_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.listening_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: listening_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.listening_history_id_seq OWNED BY public.listening_history.id;


--
-- Name: playlist_songs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.playlist_songs (
    playlist_id integer NOT NULL,
    song_id integer NOT NULL,
    added_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    position_order integer
);


--
-- Name: playlists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.playlists (
    id integer NOT NULL,
    user_id integer,
    name character varying(255) NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: playlists_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.playlists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: playlists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.playlists_id_seq OWNED BY public.playlists.id;


--
-- Name: quotes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quotes (
    id integer NOT NULL,
    quote_text text NOT NULL,
    author character varying(255) NOT NULL,
    anime character varying(255),
    quote_type character varying(50) DEFAULT 'normal'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: quotes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quotes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: quotes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quotes_id_seq OWNED BY public.quotes.id;


--
-- Name: song_genres; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.song_genres (
    song_id integer NOT NULL,
    genre_id integer NOT NULL
);


--
-- Name: songs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.songs (
    id integer NOT NULL,
    artist_id integer,
    anime_id integer,
    duration_seconds integer,
    lyrics text,
    file_path text NOT NULL,
    title text,
    song_type character varying(20),
    cover_path character varying(500),
    season integer DEFAULT 1
);


--
-- Name: songs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.songs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: songs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.songs_id_seq OWNED BY public.songs.id;


--
-- Name: user_recommendations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_recommendations (
    id integer NOT NULL,
    user_id integer,
    song_id integer,
    affinity_score integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: user_recommendations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_recommendations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_recommendations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_recommendations_id_seq OWNED BY public.user_recommendations.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    first_name character varying(100),
    last_name character varying(100) DEFAULT NULL::character varying,
    username character varying(100) NOT NULL,
    email character varying(150) NOT NULL,
    password_hash character varying(80) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    user_image text,
    banner_image text,
    role character varying(20) DEFAULT 'user'::character varying
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: animes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.animes ALTER COLUMN id SET DEFAULT nextval('public.albums_id_seq'::regclass);


--
-- Name: artists id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artists ALTER COLUMN id SET DEFAULT nextval('public.artists_id_seq'::regclass);


--
-- Name: genres id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genres ALTER COLUMN id SET DEFAULT nextval('public.genres_id_seq'::regclass);


--
-- Name: hero_banners id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hero_banners ALTER COLUMN id SET DEFAULT nextval('public.hero_banners_id_seq'::regclass);


--
-- Name: listening_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listening_history ALTER COLUMN id SET DEFAULT nextval('public.listening_history_id_seq'::regclass);


--
-- Name: playlists id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playlists ALTER COLUMN id SET DEFAULT nextval('public.playlists_id_seq'::regclass);


--
-- Name: quotes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes ALTER COLUMN id SET DEFAULT nextval('public.quotes_id_seq'::regclass);


--
-- Name: songs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.songs ALTER COLUMN id SET DEFAULT nextval('public.songs_id_seq'::regclass);


--
-- Name: user_recommendations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_recommendations ALTER COLUMN id SET DEFAULT nextval('public.user_recommendations_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: animes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.animes (id, title, artist_id) FROM stdin;
1	5 Centimeters Per Second	1
2	A Silent Voice	2
4	A Whisker Away	4
6	Accel World	6
1308	none	1308
11	After the Rain	11
13	Ah! My Goddess	13
18	Aho-Girl	18
20	Air	20
22	Akame ga Kill	22
26	Amagi Brilliant Park	26
27	Angel Beats	27
30	Anohana	30
34	Another	34
36	Ao Haru Ride	36
39	Ao-chan Can't Study	39
41	Arakawa Under the Bridge	41
46	Arifureta: From Commonplace to World's Strongest	46
50	Asobi Asobase	50
52	Assassination Classroom	52
57	Astra Lost in Space	57
59	Baka and Test - Summon the Beasts -	59
66	Monogatari	66
71	Barakamon	71
73	Beautiful Bones -Sakurako's Investigation-	73
75	Ben-To	75
77	Big Fish & Begonia	77
79	Black Bullet	79
82	Bloom Into You   	82
83	Bloom Into You	82
85	Boarding School Juliet	85
92	Cautious Hero	57
93	Chrome Shelled Regios	93
94	Code Geass	94
95	Couple of Cuckoos	95
131	Clannad	20
136	Classroom of the Elite	136
97	Bocchi the Rock!	97
102	Bofuri	102
104	Boku ga Aishita Subete no Kimi e	104
105	Btooom!	8
107	Btooom! 	106
108	Bungaku Shoujo	108
109	Bunny Girl Senpai	109
112	Cells at Work	112
118	Charlotte	27
122	Children Who Chase Lost Voices	122
123	Chobits	123
129	Citrus	129
154	Combatants will be Dispatched	154
159	Daily Lives of High School Boys	159
162	Danmachi	162
169	Dareka no Manazashi	169
96	Darker than Black	96
310	Garakawa Restore the World	310
311	Gate	311
1299	Tokyo Ghoul_c	1299
175	Darling In The FranXX	175
182	Darwin's Game	182
184	Date A Live	184
314	Genshiken	314
197	Deadman Wonderland	197
199	Deaimon: Recipe for Happiness	199
202	DearS	202
204	Death Note	204
207	Death Parade	207
208	Demon Slayer	208
215	Devil is a Part Timer	130
219	Domestic Girlfriend	219
222	Doraemon	222
223	Dororo	223
227	Dr. Stone	227
233	Dusk Maiden of Amnesia	233
234	Dusk Maiden of Amnesia  	234
266	Fate	266
241	ef ~ A Tale of Memories	241
318	Ghost Hound	318
245	86	245
251	Electromagnetic Girlfriend	251
252	Elfen Lied	252
254	Engaged to the Unidentified	254
256	Erased	256
258	Ergo Proxy	258
260	Eromanga Sensei	260
263	Even If the World Ends Tomorrow	263
265	Expelled from Paradise	265
320	Goblin Slayer	320
344	Haganai	344
295	Full Metal Panic!	295
289	Fire Force	104
293	Fireworks	293
294	Flavors of Youth	294
300	Fullmetal Alchemist Brotherhood	300
325	God Eater	325
326	Golden Boy	326
327	Golden Time	70
330	Gosick	330
333	Grand Blue	333
346	Haibane Renmei	346
335	Grimgar of Fantasy and Ash	335
338	Ground Control to Psychoelectric Girl	41
339	Guilty Crown	339
348	Hal	348
349	Hanasaku Iroha	349
357	Handyman Saitou	357
354	Hanasaku Iroha 	130
359	Happy Sugar Life	359
361	The Melancholy of Haruhi Suzumiya	361
363	Heaven's Lost Property	185
365	Hello World	365
367	Hensuki	129
369	Her Blue Sky	263
372	Higehiro	372
235	Eden of the East	235
508	Le Portrait de petit Cosette	344
385	Higurashi	385
396	Hinamatsuri	396
400	Hitsugi no Chaika	185
402	Hitsugi no Chaika  	185
403	Horimiya	403
405	Howl's Moving Castle	405
406	Hyouka	406
410	I can't understand what my Husband is saying  	410
411	I can't understand what my Husband is saying	411
412	I Want To Eat Your Pancreas	158
510	Life Lessons with Uramichi Oniian	510
448	Mushoku Tensei	447
418	If it's for My Daughter, I'd Even Defeat a Demon Lord	418
420	In this Corner of the World 	420
421	In this Corner of the World	420
422	Infinite Dendrogram	422
424	Inou Battle	424
426	Into The Forest of Fireflies	426
427	Inu x Boku Secret Service	427
433	Invaders of the Rokujoma!?	433
435	Irozuku Sekai no Ashita Kara	435
437	Isekai Quartet	437
443	Isshuukan Friends	443
445	I've Always Liked You	445
447	Mushoku Tensei 	447
512	Fantasy Bishoujo	512
453	Josee, the Tiger and the Fish	224
455	Joshikausei	455
456	Just Because	456
458	Kabaneri of the Iron Fortress	458
463	Kaginado	20
464	Kaguya sama: Love is War	464
470	Kakushigoto	470
472	Kanojo mo Kanojo	472
474	Kaze no Stigma	474
478	Kids on the Slope	222
480	Kimi wo Aishita Hitori no Boku e	480
483	Knight's & Magic	368
484	Love and Lies	484
486	Kokkoku	486
514	Link Click	514
488	Kokoro Connect	488
495	Komi Can't Communicate	48
500	Konosuba	500
505	Land of the Lustrous	447
528	Looking Up at the Half-Moon	528
530	Lord Marksman and Vanadis	530
516	Little Busters!	516
523	Log Horizon	523
532	Love Chunibyou and Other Delusions	532
539	Lovely Complex	539
543	Maid Sama	543
546	Maison Ikkoku	546
556	Maquia	556
557	March comes in like a Lion	557
566	Masamune Kun no Revenge	408
568	Mashiroiro Symphony	568
571	Midori Days	571
573	Mirai Nikki	573
572	Mirai	572
580	Miss Kobayashi's Dragon Maid	580
584	Hitsugi no Chaika 	401
414	ID: Invaded	414
595	Mob Psycho 100	595
602	Monster Girl Doctor	602
604	Monthly Girls' Nozaki Kun	604
606	Mushishi	606
608	My Bride is a Mermaid	608
610	My Dressup Darling	610
612	My Little Monster	612
614	My Neighbor Totoro	614
615	My Next Life as a Villainess	615
621	My Senpai is Annoying	70
627	Naruto	627
723	Nisekoi	723
708	Nichijou	708
740	No Game No Life	740
743	Nodame Cantabile	743
746	Non Non Biyori	746
753	Noragami	639
757	Now and Then, Here and There	757
759	Odd Taxi	759
762	Okusama wa Joshikousei	762
763	Omamori Himari	763
766	One Punch Man	766
771	Onipan!	771
773	Orange	773
775	Ore Monogatari	775
777	Oregairu	777
623	Nagi no Asukara	79
904	Re:Zero	111
794	Oreimo	794
826	Oreshura	826
919	Rising of The Shield Hero	919
828	Overlord	111
836	Paprika	836
837	Parasyte	837
838	Patema Inverted	838
839	Peach Boy Riverside	839
841	Perfect Blue	841
843	Plastic Memories	843
846	Police in a Pod	58
925	Robotic;Notes	925
848	Princess Connect! Re:Dive	848
852	Prison School	852
854	Problem Children Are Coming From Another World, Aren't They?	185
856	Quintessential Quintuplets	856
862	Real Girl	862
866	Rec	866
868	Record of Ragnarok	868
869	Redo of Healer	603
871	Relife	871
886	Remake Our Life!	886
888	Rent A Girlfriend	464
893	Rewrite	591
899	Re:CREATORS	182
950	Say I Love You	43
928	Rosario+Vampire	928
932	Sabikui Bisco	932
934	Saga of Tanya the Evil	934
938	Sankarea	130
953	Sayonara Zetsubou Sensei	953
956	School Rumble	956
962	Scum's Wish	256
964	Seirei Gensouki	964
966	Senryu Girl	966
968	Seraph of the End	245
972	Serial Experiments Lain	972
974	Shadows House	359
976	Shichisei no Subaru	433
977	Shigofumi	977
979	Shiki	979
983	Shimoneta	18
985	Shirobako	985
992	Silver Spoon	307
995	Sing Yesterday for Me	995
998	Skeleton Knight in Another World	373
1000	Somali and the Forest Spirit	1000
1002	Spice and Wolf	1002
1006	Spirited Away	1006
1007	Spy x Family	1007
1009	Steins Gate	926
1016	Record of Ragnarok 	206
1019	Ride Your Wave	1019
1119	The Garden of Sinners 	279
939	Sword Art Online	28
1032	Summer Wars	572
1033	Sweetness and Lightning	562
1125	The Garden of Words	222
1049	Tada Never Falls In Love	1049
1050	Taishou Otome Otogibanashi	1050
1052	takt op.Destiny	881
1126	The Girl from the Other Side	1126
1127	The Girl Who Leapt Through Time	1127
1054	Tamako Market	1054
1059	Tanaka Kun is always Listless	571
1128	The Idaten Deities Know Only Peace	1128
1130	The Kawai Complex	581
1067	Takagi San 	1061
1137	The Misfit of Demon King Academy	1137
1139	The Night is Short, Walk on Girl	226
1140	The Petgirl of Sakurasou	234
1146	The Place Promises in Our Early Days	1146
1147	The Promised Neverland	1147
1116	The Garden of Sinners	279
1061	Takagi San	1061
1085	Terror in Resonance	11
1087	Texhnolyze	1087
1090	The Ambition of Oda Nobuna	1090
1092	The Ancient Magus' Bride	1092
1096	The Anthem of the Heart	1096
1097	The Boy and the Beast	1097
1098	The Day I Become a God	1098
1103	The Duke of Death and His Maid	1103
1105	The Dungeon of Black Company	1105
1107	The Familiar of Zero	1107
1150	The Royal Tutor	1150
1114	The Fruit of Grisaia	1114
1115	The Fruit of Grisaia 	1018
1152	The Ryuo's Work is Never Done!	496
1154	The Secret World of Arrietty	1154
1156	The Vampire Dies in No Time	1156
1158	The Way of the Househusband	1158
1160	The Wind Rises	1160
1161	The World God Only Knows	1161
1166	The World's Finest Assassin	1166
1168	The "Hentai" Prince and the Stony Cat	1168
1170	Time of Eve	279
1171	To Love Ru	1171
1173	Toilet Bound Hanako Kun	1173
1175	Tokyo Ghoul	1175
1183	Tokyo Magnitude 8.0	1183
1185	Tokyo Ravens	619
1189	Tonikaku Kawaii	1189
1191	Toradora	70
1195	Tower of God	1195
1203	The Familiar of Zero 	1109
1208	Tokyo Godfathers	1208
1209	Tsugu Tsugumomo	1209
1211	Wandering Son	690
1212	Words Bubble up like a Soda Pop	1212
1213	Yamada Kun and the Seven Witches	1213
1220	Tsuki ga Kirei	1220
1223	Tsukimichi Moonlit Fantasy 	1223
1224	Tsukimichi Moonlit Fantasy	1224
1226	Usagi Drop	1226
1228	Utawarerumono	1228
1210	Violet Evergarden	1102
1240	Vivy: Fluorite Eye's Song	1240
1247	Voices of a Distant Star	1247
1249	Watamote	1249
1254	Weathering with you	1254
1257	Welcome to the NHK	1257
1260	When Marnie Was There	1260
1261	Whisper of the Heart	1261
1262	Why the hell are you here, Teacher!?	1262
1264	Wise Man's Grandchild	1264
1266	Wolf Children	1266
1268	WorldEnd	74
1273	Wotakoi: Love is hard for Otaku	464
1276	Ya Boy Kongming!	1276
1281	Yona of the Dawn	1281
1284	Your Lie in April	1284
1288	Your Name	1254
1293	Yuru Camp	845
1310	Ex	1310
619	My Roommate is a Cat	619
\.


--
-- Data for Name: artists; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.artists (id, name) FROM stdin;
1	Masayoshi Yamazaki
2	Aiko
3	The Who
4	Yorushika
6	KOTOKO
7	Sachiko Misawa
9	ALTIMA
10	KOTOKO x ALTIMA
13	Yoko Takahashi
149	Yuutarou Yamashita
158	Sumika
22	Miku Sawai
23	Sora Amamiya
25	Rika Mayama
26	BRILLIANT4
150	Orange Range
30	ZONE
32	Remedios
14	Yoko Ishida
34	Annabel
35	Ali Project
36	Fujifabric 
79	Nagi Yanagi
38	Chelsy
40	EDOGA-SULLIVAN
42	Maria (Miyuki Sawashiro)
44	Etsuka Yakushimaru
45	Cho
46	DracoVirgo
47	Void_Chords feat.Lio
49	MindaRyn
50	Hanako, Olivia and Kasumi
51	Hanako, Olivia, and Kasumi
53	Moumoon
54	Shiota Nagisa, Karma Akabane, Kaede Kayano, Yuuma Isogai and Maehara Hiroto
55	Shiota Nagisa,\nKarma Akabane,\nKaede Kayano,\nYuuma Isogai,\nMaehara Hiroto
52	Shion Miyawaki
60	Hitomi Harada, Kaori MIzuhashi, Emiri Katou, and Tomomi Isamura
61	Natsuko Asou
145	FLOW
59	milktub
65	Larval Stage Planning
67	Chiwa Saito
68	Emiri Katou
73	TECHNOBOYS PULCRAFT GREEN-FUND
76	Shaga (Emiri Katou)
77	Xu Jiaying
78	Zhou Shen
31	Galileo Galilei
82	Yuu Koito and Touko Nanami
154	Alice, Snow, Rose and Grim
85	Riho Iida
57	Riko Azuna
87	AKINO
43	Suneohair
89	All Students
90	Miyuki Sawashiro
139	ALI PROJECT
20	Lia
93	Chrome Shelled feat. Leerin ( Takahashi Mikako)
94	Leo Ireiri
155	Miko Itou
157	Kiyoe Yoshioka
97	Kessoku Band
102	Rico Sasaki
103	Junjou no Afilia
28	LiSA
106	Nano
109	Mai Sakurajima, Tomoe Koga, Rio Futaba, Nodoka Toyohama, Kaede Azusagawa and Shoko Makinohara
113	RBC, WBC, Killer T Cell & Macrophage
69	Kana Hanazawa
115	RBC (Kana Hanazawa) & WBC (Tomoaki Maeno)
116	POLYSICS
120	Anri Kumaki
119	Yusa Nishimori (Maaya Uchida)
122	Anri Kumaki 
123	Rie Tanaka
125	Rie Tanaka and Tomokazu Sugita
127	Chrome Shelled
128	Daisy x Daisy
159	ENA
160	Amesaki Annainin
133	Chata
48	FantasticYouth
108	eufonius
138	TK from Ling Toshite Sigure
140	SunSet Swish
141	Hitomi
202	PoppinS
144	UNIONE
181	Mika Nakashima  x  Hyde
147	Jinn
148	Access
161	Mix Speaker's,Inc
162	Kanon Wakeshima
163	Liliruca (Maaya Uchida)
165	sora tob sakana
164	Yuka Iguchi
169	Kazusa
171	HIGH and MIGHTY COLOR
70	Yui Horie
173	An Cafe
174	STEREOPONY
183	ASCA
184	Kayako Tsumita, Risako Murai, and Midori Tsukimiya
191	Erii Yamazaki
175	XX:me
129	Mia REGINA
189	Miku Izayoi
188	sweet ARMS
194	Miyu Tomita
195	Luiza
196	RinamooN
197	NIRGILIS
198	DWB feat.fade
199	ayaho x Junichi Soga
200	Nagomu (Nobunaga Shimazaki)
11	Aimer
204	Nightmare
207	BRADIO
208	FictionJunction feat. LiSA
206	Maximum the Hormone
209	Mewsic (Cover)
213	Go Shiina ft. Nami Nakagawa
156	Sangatsu no Phantasia
218	Minami Kuribayashi 
112	ClariS
16	Jyukai
104	Keina Suda
39	Spira Spica
203	UNDER17
41	Etsuko Yakushimaru
66	supercell
110	The Peggies
72	SUPER BEAVER
71	NoisyCell
58	nonoc
210	Unknown Artist
185	Iori Nomizu
137	ZAQ
167	Sajou No Hana
74	TRUE
19	angela
81	fripSide
170	Rie Fu
111	MYTH & ROID
27	Aoi Tada
182	Mashiro Ayano
130	nano.RIPE
75	Aimi
95	Eir Aoi
8	May'n
126	ROUND TABLE feat. Nino
18	Sumire Uesaka
219	Alisa Takigawa
136	Minami
223	amazarashi 
225	Ziyoou Vachi 
227	Rude-α
228	YouthK Saeki
229	BURNOUT SYNDROMES
230	PELICAN FANCLUB
231	Hatena
233	Aki Okui
236	school food punishment 
399	Rie Murakawa
238	LEAH
239	Oasis
240	Saori Hayami
241	Hiroko Taguchi
243	Main girls cast
242	ELISA
247	hitorie
249	Regal Lily
251	Tenohira
252	Chieko Kawabe
253	Kumiko  Noma
254	Mikakuning!
255	Mikakuning
365	OKAMOTO'S
258	Radiohead
259	MONORAL
260	TrySail
261	Fujita Akane
403	Friends
265	ELISA connect EFP
142	Maaya Sakamoto
270	 Maaya Sakamoto
404	You Kamiyama
273	Tainaka Sachi
405	Chieko Baisho
406	Satomi Satou & Ai Kayano
407	Eru Chitanda and Mayaka Ibara
290	Lenny code fiction
291	Mrs.GREEN
292	coldrain feat. Ryo
293	DAOKO x Kenshi Yonezu
294	Vickeblanka
409	Saori Kodama
298	Tamaru Yamada
301	Miho Fukuhara 
302	Lil'B
303	Scandal
304	Shoko Nakagawa
305	YUI 
300	Sid
310	THREE
311	Rory (Risa Taneda), Tuka (Hisako Kanemoto), Lelei (Nao Touyama)
410	Yukari Tamura, Rie Kugimiya, Ryoko Shintani
316	manzo
318	Yucca
319	Masuda Toshio
320	Soraru
411	Kaoru and Hajime
321	Mili
325	GHOST ORACLE DRIVE
326	Golden Girls, Hiroyuki Kitakubo, Saito Kanji and Tadamisu Hiro
329	Yui Horie 
330	Lisa Komine
331	Lisa Komine 
332	Yoshiko Lisa
333	Izu no Kaze
334	Shounen no Kaze
335	(K)NoW_NAME
222	Motohiro Hata
339	EGOIST
345	Tomodachi Tsukuritai
346	 Masumi Itou
347	Heart of Air
348	Yoko Hikasa
349	Sphere
353	Clammbon
357	Teary Planet
358	konoco
433	petit milady
361	Haruhi Suzumiya
364	Blue Drops
366	Nulbarich
417	Sou
263	Aimyon
371	Masaru Yokoyama 
372	Kaori Ishihara
375	Masaki Suda
235	school food punishment
377	Rumika
266	milet
250	amazarashi
295	Mikuni Shimokawa
312	Kishida Kyoudan & The Akeboshi Rockets
382	OLDCODEX
383	Erio (Asuka Oogame)
418	Latina (Kanon Takao)
419	Dale (Nobuhiko Okamoto)
388	anNina
267	UNISON SQUARE GARDEN
389	Eiko Shimamiya
359	ReoNa
396	Yoshiki Nakajima
398	Mao (Ozawa Ari)
420	Kotringo
422	Aya Uchida
423	Aoi Yuuki 
424	Madoka Kuki and Mirei Kudō
425	Qverktett
426	Shizuru Ootaka
427	Miketsukami (Yuichi Nakamura)
428	Ririchiyo (Rina Hidaka)
429	Watanuki (Mamoru Miyano)
430	Kagerou (Tomokazu Sugita)
431	Roromiya (Kana Hanazawa)
432	Renshou (Yoshimasa Hosaya) and Nobara (Youko Hikasa)
434	Heart♡Invader
436	Haruka to Miyuki 
437	Emilia, Aqua, Albedo & Tanya 
440	Shalltear, Megumin, Rem, and Viktoriya
439	Ainz, Kazuma, Subaru, and Tanya
443	Fujimiya (Sora Amamiya)
444	Natsumi Kon
445	Honeyworks meets Sphere
344	Marina Inoue
224	Eve
454	Evan Call
455	amatsuuni
456	Mio, Hatsuki, and Ena
458	Aimer with chelly
245	SawanoHiroyuki
466	Haruka Fukuhara
467	Airi Suzuki
314	Saori Atsumi
306	NICO Touches the Walls
465	Masayuki Suzuki
234	Konomi Suzuki
401	coffin princess
408	ChouCho
414	Miyavi
226	ASIAN KUNG-FU GENERATION
232	Fujifabric
256	Sayuri
307	Sukima Switch
435	Nagi Yanagi 
308	CHEMISTRY
286	Luna Haruna
464	Halca
373	DIALOGUE+
279	Kalafina
387	Asaka
385	Ayane
362	Aya Hirano
447	Yuiko Oohara
468	Miyuki Shirogane (Makoto Furukawa)
470	Eiichi Ootaka
471	flumpool
472	Momo Asakura
473	Necry Talkie
475	Ayumi, Yuka, and Shizuka
476	Sakai Kanako
474	Saori Kiuji
480	Saucy Dog
481	Clementine
482	Clementine & Ainhoa
484	Roys
486	Boku no Lyric no Bouyomi
487	MIYAVI vs. KenKen
633	ORESKABAND
655	DOMINO
492	Masaki Imai
493	Sayuri Horishita
488	Team.Nekokan
497	Kitri
499	Cider Girl
656	Aqua Timez
650	HOME MADE Kazoku
624	Ray
506	Tomoya Kurosawa
507	YURiKA
509	Yuki Kajiura
510	Mamoru Miyano
511	Iketeru Onii san and Uta Onee chan
512	Yoshiki Fukuyama
513	Luce Twinkle Wink☆
514	Fan Ka
515	Bai Sha JAWS
659	TOTALFAT
660	aluto
516	Rita
522	Suzuya
524	MAN WITH A MISSION
523	Yun*chi
526	Miyu Ooshiro
527	BAND-MAID
528	Nobuko
530	Hitomi Harada
661	Hemenway
532	Black Raison d'etre
537	Rikka (Maaya Uchida)
539	Tegomass
540	Hey!Say!7
543	heidi
545	Saaya Mizuno
546	Takao Kisugi
662	UNLIMITS
663	Aisha feat. CHEHON
547	PICASSO
552	Yuki Saito
548	Gilbert O'Sullivan
554	Kiyonori Matsuo
555	Kozo Murashita
556	rionos 
558	Hinata, Akari and Momo
559	Kenshi Yonezu
557	BUMP OF CHICKEN
586	MUCC
563	RUANN
479	YUKI
368	Ayaka Ohashi
568	marble
570	Remix by Miraie
574	Yousei Teikoku
576	Yosei Teikoku
573	Faylan
578	Yousei Teikoku 
562	Brian the Sun
580	Chorogons
582	Tohru (Yuuki Kuwahara)
572	Tatsurou Yamashita
501	Aqua, Megumin, Darkness
593	Anzen Chitai 
595	All Off
596	Mob Choir
602	Aina Suzuki
604	Chiyo (Ari Ozawa)
606	Ally Kerr
607	Lucy Rose
608	SUN&LUNAR
610	Akari Akase
612	9nine
613	Haruka Tomatsu
614	Azumi Inoue
615	Shouta Aoi 
617	Shouta Aoi
622	Igarashi, Sakurai, Kurobe, and Tsukishiro
667	Rake
619	Yoshino Nanjo
627	Hearts Grow
629	Analogfish
630	Amadori
631	CHABA
628	Akeboshi
634	SABOTEN
635	Rythem
637	Raiko
638	Mass Missile
640	GagagaSP
641	No Regret Life
642	Hound Dog
646	Sambomaster
647	Stance Punks
648	Snowkel
651	SEAMO
652	Kishidan
653	AZU
668	Akihisa Kondou
669	Shinkuu Horou
666	DISH
671	SHUN
672	Shiori Tomita
673	Diana Garnet
674	sana
676	KANIKAPILA
677	Thinking Dogs
678	Kuroneko Chelsea
679	Huwie Ishizaki
680	Ayumikurikamaki
681	MATCHY with QUESTION?
682	Swimy
683	surface
685	HALCAL
686	DEV PARADE
687	Nobodyknows+
688	tacica
689	THE CRO-MAGNONS
692	Nogizaka46
693	DOES
694	KANA-BOOM
695	Yamazaru
698	LONG SHOT PARTY
699	Anly
700	Ikimonogakari
706	Marina Kawano
707	Hanekawa (Yui Horie)
712	Yuuko, Mio and Mai
710	Hakase and Mai
715	Nano, Hakase, and Sakamoto
713	Yuuko, Mio, Mai, Nano, Hakase and Sakamoto
720	Sasahara, Misato, Nakanojou, Weboshi and Fecchan
718	Takasaki sensei, Sakurai sensei, Nakamura sensei, Makoto Sakurai, Yuria Sekiguchi, Haruna Annaka and Ogi
708	Sayaka Sasaki
644	little by little
603	ARCANA PROJECT
591	Ayaka Kitazawa
496	Miku Itou
571	CooRie
581	fhana
500	Machico
605	Masayoshi Ooishi
690	Daisuke
485	Frederic
665	7!!
721	Kenichi Maeyamada
722	Hyadain
724	Onodera (Kana Hanazawa)
728	Chitoge, Kosaki, Tsugumi, and Marika
729	Chitoge Kirisaki and Kosaki Onodera
732	Chitoge, Onodera, Tsugumi, and Marika
723	Chitoge (Nao Touyama)
727	Marika (Kana Asumi)
735	Haru Onodera (Ayane Sakura)
726	Ruri (Yumi Uchiyama)
737	Kosaki Onodera (Kana Hanazawa)
740	Shiro (Ai Kayano)
743	Crystal Kay
744	SUEMITSU & THE NODAME ORCHESTRA
745	SUEMITSU & THE SUEMITH
748	 Kotori Koiwai, Rie Murakawa, Ayane Sakura, & Kana Asumi
746	Ayane Sakura, Kana Asumi, Kotori Koiwai, & Rie Murakawa
754	The Oral Cigarettes
639	Tia
756	Hello Sleepwalkers
757	Reiko Yasuhara
758	Toshio Masuda
759	Suzuko Mimori
760	Tony Frank
761	PUNPEE
762	Ayako Kawasumi, Aya Endou, Shiho Kawaragi
763	Himarinko L. Shizukuesu
764	Daisuke Hirakawa
765	Kawada Ruka, Sakamoto Aya
766	Hiroko Moriguchi
769	Makoto Furukawa
768	JAM Project
771	Onipans!
773	Kobukuro
774	Yu Takahashi
775	LOCAL CONNECT
776	TRUSTRICK
777	Yukino and Yui
778	Yukino(Saori Hayami) & Yui(Nao Touyama)
780	Asuka Hinoi
782	Captain Straydum
786	Inoue Joe
787	Yuuko, Mio, and Mai
725	Tsugumi (Mikako Komatsu)
790	Ayako Kawsumi
795	Kanako (Yukari Tamura)
796	Ayana Taketatsu, Kana Hanazawa and Hitomi Nabatame
882	The Brilliant Green
883	PENGUIN RESEARCH
800	Kuroneko and Kyousuke
884	YUI
885	Toshinobu Kubota ft. Naomi Campbell
886	Argonavis
887	Poppin'Party 
807	Saori (Hitomi Nabatame)
12	CHiCO with HoneyWorks
892	MIMiNARI
805	Manami (Satomi Satou)
813	Ayana Taketatsu and Satomi Satou
956	Tenma, Mikoto, Sawachika & Akira
895	Runa Mizutani
900	Aki Toyosaki
804	Ayase (Saori Hayami)
818	Kirino, Kuroneko, and Saori
908	Rem (Inori Minase)
821	Gokou (Yui Ogura)
799	Kuroneko (Kana Hanazawa)
825	Bridget (Misaki Kuno)
826	Yukari Tamura 
827	Chinatsu Akasaki, Yukari Tamura, Hisako Kanemoto, Ai Kayano
829	Masayoshi Oishi x Tom-H@ck
957	Yui Horie with UNSCANDAL
834	 Mayu Maeshima
831	OxT
836	Hirasawa Susume
837	Daichi Miura
838	Michiru Oshima
839	Mitei no Hanashi
840	Q-MHz feat. Yuuko
841	M-Voice
842	Misa, Emiko and Mie
843	Melody Chubak
844	Asami Imai
905	Emilia (Rie Takahashi)
848	Pecorine, Kokkoro and Karyl
852	Kangoku Danshi (group)
857	Nakano-ke no Itsutsugo
916	Mayu Maeshima
856	Quintuplets' VA
863	Quruli
862	BiSH
866	BRACE;d
867	Kanako Sakai
868	SymaG
870	Minami Kuribayashi
871	Tamio Okuda
872	I Wish
874	Whiteberry
875	T.M. Revolution
876	BLACK BISCUITS 
877	L'Arc en Ciel
879	Sentimental Bus
880	Porno Graffiti
958	Kikoukumaru's Man Chorus Group
919	Chiai Fujikawa
921	MADKID
925	fumika
927	HARUKI
960	Ami Koshimizu and Mamiko Noto
959	Ami Tokito
928	Nana Mizuki
932	Bisco and Milo
934	Tanya (Aoi Yuuki)
935	Mako Niina
945	Yuna
952	Ritsuka Okazaki
953	Fuura, Kitsu, Kimura and Hitou
954	Kenji Ohtsuki feat. Nonaka, Marina, Yu, Miyuki & Ryoko
955	Fuura, Kitsu, Kimura, Tarou and Hitou
963	96neko
964	Aguri Oonishi
965	Marika Kouno
966	Rikako Aida
967	Sonoko Inoue
972	Reichi Nakaido
973	BOA
975	Kenichirou Suehiro
977	Snow
979	Nangi
981	Kanon x Kanon
980	Buck-Tick
984	SOX
985	Aoi, Ema, and Shizuka
986	Doughnut Quintet
987	Miyuki Kunitake
988	Mai Nakahara, Shizuku Itou, and Ai Kayano
990	Masami Okui
995	yourness
997	agehasprings feat. TaNaBaTa
941	Tomatsu Haruka
881	Mika Nakashima
933	JUNNA
855	Kaori Sadohara
792	Yui and Yukino
878	PUFFY
993	Goose house
845	Eri Sasaki
999	PelleK
1000	Inori Minase
1001	Naotarou Moriyama
1003	Kiyoura Natsumi
1002	ROCKY CHACK
1005	Akino Arai
1006	Yumi Kimura 
1007	Gen Hoshino
1008	Official HIGE DANdism
1010	Eri Sasaki and Abo Takeshi
926	Zwei
794	Kirino (Ayana Taketatsu)
1014	Fear, and Loathing in Las Vegas
1015	Aya Uchida 
636	ORANGE RANGE
1019	GENERATIONS from EXILE TRIBE
1020	Annabel 
1021	Yuko Ogura
1022	Erii Yamasaki 
1023	Shiina Mayuri and Shiina Kagari
1025	Yui Sakakibara
1171	Mami Kawada
1018	Maon Kurosaki
1188	Gero
1262	All Teachers
1038	Luna Haruna 
1041	Sayaka Kanda (as Yuna)
1048	ASCA and Asuka Okura
1049	Teresa (Manaka Iwami)
1050	Shunichi Toki
1051	GARNiDELiA
1053	ryo (supercell)
1189	KanoeRana
1056	Mamedai (Keiji Fujiwara)
1190	Tsukasa ( Akari Kitou) ft. Yunomi
1054	Tamako (Aya Suzaki)
1060	Unlimited tone
1192	Meromero Saharade (ENG cover)
1193	Yui Horie, Rie Kugimiya and Eri Kitamura
1195	Stray Kids
1024	Kanako Ito
1061	Takagi San (Rie Takahashi)
1202	AIKI & AKINO
1109	ICHIKO
1206	Uverworld
1207	Kanae Ito
1208	Moonriders
1209	Haruka Toujou
1240	Vivy (Kairi Yagi)
1212	Taeko Ohnuki
1213	WEAVER
1215	Rekka Katakiri
1216	Super Chorogons
1218	miwa
1219	AOP
1247	Low
1087	GACKT
1089	Juno Reactor
1090	Makino Mizuta
1092	Hana Itoki
1095	Jessica
1096	Jun Naruse (Inori Minase)
1097	Mr. Children
1098	Jun Maeda x Nagi Yanagi 
1099	Jun Maeda x Nagi Yanagi
1103	Alice (Ayumi Mano)
1104	Bocchan (Natsuki Hanae) & Alice (Ayumi Mano)
1105	Humbreaders
1106	HOWL BE QUIET
1107	Kugimiya Rie
1249	Tomoko (Izumi Kitta)
1110	Rie Kugimiya
1114	Hana
1250	Velvet.kodhy
1122	Kalafina 
1127	Oku Hanako
1128	Akari Nanawo
1129	Tatsuya Kitani
1131	Kawaii, Mayumi and Sayaka
1133	Asahina Mikuru
1132	Aya Hirano, Minori Chihara and Yuko Goto
1137	Tomori Kusonaki
1138	CIVILIAN
1141	Asuka Ookura
1142	Sakurasou Prime Caste
1143	Ai Kayano, Mariko Nakatsu and Natsumi Takamori
1145	Nanami Aoyama (Marika Nakatsu)
1146	Kawashima Ai
1220	Nao Toyama
1149	Takahiro Obata
1150	4 Princes with Teacher
1151	Shougo Sakamoto
1154	Cecile Corbel
1156	TRD
1157	Jun Fukuyama
1158	Uchikubi Gokumon Doukoukai 
1159	Uchikubi Gokumon Doukoukai
1160	Yumi Matsutoya
1161	Ayana Taketatsu
1162	Tomo Sakurai
1163	Nao Touyama
1164	Katsuragi (Hiro Shimono)
1165	Oratorio The World God Only Knows
1167	Yui Ninomiya
1168	Yui Ogura
1169	Yukari Tamura
1173	Akari Kitou 
1174	Jibaku Shounen Band
1175	People In The Box
1177	Ziyoou Vachi
1147	Cö Shu Nie
1176	Toru Kitajima
1181	österreich
1183	Shion Tsuji
96	abingdon boys school
1223	Tomoe (Ayane Sakura) and Mio (Akari Kitou)
1224	Ezoshika Gourmet Club
1225	syudou
1226	Kasarinchu
1228	Eri Kawai
1252	Velvet.kodhy and µ
1253	Konomi Suzuki & Kiba of Akiba
1264	Nanami Yoshi
1229	Suara
1166	Aira Yuuki
1102	Minori Chihara
1241	Estella and Elizabeth
1242	Diva AI
1243	Diva AI (Miya Kotsuki)
1265	i☆Ris
1257	Kenji Ohtsuki and Fumihiko Kitsutaka
1126	Yui Makino
1260	Priscilla Ahn
1261	Youko Honna
1266	Masakatsu Takagi
1267	never young beach
1272	Azusa Tadokoro 
1276	96Neko, Ryoutarou Okiayu, Shouya Chiba, and Lezel
1277	96Neko
1278	QUEENDOM
1034	MimimemeMIMI
1281	vistlip
1282	Akiko Shikata
1283	Cynthia
1284	Wacci
1287	Coalamode
1254	RADWIMPS
1295	TK
1299	TK_c
1308	none
1310	Linda woods 
620	Schrodinger's Cat adding Kotringo
\.


--
-- Data for Name: genres; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.genres (id, name) FROM stdin;
5	Rock
16	Moe
112	Masterclass
2	Normal
1	Soft
3	Vibe
17	Quite Different
\.


--
-- Data for Name: hero_banners; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hero_banners (id, title, subtitle, image_path, target_url, banner_type, display_order, is_active, created_at) FROM stdin;
12		Seek the finest	https://res.cloudinary.com/ddc6silap/image/upload/v1773394301/banners/axslpa4ncuexjairybz0.webp	/genre/Masterclass	home	3	t	2026-03-13 09:31:42.708945
9			https://res.cloudinary.com/ddc6silap/image/upload/v1773347593/banners/m7bwwii8zbhka4xleiiy.webp		home	0	f	2026-03-12 20:33:13.691911
11	Vibing?		https://res.cloudinary.com/ddc6silap/image/upload/v1773348107/banners/tf7cm436yrrfs12wqhzt.webp	/genre/Vibe	home	2	f	2026-03-12 20:41:48.148901
14	Soft	Soft as melody	https://res.cloudinary.com/ddc6silap/image/upload/v1773394565/banners/ksulxwgg20retbptxoul.webp	/genre/Soft	home	5	t	2026-03-13 09:36:05.799075
15	Anime Songs	See songs based by anime	https://res.cloudinary.com/ddc6silap/image/upload/v1773394644/banners/jhxdpfzpg5pzg9ybmngj.webp	/animes	home	6	t	2026-03-13 09:37:25.393817
10	Utter Calm		https://res.cloudinary.com/ddc6silap/image/upload/v1773347903/banners/eoeedr45wx6etgbgf1kx.webp	/genre/Soft	home	1	f	2026-03-12 20:38:24.533299
16	Energize!	Rock the day out	https://res.cloudinary.com/ddc6silap/image/upload/v1773394688/banners/qdd5zufvbds22sehmcn9.webp	/genre/Rock	home	7	t	2026-03-13 09:38:10.297456
\.


--
-- Data for Name: liked_songs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.liked_songs (user_id, song_id, liked_at) FROM stdin;
12	289	2026-03-05 20:36:14.461011
12	4	2026-03-01 19:04:40.180695
12	49	2026-03-01 19:53:43.490755
12	1066	2026-03-02 14:58:08.129106
12	181	2026-03-09 22:51:20.785511
12	205	2026-03-12 22:39:14.828321
16	959	2026-03-13 12:46:09.020571
16	158	2026-03-13 20:57:27.267144
16	95	2026-03-14 23:13:26.335691
16	366	2026-03-21 06:45:40.496977
16	289	2026-03-22 07:12:41.446069
12	844	2026-03-27 13:04:16.434915
16	11	2026-03-29 06:55:56.780415
16	919	2026-03-29 07:25:40.410199
16	109	2026-03-29 17:17:20.325317
\.


--
-- Data for Name: listening_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.listening_history (id, user_id, song_id, listened_seconds, duration_seconds, was_skipped, created_at) FROM stdin;
10	12	6	10	281	t	2026-02-28 10:07:53.811115+00
11	12	7	227	227	f	2026-02-28 10:08:03.666679+00
12	12	8	10	233	t	2026-02-28 10:08:14.103792+00
13	12	9	266	266	f	2026-02-28 10:08:20.522881+00
14	12	43	219	219	f	2026-02-28 10:15:06.827347+00
15	12	48	275	275	f	2026-02-28 10:19:43.00765+00
16	12	66	341	341	f	2026-02-28 10:25:24.746448+00
17	12	6	11	281	t	2026-02-28 10:36:06.403185+00
18	12	42	6	90	t	2026-02-28 10:38:24.64947+00
19	12	172	8	282	t	2026-02-28 11:28:10.633652+00
20	12	173	20	259	t	2026-02-28 11:28:31.583284+00
21	12	183	243	243	f	2026-02-28 11:28:42.030906+00
22	12	300	15	208	t	2026-02-28 12:11:12.802827+00
23	12	509	19	287	t	2026-02-28 12:11:32.663105+00
24	12	185	235	235	f	2026-02-28 17:05:42.230133+00
25	12	6	130	281	t	2026-02-28 17:07:52.976511+00
26	12	2	6	354	t	2026-02-28 17:07:59.414329+00
27	12	589	271	271	f	2026-03-01 13:41:40.067951+00
28	12	4	13	292	t	2026-03-01 14:14:41.490276+00
29	12	8	89	233	t	2026-03-01 14:16:23.414953+00
30	12	9	44	266	t	2026-03-01 14:17:08.614986+00
31	12	1066	236	236	f	2026-03-02 09:31:30.837572+00
32	12	1066	236	236	f	2026-03-02 09:35:27.442806+00
33	12	3	15	198	t	2026-03-02 09:36:13.35996+00
34	12	72	279	279	f	2026-03-02 09:40:53.139141+00
35	12	888	251	251	f	2026-03-02 09:45:11.975159+00
36	12	10	319	319	f	2026-03-02 09:50:31.561636+00
37	12	853	98	98	f	2026-03-02 09:52:10.504057+00
38	12	929	288	288	f	2026-03-02 09:56:59.455797+00
39	12	641	288	288	f	2026-03-02 10:01:48.508063+00
41	12	546	269	269	f	2026-03-02 10:41:45.325103+00
42	12	58	5	250	t	2026-03-02 10:41:51.45088+00
43	12	663	9	307	t	2026-03-02 10:47:08.05264+00
44	12	18	6	288	t	2026-03-02 10:49:40.563613+00
45	12	18	7	247	t	2026-03-02 10:49:51.37536+00
46	12	8	9	233	t	2026-03-02 10:50:15.914975+00
47	12	510	16	245	t	2026-03-02 10:50:40.177708+00
48	12	758	5	201	t	2026-03-02 10:50:46.517843+00
49	12	8	5	233	t	2026-03-02 10:51:02.071683+00
50	12	8	10	233	t	2026-03-02 10:52:02.399551+00
51	12	8	7	233	t	2026-03-02 10:52:15.342421+00
52	12	473	17	194	t	2026-03-02 10:52:39.434929+00
53	12	10	5	319	t	2026-03-02 10:52:50.144214+00
54	12	758	65	201	t	2026-03-02 10:59:42.350455+00
55	12	122	5	300	t	2026-03-02 11:18:39.029969+00
56	12	743	169	242	t	2026-03-02 11:23:52.761401+00
57	12	364	10	258	t	2026-03-02 11:24:09.742604+00
58	12	389	301	301	f	2026-03-02 11:29:15.577854+00
59	12	122	12	300	t	2026-03-02 12:54:28.7593+00
60	12	1176	240	240	f	2026-03-02 13:01:25.349817+00
61	12	6	56	281	t	2026-03-02 13:24:49.91111+00
62	12	852	17	245	t	2026-03-02 13:33:14.462545+00
63	12	256	183	183	f	2026-03-02 14:39:28.962533+00
64	12	389	301	301	f	2026-03-03 08:31:55.3395+00
65	12	122	300	300	f	2026-03-03 08:36:55.538916+00
66	12	395	279	279	f	2026-03-03 08:42:59.651089+00
67	12	213	329	329	f	2026-03-03 13:31:28.063617+00
68	12	258	8	387	t	2026-03-03 15:58:37.388996+00
69	12	977	296	296	f	2026-03-04 08:57:31.674123+00
70	12	389	301	301	f	2026-03-04 08:59:10.034103+00
71	12	40	180	185	t	2026-03-04 09:06:59.414198+00
72	12	776	5	243	t	2026-03-04 09:07:25.873789+00
73	12	289	208	208	f	2026-03-05 10:02:16.372323+00
77	12	330	64	283	t	2026-03-05 15:08:16.693181+00
78	12	266	5	283	t	2026-03-05 15:08:41.052695+00
79	12	375	258	258	f	2026-03-05 15:13:13.958903+00
80	12	908	8	359	t	2026-03-05 15:50:12.074484+00
81	12	392	275	275	f	2026-03-09 13:01:58.979724+00
82	12	18	5	247	t	2026-03-09 13:26:40.107172+00
83	12	122	142	300	t	2026-03-09 13:38:33.934128+00
84	12	1056	180	180	f	2026-03-09 14:52:37.315875+00
85	12	1056	180	180	f	2026-03-10 10:21:10.690467+00
86	12	1221	90	223	t	2026-03-11 09:28:48.94958+00
87	12	705	108	228	t	2026-03-11 11:40:03.945002+00
88	12	705	25	228	t	2026-03-11 22:42:48.965007+00
89	12	270	38	283	t	2026-03-12 10:09:20.486213+00
90	12	1071	269	269	f	2026-03-12 10:14:03.699548+00
93	12	66	224	341	t	2026-03-12 11:23:46.752919+00
94	12	67	275	275	f	2026-03-12 11:28:24.645318+00
95	12	181	9	249	t	2026-03-12 22:36:54.364855+00
96	12	146	110	218	t	2026-03-12 22:40:29.825939+00
97	12	601	188	188	f	2026-03-13 09:44:35.714903+00
98	12	199	205	226	t	2026-03-13 09:48:06.072309+00
99	12	571	16	250	t	2026-03-13 09:48:27.631015+00
100	12	1235	255	262	t	2026-03-13 09:54:08.178973+00
101	16	758	201	201	f	2026-03-13 12:26:27.360269+00
102	16	268	250	250	f	2026-03-13 12:41:22.1456+00
103	16	845	258	258	f	2026-03-13 12:44:29.735015+00
104	16	573	269	269	f	2026-03-13 12:45:40.604504+00
105	12	687	276	276	f	2026-03-13 12:53:55.465229+00
106	12	146	224	224	f	2026-03-13 12:57:13.672435+00
107	16	949	273	273	f	2026-03-13 15:49:21.105705+00
108	16	95	118	246	t	2026-03-13 15:51:23.271562+00
109	12	601	188	188	f	2026-03-13 16:55:01.624666+00
110	16	371	65	65	f	2026-03-13 20:17:38.142736+00
111	16	919	311	311	f	2026-03-13 20:27:59.829597+00
112	16	920	374	374	f	2026-03-13 20:34:18.570598+00
113	16	756	170	180	t	2026-03-13 20:37:54.173804+00
114	16	601	188	188	f	2026-03-13 20:47:56.897179+00
115	16	1044	250	250	f	2026-03-13 20:52:27.154062+00
116	16	158	8	193	t	2026-03-13 21:06:09.102941+00
117	12	1139	15	259	t	2026-03-13 21:19:53.967149+00
118	16	500	265	265	f	2026-03-14 18:22:32.881827+00
119	16	501	196	196	f	2026-03-14 18:25:51.749149+00
120	16	502	242	242	f	2026-03-14 18:29:58.888031+00
121	16	503	200	200	f	2026-03-14 18:33:23.254262+00
122	16	504	215	273	t	2026-03-14 18:36:59.447515+00
123	16	570	140	140	f	2026-03-14 18:39:22.472577+00
124	16	590	196	196	f	2026-03-14 18:42:41.830713+00
125	16	500	265	265	f	2026-03-14 18:47:07.594943+00
126	16	501	196	196	f	2026-03-14 18:50:24.91916+00
127	16	69	258	258	f	2026-03-14 18:55:40.016848+00
128	16	79	261	261	f	2026-03-14 19:00:03.787838+00
129	16	86	225	225	f	2026-03-14 19:03:53.455019+00
130	16	104	213	213	f	2026-03-14 19:07:45.795018+00
131	16	109	236	236	f	2026-03-14 19:13:20.60913+00
132	16	116	175	175	f	2026-03-14 19:16:35.609961+00
133	16	119	260	260	f	2026-03-14 19:21:07.692138+00
134	16	121	330	330	f	2026-03-14 19:26:41.784092+00
135	16	123	247	247	f	2026-03-14 19:30:51.344914+00
136	16	124	244	244	f	2026-03-14 19:34:59.262126+00
137	16	138	301	301	f	2026-03-14 19:40:03.468704+00
138	16	140	271	271	f	2026-03-14 19:44:38.492277+00
139	16	12	66	237	t	2026-03-14 19:45:44.896662+00
140	16	13	191	191	f	2026-03-14 19:48:58.819479+00
141	16	40	185	185	f	2026-03-14 19:52:07.50839+00
142	16	41	190	190	f	2026-03-14 19:55:20.578678+00
143	16	1294	9	266	t	2026-03-14 22:57:48.593722+00
144	16	66	215	341	t	2026-03-14 23:05:20.219017+00
145	12	1139	20	259	t	2026-03-14 23:39:52.671396+00
146	16	607	61	217	t	2026-03-15 06:39:21.135809+00
147	16	295	35	255	t	2026-03-15 06:40:14.686752+00
148	16	1002	136	290	t	2026-03-15 06:42:37.011218+00
149	16	286	8	270	t	2026-03-15 06:42:49.682985+00
150	16	122	38	300	t	2026-03-15 06:43:52.99259+00
151	16	503	200	200	f	2026-03-15 07:56:28.776153+00
152	16	119	126	260	t	2026-03-15 07:59:48.475459+00
153	14	892	10	204	t	2026-03-15 11:41:41.067066+00
154	14	62	14	232	t	2026-03-15 11:42:01.727079+00
155	16	1139	259	259	f	2026-03-15 11:44:32.871057+00
156	16	1139	24	259	t	2026-03-15 11:44:56.384999+00
157	16	930	6	266	t	2026-03-15 11:45:48.292454+00
158	16	883	236	236	f	2026-03-15 11:49:51.877159+00
159	16	1175	238	238	f	2026-03-15 11:55:31.244074+00
160	12	25	293	293	f	2026-03-15 11:58:04.649998+00
161	16	730	272	272	f	2026-03-15 12:00:05.533993+00
162	12	1235	265	265	f	2026-03-15 12:02:51.656056+00
163	12	601	188	188	f	2026-03-15 12:10:24.916949+00
164	12	146	224	224	f	2026-03-15 12:15:47.737557+00
165	16	1175	237	237	f	2026-03-16 07:10:57.786794+00
166	16	632	311	311	f	2026-03-16 07:16:31.672378+00
167	16	646	12	286	t	2026-03-16 07:16:46.216299+00
168	16	639	74	318	t	2026-03-16 07:18:03.967231+00
169	16	643	17	246	t	2026-03-16 07:18:10.732629+00
170	16	642	292	292	f	2026-03-16 07:23:06.250463+00
171	16	634	198	198	f	2026-03-16 07:26:26.31006+00
172	16	637	285	285	f	2026-03-16 07:31:14.422964+00
173	16	638	281	281	f	2026-03-16 07:35:58.714224+00
174	16	644	240	240	f	2026-03-16 07:40:02.258318+00
175	16	635	175	249	t	2026-03-16 07:43:00.484293+00
176	16	641	288	288	f	2026-03-16 07:47:51.270879+00
177	16	636	69	211	t	2026-03-16 07:48:02.617196+00
178	16	628	220	220	f	2026-03-16 07:51:46.107782+00
179	16	631	293	293	f	2026-03-16 07:56:44.468863+00
180	16	123	243	247	t	2026-03-16 08:44:44.423291+00
181	12	421	289	289	f	2026-03-16 12:27:13.83213+00
182	12	466	272	272	f	2026-03-16 12:31:08.80856+00
183	12	482	362	362	f	2026-03-16 12:32:02.408095+00
184	12	109	236	236	f	2026-03-16 12:35:08.637499+00
185	12	441	89	89	f	2026-03-16 12:37:50.676372+00
186	12	551	272	272	f	2026-03-16 12:39:43.756913+00
187	12	213	329	329	f	2026-03-16 12:45:15.688091+00
188	12	844	274	274	f	2026-03-16 12:49:52.994747+00
189	12	121	330	330	f	2026-03-16 12:55:28.268287+00
190	12	294	219	219	f	2026-03-16 12:59:09.804886+00
191	12	950	313	313	f	2026-03-16 13:04:26.644192+00
192	12	843	174	174	f	2026-03-16 13:07:25.134186+00
193	12	51	274	274	f	2026-03-16 13:12:03.290764+00
194	12	163	342	350	t	2026-03-16 13:17:48.353749+00
195	12	253	266	341	t	2026-03-16 13:27:13.00102+00
196	12	508	212	289	t	2026-03-16 13:30:48.103275+00
197	12	1300	159	159	f	2026-03-17 10:15:07.045426+00
198	12	1300	159	159	f	2026-03-17 10:17:46.11618+00
199	12	373	266	266	f	2026-03-17 10:23:12.111506+00
200	12	740	109	277	t	2026-03-17 10:24:05.797266+00
201	12	337	234	234	f	2026-03-17 10:28:04.662411+00
202	12	1086	307	307	f	2026-03-17 10:33:18.031066+00
203	12	742	292	292	f	2026-03-17 10:38:13.147886+00
204	12	353	261	261	f	2026-03-17 10:42:38.023177+00
205	12	800	90	90	f	2026-03-17 10:44:12.189418+00
206	12	875	221	221	f	2026-03-17 10:48:20.466474+00
207	12	1104	237	237	f	2026-03-17 10:52:22.408884+00
208	12	809	258	258	f	2026-03-17 10:56:44.297271+00
209	12	1134	253	253	f	2026-03-17 11:01:01.121298+00
210	12	598	139	200	t	2026-03-17 11:03:27.136071+00
211	12	243	53	289	t	2026-03-17 11:03:32.846328+00
212	12	1105	239	239	f	2026-03-17 11:07:42.223255+00
213	12	1008	211	211	f	2026-03-17 11:11:16.495672+00
214	12	93	266	266	f	2026-03-17 11:15:47.42444+00
215	12	279	297	297	f	2026-03-17 11:20:48.803555+00
216	12	486	178	246	t	2026-03-17 11:23:49.382381+00
217	12	425	254	254	f	2026-03-17 11:31:48.709093+00
218	12	957	222	222	f	2026-03-17 11:35:34.138604+00
219	12	992	229	240	t	2026-03-17 11:39:27.906863+00
220	12	445	14	330	t	2026-03-17 11:39:44.57911+00
221	16	1081	166	166	f	2026-03-17 15:31:57.750485+00
222	16	1078	44	260	t	2026-03-17 15:32:45.971658+00
223	16	1072	30	358	t	2026-03-17 15:33:23.944886+00
224	16	1078	224	260	t	2026-03-17 15:34:51.011979+00
225	16	1072	209	358	t	2026-03-17 15:37:46.827427+00
226	16	1074	196	196	f	2026-03-17 15:41:10.540962+00
227	16	1079	308	308	f	2026-03-17 15:46:32.547694+00
228	16	1062	312	312	f	2026-03-17 15:59:38.221576+00
229	16	520	396	396	f	2026-03-18 08:19:19.020594+00
230	16	405	260	260	f	2026-03-18 08:23:42.881619+00
231	16	718	89	89	f	2026-03-18 08:25:16.982219+00
232	16	1210	283	283	f	2026-03-18 08:30:04.978839+00
233	16	1000	281	281	f	2026-03-18 08:34:48.439625+00
234	16	214	276	276	f	2026-03-18 08:39:28.222575+00
235	16	220	252	252	f	2026-03-18 08:43:43.37977+00
236	16	118	315	315	f	2026-03-18 08:49:03.918498+00
237	16	133	294	294	f	2026-03-18 08:54:00.330979+00
238	16	950	313	313	f	2026-03-18 08:59:16.780478+00
239	16	1119	311	311	f	2026-03-18 09:04:32.22457+00
240	16	1291	408	408	f	2026-03-18 09:11:24.09395+00
241	16	780	300	300	f	2026-03-18 09:16:27.102841+00
242	16	1256	258	258	f	2026-03-18 09:20:49.773238+00
243	16	1118	383	383	f	2026-03-18 09:27:15.948864+00
244	16	1050	268	268	f	2026-03-18 09:31:47.746615+00
245	16	967	267	267	f	2026-03-18 09:36:19.296314+00
246	16	201	238	238	f	2026-03-18 09:40:20.085292+00
247	16	519	314	314	f	2026-03-18 09:45:38.232516+00
248	16	388	251	251	f	2026-03-18 09:49:52.58894+00
249	16	360	287	287	f	2026-03-18 09:54:42.940731+00
250	16	1284	283	283	f	2026-03-18 09:59:29.321118+00
251	16	1025	305	305	f	2026-03-18 10:04:38.0815+00
252	16	1044	250	250	f	2026-03-18 10:08:53.002882+00
253	16	1232	154	294	t	2026-03-18 10:12:42.787415+00
254	16	1005	66	291	t	2026-03-18 10:12:54.432076+00
255	16	909	129	241	t	2026-03-18 10:14:06.549593+00
256	16	1170	358	358	f	2026-03-18 10:20:07.185816+00
257	16	1237	89	234	t	2026-03-18 10:21:42.525132+00
258	16	1090	5	273	t	2026-03-18 10:22:00.017424+00
259	16	606	6	189	t	2026-03-18 10:22:18.382721+00
260	16	266	241	241	f	2026-03-18 10:26:38.904308+00
261	16	378	223	223	f	2026-03-18 10:30:29.094678+00
262	16	1175	218	238	t	2026-03-18 10:52:29.326308+00
263	16	1256	258	258	f	2026-03-18 15:04:06.349291+00
264	16	973	205	205	f	2026-03-18 15:08:16.589426+00
265	16	256	183	183	f	2026-03-18 15:11:58.890662+00
266	16	257	119	119	f	2026-03-18 15:14:04.152591+00
267	16	223	272	272	f	2026-03-18 15:19:11.762765+00
268	16	223	272	272	f	2026-03-18 15:26:54.595458+00
269	16	396	297	297	f	2026-03-18 15:33:29.864667+00
270	16	176	6	225	t	2026-03-18 15:34:35.61753+00
271	16	601	188	188	f	2026-03-18 15:43:19.282954+00
272	16	755	294	294	f	2026-03-18 15:48:48.401299+00
273	16	570	140	140	f	2026-03-19 06:13:10.107448+00
274	16	536	139	248	t	2026-03-19 06:15:07.414441+00
275	16	1206	260	260	f	2026-03-19 06:18:02.413228+00
276	16	327	83	189	t	2026-03-19 06:19:40.297418+00
277	16	68	164	247	t	2026-03-19 06:20:01.04763+00
278	16	69	258	258	f	2026-03-19 06:24:25.390531+00
279	16	187	75	298	t	2026-03-19 06:25:08.189593+00
280	16	363	71	192	t	2026-03-19 06:26:22.313699+00
281	16	604	62	219	t	2026-03-19 06:26:32.585517+00
282	16	383	44	203	t	2026-03-19 06:26:43.351462+00
283	16	202	205	255	t	2026-03-19 06:30:13.712727+00
284	16	418	35	243	t	2026-03-19 06:30:30.563885+00
285	16	608	32	245	t	2026-03-19 06:32:27.078368+00
286	16	366	250	250	f	2026-03-21 06:46:27.798153+00
287	16	241	250	250	f	2026-03-21 17:39:31.220076+00
288	16	272	186	298	t	2026-03-21 17:41:55.185753+00
289	16	1003	291	291	f	2026-03-21 17:52:29.932969+00
290	16	261	275	275	f	2026-03-21 17:57:50.916225+00
291	16	178	241	241	f	2026-03-21 18:02:22.938635+00
292	16	1166	125	292	t	2026-03-21 18:05:24.808365+00
293	16	498	281	326	t	2026-03-21 18:10:21.694941+00
294	16	229	246	249	t	2026-03-22 06:56:33.006552+00
295	16	1261	213	213	f	2026-03-22 07:00:12.034061+00
296	16	953	83	222	t	2026-03-22 07:00:44.77997+00
297	16	318	86	288	t	2026-03-22 07:00:58.374683+00
298	16	759	214	214	f	2026-03-22 07:04:44.215621+00
299	16	761	203	203	f	2026-03-22 07:10:04.8906+00
300	16	289	208	208	f	2026-03-22 07:14:01.185019+00
301	16	290	68	253	t	2026-03-22 07:15:14.705027+00
302	16	292	83	227	t	2026-03-22 07:16:53.886333+00
303	16	1029	309	309	f	2026-03-22 07:25:49.237429+00
304	16	323	214	214	f	2026-03-22 07:29:29.336357+00
305	16	289	208	208	f	2026-03-22 08:56:13.117898+00
306	16	95	246	246	f	2026-03-23 10:00:11.305552+00
307	16	149	41	239	t	2026-03-23 10:00:28.3142+00
308	16	451	65	269	t	2026-03-23 10:00:42.950796+00
309	16	712	91	91	f	2026-03-23 10:02:21.814499+00
310	16	476	149	149	f	2026-03-23 10:05:00.125279+00
311	16	460	262	262	f	2026-03-23 10:09:29.279511+00
312	16	271	44	291	t	2026-03-23 14:38:55.29144+00
313	16	1030	254	254	f	2026-03-23 14:43:38.440831+00
314	16	1293	278	278	f	2026-03-23 14:48:25.279273+00
315	16	27	113	113	f	2026-03-23 14:50:27.551222+00
316	16	171	324	324	f	2026-03-23 14:55:58.645035+00
317	16	1035	288	288	f	2026-03-23 15:00:55.625142+00
318	16	1123	279	279	f	2026-03-23 15:05:44.593917+00
319	16	122	16	300	t	2026-03-23 15:06:10.655994+00
320	16	710	100	100	f	2026-03-23 15:07:57.391795+00
321	16	369	252	252	f	2026-03-23 15:13:01.099522+00
322	16	5	181	240	t	2026-03-23 15:16:13.175245+00
323	16	105	300	300	f	2026-03-23 15:21:21.58992+00
324	16	637	158	285	t	2026-03-23 18:14:42.399333+00
325	16	182	15	235	t	2026-03-23 18:19:22.615513+00
326	16	637	285	285	f	2026-03-23 18:24:05.288809+00
327	16	905	267	267	f	2026-03-23 18:28:40.37363+00
328	16	182	235	235	f	2026-03-23 18:32:36.824265+00
329	16	637	8	285	t	2026-03-23 18:32:44.764801+00
330	16	79	261	261	f	2026-03-23 18:37:34.077918+00
331	16	48	267	275	t	2026-03-23 18:43:08.650237+00
332	16	1139	259	259	f	2026-03-23 18:52:01.684325+00
333	16	637	11	285	t	2026-03-23 18:52:11.408981+00
334	16	1175	238	238	f	2026-03-23 18:57:28.448541+00
335	16	919	311	311	f	2026-03-24 07:29:58.21554+00
336	16	1300	159	159	f	2026-03-24 07:32:41.802657+00
337	16	1220	362	362	f	2026-03-24 07:38:50.464872+00
338	16	253	341	341	f	2026-03-24 07:44:35.336206+00
339	16	1055	208	208	f	2026-03-24 07:48:13.849757+00
340	16	912	210	210	f	2026-03-24 07:53:43.286321+00
341	16	274	373	373	f	2026-03-24 08:15:17.689301+00
342	16	132	293	293	f	2026-03-24 08:20:27.504346+00
343	16	394	328	328	f	2026-03-24 08:26:09.186297+00
344	16	942	289	289	f	2026-03-24 08:31:12.967007+00
345	16	11	269	269	f	2026-03-24 08:35:50.650778+00
346	16	225	230	230	f	2026-03-24 18:42:14.907174+00
347	16	590	196	196	f	2026-03-25 07:57:48.215862+00
348	12	932	116	276	t	2026-03-25 15:18:51.896394+00
349	12	453	298	298	f	2026-03-25 15:23:57.440363+00
350	12	308	217	217	f	2026-03-25 15:30:59.96649+00
351	12	306	164	244	t	2026-03-25 15:33:50.335645+00
352	12	303	5	220	t	2026-03-25 15:34:02.016633+00
353	12	305	202	256	t	2026-03-25 15:34:20.504324+00
354	16	501	196	196	f	2026-03-25 15:36:39.531962+00
355	16	307	89	89	f	2026-03-25 15:38:46.082622+00
356	16	309	256	256	f	2026-03-25 16:08:12.908834+00
357	16	300	7	208	t	2026-03-25 16:08:26.585317+00
358	16	300	133	208	t	2026-03-25 16:10:44.989764+00
359	16	302	276	276	f	2026-03-25 16:15:39.689339+00
360	16	1256	258	258	f	2026-03-25 18:35:14.31767+00
361	16	641	288	288	f	2026-03-26 07:10:57.100329+00
362	16	637	285	285	f	2026-03-26 07:18:04.999351+00
363	16	645	9	93	t	2026-03-26 07:18:19.239331+00
364	16	590	196	196	f	2026-03-26 08:02:59.600485+00
365	16	501	196	196	f	2026-03-26 08:06:21.445624+00
366	16	105	235	300	t	2026-03-26 08:10:26.436081+00
367	16	95	246	246	f	2026-03-27 04:16:11.606272+00
368	16	109	236	236	f	2026-03-27 04:20:15.025415+00
369	16	228	238	268	t	2026-03-27 04:26:16.096084+00
370	16	293	292	292	f	2026-03-27 04:31:17.58096+00
371	16	241	250	250	f	2026-03-27 04:37:25.340166+00
372	16	261	275	275	f	2026-03-27 04:43:17.032274+00
373	16	177	259	259	f	2026-03-27 04:47:58.881173+00
374	12	923	244	244	f	2026-03-27 09:41:16.774916+00
375	12	921	203	203	f	2026-03-27 09:46:12.020257+00
376	12	919	311	311	f	2026-03-27 09:51:27.410706+00
377	12	920	374	374	f	2026-03-27 09:57:48.340945+00
378	12	767	303	303	f	2026-03-27 10:03:24.199979+00
379	12	769	253	253	f	2026-03-27 10:07:45.129383+00
380	12	242	238	238	f	2026-03-27 10:11:51.687622+00
381	12	41	190	190	f	2026-03-27 10:15:12.49849+00
382	12	1085	227	293	t	2026-03-27 10:19:04.718141+00
383	12	403	296	296	f	2026-03-27 10:24:05.289192+00
384	12	881	341	341	f	2026-03-27 10:29:50.688188+00
385	12	177	259	259	f	2026-03-27 10:34:16.111566+00
386	12	519	314	314	f	2026-03-27 10:39:35.090458+00
387	12	529	247	247	f	2026-03-27 10:43:48.316296+00
388	12	751	330	330	f	2026-03-27 10:49:23.187425+00
389	12	1154	213	213	f	2026-03-27 10:52:59.676823+00
390	12	1254	339	339	f	2026-03-27 10:58:44.117873+00
391	12	1117	282	282	f	2026-03-27 11:03:32.441156+00
392	12	1239	275	299	t	2026-03-27 11:09:31.277231+00
393	12	124	244	244	f	2026-03-27 11:13:38.958796+00
394	12	193	267	267	f	2026-03-27 11:18:11.218619+00
395	12	977	296	296	f	2026-03-27 11:23:13.346933+00
396	12	1069	325	325	f	2026-03-27 11:28:43.466093+00
397	12	201	238	238	f	2026-03-27 11:32:45.660985+00
398	12	1050	268	268	f	2026-03-27 11:37:20.859538+00
399	12	346	230	230	f	2026-03-27 11:41:09.261817+00
400	12	350	227	227	f	2026-03-27 11:46:43.07744+00
401	12	960	254	254	f	2026-03-27 11:52:57.687025+00
402	12	970	56	250	t	2026-03-27 11:53:58.089267+00
403	12	714	92	92	f	2026-03-27 11:55:33.977695+00
404	12	1244	292	292	f	2026-03-27 12:00:31.858652+00
405	12	141	267	267	f	2026-03-27 12:05:04.755288+00
406	12	1248	243	243	f	2026-03-27 12:09:13.637359+00
407	12	523	290	290	f	2026-03-27 12:14:08.036935+00
408	12	549	241	241	f	2026-03-27 12:18:13.406632+00
409	12	1062	312	312	f	2026-03-27 12:23:31.274312+00
410	12	271	291	291	f	2026-03-27 12:28:25.809399+00
411	12	1127	262	262	f	2026-03-27 12:34:47.18038+00
412	12	142	330	330	f	2026-03-27 12:40:37.103061+00
413	12	1260	5	254	t	2026-03-27 12:41:46.707885+00
414	12	1260	254	254	f	2026-03-27 12:46:04.019808+00
415	12	349	263	263	f	2026-03-27 12:50:32.390034+00
416	12	428	88	88	f	2026-03-27 12:52:07.759921+00
417	12	53	90	90	f	2026-03-27 12:53:42.277862+00
418	12	1241	277	277	f	2026-03-27 12:58:46.315946+00
419	12	1160	218	218	f	2026-03-27 13:02:28.41346+00
420	16	1300	159	159	f	2026-03-27 18:00:34.939316+00
421	16	1300	6	159	t	2026-03-28 18:11:33.800093+00
422	16	1300	159	159	f	2026-03-29 06:29:03.23091+00
423	16	637	285	285	f	2026-03-29 06:34:01.011227+00
424	16	276	301	301	f	2026-03-29 06:39:21.43941+00
425	16	497	211	211	f	2026-03-29 06:42:56.628657+00
426	16	134	299	299	f	2026-03-29 06:48:00.204249+00
427	16	518	303	303	f	2026-03-29 06:53:07.274669+00
428	16	521	35	334	t	2026-03-29 06:53:52.423694+00
429	16	11	269	269	f	2026-03-29 06:58:26.970578+00
430	16	495	227	227	f	2026-03-29 07:02:17.573864+00
431	16	394	328	328	f	2026-03-29 07:07:50.140597+00
432	16	470	333	333	f	2026-03-29 07:13:27.653488+00
433	16	920	362	364	t	2026-03-29 07:19:33.295148+00
434	16	275	270	270	f	2026-03-29 07:24:07.584138+00
435	16	919	311	311	f	2026-03-29 07:29:24.04466+00
436	16	297	308	308	f	2026-03-29 07:34:36.456452+00
437	16	248	245	245	f	2026-03-29 07:38:46.519283+00
438	16	1270	182	182	f	2026-03-29 07:41:53.064074+00
439	16	942	289	289	f	2026-03-29 08:37:22.315726+00
440	16	1222	288	288	f	2026-03-29 08:42:14.020336+00
441	16	109	236	236	f	2026-03-29 08:46:22.449736+00
442	16	222	308	318	t	2026-03-29 08:51:35.214255+00
443	16	222	254	318	t	2026-03-29 17:17:13.224757+00
444	16	30	295	295	f	2026-04-01 07:35:11.057211+00
445	16	403	264	296	t	2026-04-01 07:40:03.194363+00
446	16	508	89	289	t	2026-04-01 07:41:37.427353+00
447	16	909	237	241	t	2026-04-01 07:45:42.802602+00
448	16	372	274	274	f	2026-04-01 07:52:44.315733+00
449	16	372	80	266	t	2026-04-01 07:52:58.132348+00
450	16	1062	153	309	t	2026-04-01 08:27:47.878783+00
451	16	495	227	227	f	2026-04-02 07:29:13.819419+00
452	16	375	258	258	f	2026-04-02 07:34:05.448556+00
453	16	1222	288	288	f	2026-04-02 07:38:57.833771+00
454	16	330	53	283	t	2026-04-02 07:39:54.133264+00
455	16	915	298	298	f	2026-04-02 07:45:00.528395+00
456	16	366	250	250	f	2026-04-02 07:49:14.214472+00
457	16	266	241	241	f	2026-04-02 07:53:20.126894+00
458	16	274	373	373	f	2026-04-02 07:59:40.285022+00
459	16	109	6	236	t	2026-04-02 07:59:51.635168+00
460	16	378	223	223	f	2026-04-02 08:03:40.539343+00
461	16	505	254	254	f	2026-04-02 08:08:47.298572+00
462	16	590	196	196	f	2026-04-03 04:45:36.807406+00
463	16	266	241	241	f	2026-04-04 06:23:26.031023+00
464	16	378	223	223	f	2026-04-04 06:27:14.029644+00
465	16	590	196	196	f	2026-04-04 06:31:28.018239+00
466	16	857	211	211	f	2026-04-19 08:50:33.977443+00
467	16	1237	235	235	f	2026-04-19 08:54:54.748943+00
468	16	995	319	319	f	2026-04-19 09:23:59.867393+00
469	16	549	241	241	f	2026-04-19 09:28:04.786514+00
470	16	894	15	273	t	2026-04-19 09:28:22.522317+00
471	16	421	289	289	f	2026-04-19 09:33:16.420643+00
472	16	1006	222	222	f	2026-04-19 09:37:03.512848+00
473	16	556	37	292	t	2026-04-19 11:11:46.660913+00
474	16	436	10	270	t	2026-04-19 11:11:59.474845+00
475	16	590	196	196	f	2026-04-20 09:50:54.043159+00
476	16	501	196	196	f	2026-04-20 09:54:18.915275+00
477	16	500	8	265	t	2026-04-20 09:54:30.795892+00
478	16	503	200	200	f	2026-04-20 09:58:59.561395+00
\.


--
-- Data for Name: playlist_songs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.playlist_songs (playlist_id, song_id, added_at, position_order) FROM stdin;
1	1	2026-02-23 19:24:26.833577	1
3	6	2026-02-24 20:15:28.049776	1
2	8	2026-02-26 19:58:53.971217	1
2	6	2026-02-26 20:37:16.399195	1
4	4	2026-02-27 17:41:33.564017	1
1	12	2026-02-27 17:59:18.486889	1
1	8	2026-02-27 17:59:44.344144	1
1	9	2026-02-27 17:59:54.590117	1
1	2	2026-02-27 18:00:07.459111	1
3	2	2026-02-27 19:57:33.587417	1
3	10	2026-02-28 15:41:03.13385	1
2	10	2026-02-28 21:23:59.98656	1
3	4	2026-02-28 21:42:53.128194	1
3	185	2026-02-28 22:31:37.338244	1
3	49	2026-03-01 19:53:40.998538	1
3	743	2026-03-02 17:15:38.218344	1
3	313	2026-03-02 17:40:41.818104	1
3	18	2026-03-02 18:10:40.844908	1
2	442	2026-03-02 18:11:25.402112	1
3	122	2026-03-02 18:19:36.263036	1
2	122	2026-03-02 18:19:46.910785	1
8	258	2026-03-02 20:12:10.012537	1
9	40	2026-03-14 23:02:29.551837	1
9	69	2026-03-19 06:20:18.76244	1
\.


--
-- Data for Name: playlists; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.playlists (id, user_id, name, description, created_at) FROM stdin;
1	10	test-playlist	test-description	2026-02-23 19:19:33.737642
2	12	Fafnir's playlist		2026-02-24 20:14:57.477905
3	12	Fafnir	fafnir\n	2026-02-24 20:15:23.264043
4	10	shubham's playlist		2026-02-27 17:41:20.81417
5	10	playlist2		2026-02-27 17:46:24.505728
6	10	playlist 3		2026-02-27 17:53:00.810684
8	12	Test Fafnir		2026-03-02 20:12:05.59811
9	16	Dreams	A playlist that is meant for dreamy songs	2026-03-14 23:02:26.960196
\.


--
-- Data for Name: quotes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quotes (id, quote_text, author, anime, quote_type, is_active, created_at) FROM stdin;
4	El Psy Kongroo.	Rintarou Okabe	Steins;Gate	special	t	2026-03-09 23:18:59.229615
5	No one knows what the future holds. That's why its potential is infinite.	Rintarou Okabe	Steins;Gate	special	t	2026-03-09 23:18:59.229615
6	People's feelings are memories that transcend time.	Kurisu Makise	Steins;Gate	normal	t	2026-03-09 23:18:59.229615
7	Remembering something that no one else can is a painful thing.	Rintarou Okabe	Steins;Gate	special	t	2026-03-09 23:18:59.229615
8	Living should mean no do-overs.	Itaru Hashida	Steins;Gate	normal	t	2026-03-09 23:18:59.229615
9	Time passes so quickly. Right now, I feel like complaining to Einstein.	Kurisu Makise	Steins;Gate	normal	t	2026-03-09 23:18:59.229615
10	Every day might not be fun. But as long as you're alive, good things might happen.	Nagisa Furukawa	Clannad	special	t	2026-03-09 23:18:59.229615
11	If your life can change once, your life can change again.	Sanae Furukawa	Clannad	normal	t	2026-03-09 23:18:59.229615
12	Nothing can stay unchanged. Fun things... happy things... they can't all possibly stay unchanged.	Nagisa Furukawa	Clannad	normal	t	2026-03-09 23:18:59.229615
13	Do not ever look down on your own life.	Akio Furukawa	Clannad	special	t	2026-03-09 23:18:59.229615
14	I hope one day, you'll be reunited with the one you cherish.	Isla	Plastic Memories	special	t	2026-03-09 23:18:59.229615
15	Having happy and beautiful memories won't always bring you salvation.	Isla	Plastic Memories	normal	t	2026-03-09 23:18:59.229615
16	Memories are meant to be cherished, not to be a source of pain.	Tsukasa Mizugaki	Plastic Memories	normal	t	2026-03-09 23:18:59.229615
17	I'd rather die with someone than let that person die before my eyes.	Kirito	Sword Art Online	special	t	2026-03-09 23:18:59.229615
18	Levels are just numbers. In this world, strength is just an illusion. There are more important things.	Kirito	Sword Art Online	normal	t	2026-03-09 23:18:59.229615
19	It's impossible to work hard for something you don't enjoy.	Silica	Sword Art Online	normal	t	2026-03-09 23:18:59.229615
20	Real or not, a feeling is a feeling.	Kirito	Sword Art Online	normal	t	2026-03-09 23:18:59.229615
21	Life isn't just doing things for yourself. It's possible to live in such a way that other people's happiness makes you happy too.	Asuna Yuuki	Sword Art Online	special	t	2026-03-09 23:18:59.229615
22	Listen well. You are the protagonist of your own life.	Arataka Reigen	Mob Psycho 100	special	t	2026-03-09 23:18:59.229615
23	If everyone is not special, maybe you can be what you want to be.	Shigeo Kageyama	Mob Psycho 100	special	t	2026-03-09 23:18:59.229615
24	You don't need a reason to help people.	Shigeo Kageyama	Mob Psycho 100	normal	t	2026-03-09 23:18:59.229615
25	When things go south, it's okay to run away!	Arataka Reigen	Mob Psycho 100	special	t	2026-03-09 23:18:59.229615
26	Explosion!	Megumin	Konosuba	special	t	2026-03-09 23:18:59.229615
27	I yearn for true gender equality.	Kazuma Satou	Konosuba	special	t	2026-03-09 23:18:59.229615
28	A beautiful goddess is an undeniable fact.	Aqua	Konosuba	normal	t	2026-03-09 23:18:59.229615
29	If I could meet you again, I would definitely fall in love with you.	Taki Tachibana	Your Name	special	t	2026-03-09 23:18:59.229615
30	Wherever you are in the world, I'll search for you.	Taki Tachibana	Your Name	special	t	2026-03-09 23:18:59.229615
31	Treasure the experience. Dreams fade away after you wake up.	Hitoha Miyamizu	Your Name	normal	t	2026-03-09 23:18:59.229615
32	I want to know what "I love you" means.	Violet Evergarden	Violet Evergarden	special	t	2026-03-09 23:18:59.229615
33	No letter that could be sent deserves to go undelivered.	Violet Evergarden	Violet Evergarden	normal	t	2026-03-09 23:18:59.229615
34	You're going to learn a lot of things, but it's easier to keep living if you don't know them.	Claudia Hodgins	Violet Evergarden	normal	t	2026-03-09 23:18:59.229615
35	Spring will be here soon. Spring, the season I met you, is coming.	Kousei Arima	Your Lie in April	special	t	2026-03-09 23:18:59.229615
36	Whether you're sad, you're a mess, or you've hit rock bottom, you still have to play!	Kaori Miyazono	Your Lie in April	special	t	2026-03-09 23:18:59.229615
37	A lie is a lie, no matter the reason.	Tsubaki Sawabe	Your Lie in April	normal	t	2026-03-09 23:18:59.229615
38	Music is freedom.	Kaori Miyazono	Your Lie in April	special	t	2026-03-09 23:18:59.229615
39	Sometimes people are just mean. Don't fight mean with mean. Hold your head high.	Hinata Miyake	A Place Further Than the Universe	normal	t	2026-03-09 23:18:59.229615
40	I want to see the world you see.	Shirase Kobuchizawa	A Place Further Than the Universe	normal	t	2026-03-09 23:18:59.229615
41	If you don't belong here, just build a place where you do.	Tohru Honda	Fruits Basket	special	t	2026-03-09 23:18:59.229615
42	Sometimes living can be hard! But it's only because we're alive that we can make each other laugh, cry, and be happy!	Tohru Honda	Fruits Basket	special	t	2026-03-09 23:18:59.229615
43	It's not always easy to see the good in people.	Tohru Honda	Fruits Basket	normal	t	2026-03-09 23:18:59.229615
44	Fake people have an image to maintain. Real people just don't care.	Hachiman Hikigaya	Oregairu	special	t	2026-03-09 23:18:59.229615
45	Hard work betrays none, but dreams betray many.	Hachiman Hikigaya	Oregairu	special	t	2026-03-09 23:18:59.229615
46	I don't care if no one likes me, I wasn't created in this world to entertain everyone.	Houtarou Oreki	Hyouka	special	t	2026-03-09 23:18:59.229615
47	If I don't have to do it, I won't. If I have to do it, I'll make it quick.	Houtarou Oreki	Hyouka	special	t	2026-03-09 23:18:59.229615
48	I'm curious!	Eru Chitanda	Hyouka	special	t	2026-03-09 23:18:59.229615
49	There is no such thing as a painless lesson.	Edward Elric	Fullmetal Alchemist: Brotherhood	special	t	2026-03-09 23:18:59.229615
50	Nothing's perfect, the world's not perfect. But it's there for us, trying the best it can.	Roy Mustang	Fullmetal Alchemist: Brotherhood	special	t	2026-03-09 23:18:59.229615
51	Even when our eyes are closed, there's a whole world out there.	Edward Elric	Fullmetal Alchemist: Brotherhood	normal	t	2026-03-09 23:18:59.229615
52	A heart's a heavy burden.	Sophie Hatter	Howl's Moving Castle	special	t	2026-03-09 23:18:59.229615
53	They say that the best blaze burns brightest when circumstances are at their worst.	Sophie Hatter	Howl's Moving Castle	normal	t	2026-03-09 23:18:59.229615
54	Once you've met someone, you never really forget them.	Zeniba	Spirited Away	special	t	2026-03-09 23:18:59.229615
55	You cannot alter your fate. However, you can rise to meet it.	Hii-sama	Princess Mononoke	special	t	2026-03-09 23:18:59.229615
56	Life is suffering. It is hard. The world is cursed, but still, you find reasons to keep living.	Osa	Princess Mononoke	normal	t	2026-03-09 23:18:59.229615
57	I love you, but you must learn to love yourself.	San	Princess Mononoke	normal	t	2026-03-09 23:18:59.229615
58	You can't sit around envying other people's worlds. You have to go out and change your own.	Shinichi Chiaki	Nodame Cantabile	normal	t	2026-03-09 23:18:59.229615
3	If you don't like your destiny, don't accept it. Instead, have the courage to change it.	Naruto Uzumaki	Naruto	special	t	2026-03-09 23:18:59.229615
59	There's no limit to how much you can improve.	Megumi Noda	Nodame Cantabile	normal	t	2026-03-09 23:18:59.229615
60	The ticket to the future is always open.	Vash the Stampede	Trigun	special	t	2026-03-09 23:18:59.229615
61	Love and peace!	Vash the Stampede	Trigun	special	t	2026-03-09 23:18:59.229615
62	Whatever happens, happens.	Spike Spiegel	Cowboy Bebop	special	t	2026-03-09 23:18:59.229615
63	I'm not going there to die. I'm going to find out if I'm really alive.	Spike Spiegel	Cowboy Bebop	special	t	2026-03-09 23:18:59.229615
64	You're gonna carry that weight.	Title Card	Cowboy Bebop	special	t	2026-03-09 23:18:59.229615
65	See you space cowboy...	Title Card	Cowboy Bebop	special	t	2026-03-09 23:18:59.229615
66	Get in the robot, Shinji.	Gendo Ikari	Neon Genesis Evangelion	special	t	2026-03-09 23:18:59.229615
67	Any new position from which you view your reality will change your perception of its nature.	Maya Ibuki	Neon Genesis Evangelion	normal	t	2026-03-09 23:18:59.229615
68	Sometimes you need a little wishful thinking just to keep on living.	Misato Katsuragi	Neon Genesis Evangelion	normal	t	2026-03-09 23:18:59.229615
69	Man fears the darkness, and so he scrapes away at the edges of it with fire.	Rei Ayanami	Neon Genesis Evangelion	special	t	2026-03-09 23:18:59.229615
70	The world is not beautiful, therefore it is.	Kino	Kino's Journey	special	t	2026-03-09 23:18:59.229615
71	If you don't share someone's pain, you can never understand them.	Pain	Naruto Shippuden	special	t	2026-03-09 23:18:59.229615
72	Wake up to reality! Nothing ever goes as planned in this accursed world.	Madara Uchiha	Naruto Shippuden	special	t	2026-03-09 23:18:59.229615
73	When a man learns to love, he must bear the risk of hatred.	Madara Uchiha	Naruto Shippuden	normal	t	2026-03-09 23:18:59.229615
74	Those who break the rules are scum, but those who abandon their friends are worse than scum.	Kakashi Hatake	Naruto	special	t	2026-03-09 23:18:59.229615
75	A smile is the best way to get oneself out of a tight spot.	Sai	Naruto Shippuden	normal	t	2026-03-09 23:18:59.229615
76	It is only through the eyes of others that our lives have any meaning.	Haku	Naruto	normal	t	2026-03-09 23:18:59.229615
77	People's lives don't end when they die, it ends when they lose faith.	Itachi Uchiha	Naruto	normal	t	2026-03-09 23:18:59.229615
78	The true measure of a shinobi is not how he lives but how he dies.	Jiraiya	Naruto Shippuden	special	t	2026-03-09 23:18:59.229615
79	To know sorrow is not terrifying. What is terrifying is to know you can't go back to happiness.	Rangiku Matsumoto	Bleach	normal	t	2026-03-09 23:18:59.229615
80	When do you think people die? It's when they are forgotten.	Dr. Hiriluk	One Piece	special	t	2026-03-09 23:18:59.229615
81	Scars on the back are a swordsman's shame.	Roronoa Zoro	One Piece	special	t	2026-03-09 23:18:59.229615
82	People's dreams... have no end!	Marshall D. Teach	One Piece	special	t	2026-03-09 23:18:59.229615
83	Fools who don't respect the past are likely to repeat it.	Nico Robin	One Piece	normal	t	2026-03-09 23:18:59.229615
84	I don't wanna conquer anything. It's just that the person with the most freedom is the Pirate King.	Monkey D. Luffy	One Piece	special	t	2026-03-09 23:18:59.229615
85	No matter how hard or impossible it is, never lose sight of your goal.	Monkey D. Luffy	One Piece	normal	t	2026-03-09 23:18:59.229615
86	I want to live!	Nico Robin	One Piece	special	t	2026-03-09 23:18:59.229615
87	If you win, you live. If you lose, you die. If you don't fight, you can't win!	Eren Yeager	Attack on Titan	special	t	2026-03-09 23:18:59.229615
88	This world is cruel, and it's also very beautiful.	Mikasa Ackerman	Attack on Titan	special	t	2026-03-09 23:18:59.229615
89	Give up on your dream and die.	Levi Ackerman	Attack on Titan	special	t	2026-03-09 23:18:59.229615
90	People who can't throw something important away, can never hope to change anything.	Armin Arlert	Attack on Titan	special	t	2026-03-09 23:18:59.229615
91	We are born free. All of us. Free.	Eren Yeager	Attack on Titan	special	t	2026-03-09 23:18:59.229615
92	I just keep moving forward, until my enemies are destroyed.	Eren Yeager	Attack on Titan	special	t	2026-03-09 23:18:59.229615
93	My soldiers, rage! My soldiers, scream! My soldiers, fight!	Erwin Smith	Attack on Titan	special	t	2026-03-09 23:18:59.229615
94	I am Justice!	L Lawliet	Death Note	special	t	2026-03-09 23:18:59.229615
95	This world is rotten, and those who are making it rot deserve to die.	Light Yagami	Death Note	normal	t	2026-03-09 23:18:59.229615
96	I have two rules: First, I'm never wrong. Second, if I'm wrong... back to the first rule.	L Lawliet	Death Note	special	t	2026-03-09 23:18:59.229615
97	If you can't win the game, if you can't solve the puzzle, you're nothing but a loser.	Near	Death Note	special	t	2026-03-09 23:18:59.229615
98	The only ones who should kill are those who are prepared to be killed.	Lelouch vi Britannia	Code Geass	special	t	2026-03-09 23:18:59.229615
99	If the king doesn't move, then his subjects won't follow.	Lelouch vi Britannia	Code Geass	special	t	2026-03-09 23:18:59.229615
100	False tears bring pain to those around you. A false smile brings pain to yourself.	C.C.	Code Geass	normal	t	2026-03-09 23:18:59.229615
101	To defeat evil, I will become an even greater evil.	Lelouch vi Britannia	Code Geass	special	t	2026-03-09 23:18:59.229615
102	I command you: Die!	Lelouch vi Britannia	Code Geass	special	t	2026-03-09 23:18:59.229615
103	I am the hope of the universe.	Goku	Dragon Ball Z	special	t	2026-03-09 23:18:59.229615
104	Power comes in response to a need, not a desire.	Goku	Dragon Ball Z	normal	t	2026-03-09 23:18:59.229615
105	There's only one certainty in life. A strong man stands above and conquers all!	Vegeta	Dragon Ball Z	normal	t	2026-03-09 23:18:59.229615
106	You can take control of my mind and my body, but there is one thing a Saiyan always keep... his pride!	Majin Vegeta	Dragon Ball Z	special	t	2026-03-09 23:18:59.229615
107	Plus Ultra!	All Might	My Hero Academia	special	t	2026-03-09 23:18:59.229615
108	Whether you win or lose, looking back and learning from your experience is a part of life.	All Might	My Hero Academia	normal	t	2026-03-09 23:18:59.229615
109	Stop talking, I will win. That's... what heroes do.	Katsuki Bakugo	My Hero Academia	special	t	2026-03-09 23:18:59.229615
110	Since when were you under the impression that I wasn't using Kyoka Suigetsu?	Sosuke Aizen	Bleach	special	t	2026-03-09 23:18:59.229615
111	Fear is not evil. It tells you what your weakness is.	Gildarts Clive	Fairy Tail	normal	t	2026-03-09 23:18:59.229615
112	Mistakes are not shackles that halt one from stepping forward.	Mavis Vermillion	Fairy Tail	special	t	2026-03-09 23:18:59.229615
113	Moving on doesn't mean you forget about things. It just means you have to accept what happened.	Erza Scarlet	Fairy Tail	normal	t	2026-03-09 23:18:59.229615
114	Set your heart ablaze!	Kyojuro Rengoku	Demon Slayer	special	t	2026-03-09 23:18:59.229615
115	If you can only do one thing, hone it to perfection.	Jigoro Kuwajima	Demon Slayer	special	t	2026-03-09 23:18:59.229615
116	Growing old and dying is what gives meaning and beauty to the fleeting span of a human life.	Kyojuro Rengoku	Demon Slayer	special	t	2026-03-09 23:18:59.229615
117	Feel the rage. The powerful, pure rage of not being able to forgive will become your unswerving drive.	Giyu Tomioka	Demon Slayer	normal	t	2026-03-09 23:18:59.229615
118	Throughout heaven and earth, I alone am the honored one.	Satoru Gojo	Jujutsu Kaisen	special	t	2026-03-09 23:18:59.229615
119	It's not about whether I can, I have to do it.	Megumi Fushiguro	Jujutsu Kaisen	normal	t	2026-03-09 23:18:59.229615
120	Dying to win and risking death to win are completely different.	Satoru Gojo	Jujutsu Kaisen	special	t	2026-03-09 23:18:59.229615
121	You should enjoy the little detours. To the fullest.	Ging Freecss	Hunter x Hunter	special	t	2026-03-09 23:18:59.229615
122	I do not fear death. I fear only that my rage will fade over time.	Kurapika	Hunter x Hunter	special	t	2026-03-09 23:18:59.229615
123	A human's potential for evolution is limitless.	Isaac Netero	Hunter x Hunter	special	t	2026-03-09 23:18:59.229615
124	What's wrong isn't me, what's wrong is the world!	Ken Kaneki	Tokyo Ghoul	special	t	2026-03-09 23:18:59.229615
125	Never trust anyone too much, remember the devil was once an angel.	Ken Kaneki	Tokyo Ghoul	normal	t	2026-03-09 23:18:59.229615
126	It's better to be hurt than to hurt others.	Ken Kaneki	Tokyo Ghoul	normal	t	2026-03-09 23:18:59.229615
127	Whatever you do, enjoy it to the fullest. That is the secret of life.	Rider	Fate/Zero	special	t	2026-03-09 23:18:59.229615
128	People die if they are killed.	Shirou Emiya	Fate/stay night	normal	t	2026-03-09 23:18:59.229615
129	I am the bone of my sword.	Archer	Fate/stay night	special	t	2026-03-09 23:18:59.229615
130	Talent is something you make bloom, instinct is something you polish.	Tooru Oikawa	Haikyuu!!	special	t	2026-03-09 23:18:59.229615
131	Even if we're not confident that we'll win, we must never tell ourselves that.	Daichi Sawamura	Haikyuu!!	special	t	2026-03-09 23:18:59.229615
132	Someone who can't see the opponent standing right in front of him, can't defeat the opponent beyond!	Hajime Iwaizumi	Haikyuu!!	normal	t	2026-03-09 23:18:59.229615
133	If you don't have the courage to change things then you might as well die!	Natsu Dragneel	Fairy Tail	normal	t	2026-03-09 23:18:59.229615
134	There are two things that collectors always want. The first is an item of extreme rarity.	Kurapika	Hunter x Hunter	normal	t	2026-03-09 23:18:59.229615
135	Sometimes, we have to look beyond what we want and do what's best.	Piccolo	Dragon Ball Z	normal	t	2026-03-09 23:18:59.229615
136	You're not a monster, are you? You're a god.	Yelena	Attack on Titan	normal	t	2026-03-09 23:18:59.229615
137	Are you crying? No, it's just raining.	Roy Mustang	Fullmetal Alchemist: Brotherhood	normal	t	2026-03-09 23:18:59.229615
138	If nobody cares to accept you and wants you in this world, accept yourself.	Alibaba Saluja	Magi: The Labyrinth of Magic	normal	t	2026-03-09 23:18:59.229615
139	If you just submit yourself to fate, then that's the end of it.	Keiichi Maebara	Higurashi: When They Cry	normal	t	2026-03-09 23:18:59.229615
140	Knowing you're different is only the beginning. If you accept these differences you'll grow closer.	Miss Kobayashi	Miss Kobayashi's Dragon Maid	normal	t	2026-03-09 23:18:59.229615
141	No matter how deep the night, it always turns to day, eventually.	Brook	One Piece	normal	t	2026-03-09 23:18:59.229615
142	Fake people have an image to maintain. Real people just don't care.	Hachiman Hikigaya	Oregairu	special	t	2026-03-09 23:18:59.229615
143	I'll take my time. I'll take all the time I need.	Guts	Berserk	normal	t	2026-03-09 23:18:59.229615
144	If you're always worried about crushing the ants beneath you... you won't be able to walk.	Guts	Berserk	special	t	2026-03-09 23:18:59.229615
145	If you have time to think of a beautiful end, then live beautifully until the end.	Gintoki Sakata	Gintama	special	t	2026-03-09 23:18:59.229615
146	A samurai doesn't need a reason to act. If something needs saving, he just saves it.	Gintoki Sakata	Gintama	normal	t	2026-03-09 23:18:59.229615
147	Don't give up, there's no shame in falling down! The true shame is to not stand up again!	Shintaro Midorima	Kuroko no Basket	special	t	2026-03-09 23:18:59.229615
148	The only ones who can beat me, are me.	Daiki Aomine	Kuroko no Basket	special	t	2026-03-09 23:18:59.229615
149	Blank never loses.	Sora and Shiro	No Game No Life	special	t	2026-03-09 23:18:59.229615
150	We are humans. We are the most vulnerable species... But we have intellect.	Sora	No Game No Life	special	t	2026-03-09 23:18:59.229615
151	I don't know everything, I just know what I know.	Tsubasa Hanekawa	Monogatari Series	special	t	2026-03-09 23:18:59.229615
152	People save themselves on their own. Nobody can ever save anyone else.	Meme Oshino	Monogatari Series	special	t	2026-03-09 23:18:59.229615
153	Being kind to everyone simply means there's no one special.	Koyomi Araragi	Monogatari Series	normal	t	2026-03-09 23:18:59.229615
154	Just because you're right, doesn't mean you're correct.	Shirou Emiya	Fate/stay night: Unlimited Blade Works	normal	t	2026-03-09 23:18:59.229615
155	Yours is the drill that will pierce the heavens!	Kamina	Tengen Toppa Gurren Lagann	special	t	2026-03-09 23:18:59.229615
156	Who the hell do you think I am?!	Kamina	Tengen Toppa Gurren Lagann	special	t	2026-03-09 23:18:59.229615
157	Even if the morrow is barren of promises, nothing shall forestall my return.	Genesis Rhapsodos	Final Fantasy VII: Advent Children	normal	t	2026-03-09 23:18:59.229615
158	What is life without the pursuit of dreams?	Kenshin Himura	Rurouni Kenshin	normal	t	2026-03-09 23:18:59.229615
159	You can die anytime, but living takes true courage.	Kenshin Himura	Rurouni Kenshin	special	t	2026-03-09 23:18:59.229615
160	Every journey begins with a single step. We just have to have patience.	Master Roshi	Dragon Ball	normal	t	2026-03-09 23:18:59.229615
161	Do you always want to live hiding behind the mask you put up for the sake of others?	Ymir	Attack on Titan	special	t	2026-03-09 23:18:59.229615
162	When you give up, that's when the game ends.	Mitsuyoshi Anzai	Slam Dunk	special	t	2026-03-09 23:18:59.229615
163	Even a fool has at least one talent.	Hidenori Tabata	Daily Lives of High School Boys	normal	t	2026-03-09 23:18:59.229615
164	The night is darkest just before dawn. But keep your eyes open.	Gintoki Sakata	Gintama	special	t	2026-03-09 23:18:59.229615
165	A sound soul dwells within a sound mind and a sound body.	Maka Albarn	Soul Eater	special	t	2026-03-09 23:18:59.229615
166	Do you want to know what death is? Death is a state of non-existence.	Franken Stein	Soul Eater	normal	t	2026-03-09 23:18:59.229615
167	Symmetry is what makes the world beautiful.	Death the Kid	Soul Eater	special	t	2026-03-09 23:18:59.229615
168	I won't let my past dictate who I am.	Touka Kirishima	Tokyo Ghoul	normal	t	2026-03-09 23:18:59.229615
169	Sometimes you have to accept the fact that certain things will never go back to how they used to be.	Ciel Phantomhive	Black Butler	normal	t	2026-03-09 23:18:59.229615
170	I am simply one hell of a butler.	Sebastian Michaelis	Black Butler	special	t	2026-03-09 23:18:59.229615
171	If a miracle only happens once, then what is it called the second time?	Ichigo Kurosaki	Bleach	normal	t	2026-03-09 23:18:59.229615
172	Don't break anyone's heart, they only have one. Break their bones, they have 206.	Ichigo Kurosaki	Bleach	normal	t	2026-03-09 23:18:59.229615
173	The world is an ocean, and we are just small boats.	Silvers Rayleigh	One Piece	normal	t	2026-03-09 23:18:59.229615
174	Strength isn't just about winning. It's about not giving up when you lose.	Jiraiya	Naruto	normal	t	2026-03-09 23:18:59.229615
175	Because people don't have wings, we look for ways to fly.	Keishin Ukai	Haikyuu!!	special	t	2026-03-09 23:18:59.229615
176	Magic is just something you use to get by. What matters is the heart.	Frieren	Frieren: Beyond Journey's End	special	t	2026-03-09 23:18:59.229615
177	It's the simple joys that make life worth living.	Himmel	Frieren: Beyond Journey's End	normal	t	2026-03-09 23:18:59.229615
178	Time spent with others is never wasted.	Fern	Frieren: Beyond Journey's End	normal	t	2026-03-09 23:18:59.229615
179	Bravery is not the absence of fear, but acting despite it.	Stark	Frieren: Beyond Journey's End	normal	t	2026-03-09 23:18:59.229615
180	A journey's meaning is found in the memories we make along the way.	Frieren	Frieren: Beyond Journey's End	special	t	2026-03-09 23:18:59.229615
181	Betrayal is just a word. The reality is much colder.	Askeladd	Vinland Saga	normal	t	2026-03-09 23:18:59.229615
182	You have no enemies. No one has any enemies.	Thors Snoresson	Vinland Saga	special	t	2026-03-09 23:18:59.229615
183	A true warrior needs no sword.	Thors Snoresson	Vinland Saga	special	t	2026-03-09 23:18:59.229615
184	Revenge is a poison that eats you from the inside.	Thorfinn	Vinland Saga	normal	t	2026-03-09 23:18:59.229615
185	Life has meaning only when we are useful to others.	Johan Liebert	Monster	normal	t	2026-03-09 23:18:59.229615
186	All lives are not created equal.	Johan Liebert	Monster	special	t	2026-03-09 23:18:59.229615
187	Tomorrow will be a good day.	Kenzo Tenma	Monster	normal	t	2026-03-09 23:18:59.229615
188	The law doesn't protect people. People protect the law.	Akane Tsunemori	Psycho-Pass	special	t	2026-03-09 23:18:59.229615
189	Society doesn't always do what is right. That's why we must judge for ourselves.	Shinya Kogami	Psycho-Pass	normal	t	2026-03-09 23:18:59.229615
190	A perfect society is an illusion created by the blind.	Shogo Makishima	Psycho-Pass	normal	t	2026-03-09 23:18:59.229615
191	Do not judge a book by its cover, nor a man by his scars.	Batou	Ghost in the Shell	normal	t	2026-03-09 23:18:59.229615
192	It is the duty of the living to remember the dead.	Motoko Kusanagi	Ghost in the Shell	special	t	2026-03-09 23:18:59.229615
193	Hope is the greatest weapon we have.	Madoka Kaname	Puella Magi Madoka Magica	special	t	2026-03-09 23:18:59.229615
194	If someone tells me that it's wrong to hope, I will tell them they're wrong every time.	Madoka Kaname	Puella Magi Madoka Magica	special	t	2026-03-09 23:18:59.229615
195	I will do it over. No matter how many times it takes.	Homura Akemi	Puella Magi Madoka Magica	special	t	2026-03-09 23:18:59.229615
196	Miracles are not free. When you wish for hope, it creates an equivalent despair.	Kyubey	Puella Magi Madoka Magica	special	t	2026-03-09 23:18:59.229615
197	Love is the most beautiful and terrifying thing in the world.	Holo	Spice and Wolf	normal	t	2026-03-09 23:18:59.229615
198	A wise merchant knows when to cut his losses.	Kraft Lawrence	Spice and Wolf	normal	t	2026-03-09 23:18:59.229615
199	Sometimes the most logical choice is the hardest one to make.	Kraft Lawrence	Spice and Wolf	normal	t	2026-03-09 23:18:59.229615
200	Music speaks the words we cannot say.	Yui Hirasawa	K-On!	normal	t	2026-03-09 23:18:59.229615
201	A single note can change the world if played with feeling.	Mio Akiyama	K-On!	normal	t	2026-03-09 23:18:59.229615
202	Friendship is a melody that plays on forever.	Ritsu Tainaka	K-On!	normal	t	2026-03-09 23:18:59.229615
203	Things we can't see are the most important.	Shoya Ishida	A Silent Voice	normal	t	2026-03-09 23:18:59.229615
204	I want to help you live.	Shoya Ishida	A Silent Voice	special	t	2026-03-09 23:18:59.229615
205	Every voice deserves to be heard.	Shouko Nishimiya	A Silent Voice	normal	t	2026-03-09 23:18:59.229615
206	You can't protect everything. Sometimes you have to choose.	Rei Kiriyama	March Comes in Like a Lion	normal	t	2026-03-09 23:18:59.229615
207	The storm will pass, and the sun will shine again.	Hinata Kawamoto	March Comes in Like a Lion	normal	t	2026-03-09 23:18:59.229615
208	Life is a game of shogi. You must think three steps ahead.	Rei Kiriyama	March Comes in Like a Lion	normal	t	2026-03-09 23:18:59.229615
209	Passion is what keeps the soul alive.	Nana Osaki	NANA	special	t	2026-03-09 23:18:59.229615
210	Dreams are meant to be chased, not just dreamt.	Nana Komatsu	NANA	normal	t	2026-03-09 23:18:59.229615
211	Love is selfish, but that's what makes it real.	Nana Osaki	NANA	normal	t	2026-03-09 23:18:59.229615
212	I'm a dragon, you're a human. We are different, but we are family.	Tohru	Miss Kobayashi's Dragon Maid	normal	t	2026-03-09 23:18:59.229615
213	A house is not a home without the people you love.	Kobayashi	Miss Kobayashi's Dragon Maid	normal	t	2026-03-09 23:18:59.229615
214	Even a goddess needs a break sometimes.	Aqua	Konosuba	normal	t	2026-03-09 23:18:59.229615
\.


--
-- Data for Name: song_genres; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.song_genres (song_id, genre_id) FROM stdin;
22	1
12	2
12	3
17	2
25	5
9	5
226	5
15	1
10	5
6	2
37	1
14	1
24	5
13	1
13	3
26	16
19	17
16	2
7	2
8	5
20	1
5	1
27	1
18	17
39	5
45	17
59	5
49	5
42	17
66	2
66	3
44	2
65	16
68	16
68	3
63	5
62	2
47	2
46	2
64	5
40	2
40	3
51	1
60	16
61	16
73	1
43	3
43	1
57	2
67	2
50	5
58	5
70	2
71	5
85	2
108	1
96	1
80	1
86	3
86	1
74	2
82	2
106	5
79	5
79	3
100	5
92	2
84	2
91	2
87	5
107	5
98	5
103	5
76	5
78	1
95	1
77	1
93	2
102	2
97	5
101	5
83	2
81	5
99	5
75	5
124	1
124	3
144	2
111	5
148	2
135	1
117	5
112	2
147	5
141	1
125	2
140	3
123	2
123	3
113	2
130	5
145	5
133	1
138	3
120	1
127	1
142	1
137	5
114	2
126	16
115	2
134	112
139	2
129	2
136	2
152	2
178	1
149	1
155	2
153	5
154	2
184	17
174	3
180	2
180	3
163	1
161	5
181	2
166	2
172	5
164	2
171	1
162	5
151	5
157	2
173	5
158	2
156	2
170	1
169	1
165	2
159	1
160	2
160	3
168	2
175	3
203	16
190	5
219	2
216	2
210	1
214	1
209	1
204	5
187	16
220	1
212	1
188	2
197	2
193	1
191	16
218	5
224	3
198	5
206	5
196	1
217	2
186	2
201	1
205	5
192	2
213	1
208	2
195	1
200	3
194	2
247	5
249	2
230	2
241	1
241	3
258	3
243	2
261	1
228	1
228	3
262	2
231	2
251	2
245	3
239	5
236	5
248	1
248	112
235	5
254	16
233	3
240	2
242	1
234	2
259	1
259	3
255	3
237	5
229	2
238	2
253	1
253	112
244	3
260	16
297	112
291	5
265	1
270	1
267	5
299	5
298	5
285	5
274	112
268	3
276	112
296	2
269	2
284	2
282	1
286	1
271	1
275	112
295	1
287	2
280	2
292	5
288	2
281	2
290	5
278	2
283	3
272	1
273	1
334	3
303	2
312	5
327	16
315	16
323	2
320	2
310	2
314	1
316	3
319	2
328	16
321	1
333	17
326	3
336	2
322	2
301	3
305	3
305	5
335	2
313	5
311	16
318	1
325	3
351	2
349	1
346	1
343	5
360	1
374	5
374	3
361	5
339	1
371	17
340	2
356	2
363	16
345	2
357	2
365	2
353	2
354	3
347	3
352	1
362	5
350	1
344	5
373	2
359	1
342	2
372	1
337	2
364	16
396	2
396	3
385	2
376	5
399	2
387	2
411	3
402	5
395	5
382	5
391	2
381	5
386	3
397	1
390	2
383	16
389	1
377	1
401	2
380	2
388	1
405	1
403	1
398	16
392	2
400	2
410	16
418	16
424	2
436	1
432	2
437	17
444	2
427	2
433	16
416	3
429	3
434	16
438	2
440	16
440	17
430	17
428	1
425	2
415	3
442	17
421	1
421	3
439	17
441	1
441	3
420	1
478	1
453	2
474	1
451	1
456	2
459	5
480	2
475	2
454	1
471	3
448	2
450	2
469	3
446	2
476	1
455	2
468	17
468	3
457	2
460	1
447	5
472	2
462	2
479	2
467	3
477	2
449	2
463	2
458	2
458	3
509	2
507	3
484	3
481	1
506	1
482	1
494	1
508	1
514	3
486	2
511	2
488	2
512	5
498	1
495	112
513	2
496	2
483	5
516	2
501	1
540	2
541	2
529	1
537	2
526	3
545	2
517	2
816	2
543	2
544	5
519	1
536	5
550	1
524	5
523	3
523	1
522	2
548	2
542	2
531	5
530	2
525	1
527	5
570	1
586	2
559	2
572	3
568	2
580	2
555	2
574	2
574	3
576	5
569	2
553	3
584	2
562	2
564	3
564	2
552	2
577	2
575	2
582	17
561	3
561	2
581	2
567	2
587	1
565	5
571	2
566	2
563	2
583	2
560	3
560	2
558	16
557	2
589	2
593	2
611	2
612	2
592	5
615	2
616	17
606	1
610	2
618	17
591	2
621	2
608	16
597	5
605	5
603	5
604	16
607	1
599	2
609	16
602	2
614	2
662	2
613	2
598	2
595	5
617	5
647	5
633	5
625	2
640	5
659	5
654	2
627	2
623	1
626	1
622	2
630	3
652	5
631	2
643	5
651	2
653	2
632	2
636	2
639	2
648	5
646	5
658	5
628	3
656	5
650	2
657	5
649	5
624	1
638	5
634	5
629	5
661	5
644	2
635	2
641	5
645	5
660	2
672	5
668	5
665	2
669	5
682	5
664	5
687	3
687	5
670	5
693	5
683	2
688	5
666	5
692	5
677	5
671	5
676	5
681	5
689	5
674	2
690	5
698	5
673	5
695	5
675	5
696	2
663	5
685	2
678	5
691	5
686	5
667	2
667	3
684	5
697	5
680	5
709	1
727	2
723	2
725	2
706	2
712	1
737	2
730	2
736	2
736	3
735	2
729	2
701	2
724	2
720	1
722	2
714	1
707	1
738	2
716	1
728	2
721	2
726	2
726	3
733	2
715	1
704	5
719	1
710	1
710	16
703	5
711	17
732	2
718	1
708	1
734	2
731	2
713	1
746	2
739	2
771	16
763	5
747	2
775	1
760	17
755	2
757	1
767	1
748	2
749	2
742	2
762	16
745	5
751	1
773	1
740	2
772	16
772	3
753	2
752	2
750	2
743	3
764	2
758	3
765	5
766	1
796	2
776	2
788	2
777	2
784	5
803	2
778	2
797	1
798	2
790	16
804	2
809	2
806	2
807	2
786	5
780	1
794	2
814	2
810	16
781	1
800	2
799	2
787	1
805	2
815	2
812	2
785	5
802	2
801	2
783	1
791	2
808	2
789	2
792	2
813	2
782	5
779	2
793	2
830	2
840	5
842	2
842	3
836	2
836	3
843	1
822	2
846	2
824	2
829	2
844	1
834	2
827	16
820	16
838	1
847	2
817	2
851	1
841	2
828	2
839	2
826	16
819	2
845	2
825	16
854	5
818	1
821	16
848	1
833	2
849	16
853	5
823	2
831	2
852	5
857	1
882	2
878	2
889	5
864	2
863	2
891	2
862	5
877	5
870	5
858	2
859	2
866	2
884	2
879	5
886	5
873	2
861	2
890	5
872	2
867	16
871	2
885	2
865	5
881	1
868	5
887	5
856	2
876	2
883	5
855	5
888	5
929	5
921	5
905	112
924	5
925	2
916	1
892	2
893	2
917	2
898	2
906	5
918	5
914	1
915	112
894	1
900	5
899	5
903	5
909	1
928	5
912	112
897	5
908	112
907	5
926	5
901	2
927	5
902	5
913	2
895	1
930	2
539	2
964	2
931	16
946	2
945	1
954	5
935	2
955	2
933	5
951	2
957	2
939	2
960	1
937	5
948	2
947	2
932	2
966	1
950	1
962	2
938	2
949	2
956	2
936	2
965	2
959	1
934	5
952	1
958	17
942	112
943	2
961	2
953	2
963	5
940	2
980	2
984	17
975	2
983	17
994	2
985	2
990	2
979	2
995	1
969	2
1000	1
987	3
988	16
971	2
986	2
996	1
970	1
1002	1
991	2
999	5
992	2
976	2
981	2
977	1
998	2
968	2
989	2
993	2
997	3
972	3
1013	2
1041	1
1010	2
1025	1
1024	2
1040	2
1012	3
1018	5
1016	5
1011	1
1033	2
1036	2
1019	3
1035	1
1017	2
1028	5
1032	3
1015	2
1020	1
1038	2
1014	3
1004	2
1022	1
1026	5
1037	1
1031	1
1027	1
1034	2
1006	1
1008	2
1029	2
1066	1
1051	2
1049	1
1059	2
1075	1
1073	1
1054	2
1052	2
1069	1
1071	1
1074	2
1064	2
1043	1
1067	2
1058	2
1046	2
1047	2
1070	1
1055	112
1068	2
1060	2
1063	2
1062	1
1061	2
1065	1
1042	2
1050	1
1048	2
1057	2
1218	2
1091	5
1097	2
1086	2
1092	1
1101	1
1081	2
1100	2
1108	16
1087	2
1077	1
1104	2
1103	2
1096	1
1093	2
1089	2
1088	1
1084	2
1105	2
1078	2
1080	2
1106	5
1094	2
1095	2
1090	1
1085	1
1083	2
1082	1
1099	2
1076	2
1079	1
1109	2
1137	2
1112	16
1123	1
1125	1
1121	1
1124	1
1120	2
1122	1
1134	2
1116	1
1131	2
1127	1
1135	2
1119	1
1113	2
1114	2
1111	2
1118	1
1128	5
1126	1
1132	2
1139	2
1136	2
1115	2
1133	16
1130	2
1138	5
1167	3
1152	16
1148	2
1154	1
1159	5
1156	2
1160	1
1146	1
1157	2
1169	16
1149	1
1162	16
1168	16
1163	16
1145	1
1147	2
1143	2
1151	2
1166	1
1155	1
1144	2
1165	2
1172	2
1153	16
1158	5
1164	1
1171	2
1150	2
250	5
1201	2
1173	2
1197	5
1178	2
1199	2
1179	2
1204	3
1182	2
1194	16
1205	1
1191	16
1185	1
1188	5
1203	2
1202	1
1208	17
1207	16
1209	2
1180	3
1192	16
1184	5
1181	2
1177	2
1183	2
1186	2
1237	1
1225	2
1217	2
1238	1
1227	2
1222	112
1235	1
1211	2
1215	1
1220	112
1240	1
1216	2
1236	1
1212	1
1224	2
1213	2
1213	3
1234	2
1233	2
1214	5
1219	2
1228	1
1242	2
1223	2
1230	1
1243	2
1239	1
1229	1
1244	1
1221	2
1268	2
1255	1
1263	16
1267	2
1257	5
1256	1
1245	2
1265	2
1247	1
1260	1
1276	2
1279	2
1262	16
1246	2
1259	2
1269	1
1274	1
1249	17
1250	2
1264	5
1252	2
1258	1
1253	5
1266	1
1278	3
978	5
642	5
473	3
860	1
1187	5
1285	112
896	5
538	1
919	112
1287	2
1291	1
1289	1
1294	2
1286	2
1282	3
1281	5
1284	1
1293	1
90	5
699	5
1273	2
1102	1
279	2
341	1
600	2
1140	2
393	2
811	1
1023	1
167	2
941	2
492	2
717	1
556	1
578	5
850	2
744	2
317	2
189	1
189	16
944	1
1117	1
445	2
1170	1
128	5
35	2
72	5
324	3
518	112
1007	3
11	112
1200	2
409	2
408	2
1021	2
1232	3
1232	1
1277	3
594	1
31	1
588	3
705	2
355	2
1141	2
875	2
1072	1
1001	2
146	3
499	3
225	3
1142	1
33	1
596	3
795	16
1044	1
493	2
110	2
329	16
452	1
452	3
426	1
379	3
118	1
289	3
384	2
384	3
911	5
1288	2
774	2
547	1
832	2
1193	16
30	1
182	2
1206	5
679	1
579	3
257	5
414	3
1110	16
215	2
741	3
330	3
330	112
375	112
41	1
41	3
370	1
655	3
655	5
3	5
1053	2
413	5
700	2
700	3
406	1
1196	3
378	112
1210	1
1241	1
546	3
973	3
53	1
554	3
485	3
1270	112
489	1
55	2
904	2
294	1
590	1
367	2
105	1
121	1
121	3
2	1
443	112
702	5
769	1
1129	3
1198	1
601	3
770	5
1009	1
1280	3
761	3
487	3
694	5
694	3
1056	2
227	3
490	5
920	112
1248	1
1261	3
21	112
246	3
338	16
202	16
534	16
29	1
332	2
263	3
119	5
119	3
1107	16
461	3
266	112
394	112
491	2
1283	5
1271	1
36	1
199	1
1254	1
585	3
435	2
302	3
982	2
982	3
69	16
69	3
532	5
309	5
368	5
422	5
94	1
1272	3
1272	2
52	1
1290	1
32	1
637	3
277	3
423	5
1195	3
252	3
1226	1
573	2
880	5
466	1
1045	2
967	1
4	1
502	2
1039	3
183	5
34	1
1003	1
104	3
1161	16
176	3
470	1
470	112
331	3
308	5
759	3
132	112
1251	17
500	2
922	5
88	2
54	2
232	3
869	2
179	3
109	1
109	3
109	112
300	2
264	3
307	5
211	2
515	3
404	3
1190	2
1190	3
1189	1
131	1
56	1
221	3
150	3
533	5
89	5
256	3
1	112
1175	3
756	5
1292	5
306	5
122	1
48	3
754	5
28	1
1176	3
412	112
520	1
419	3
503	1
910	2
304	2
1005	1
619	1
464	1
837	1
521	112
348	1
1030	1
366	112
510	3
1275	3
1275	2
1174	5
528	1
407	2
358	1
1098	1
551	1
293	1
1231	1
874	2
874	3
768	5
143	1
222	112
185	3
549	1
923	1
417	3
223	3
38	1
431	16
431	3
505	112
465	3
835	3
974	3
23	1
504	2
177	1
177	3
497	112
207	2
207	3
535	2
369	1
116	3
\.


--
-- Data for Name: songs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.songs (id, artist_id, anime_id, duration_seconds, lyrics, file_path, title, song_type, cover_path, season) FROM stdin;
2	2	2	355	[00:00.00] \n[00:01.63]Aa  Aa  Aa  Aa\n[00:04.80]Koi wo Shita no wa\n[00:11.09] \n[00:32.18]Ima furu kono ame tooku wa hareteiru\n[00:39.37]Dakara sugu ni aeru ne\n[00:44.10]Yameba kawaite soshite hoshi ga furu kara\n[00:52.67]Onegai\n[00:55.21]Ichimai ichimai fueru iro no\n[01:07.24]Chigau shashin mekuru you ni\n[01:19.14]Tsutaetakatta koto wa\n[01:27.70]Ima mo mukashi mo zutto onaji mama da yo\n[01:41.07]Darling\n[01:42.65]Mayowanu you aruiteyukeru\n[01:53.07]Tatta hitotsu no michishirube\n[02:06.94] \n[02:11.88]Nee mae muite atashi wa koko ni iru desho\n[02:18.85]Dakara mou nakanaide\n[02:23.63]Kokoro ga wareta toki mo\n[02:27.75]Tokubetsu na hibi wo kureta\n[02:34.10]Sasai ni kakechigaeta akairo\n[02:46.93]Ano hi no rouka no shiroiro\n[02:58.23] \n[02:58.79]Hajimete mo saigo mo ima mo\n[03:08.97]Mau hanabira ni kizami okuru yo\n[03:20.72]Darling\n[03:22.28]Ochiru ame ni utsuru futari\n[03:32.24]Sekai wa dare mo shiranai\n[03:44.66] \n[03:47.72]Koi wo shita no wa itsukara ka\n[03:53.36]Naita no wa nandome ka\n[03:56.83]Kazoeru to yoru ga akeru wa komaru na\n[04:07.46]Darling\n[04:12.26] \n[04:32.23]Tsutaetakatta koto wa\n[04:40.81]Ima mo mukashi mo zutto onaji mama da yo\n[04:54.39]Darling\n[04:55.80]Mayowanu you aruiteyukeru\n[05:06.01]Tatta hitotsu no michishirube\n	/audio/A Silent Voice ED Theme 「Koi wo Shita no wa」.mp3	Koi wo Shita no wa	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253816/covers/A_Silent_Voice_ED_Theme_Koi_wo_Shita_no_wa.jpg	1
13	13	13	192		/audio/Ah! My Goddess ED2 「Wing」.mp3	Wing	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251517/covers/Ah_My_Goddess_ED2_Wing.jpg	1
453	224	453	298		/audio/Josee, the Tiger and the Fish ED 「Ao no Waltz」.mp3	Ao no Waltz	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252532/covers/Josee_the_Tiger_and_the_Fish_ED_Ao_no_Waltz.jpg	1
456	456	456	335		/audio/Just Because ED 「behind」.mp3	behind	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252537/covers/Just_Because_ED_behind.jpg	1
507	507	505	269		/audio/Land of the Lustrous OP 「Kyoumen no Nami」.mp3	Kyoumen no Nami	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252599/covers/Land_of_the_Lustrous_OP_Kyoumen_no_Nami.jpg	1
598	167	595	200		/audio/Mob Psycho 100 Season 2 ED 3「Mabuta no Ura」.mp3	Mabuta no Ura	3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252525/covers/Mob_Psycho_100_Season_2_ED_3_Mabuta_no_Ura.jpg	1
622	622	621	277		/audio/My Senpai is Annoying OP 「Annoying! San San Wee.mp3	Annoying! San San Week!	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252550/covers/My_Senpai_is_Annoying_OP_Annoying_San_San_Week.jpg	1
627	627	627	300		/audio/Naruta OP9 「YURA YURA」.mp3	YURA YURA	OP9	https://res.cloudinary.com/ddc6silap/image/upload/v1773252545/covers/Naruta_OP9_YURA_YURA.jpg	1
638	638	627	282		/audio/Naruto ED5 「Ima made Nande mo」.mp3	Ima made Nande mo	ED5	https://res.cloudinary.com/ddc6silap/image/upload/v1773252587/covers/Naruto_ED5_Ima_made_Nande_mo.jpg	1
639	639	627	318		/audio/Naruto ED6 「Ryusei」.mp3	Ryusei	ED6	https://res.cloudinary.com/ddc6silap/image/upload/v1773252572/covers/Naruto_ED6_Ryusei.jpg	1
640	640	627	181		/audio/Naruto ED8 「Hajimete Kimi to Shabetta」.mp3	Hajimete Kimi to Shabetta	ED8	https://res.cloudinary.com/ddc6silap/image/upload/v1773252539/covers/Naruto_ED8_Hajimete_Kimi_to_Shabetta.jpg	1
645	145	627	93		/audio/Naruto OP4 「GO!!!」.mp3	GO!!!	OP4	https://res.cloudinary.com/ddc6silap/image/upload/v1773252519/covers/Naruto_OP4_GO.jpg	1
646	646	627	286		/audio/Naruto OP5 「Seishun Kyousoukyoku」.mp3	Seishun Kyousoukyoku	OP5	https://res.cloudinary.com/ddc6silap/image/upload/v1773252575/covers/Naruto_OP5_Seishun_Kyousoukyoku.jpg	1
651	651	627	223		/audio/Naruto Shippuden ED10 「MY ANSWER」.mp3	MY ANSWER	ED10	https://res.cloudinary.com/ddc6silap/image/upload/v1773252565/covers/Naruto_Shippuden_ED10_MY_ANSWER.jpg	1
652	652	627	242		/audio/Naruto Shippuden ED11 「Omae Dattanda」.mp3	Omae Dattanda	ED11	https://res.cloudinary.com/ddc6silap/image/upload/v1773252554/covers/Naruto_Shippuden_ED11_Omae_Dattanda.jpg	1
653	653	627	257		/audio/Naruto Shippuden ED12 「For You」.mp3	For You	ED12	https://res.cloudinary.com/ddc6silap/image/upload/v1773252566/covers/Naruto_Shippuden_ED12_For_You.jpg	1
656	656	627	354		/audio/Naruto Shippuden ED16 「Mayonaka No Orchestra」.mp3	Mayonaka No Orchestra	ED16	https://res.cloudinary.com/ddc6silap/image/upload/v1773252580/covers/Naruto_Shippuden_ED16_Mayonaka_No_Orchestra.jpg	1
657	650	627	237		/audio/Naruto Shippuden ED17 「FREEDOM」.mp3	FREEDOM	ED17	https://res.cloudinary.com/ddc6silap/image/upload/v1773252582/covers/Naruto_Shippuden_ED17_FREEDOM.jpg	1
660	660	627	249		/audio/Naruto Shippuden ED2 「Michi~To You All」.mp3	Michi~To You All	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252597/covers/Naruto_Shippuden_ED2_Michi_To_You_All.jpg	1
661	661	627	207		/audio/Naruto Shippuden ED20 「By My Side」.mp3	By My Side	ED20	https://res.cloudinary.com/ddc6silap/image/upload/v1773252591/covers/Naruto_Shippuden_ED20_By_My_Side.jpg	1
662	662	627	228		/audio/Naruto Shippuden ED21 「Cascade」.mp3	Cascade	ED21	https://res.cloudinary.com/ddc6silap/image/upload/v1773252522/covers/Naruto_Shippuden_ED21_Cascade.jpg	1
22	22	22	258		/audio/Akame ga Kill ED 「Konna Sekai, Shiritakunakatta.mp3	Konna Sekai, Shiritakunakatta	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251508/covers/Akame_ga_Kill_ED_Konna_Sekai_Shiritakunakatta.jpg	1
24	23	22	270		/audio/Akame ga Kill OP 「Skyreach」.mp3	Skyreach	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251513/covers/Akame_ga_Kill_OP_Skyreach.jpg	1
45	45	41	90		/audio/Arakawa Under the Bridge x Bridge OP2 「Kou sama.mp3	Kou sama, Go! Summer!	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251522/covers/Arakawa_Under_the_Bridge_x_Bridge_OP2_Kou_sama_Go_Summer.jpg	1
83	82	83	250		/audio/Bloom Into You ED2 「Suki, Igai no Kotoba de」.mp3	Suki, Igai no Kotoba de	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251529/covers/Bloom_Into_You_ED2_Suki_Igai_no_Kotoba_de.jpg	1
85	85	85	278		/audio/Boarding School Juliet ED 「Itsuka Sekai ga Kawa.mp3	Itsuka Sekai ga Kawaru made	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251534/covers/Boarding_School_Juliet_ED_Itsuka_Sekai_ga_Kawaru_made.jpg	1
537	537	532	259		/audio/Love, Chunibyo and Other Delusions Movie_ Rikka.mp3	Across the line	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252666/covers/Love_Chunibyo_and_Other_Delusions_Movie_Rikka_Version_OP_Across_the_line.jpg	1
541	539	539	242		/audio/Lovely Complex OP 「Kimi+Boku = Love_ 」.mp3	Kimi+Boku = Love? 	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252662/covers/Lovely_Complex_OP_Kimi_Boku_Love.jpg	1
663	663	627	307		/audio/Naruto Shippuden ED22 「Kono Koe Karashite」.mp3	Kono Koe Karashite	ED22	https://res.cloudinary.com/ddc6silap/image/upload/v1773252639/covers/Naruto_Shippuden_ED22_Kono_Koe_Karashite.jpg	1
667	667	627	281		/audio/Naruto Shippuden ED26 「Yume wo Daite Hajimari n.mp3	Yume wo Daite Hajimari no Crissroad	ED26	https://res.cloudinary.com/ddc6silap/image/upload/v1773252647/covers/Naruto_Shippuden_ED26_Yume_wo_Daite_Hajimari_no_Crissroad.jpg	1
675	145	627	256		/audio/Naruto Shippuden ED34 「Niji no Sora」.mp3	Niji no Sora	ED34	https://res.cloudinary.com/ddc6silap/image/upload/v1773252636/covers/Naruto_Shippuden_ED34_Niji_no_Sora.jpg	1
676	676	627	244		/audio/Naruto Shippuden ED35 「Trouble Maker」.mp3	Trouble Maker	ED35	https://res.cloudinary.com/ddc6silap/image/upload/v1773252620/covers/Naruto_Shippuden_ED35_Trouble_Maker.jpg	1
682	682	627	199		/audio/Naruto Shippuden ED40 「Zetsu Zetsu」.mp3	Zetsu Zetsu	ED40	https://res.cloudinary.com/ddc6silap/image/upload/v1773252604/covers/Naruto_Shippuden_ED40_Zetsu_Zetsu.jpg	1
683	683	627	332		/audio/Naruto Shippuden ED5 「Sunao na Niji」.mp3	Sunao na Niji	ED5	https://res.cloudinary.com/ddc6silap/image/upload/v1773252611/covers/Naruto_Shippuden_ED5_Sunao_na_Niji.jpg	1
687	687	627	276		/audio/Naruto Shippuden OP 「Hero_s Come Back」.mp3	Hero's Come Back	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252607/covers/Naruto_Shippuden_OP_Hero_s_Come_Back.jpg	1
689	689	627	142		/audio/Naruto Shippuden OP11 「Totsugeki Rock」.mp3	Totsugeki Rock	OP11	https://res.cloudinary.com/ddc6silap/image/upload/v1773252624/covers/Naruto_Shippuden_OP11_Totsugeki_Rock.jpg	1
691	306	627	263		/audio/Naruto Shippuden OP13 「Niwaka Ame Nimo Makezu」.mp3	Niwaka Ame Nimo Makezu	OP13	https://res.cloudinary.com/ddc6silap/image/upload/v1773252644/covers/Naruto_Shippuden_OP13_Niwaka_Ame_Nimo_Makezu.jpg	1
692	692	627	236		/audio/Naruto Shippuden OP14 「Tsuki no Ookisa」.mp3	Tsuki no Ookisa	OP14	https://res.cloudinary.com/ddc6silap/image/upload/v1773252616/covers/Naruto_Shippuden_OP14_Tsuki_no_Ookisa.jpg	1
696	307	627	279		/audio/Naruto Shippuden OP18 「LINE」.mp3	LINE	OP18	https://res.cloudinary.com/ddc6silap/image/upload/v1773252638/covers/Naruto_Shippuden_OP18_LINE.jpg	1
698	698	627	187		/audio/Naruto Shippuden OP2 「distance」.mp3	distance	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252631/covers/Naruto_Shippuden_OP2_distance.jpg	1
706	706	66	279		/audio/Nekomonogatari Black ED 「Kieru Daydream」.mp3	Kieru Daydream	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252653/covers/Nekomonogatari_Black_ED_Kieru_Daydream.jpg	1
707	707	66	268		/audio/Nekomonogatari Black OP 「perfect slumbers」.mp3	perfect slumbers	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252676/covers/Nekomonogatari_Black_OP_perfect_slumbers.jpg	1
721	721	708	235		/audio/Nichijou OP 「Hyadain no Kakakata」.mp3	Hyadain no Kakakata	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252682/covers/Nichijou_OP_Hyadain_no_Kakakata.jpg	1
722	722	708	252		/audio/Nichijou OP2 「Hyadain no Joujou Yuujou」.mp3	Hyadain no Joujou Yuujou	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252673/covers/Nichijou_OP2_Hyadain_no_Joujou_Yuujou.jpg	1
729	729	723	90		/audio/Nisekoi ED7 「Taisetsu no Tsukurikata」.mp3	Taisetsu no Tsukurikata	ED7	https://res.cloudinary.com/ddc6silap/image/upload/v1773252657/covers/Nisekoi_ED7_Taisetsu_no_Tsukurikata.jpg	1
733	723	723	271		/audio/Nisekoi S2 ED3 「Sleep zzz...」.mp3	Sleep zzz...	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252684/covers/Nisekoi_S2_ED3_Sleep_zzz....jpg	2
49	49	46	241		/audio/Arifureta S2 OP 「Daylight」.mp3	Daylight	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251527/covers/Arifureta_S2_OP_Daylight.jpg	2
59	59	59	208		/audio/Baka and Test ED 「Baka Go Home」.mp3	Baka Go Home	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251524/covers/Baka_and_Test_ED_Baka_Go_Home.jpg	1
81	81	79	264		/audio/Black Bullet OP 「black bullet」.mp3	black bullet	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251532/covers/Black_Bullet_OP_black_bullet.jpg	1
11	11	11	270	[ti:After the Rain ED 「Ref:rain」]\n[ar:Aimer]\n[al:After the Rain]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:29.83]\n[00:07.63]Raining natsu no gogo ni touriame kasa no shita\n[00:13.68]Kissing nureta hoho ni sotto kuchizuketa\n[00:20.97]Ano kisetsu ni mada kogarete iru\n[00:32.31]Miss you mado no soto ni toozakaru keshiki-tachi\n[00:38.33]Breezing niji ga mieta sugu ni kie sou de\n[00:45.42]Ame ashita wa furanakereba ii\n[00:55.73]Nanimo te ni tsukazu ni uwanosora no hibi\n[01:01.81]Nothing but you're the part of me\n[01:06.94]Mada tarinakute\n[01:10.00]Mada kienakute\n[01:12.88]Kasaneta tenohira kara osanasa ga\n[01:19.04]What a good thing we lose?\n[01:22.08]What a bad thing we knew\n[01:25.47]Sonna FUREIZU ni nureteku ame no naka\n[01:31.48]Tada tarinakute\n[01:34.58]Mada ienakute\n[01:37.68]Kazoeta hi no yume kara sayonara ga\n[01:43.73]What a good thing we lose?\n[01:46.81]What a bad thing we knew\n[01:49.96]Furerarezu ni iretara waraeta kana?\n[01:58.43]Calling shiroi iki ga maiagaru sora no shita\n[02:04.47]Freezing tsuyoi kaze ni sukoshi kajikanda te to\n[02:12.92]Yowasa wo POKETTO no naka ni\n[02:21.88]Doko wo miwatashite mo tourisugita hibi\n[02:27.92]Nothing but you're the part of me\n[02:33.05]Mata furetakute\n[02:36.07]Tada mabushikute\n[02:39.13]Omowazu me wo sorashita yasashisa ni\n[02:45.38]I wanna sleep in your feel\n[02:48.38]I wanna see you in the deep\n[02:51.44]Sonna FUREIZU wo narabeta uta wo ima\n[02:57.60]Ano kaerimichi BASU ni yurarete\n[03:03.71]Kanau hazu mo nai you na yume wo mita\n[03:09.92]I wanna sleep in your feel\n[03:12.99]I wanna see you in the deep\n[03:16.12]Kurikaesu kisetsu ni narenai mama\n[03:24.44]Mou sukoshi kurai otona de iretara nante ieta darou?\n[03:39.27]Mada tarinakute\n[03:42.33]Mada kienakute\n[03:45.28]Kasaneta tenohira kara osanasa ga\n[03:51.41]What a good thing we lose?\n[03:54.57]What a bad thing we knew\n[03:57.68]Sonna FUREIZU ni nureteku ame no naka\n[04:03.76]Tada tarinakute\n[04:06.88]Mada ienakute\n[04:09.94]Kazoeta hi no yume kara sayonara ga\n[04:16.06]What a good thing we lose?\n[04:19.15]What a bad thing we knew\n[04:22.29]Furerarezu ni iretara waraeta kana?	/audio/After the Rain ED 「Ref_rain」.mp3	Ref:rain	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253635/covers/After_the_Rain_ED_Refrain.jpg	1
214	28	208	277		/audio/Demon Slayer_ Mugen Train Ending Song 「Homura」.mp3	Homura	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773251538/covers/Demon_Slayer_Mugen_Train_Ending_Song_Homura.jpg	1
703	222	627	233		/audio/Naruto Shippuden OP7 「Toumei Datta Sekai」.mp3	Toumei Datta Sekai	OP7	https://res.cloudinary.com/ddc6silap/image/upload/v1773252692/covers/Naruto_Shippuden_OP7_Toumei_Datta_Sekai.jpg	1
708	708	708	252		/audio/Nichijou ED 「Zzz」.mp3	Zzz	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252701/covers/Nichijou_ED_Zzz.jpg	1
719	708	708	90		/audio/Nichijou ED8 「Ano Subarashii Ai o Mou Ichido」.mp3	Ano Subarashii Ai o Mou Ichido	ED8	https://res.cloudinary.com/ddc6silap/image/upload/v1773252689/covers/Nichijou_ED8_Ano_Subarashii_Ai_o_Mou_Ichido.jpg	1
731	112	723	256		/audio/Nisekoi OP2 「STEP」.mp3	STEP	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252705/covers/Nisekoi_OP2_STEP.jpg	1
740	740	740	277		/audio/No Game no Life ED 「Oracion」.mp3	Oracion	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252743/covers/No_Game_no_Life_ED_Oracion.jpg	1
747	746	746	336		/audio/Non Non Biyori Movie Vacation ED 「Omoide」.mp3	Omoide	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252712/covers/Non_Non_Biyori_Movie_Vacation_ED_Omoide.jpg	1
752	130	746	250		/audio/Non Non Biyori Repeat OP 「Kodama Kotodama」.mp3	Kodama Kotodama	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252747/covers/Non_Non_Biyori_Repeat_OP_Kodama_Kotodama.jpg	1
757	757	757	137	[00:00.00] \n[00:21.45]Itsumo, itsumo\n[00:26.62]Boku ga, kimi wo\n[00:31.80]Mite te, ageru kara\n[00:36.99]Anshin shite, oyasumi\n[01:03.44]Kizu tsuke au koto ni\n[01:13.74]Narete shimatta, kono sekai\n[01:24.32]Soko de bokurawa, umare\n[01:34.14]Sodatta\n[01:36.97] 	/audio/Now and Then, Here and There ED 「Komoriuta...」.mp3	Komoriuta...	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252726/covers/Now_and_Then_Here_and_There_ED_Komoriuta....jpg	1
760	760	759	209		/audio/Odd Taxi ED2 「Kabe no Mukou ni Waraigoe wo Kiki.mp3	Kabe no Mukou ni Waraigoe wo Kikimashita ka	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252715/covers/Odd_Taxi_ED2_Kabe_no_Mukou_ni_Waraigoe_wo_Kikimashita_ka.jpg	1
762	762	762	90		/audio/Okusama wa Joshikousei ED 「Ai no Koneko」.mp3	Ai no Koneko	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252736/covers/Okusama_wa_Joshikousei_ED_Ai_no_Koneko.jpg	1
771	771	771	172		/audio/Onipan! ED 「Onipapapan! Pan!」.mp3	Onipapapan! Pan!	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252710/covers/Onipan_ED_Onipapapan_Pan.jpg	1
780	780	608	300		/audio/My Bride is a Mermaid ED 「Ashita e no Hikari」.mp3	Ashita e no Hikari	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252786/covers/My_Bride_is_a_Mermaid_ED_Ashita_e_no_Hikari.jpg	1
790	790	762	91		/audio/Okusama wa Joshikousei OP 「Love Love! Chu Chu!」.mp3	Love Love! Chu Chu!	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252778/covers/Okusama_wa_Joshikousei_OP_Love_Love_Chu_Chu.jpg	1
797	794	794	90		/audio/Oreimo ED12 「Tadaima」.mp3	Tadaima	ED12	https://res.cloudinary.com/ddc6silap/image/upload/v1773252769/covers/Oreimo_ED12_Tadaima.jpg	1
800	800	794	91		/audio/Oreimo ED15 「Shokuzai no Serenade」.mp3	Shokuzai no Serenade	ED15	https://res.cloudinary.com/ddc6silap/image/upload/v1773252791/covers/Oreimo_ED15_Shokuzai_no_Serenade.jpg	1
807	807	794	90		/audio/Oreimo ED8 「KAMERON DAUGHTER」.mp3	KAMERON DAUGHTER	ED8	https://res.cloudinary.com/ddc6silap/image/upload/v1773252783/covers/Oreimo_ED8_KAMERON_DAUGHTER.jpg	1
620	620	619	\N		/audio/My Roommate is a Cat OP 「Unknown World」.mp3	Unknown World	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252774/covers/My_Roommate_is_a_Cat_OP_Unknown_World.jpg	1
568	568	568	261		/audio/Mashiroiro Symphony ED 「Suisai Candy」.mp3	Suisai Candy	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252723/covers/Mashiroiro_Symphony_ED_Suisai_Candy.jpg	1
589	581	483	271		/audio/Knight_s _ Magic OP 「Hello! My World!!」.mp3	Hello! My World!!	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252770/covers/Knight_s_Magic_OP_Hello_My_World.jpg	1
19	19	18	234		/audio/Aho-Girl OP 「Zenryoku☆Summer」.mp3	Zenryoku☆Summer	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251543/covers/Aho-Girl_OP_Zenryoku_Summer.jpg	1
21	20	20	368	[00:00.00] \n[00:16.05]Kieru hikoukigumo bokutachi wa miokutta\n[00:24.61]Mabushikute nigeta itsudatte yowakute\n[00:31.61]Ano hi kara kawarazu\n[00:35.93]Itsumademo kawarazu ni irarenakatta koto\n[00:43.71]Kuyashikute yubi wo hanasu\n[00:54.25]Ano tori wa mada umaku tobenai kedo\n[01:01.45]Itsuka wa kaze wo kitte shiru\n[01:09.03]Todokanai basho ga mada tooku ni aru\n[01:16.98]Negai dake himete mitsumeteru\n[01:24.39]Kodomotachi wa natsu no senro aruku\n[01:32.39]Fuku kaze ni suashi wo sarashite\n[01:40.22]Tooku ni wa osanakatta hibi wo\n[01:47.94]Ryoute ni wa tobitatsu kibou wo\n[01:54.71]Kieru hikoukigumo oikakete oikakete\n[02:02.99]Kono oka wo koeta ano hi kara kawarazu itsumademo\n[02:11.54]Massugu ni bokutachi wa aru you ni\n[02:18.76]Watatsumi no you na tsuyosa wo mamoreru yo kitto\n[02:47.98]Ano sora wo mawaru fuusha no hane-tachi wa\n[02:55.15]Itsumademo onaji yume miru\n[03:02.73]Todokanai basho wo zutto mitsumeteru\n[03:11.04]Negai wo himeta tori no yume wo\n[03:18.24]Furikaeru yaketa senro oou\n[03:26.42]Nyuudougumo katachi wo kaete mo\n[03:34.18]Bokura wa oboete ite dou ka\n[03:42.08]Kisetsu ga nokoshita kinou wo\n[03:47.50]Kieru hikoukigumo oikakete oikakete\n[03:56.05]Hayasugiru aizu futari waraidashiteru itsumademo\n[04:04.94]Massugu ni manazashi wa aru you ni\n[04:12.10]Ase ga nijinde mo te wo hanasanai yo zutto\n[04:23.68]Kieru hikoukigumo bokutachi wa miokutta\n[04:31.56]Mabushikute nigeta itsudatte yowakute\n[04:38.38]Ano hi kara kawarazu\n[04:42.81]Itsumademo kawarazu ni irarenakatta koto\n[04:50.78]Kuyashikute yubi wo hanasu\n[05:03.05]	/audio/Air OP 「Tori no Uta」.mp3	Tori no Uta	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253859/covers/Air_OP_Tori_no_Uta.jpg	1
26	26	26	233		/audio/Amagi Brilliant Park ED 「Elementario de Aimasho.mp3	Elementario de Aimashou	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251542/covers/Amagi_Brilliant_Park_ED_Elementario_de_Aimashou.jpg	1
783	66	627	364		/audio/Naruto Shippuden ED14 「Utakata Hanabi」.mp3	Utakata Hanabi	ED14	https://res.cloudinary.com/ddc6silap/image/upload/v1773252802/covers/Naruto_Shippuden_ED14_Utakata_Hanabi.jpg	1
785	72	627	286		/audio/Naruto Shippuden ED9 「Shinkokyuu」.mp3	Shinkokyuu	ED9	https://res.cloudinary.com/ddc6silap/image/upload/v1773252798/covers/Naruto_Shippuden_ED9_Shinkokyuu.jpg	1
1288	1254	1288	301	[00:00.00] \r\n[00:24.38]aa kono mama bokutachi no koe ga sekai no hajikko made kieru koto naku\r\n[00:35.49]todoitari shitara ii nonina\r\n[00:40.36]soshitara nee futari de donna kotoba o hanatou\r\n[00:46.10]kieru koto nai yakusoku futari de se-no de iou\r\n[00:52.99] \r\n[01:03.22]aa negattara nanigashika ga kanau sono kotoba no me o mou mirenakunatta nowa\r\n[01:10.33]iitai itsu kara darou ka naniyue darou ka\r\n[01:13.95]aa ame no yamu masa ni sono kirema to niji no shuppatsuten shuuten to\r\n[01:19.84]kono inochi hateru basho ni nanika ga aru atte itsumo iihatteita\r\n[01:25.47] \r\n[01:30.25]itsuka ikou zenseimei mo mitou mikaitaku no\r\n[01:35.42]kanjou ni haitacchi shite jikan ni kisu o\r\n[01:39.90]gojigen ni karakawarete soredemo kimi o miru yo\r\n[01:45.93]mata hajimemashite no aizu o kimeyou\r\n[01:51.65]kimi no na o ima oikakeru yo\r\n[01:55.09] \r\n[02:05.26]aa negattara nanigashika ga kanau sono kotoba no me o mou mirenakunatta nowa\r\n[02:12.31]iitai itsu kara darou ka naniyue darou ka\r\n[02:15.94]aa ame no yamu masa ni sono kirema to niji no shuppatsuten shuuten to\r\n[02:21.75]kono inochi hateru basho ni nanika ga aru atte itsumo iihatteita\r\n[02:27.43] \r\n[02:37.68]itsuka ikou zenseimei mo mitou mikaitaku no\r\n[02:42.99]kanjou ni haitacchi shite jikan ni kisu o\r\n[02:47.54]gojigen ni karakawarete soredemo kimi o miru yo\r\n[02:53.31]mata hajimemashite no aizu o kimeyou\r\n[02:58.99]kimi no na o ima oikakeru yo\r\n[03:02.24] \r\n[03:24.97]aa kono mama bokutachi no koe ga sekai no hajikko made kieru koto naku\r\n[03:36.17]todoitari shitara ii nonina\r\n[03:40.95]soshitara nee futari de donna kotoba o hanatou\r\n[03:46.55]kieru koto nai yakusoku futari de se-no de iou\r\n[03:53.45] \r\n[04:03.88]itsuka ikou zenseimei mo mitou mikaitaku no\r\n[04:09.23]kanjou ni haitacchi shite jikan ni kisu o\r\n[04:13.55]gojigen ni karakawarete soredemo kimi o miru yo\r\n[04:19.59]mata hajimemashite no aizu o kimeyou\r\n[04:25.21]kimi no na o ima oikakeru yo\r\n[04:28.50]	/audio/Your Name Opening 「Yumetourou」.mp3	Yumetourou	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253711/covers/Your_Name_Opening_Yumetourou.jpg	1
787	787	708	90		/audio/Nichijou ED5 「Kaijuu no Ballad」.mp3	Kaijuu no Ballad	ED5	https://res.cloudinary.com/ddc6silap/image/upload/v1773252794/covers/Nichijou_ED5_Kaijuu_no_Ballad.jpg	1
789	130	746	321		/audio/Non Non Biyori Movie Vacation  OP 「Ao no Rakugaki」.mp3	Ao no Rakugaki	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252806/covers/Non_Non_Biyori_Movie_Vacation_OP_Ao_no_Rakugaki.jpg	1
8	8	6	234		/audio/Accel World OP 「Chase the world」.mp3	Chase the world	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251548/covers/Accel_World_OP_Chase_the_world.jpg	1
1300	1310	1310	159	\N	/audio/audio_file-b7c0a573-1773403334615.mp3	Jar of hearts 	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773403335/covers/crop-1773403281733.webp	1
203	203	202	271		/audio/DearS OP 「Love Slave」.mp3	Love Slave	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251552/covers/DearS_OP_Love_Slave.jpg	1
216	130	215	276		/audio/Devil is a Part Timer ED2 「Star Chart」.mp3	Star Chart	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251558/covers/Devil_is_a_Part_Timer_ED2_Star_Chart.jpg	1
219	219	219	286		/audio/Domestic Girlfriend ED 「Wagamama」.mp3	Wagamama	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251557/covers/Domestic_Girlfriend_ED_Wagamama.jpg	1
665	665	627	218		/audio/Naruto Shippuden ED24 「Sayonara Memory」.mp3	Sayonara Memory	ED24	https://res.cloudinary.com/ddc6silap/image/upload/v1773252885/covers/Naruto_Shippuden_ED24_Sayonara_Memory.jpg	1
782	782	627	259		/audio/Naruto ED7 「Mountain A Go Go Too」.mp3	Mountain A Go Go Too	ED7	https://res.cloudinary.com/ddc6silap/image/upload/v1773252810/covers/Naruto_ED7_Mountain_A_Go_Go_Too.jpg	1
820	799	794	91		/audio/Oreimo S2 ED6 「Monochrome☆HAPPY DAY」.mp3	Monochrome☆HAPPY DAY	ED6	https://res.cloudinary.com/ddc6silap/image/upload/v1773252825/covers/Oreimo_S2_ED6_Monochrome_HAPPY_DAY.jpg	2
821	821	794	91		/audio/Oreimo S2 ED7 「Kyou mo Shiawase」.mp3	Kyou mo Shiawase	ED7	https://res.cloudinary.com/ddc6silap/image/upload/v1773252845/covers/Oreimo_S2_ED7_Kyou_mo_Shiawase.jpg	2
825	825	794	90		/audio/Oreimo S2 OP2 「Hoshikuzu Cosplay☆Witch! Desu! O.mp3	Hoshikuzu Cosplay☆Witch! Desu! Omega!	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252840/covers/Oreimo_S2_OP2_Hoshikuzu_Cosplay_Witch_Desu_Omega.jpg	2
828	111	828	222		/audio/Overlord ED 「L.L.L.」.mp3	L.L.L.	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252833/covers/Overlord_ED_L.L.L..jpg	1
829	829	828	238	[00:00.00] \n[00:02.58]Kotae wa doko e sagashite\n[00:08.10]Where's my soul?\n[00:10.07] \n[00:19.12]It's like a fear warui yume no you de\n[00:21.42]Mezametemo All I've got is bones\n[00:23.97]I'm in a panic? Get out, hurry\n[00:26.10]Oh, there're mysteries and miseries\n[00:29.02]Dead or alive hazama ni yurarete\n[00:31.44]Samayoeba Right to left to hell\n[00:34.03]Ronri no shoutai emo no shoutai\n[00:35.95]Odoru 1,2,3 steps on this dark stage\n[00:39.01]Raise your flag, march on, fight\n[00:41.14]Kamen no fuchi e te wo kakedo tada hone ga naru nomi\n[00:44.83]Wars and swords, tears and blood\n[00:46.62]Afuru chikara ga fui ni waraidashita\n[00:51.83]Kotae wa doko e sagashite\n[00:57.31]Where's my soul? Where's my heart?\n[00:59.74]Riaru ni nomareteku\n[01:02.47]Don't hesitate, go this way\n[01:07.42]Wakaranai kamawanai\n[01:09.70]Magai mono furuttemo\n[01:13.09]Tada kono sekai wo ikinuke yo\n[01:17.67]Aa nakushita kanashimi ga mata uzuiteku...\n[01:22.64]Misery-World\n[01:25.92] \n[01:33.43]Shikkoku no sora tsumetaku Midnight\n[01:35.79]Yo no yami wa Always drive me mad\n[01:38.49]Where is that star now? I found the star now\n[01:40.48]But it's so beautiful, I'm so doubtful\n[01:43.56]Tomadoi no naka yadoru Desire\n[01:45.83]Miwataseba Sky and land and sea\n[01:48.68]Hai e no izanai zettai no shihai\n[01:50.52]Nobore 1.2.3 steps to the royal throne\n[01:53.53]Cast a spell, call them up\n[01:55.56]Zetsubou wo yobe munashisa ni yoi heitachi ga mau\n[01:59.23]Shouts and barks, grief and death\n[02:01.19]Ononoku mono ni mujihi wo furiorose\n[02:06.30]Mujou wo yuke abaite\n[02:11.79]Break it all, take it all\n[02:14.25]Te ni irero subete wo\n[02:17.01]I just pray, or just play?\n[02:21.73]Sou janai tomaranai\n[02:24.31]Kienai ginen idaite\n[02:27.66]Nakushita mono wo torimodose yo\n[02:32.13]Aa sore sae oou kyouki ni mamiretemo\n[02:37.16]Crazy world\n[02:38.74] \n[02:48.11]Mienai kokoro to tashika ni aru karada\n[02:57.83]Shinjitai mono wo onore ni chikae\n[03:09.52]Kotae wo sutete hashire\n[03:15.06]Where's my soul? Where's my heart?\n[03:17.56]Sono ishi wo shinjite\n[03:19.91]Don't hesitate, go this way\n[03:25.03]Wakaranai kamawanai\n[03:27.70]Yume demo genjitsu demo\n[03:30.79]Tada kono sekai wo ikinukou\n[03:35.25]Saa dokomade demo kono ashi ga yuku kagiri\n[03:40.22]Misery-World\n[03:43.83] \n	/audio/Overlord OP 「Clattanoia」.mp3	Clattanoia	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252819/covers/Overlord_OP_Clattanoia.jpg	1
833	111	828	230		/audio/Overlord S3 OP 「VORACITY」.mp3	VORACITY	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252848/covers/Overlord_S3_OP_VORACITY.jpg	3
834	834	828	236		/audio/Overlord S4 ED 「No Man's Dawn」.mp3	No Man's Dawn	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252822/covers/Overlord_S4_ED_No_Man_s_Dawn.jpg	4
839	839	839	89		/audio/Peach Boy Riverside ED 「Yoru wo Koeru Ashioto」.mp3	Yoru wo Koeru Ashioto	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252834/covers/Peach_Boy_Riverside_ED_Yoru_wo_Koeru_Ashioto.jpg	1
841	841	841	220		/audio/Perfect Blue ED 「Season」.mp3	Season	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252832/covers/Perfect_Blue_ED_Season.jpg	1
843	843	843	174		/audio/Plastic Memories ED 「Again _ Again 」.mp3	Again & Again 	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252814/covers/Plastic_Memories_ED_Again_Again.jpg	1
851	848	848	267		/audio/Princess Connect! Re_Dive S2 ED 「Tabidachi no K.mp3	Tabidachi no Kisetsu	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252830/covers/Princess_Connect_ReDive_S2_ED_Tabidachi_no_Kisetsu.jpg	2
852	852	852	246		/audio/Prison School ED 「Tsumibukaki Oretachi no Sanka.mp3	Tsumibukaki Oretachi no Sanka	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252856/covers/Prison_School_ED_Tsumibukaki_Oretachi_no_Sanka.jpg	1
853	852	852	98		/audio/Prison School OP 「Ai no Prison」.mp3	Ai no Prison	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252851/covers/Prison_School_OP_Ai_no_Prison.jpg	1
859	856	856	220		/audio/Quintessential Quintuplets OP 「Gotoubun no Kimo.mp3	Gotoubun no Kimochi	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252869/covers/Quintessential_Quintuplets_OP_Gotoubun_no_Kimochi.jpg	1
861	856	856	240		/audio/Quintessential Quintuplets S2 OP 「Gotoubun no K.mp3	Gotoubun no Katachi	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252880/covers/Quintessential_Quintuplets_S2_OP_Gotoubun_no_Katachi.jpg	2
867	867	866	247		/audio/Rec OP 「Cheer! Makkana Kimochi」.mp3	Cheer! Makkana Kimochi	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252888/covers/Rec_OP_Cheer_Makkana_Kimochi.jpg	1
870	870	869	264		/audio/Redo of Healer OP 「Zankoko na Yume to Nemure 」.mp3	Zankoko na Yume to Nemure 	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252866/covers/Redo_of_Healer_OP_Zankoko_na_Yume_to_Nemure.jpg	1
886	886	886	213		/audio/Remake our Life! ED 「Kanousei」.mp3	Kanousei	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252875/covers/Remake_our_Life_ED_Kanousei.jpg	1
891	12	888	218		/audio/Rent A Girlfriend OP 「Himitsu Koigokoro」.mp3	Himitsu Koigokoro	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252860/covers/Rent_A_Girlfriend_OP_Himitsu_Koigokoro.jpg	1
20	20	20	332		/audio/Air ED 「Farewell」.mp3	Farewell	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251549/covers/Air_ED_Farewell.jpg	1
190	188	184	274		/audio/Date A Live S2 OP 「Trust in you」.mp3	Trust in you	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251553/covers/Date_A_Live_S2_OP_Trust_in_you.jpg	2
247	247	245	223		/audio/Eighty Six OP 「 3-pun 29-byou 」.mp3	 3-pun 29-byou 	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251560/covers/Eighty_Six_OP_3-pun_29-byou.jpg	1
395	385	385	280		/audio/Higurashi Sotsu OP 「Analogy」.mp3	Analogy	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251570/covers/Higurashi_Sotsu_OP_Analogy.jpg	1
709	708	708	94		/audio/Nichijou ED10 「Aogeba Toutoshi」.mp3	Aogeba Toutoshi	ED10	https://res.cloudinary.com/ddc6silap/image/upload/v1773252932/covers/Nichijou_ED10_Aogeba_Toutoshi.jpg	1
725	725	723	95		/audio/Nisekoi ED3 「TRICK BOX」.mp3	TRICK BOX	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252938/covers/Nisekoi_ED3_TRICK_BOX.jpg	1
855	855	854	269		/audio/Problem Children Are Coming From Another World,.mp3	To Be Continued?	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252899/covers/Problem_Children_Are_Coming_From_Another_World_Aren_t_They_ED_To_Be_Continued.jpg	1
865	862	862	231		/audio/Real Girl S2 OP 「Futari Nara」.mp3	Futari Nara	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252892/covers/Real_Girl_S2_OP_Futari_Nara.jpg	2
887	887	886	278		/audio/Remake Our Life! OP 「Koko kara Saki wa Uta ni N.mp3	Koko kara Saki wa Uta ni Naranai	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252897/covers/Remake_Our_Life_OP_Koko_kara_Saki_wa_Uta_ni_Naranai.jpg	1
892	892	888	205		/audio/Rent A Girlfriend S2 ED  「Ienai 」.mp3	Ienai 	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252904/covers/Rent_A_Girlfriend_S2_ED_Ienai.jpg	2
897	120	893	315		/audio/Rewrite OP2 「End of the World」.mp3	End of the World	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252928/covers/Rewrite_OP2_End_of_the_World.jpg	1
898	895	893	325		/audio/Rewrite S2 ED2 「Instincts」.mp3	Instincts	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252908/covers/Rewrite_S2_ED2_Instincts.jpg	2
906	111	904	222	対　　㨀　　⸀　　崀 ਀嬀　　㨀㈀㜀⸀　㐀崀吀栀攀 琀椀挀欀攀琀 椀猀 愀氀氀 琀栀愀琀 䤀 栀愀瘀攀 氀漀猀琀਀嬀　　㨀㌀　⸀㐀㔀崀䨀甀甀戀甀渀 渀愀 猀漀甀猀栀椀琀猀甀 琀漀 猀栀漀甀琀愀椀 猀愀爀攀਀嬀　　㨀㌀㌀⸀㜀㌀崀吀漀搀愀礀ᤀ猠 瀀爀漀最爀愀洀 椀猀㨀	/audio/Re_Zero EP14 Insert Song 「Theater D」.mp3	Theater D	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773252910/covers/ReZero_EP14_Insert_Song_Theater_D.jpg	1
909	58	904	242		/audio/Re_Zero Memory Snow movie ED Theme 「White White.mp3	White White Snow	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773252923/covers/ReZero_Memory_Snow_movie_ED_Theme_White_White_Snow.jpg	1
925	925	925	241		/audio/Robotic_Notes ED 「Umi Kaze No Brave」.mp3	Umi Kaze No Brave	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252902/covers/Robotic_Notes_ED_Umi_Kaze_No_Brave.jpg	1
926	926	925	89	[00:00.00] \n[00:13.52]surechigau kotoba no ura ni tozasareta kokoro no kagi\n[00:24.12]kimi to iu furagu kaijo ga egao sukueru no nara\n[00:34.59]natsu no kaze izanau hakuchuu no sukooru hachou shinkuro\n[00:45.10]romanchikku mitai ni ki no kiita kotoba mo\n[00:50.12]mitsukaranai kedo aozora wo mezasu kara...\n[00:59.62]bokutachi wa hitotsu ni nareru tomadoi no namida mo yume mo\n[01:09.22]shinjitsu ni hikiyoserareru mono\n[01:15.99]sore wa itoshisugiru mahou no kiiwaado\n[01:24.28] 	/audio/Robotic_Notes OP 「Junjou Spectra」.mp3	Junjou Spectra	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252941/covers/Robotic_Notes_OP_Junjou_Spectra.jpg	1
931	928	928	236		/audio/Rosario+Vampire S2 OP 「DISCOTHEQUE」.mp3	DISCOTHEQUE	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252952/covers/Rosario_Vampire_S2_OP_DISCOTHEQUE.jpg	2
937	111	934	228		/audio/Saga of Tanya the Evil OP 「JINGLE JUNGLE」.mp3	JINGLE JUNGLE	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252970/covers/Saga_of_Tanya_the_Evil_OP_JINGLE_JUNGLE.jpg	1
939	28	939	294		/audio/SAO 2 ED 「No More Time Machine」.mp3	No More Time Machine	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252966/covers/SAO_2_ED_No_More_Time_Machine.jpg	1
947	945	939	249		/audio/SAO Ordinal Scale OST 「Break Beat Bark!」.mp3	Break Beat Bark!	OST	https://res.cloudinary.com/ddc6silap/image/upload/v1773252973/covers/SAO_Ordinal_Scale_OST_Break_Beat_Bark.jpg	1
954	954	953	219		/audio/Sayonara Zetsubou Sensei OP 「Hito toshite Jiku .mp3	Hito toshite Jiku ga Bureteiru	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252958/covers/Sayonara_Zetsubou_Sensei_OP_Hito_toshite_Jiku_ga_Bureteiru.jpg	1
955	955	953	239		/audio/Sayonara Zetsubou Sensei OP2 「Gouin ni Mai Yeah.mp3	Gouin ni Mai Yeah	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252961/covers/Sayonara_Zetsubou_Sensei_OP2_Gouin_ni_Mai_Yeah.jpg	1
1038	1038	939	265		/audio/Sword art Online ED2 「Overfly」.mp3	Overfly	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252957/covers/Sword_art_Online_ED2_Overfly.jpg	1
249	249	245	258		/audio/Eighty Six S2 ED2 「Alchemilla」.mp3	Alchemilla	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251562/covers/Eighty_Six_S2_ED2_Alchemilla.jpg	2
382	382	325	266		/audio/God Eater OP 「Feed」.mp3	Feed	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251571/covers/God_Eater_OP_Feed.jpg	1
391	388	385	259		/audio/Higurashi Rei ED 「Manazashi」.mp3	Manazashi	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251572/covers/Higurashi_Rei_ED_Manazashi.jpg	1
28	28	27	360	[00:00.00] \r\n[00:17.40]Kao o awashitara kenka shite bakari\r\n[00:25.39]Sore mo i omoide datta\r\n[00:32.14]Kimi ga oshietekureta da mou kowaku nai\r\n[00:40.21]Donna fujiyuu demo shiawase wa tsukameru dakara\r\n[00:52.72] \r\n[00:56.28]Hitori demo yuku yo tatoe tsurakute mo\r\n[01:04.09]Kimi to mita yume wa kanarazu motteku yo\r\n[01:12.20]Kimi to ga yokatta hoka no dare demo nai\r\n[01:20.17]Demo mezameta asa kimi wa inai nda ne\r\n[01:29.64] \r\n[01:45.41]Zutto asondereru sonna ki ga shiteta\r\n[01:53.06]Ki ga shiteita dake wakatteru\r\n[02:00.32]Umaretekita koto mou koukai wa shinai\r\n[02:08.13]Matsuri no ato mitai samishii kedo sorosoro ikou\r\n[02:20.83] \r\n[02:24.38]Doko made mo yuku yo koko de shitta koto\r\n[02:32.00]Shiawase to iu yume o kanaetemiseru yo\r\n[02:40.18]Kimi to hanarete mo donna ni tooku natte mo\r\n[02:47.97]Atarashii asa ni atashi wa ikiru yo\r\n[02:56.59] \r\n[03:32.18]Hitori demo yuku yo shinitaku natte mo\r\n[03:40.10]Koe ga kikoeru yo shinde wa ikenai to\r\n[03:48.21]Tatoe tsurakute mo samishisa ni naite mo\r\n[03:56.12]Kokoro no oku ni wa nukumori o kanjiru yo\r\n[04:04.12]Megutte nagarete toki wa utsuroi da\r\n[04:12.26]Mou nani ga atta ka omoidasenai kedo\r\n[04:20.12]Me o tojitemireba dareka no waraigoe\r\n[04:28.20]Nazeka sore ga ima ichiban no takaramono\r\n	/audio/Angel Beats Insert Song 「Ichiban no Takaramono」.mp3	Ichiban no Takaramono	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773254089/covers/Angel_Beats_Insert_Song_Ichiban_no_Takaramono.jpg	1
291	291	289	223		/audio/Fire Force OP 「Inferno」.mp3	Inferno	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251575/covers/Fire_Force_OP_Inferno.jpg	1
297	295	295	308		/audio/Full Metal Panic! S2 ED 「Mouichido Kimi ni Aita.mp3	Mouichido Kimi ni Aitai	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251573/covers/Full_Metal_Panic_S2_ED_Mouichido_Kimi_ni_Aitai.jpg	2
429	429	427	91		/audio/Inu x Boku SS ED3 「one way」.mp3	one way	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773251580/covers/Inu_x_Boku_SS_ED3_one_way.jpg	1
434	434	433	219		/audio/Invaders of the Rokujoma!_ OP 「Koukan win-win M.mp3	Koukan win-win Mujouken	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251582/covers/Invaders_of_the_Rokujoma_OP_Koukan_win-win_Mujouken.jpg	1
739	69	723	247		/audio/Nisekoi S2 OP2 「Magical ☆ Styling」.mp3	Magical ☆ Styling	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252990/covers/Nisekoi_S2_OP2_Magical_Styling.jpg	2
796	796	794	90		/audio/Oreimo ED11 「AKIHABARA Dance Now!!」.mp3	AKIHABARA Dance Now!!	ED11	https://res.cloudinary.com/ddc6silap/image/upload/v1773253066/covers/Oreimo_ED11_AKIHABARA_Dance_Now.jpg	1
942	359	939	290		/audio/SAO Alicization EP19,24 「Niji no kanatani」.mp3	Niji no kanatani	24	https://res.cloudinary.com/ddc6silap/image/upload/v1773253000/covers/SAO_Alicization_EP19_24_Niji_no_kanatani.jpg	1
949	95	939	273		/audio/SAO_ Alicization War of Underworld S2 ED 「I Wil.mp3	I Will...	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252983/covers/SAO_Alicization_War_of_Underworld_S2_ED_I_Will....jpg	2
953	953	953	222		/audio/Sayonara Zetsubou Sensei ED 「Zessei Bijin」.mp3	Zessei Bijin	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253005/covers/Sayonara_Zetsubou_Sensei_ED_Zessei_Bijin.jpg	1
962	256	962	299		/audio/Scum_s Wish ED 「Heikousen」.mp3	Heikousen	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252979/covers/Scum_s_Wish_ED_Heikousen.jpg	1
965	965	964	256		/audio/Seirei Gensouki OP 「New story」.mp3	New story	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252987/covers/Seirei_Gensouki_OP_New_story.jpg	1
970	79	968	250		/audio/Seraph of the End_ Battle in Nagoya ED 「Orarion.mp3	Orarion	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253025/covers/Seraph_of_the_End_Battle_in_Nagoya_ED_Orarion.jpg	1
981	981	979	268		/audio/Shiki OP2 「Calendula Requiem」.mp3	Calendula Requiem	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253041/covers/Shiki_OP2_Calendula_Requiem.jpg	1
985	985	985	312		/audio/Shirobako ED 「Animetic Love Letter」.mp3	Animetic Love Letter	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253010/covers/Shirobako_ED_Animetic_Love_Letter.jpg	1
986	986	985	277		/audio/Shirobako ED2 「Platinum Jet」.mp3	Platinum Jet	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253021/covers/Shirobako_ED2_Platinum_Jet.jpg	1
987	987	985	92		/audio/Shirobako ED3 「Yama Harinezumi Andes Chucky」.mp3	Yama Harinezumi Andes Chucky	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253017/covers/Shirobako_ED3_Yama_Harinezumi_Andes_Chucky.jpg	1
991	581	985	261		/audio/Shirobako the Movie ED 「Hoshi wo Atsumete」.mp3	Hoshi wo Atsumete	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253028/covers/Shirobako_the_Movie_ED_Hoshi_wo_Atsumete.jpg	1
995	995	995	319		/audio/Sing Yesterday for Me ED 「Kago no Naka ni Tori」.mp3	Kago no Naka ni Tori	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253014/covers/Sing_Yesterday_for_Me_ED_Kago_no_Naka_ni_Tori.jpg	1
997	997	995	90		/audio/Sing Yesterday for Me ED3 「Yesterday wa Utatte」.mp3	Yesterday wa Utatte	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253057/covers/Sing_Yesterday_for_Me_ED3_Yesterday_wa_Utatte.jpg	1
998	373	998	272		/audio/Skeleton Knight in Another World ED 「Bokura ga .mp3	Bokura ga Orokadante Dare ga Itta	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253047/covers/Skeleton_Knight_in_Another_World_ED_Bokura_ga_Orokadante_Dare_ga_Itta.jpg	1
999	999	998	223		/audio/Skeleton Knight in Another World OP 「Aah, Wage .mp3	Aah, Wage Rouman no Michi yo	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253033/covers/Skeleton_Knight_in_Another_World_OP_Aah_Wage_Rouman_no_Michi_yo.jpg	1
1011	926	1009	335		/audio/Steins Gate 0 EP8 ED 「LYRA」.mp3	LYRA	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253079/covers/Steins_Gate_0_EP8_ED_LYRA.jpg	1
1018	1018	893	251		/audio/Rewrite S2 OP 「Last Desire」.mp3	Last Desire	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253073/covers/Rewrite_S2_OP_Last_Desire.jpg	2
1019	1019	1019	217		/audio/Ride Your Wave ED 「Brand New Story」.mp3	Brand New Story	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253087/covers/Ride_Your_Wave_ED_Brand_New_Story.jpg	1
30	30	30	296	[00:00.00] \n[00:01.25]Kimi to natsu no owari shourai no yume\n[00:05.12]Ooki na kibou wasurenai\n[00:08.26]Juunen go no hachigatsu mata deaeru no wo shinjite\n[00:15.65]Saikou no omoide wo\n[00:23.47] \n[00:41.17]Deai wa futto shita shukan kaerimichi no kousaten de\n[00:48.22]Koe wo kakete kureta ne, "Issho ni kaerou"\n[00:55.49]Boku wa terekusasou ni\n[00:58.95]Kaban de kao wo kakushi nagara\n[01:02.64]Hontou wa totemo totemo ureshikatta yo\n[01:09.85]Aa Hanabi ga yozora kirei ni saite\n[01:14.65]Chotto setsunaku\n[01:16.95]Aa Kaze ga jikan to tomo ni nagareru\n[01:23.65]Ureshikutte tanoshikutte\n[01:27.39]Bouken mo iroiro shita ne\n[01:30.65]Futari no himitsu no kichi no naka\n[01:37.73]Kimi to natsu no owari shourai no yume\n[01:41.81]Ooki na kibou wasurenai\n[01:44.95]Juunen go no hachigatsu mata deaeru no wo shinjite\n[01:52.14]Kimi ga saigo made kokoro kara\n[01:55.35]"Arigatou", sakende 'ta koto shitte 'ta yo\n[01:59.23]Namida wo koraete egao de sayonara\n[02:03.15]Setsunai yo ne Saikou no omoide wo\n[02:14.33]Aa Natsuyasumi mo ato sukoshi de owatchau kara\n[02:21.34]Aa Taiyou to tsuki nakayoku shite\n[02:28.27]Kanashikutte samishikute\n[02:31.69]Kenka mo iroiro shita ne\n[02:35.28]Futari no himitsu no kichi no naka\n[02:42.30]Kimi ga saigo made kokoro kara\n[02:45.54]"Arigatou", sakende 'ta koto shitte 'ta yo\n[02:49.47]Namida wo koraete egao de sayounara\n[02:53.25]Setsunai yo ne Saikou no omoide wo\n[03:04.47]Totsuzen no tenkou de dou shiyou mo naku\n[03:25.43]Tegami kaku yo Denwa mo suru yo\n[03:28.98]Wasurenaide ne Boku no koto wo\n[03:32.65]Itsu made mo futari no kichi no naka\n[03:39.77]Kimi to natsu no owari Zutto hanashite\n[03:43.62]Yuuhi wo mite kara hoshi wo nagame\n[03:46.79]Kimi no hoho wo nagareta namida wa zutto wasurenai\n[03:53.95]Kimi ga saigo made ookiku te wo\n[03:57.16]Futte kureta koto kitto wasurenai\n[04:01.01]Da kara kou shite yume no naka de zutto eien ni\n[04:08.28]Kimi to natsu no owari shourai no yume\n[04:12.07]Ooki na kibou wasurenai\n[04:15.36]Juunen go no hachigatsu mata deaeru no wo shinjite\n[04:22.51]Kimi ga saigo made kokoro kara\n[04:25.92]"Arigatou", sakende 'ta koto shitte 'ta yo\n[04:29.59]Namida wo koraete egao de sayonara\n[04:33.60]Setsunai yo ne Saikou no omoide wo\n[04:44.28]Saikou no omoide wo\n	/audio/Anohana ED 「Secret Base」.mp3	Secret Base	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253728/covers/Anohana_ED_Secret_Base.jpg	1
1004	1002	1002	355		/audio/Spice and Wolf S2 ED 「Perfect World」.mp3	Perfect World	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253108/covers/Spice_and_Wolf_S2_ED_Perfect_World.jpg	2
1008	1008	1007	211		/audio/Spy x Family OP 「Mixed Nuts」.mp3	Mixed Nuts	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253124/covers/Spy_x_Family_OP_Mixed_Nuts.jpg	1
1015	1015	856	244		/audio/Quintessential Quintuplets ED 「Sign」.mp3	Sign	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253100/covers/Quintessential_Quintuplets_ED_Sign.jpg	1
1026	1024	1009	277		/audio/Steins Gate EP23 ED 「Sky Clad Observer」.mp3	Sky Clad Observer	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253112/covers/Steins_Gate_EP23_ED_Sky_Clad_Observer.jpg	1
1027	385	1009	321		/audio/Steins Gate Movie ED Theme 「Itsumo Kono Basho d.mp3	Itsumo Kono Basho de	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253119/covers/Steins_Gate_Movie_ED_Theme_Itsumo_Kono_Basho_de.jpg	1
1028	1024	1009	257		/audio/Steins Gate OP 「Hacking to the Gate」.mp3	Hacking to the Gate	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253095/covers/Steins_Gate_OP_Hacking_to_the_Gate.jpg	1
1048	1048	939	226		/audio/Sword Art Online_ Alicization OP2 「Resister」.mp3	Resister	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253195/covers/Sword_Art_Online_Alicization_OP2_Resister.jpg	1
1052	881	1052	269		/audio/takt op.Destiny ED 「SYMPHONIA」.mp3	SYMPHONIA	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253137/covers/takt_op.Destiny_ED_SYMPHONIA.jpg	1
1054	1054	1054	255		/audio/Tamako Love Story ED 「Principle」.mp3	Principle	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253135/covers/Tamako_Love_Story_ED_Principle.jpg	1
1058	1054	1054	268		/audio/Tamako Market OP 「Dramatic Market Ride」.mp3	Dramatic Market Ride	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253155/covers/Tamako_Market_OP_Dramatic_Market_Ride.jpg	1
1059	571	1059	270	[ti:Tanaka Kun is always Listless ED 「BON-BON」]\n[ar:CooRie]\n[al:Tanaka Kun is always Listless]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:30.04]\n[00:00.30]makuake ni sawagu mune no RIZUMU\n[00:12.63]yokubari na kimochi tsuredashite\n[00:20.21]hajimari no, hajimari.\n[00:33.83]BON-BON\n[00:34.78]itsumo no itazura neko mitai\n[00:39.62]shizentai de wagamama shitai\n[00:44.84]kimama MYUUJIKKU\n[00:47.74]kossori norinori de\n[00:50.13]kuusou nara tokui kamo\n[00:55.49]iwayuru shiawase\n[01:01.26]sore tte naani?\n[01:06.57]suki na koto tokoton yatte mite\n[01:12.27]wakaru no kanaa\n[01:17.51]BON-BON\n[01:18.18]DORAMACHIKKU "sokosoko" ga kibou\n[01:23.01]POJITIBU CHIKETTO mottetai ne\n[01:28.32]seiippai nara seikai nano kana\n[01:33.79]POOKAAFEISU wa nigate desu\n[01:39.29]guruguru shichau ne\n[01:41.97]BON-BON KUBBIDYU\n[01:44.42]mou ikkai\n[01:47.38]BON-BON KUBBIDYU\n[01:55.50]itsu kara hibiiteta?\n[01:57.84]yawaraka na MERODI wa rairara\n[02:06.48]hanauta shinkokyuu\n[02:08.76]akubi namida harari\n[02:17.38]me ga sametara kyou ni natteta\n[02:23.35]sonna kurikaeshi\n[02:28.38]yoteidoori ja umaranainda yo...\n[02:33.68]a~a\n[02:39.22]BON-BON\n[02:44.39]BOBOBO BON-BON\n[02:50.41]BON-BON sore kara?\n[02:55.12]BOBBO BON-BON\n[03:02.88]yokubari de in janai?\n[03:08.21]kakko tsuketekou\n[03:13.22]SENCHIMENTARU moyou no kumo ni notte\n[03:18.72]ashita made hitoyasumi mo iin janai\n[03:26.82]BON-BON\n[03:27.59]soko yuku itazura neko mitai\n[03:32.21]shizentai de wagamama shitai\n[03:37.62]kimama MYUUJIKKU\n[03:40.42]kossori norinori de\n[03:43.09]suki na mono wa suki nanda tte\n[03:48.26]icchatta nara\n[03:50.98]mou tomaranai yo\n[03:54.10]BON-BON KUBBIDYU\n[03:56.38]mou ikkai\n[03:59.18]BON-BON KUBBIDYU\n[04:01.73] 	/audio/Tanaka Kun is always Listless ED 「BON-BON」.mp3	BON-BON	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253128/covers/Tanaka_Kun_is_always_Listless_ED_BON-BON.jpg	1
1062	1061	1061	313		/audio/Teasing Master Takagi San ED2 「AM11_00」.mp3	AM11:00	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253185/covers/Teasing_Master_Takagi_San_ED2_AM1100.jpg	1
1064	1061	1061	222		/audio/Teasing Master Takagi San ED4 「Kaze Fukeba Koi」.mp3	Kaze Fukeba Koi	ED4	https://res.cloudinary.com/ddc6silap/image/upload/v1773253147/covers/Teasing_Master_Takagi_San_ED4_Kaze_Fukeba_Koi.jpg	1
1065	1061	1061	247		/audio/Teasing Master Takagi San ED5 「Chiisana Koi no .mp3	Chiisana Koi no Uta	ED5	https://res.cloudinary.com/ddc6silap/image/upload/v1773253189/covers/Teasing_Master_Takagi_San_ED5_Chiisana_Koi_no_Uta.jpg	1
1068	447	1061	271		/audio/Teasing Master Takagi San OP 「Iwanai kedo ne」.mp3	Iwanai kedo ne	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253177/covers/Teasing_Master_Takagi_San_OP_Iwanai_kedo_ne.jpg	1
1070	1061	1061	321		/audio/Teasing Master Takagi San S2 ED2 「Konayuki」.mp3	Konayuki	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253173/covers/Teasing_Master_Takagi_San_S2_ED2_Konayuki.jpg	2
1071	1061	1061	270		/audio/Teasing Master Takagi San S2 ED3 「Kiseki」.mp3	Kiseki	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253142/covers/Teasing_Master_Takagi_San_S2_ED3_Kiseki.jpg	2
1077	1061	1061	215		/audio/Teasing Master Takagi San S3 ED 「Yume de Aetara.mp3	Yume de Aetara	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253217/covers/Teasing_Master_Takagi_San_S3_ED_Yume_de_Aetara.jpg	3
1081	1061	1061	166		/audio/Teasing Master Takagi San S3 ED6 「Santa Claus i.mp3	Santa Claus is Coming to Town	ED6	https://res.cloudinary.com/ddc6silap/image/upload/v1773253207/covers/Teasing_Master_Takagi_San_S3_ED6_Santa_Claus_is_Coming_to_Town.jpg	3
1092	1092	1092	226		/audio/The Ancient Magus Bride ED 「Wa -cycle-」.mp3	Wa -cycle-	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253202/covers/The_Ancient_Magus_Bride_ED_Wa_-cycle-.jpg	1
840	840	839	240		/audio/Peach Boy Riverside OP 「Dark spiral journey」.mp3	Dark spiral journey	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253162/covers/Peach_Boy_Riverside_OP_Dark_spiral_journey.jpg	1
846	58	846	235		/audio/Police in a Pod ED 「Change」.mp3	Change	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253168/covers/Police_in_a_Pod_ED_Change.png	1
32	32	30	236	[00:00.00] \n[00:06.84]Dear Love...\n[00:09.31]Your charms alone are beautiful\n[00:13.66]Can you be my dear love\n[00:17.68]I'll hold your hands I'll hold your arms\n[00:21.91]'Til the end of time Will you be mine\n[00:28.37]This love is climbing over sunrise\n[00:34.23]Over the moon slides\n[00:38.49]So when the wind blows\n[00:42.63]I'll seal this love\n[00:45.25]Until the end of time...\n[00:50.14] \n[00:56.82]Dear Love...\n[00:59.41]Your charms alone are beautiful\n[01:03.73]Can you be my dear love\n[01:07.67]I've come to know that chances\n[01:11.44]Fall into the sand\n[01:16.11]Please understand\n[01:18.43]You've brought the girl inside of me\n[01:24.49]Inside of me...\n[01:30.05] \n[01:55.28]Dear Love...\n[01:57.77]Your charms alone are beautiful\n[02:02.05]Can you be my dear love\n[02:06.13]I'll hold your hands I'll hold your arms\n[02:10.35]'Til the end of time Will you be mine\n[02:16.72]This love is climbing over sunrise\n[02:22.82]Over the moon slides\n[02:26.99]So when the wind blows\n[02:31.18]I'll seal this love\n[02:33.50]Until the end of time...\n[02:39.59] \n[02:45.29]Dear Love...\n[02:47.81]Your charms alone are beautiful\n[02:52.24]Can you be my dear love\n[02:56.23]I've come to know that chances\n[02:59.96]Fall into the sand\n[03:04.41]Please understand\n[03:06.91]You've brought the girl inside of me\n[03:12.96]Inside of me...\n[03:18.86] \n	/audio/Anohana Movie ED Theme 「Dear Love」.mp3	Dear Love	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253908/covers/Anohana_Movie_ED_Theme_Dear_Love.jpg	1
36	36	36	350	[00:00.00] \n[00:10.56]Yuudachi nokotteiru machi no naka  sore ja mata ne to chiisaku furu yo\n[00:21.30]Kaisatsu no saki, me de oikakete  kitai-doori ni wa naka naka ne\n[00:32.00]Chiisa na akari de mitasareteku  hitorikiri de yokeru mizutamari\n[00:42.86]Nandaka omotteta yori mou hitotsu  jibun katte ni wa narenai ne\n[00:53.69]Nanika ga kowarete shimai sou de\n[01:03.16]Mata kyou mo sugite yuku\n[01:10.05]REERU wa kimi wo hakonde yuku kara\n[01:19.55]Itsumo onaji miakita kaerimichi\n[01:28.88]Matometa kotoba  tanjun na no ni na\n[01:38.24]Itsumo umaku ienai no wa nande darou  nande darou\n[01:52.37] \n[02:01.12]"Tatoe kimazuku natte shimatte mo\n[02:06.35]Mata tsukurinaoseba ii hazu sa\n[02:11.74]Nani mo hajimatteinai kara ne"\n[02:17.32]Mou hitori no boku ga iikikaseru\n[02:22.67] \n[02:44.80]Hiraku mae ni kotae awase\n[02:50.15]Ookiku naru fumikiri no oto\n[02:55.46]Sawagu  sawagu mune no naka wo\n[03:00.92]Miseru koto ga dekiru no nara dou naru'n darou?\n[03:13.09] \n[03:16.80]Okubyou dakedo samenai kokoro\n[03:26.09]Norisugoshite kizukunda\n[03:31.27]Kyou mo mata\n[03:35.71]REERU wa kimi wo hakonde yuku kara\n[03:45.13]Itsumo onaji miakita kaerimichi\n[03:54.60]Matometa kotoba  tanjun na no ni na\n[04:03.96]Itsumo umaku ienai no wa nande darou  nande darou\n[04:20.08] \n	/audio/Ao Haru Ride ED 「Blue」.mp3	Blue	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253878/covers/Ao_Haru_Ride_ED_Blue.jpg	1
97	97	97	203		/audio/Bocchi the Rock! ED 「Distortion!!」.mp3	Distortion!!	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251596/covers/Bocchi_the_Rock_ED_Distortion.jpg	1
102	102	102	272		/audio/Bofuri ED 「Play the world」.mp3	Play the world	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251595/covers/Bofuri_ED_Play_the_world.jpg	1
198	198	197	261		/audio/Deadman Wonderland OP 「One Reason」.mp3	One Reason	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251674/covers/Deadman_Wonderland_OP_One_Reason.jpg	1
889	464	888	235		/audio/Rent A Girlfriend ED2 「First Drop」.mp3	First Drop	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253244/covers/Rent_A_Girlfriend_ED2_First_Drop.jpg	1
1078	1061	1061	261		/audio/Teasing Master Takagi San S3 ED2 「Over Drive」.mp3	Over Drive	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253237/covers/Teasing_Master_Takagi_San_S3_ED2_Over_Drive.jpg	3
1082	1061	1061	329		/audio/Teasing Master Takagi San S3 ED7 「Snow Magic Fa.mp3	Snow Magic Fantasy	ED7	https://res.cloudinary.com/ddc6silap/image/upload/v1773253258/covers/Teasing_Master_Takagi_San_S3_ED7_Snow_Magic_Fantasy.jpg	3
1084	447	1061	277		/audio/Teasing master Takagi san S3 OP 「Massugu」.mp3	Massugu	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253234/covers/Teasing_master_Takagi_san_S3_OP_Massugu.jpg	3
1089	1089	1087	86		/audio/Texhnolyze OP 「Guardian Angel 」.mp3	Guardian Angel (Xavier's Edit 	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253230/covers/Texhnolyze_OP_Guardian_Angel_Xavier_s_Edit.jpg	1
1095	1095	1092	100		/audio/The Ancient Magus_ Bride ED3 「The Legend of _Th.mp3	The Legend of "The Ancient Magus Bride"	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253251/covers/The_Ancient_Magus_Bride_ED3_The_Legend_of_The_Ancient_Magus_Bride.jpg	1
1103	1103	1103	247		/audio/The Duke of Death and His Maid ED 「Nocturne」.mp3	Nocturne	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253225/covers/The_Duke_of_Death_and_His_Maid_ED_Nocturne.jpg	1
1106	1106	1105	176		/audio/The Dungeon of Black Company OP 「Shimi」.mp3	Shimi	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253246/covers/The_Dungeon_of_Black_Company_OP_Shimi.png	1
1111	1109	1107	315		/audio/The Familiar of Zero S3 OP 「YOU_RE THE ONE」.mp3	YOU'RE THE ONE	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253291/covers/The_Familiar_of_Zero_S3_OP_YOU_RE_THE_ONE.jpg	3
1119	279	1119	311		/audio/The Garden of Sinners_ Oblivion Recording ED 「f.mp3	fairytale	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253285/covers/The_Garden_of_Sinners_Oblivion_Recording_ED_fairytale.jpg	1
1124	279	1119	324		/audio/The Garden of Sinners_ The Hollow Shrine ED 「Ar.mp3	Aria	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253271/covers/The_Garden_of_Sinners_The_Hollow_Shrine_ED_Aria.jpg	1
1127	1127	1127	263		/audio/The Girl Who Leapt Time Through Time ED 「Garnet.mp3	Garnet	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253281/covers/The_Girl_Who_Leapt_Time_Through_Time_ED_Garnet.jpg	1
1134	362	361	253		/audio/The Melancholy of Haruhi Suzumiya OP2 「Bouken D.mp3	Bouken Desho Desho?	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253274/covers/The_Melancholy_of_Haruhi_Suzumiya_OP2_Bouken_Desho_Desho.jpg	1
1136	362	361	271		/audio/The Melancholy of Haruhi Suzumiya S2 OP 「Super .mp3	Super Driver	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253297/covers/The_Melancholy_of_Haruhi_Suzumiya_S2_OP_Super_Driver.jpg	2
1191	70	1191	90		/audio/Toradora ED 「Vanilla Salt」.mp3	Vanilla Salt	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251586/covers/Toradora_ED_Vanilla_Salt.jpg	1
40	40	39	185	[00:00.00] \n[00:06.02]Wakannai koto ō-sugi\n[00:08.99]'wakarō to shiteru jiten nansensu'\n[00:11.91]Kimi no kotoba, muzukashī\n[00:14.65]Kimi no miryoku mo wandārando\n[00:17.87]Keshi gomu ka pen o kashitara\n[00:20.79]Kimi to ashita mo shabereru kara\n[00:23.73]Takusan no nakami no pen keisu\n[00:26.69]Kyōshitsu no sumi de hachikireru\n[00:31.32]Chaimu ga nattaraai ni iku ne\n[00:37.25]Muchū ni sasete\n[00:39.05]A. i. a. i. a\n[00:41.62](se-no)\n[00:42.51]Hyaku kara hajimaru kaunto\n[00:45.26]Kimi ni chikazukeru rimitto (Ah Ah Ah)\n[00:51.09]Jitsu ni tanjun meikai na kokoro\n[00:54.78]Zero ni chikai daritsu de\n[00:57.73]Seishun no uchi ni inukeru ka!? (Ah Ah Ah)\n[01:03.15]Jitsu ni muzukashī boku-ra no kankei\n[01:06.99]WONDER WONDER\n[01:08.03]WONDERFUL WONDER\n[01:13.14]Nō auto. wan tsū\n[01:14.51]Koshi tantan to nerau kono sutairu\n[01:19.31]Nō dauto kitto\n[01:20.75]Ikeru ki ga shiteru naze ka Chō shiteru no\n[01:25.94]Chaimu ga nattaraai ni iku ne\n[01:31.90]Fushigi no kuni no Arisu kurai ni sa\n[01:37.96]Saiko na kimi ga terewarai suru\n[01:43.98]Memoriaru shōri\n[01:45.87]Agete miseru n da zettai\n[01:48.56]A. i. a. i. a\n[01:51.55]Hyaku kara hajimaru kaunto\n[01:54.22]Koi no kyū na akuserareishon\n[01:57.30]A. i. a. i. a\n[01:59.80]Mō atomodori nante dekinai\n[02:03.19]Hyaku kara hajimaru kaunto\n[02:06.17]Kimi ni chikazukeru rimitto (Ah Ah Ah)\n[02:11.98]Jitsu ni tanjun meikai na kokoro\n[02:15.37]Zero ni chikai daritsu de\n[02:18.26]Seishun no uchi ni inukeru ka!? (Ah Ah Ah)\n[02:23.72]Jitsu ni muzukashī boku-ra no kankei\n[02:27.48](Hyaku kara hajimaru kaunto\n[02:33.37]Kimi ni chikazukeru rimitto)\n[02:39.49]Nō auto. wan tsū de nerau\n[02:42.80]Nō dauto kono sutairu\n[02:45.92]Nō auto. wan tsū de nerau\n[02:48.83]Nō dauto kono sutairu\n[02:51.55]WONDER WONDER\n[02:52.70]WONDERFUL WONDER	/audio/Ao-chan Can_t Study OP 「Wonderful Wonder」.mp3	Wonderful Wonder	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254191/covers/Ao-chan_Can_t_Study_OP_Wonderful_Wonder.jpg	1
99	97	97	227		/audio/Bocchi the Rock! ED3 「Nani ga Warui」.mp3	Nani ga Warui	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773251600/covers/Bocchi_the_Rock_ED3_Nani_ga_Warui.jpg	1
125	125	123	155		/audio/Chobits ED3 「Katakoto no Koi」.mp3	Katakoto no Koi	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773251607/covers/Chobits_ED3_Katakoto_no_Koi.jpg	1
141	141	94	267		/audio/Code Geass ED3 「Innocent Days」.mp3	Innocent Days	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773251606/covers/Code_Geass_ED3_Innocent_Days.jpg	1
147	147	94	185		/audio/Code Geass OP2 「Kaidoku Funou」.mp3	Kaidoku Funou	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251604/covers/Code_Geass_OP2_Kaidoku_Funou.jpg	1
196	196	184	272		/audio/Date A Live_ Nightmare or Queen ED 「Precious」.mp3	Precious	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251686/covers/Date_A_Live_Nightmare_or_Queen_ED_Precious.jpg	1
206	206	204	253		/audio/Death Note OP 「What_s up People」.mp3	What's up People	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251678/covers/Death_Note_OP_What_s_up_People.jpg	1
399	399	396	216		/audio/Hinamatsuri OP 「Distance」.mp3	Distance	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251609/covers/Hinamatsuri_OP_Distance.jpg	1
1133	1133	361	202		/audio/The Melancholy of Haruhi Suzumiya OP 「Koi no Mi.mp3	Koi no Mikuru Densetsu 	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253301/covers/The_Melancholy_of_Haruhi_Suzumiya_OP_Koi_no_Mikuru_Densetsu.jpg	1
1138	1138	1137	292		/audio/The Misfit of Demon King Academy OP 「Seikai Fus.mp3	Seikai Fuseikai	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253308/covers/The_Misfit_of_Demon_King_Academy_OP_Seikai_Fuseikai.jpg	1
1146	1146	1146	334		/audio/The Place Promises in Our Early Days ED Theme 「.mp3	Kimi no Koe	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253324/covers/The_Place_Promises_in_Our_Early_Days_ED_Theme_Kimi_no_Koe.jpg	1
1149	1149	1147	323		/audio/The Promised Neverland OST 「Isabella’s Lullaby」.mp3	Isabella’s Lullaby	OST	https://res.cloudinary.com/ddc6silap/image/upload/v1773253332/covers/The_Promised_Neverland_OST_Isabella_s_Lullaby.jpg	1
1152	496	1152	267		/audio/The Ryuo_s Work is Never Done! ED 「Mamoritai Mo.mp3	Mamoritai Mono no Tame ni	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253310/covers/The_Ryuo_s_Work_is_Never_Done_ED_Mamoritai_Mono_no_Tame_ni.jpg	1
1159	1159	1158	192		/audio/The Way of the Househusband OP 「Shufu no Michi」.mp3	Shufu no Michi	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253317/covers/The_Way_of_the_Househusband_OP_Shufu_no_Michi.jpg	1
1164	1164	1161	99		/audio/The World God Only Knows ED8 「Shuuseki Kairo no.mp3	Shuuseki Kairo no Yume Tabibito	ED8	https://res.cloudinary.com/ddc6silap/image/upload/v1773253369/covers/The_World_God_Only_Knows_ED8_Shuuseki_Kairo_no_Yume_Tabibito.jpg	1
1168	1168	1168	244		/audio/The _Hentai_ Prince and the Stony Cat ED 「Baby .mp3	Baby Sweet Berry Love	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253338/covers/The_Hentai_Prince_and_the_Stony_Cat_ED_Baby_Sweet_Berry_Love.jpg	1
1178	250	1175	339		/audio/Tokyo Ghoul Re_ ED 「Kisetsu wa Tsugitsugi Shind.mp3	Kisetsu wa Tsugitsugi Shindeiku	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253376/covers/Tokyo_Ghoul_Re_ED_Kisetsu_wa_Tsugitsugi_Shindeiku.jpg	1
1202	1202	1092	272		/audio/The Ancient Magus' Bride OP2 「You」.mp3	Tsuki no mou Hanbun	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253405/covers/The_Ancient_Magus_Bride_ED2_Tsuki_no_mou_Hanbun.jpg	1
1203	1109	1203	247		/audio/The Familiar of Zero OP 「First Kiss」.mp3	First Kiss	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253403/covers/The_Familiar_of_Zero_OP_First_Kiss.jpg	1
1204	279	1116	263		/audio/The Garden of Sinners_ Overlooking View ED 「obl.mp3	oblivious	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253383/covers/The_Garden_of_Sinners_Overlooking_View_ED_oblivious.jpg	1
1205	307	627	335		/audio/The Last_ Naruto the Movie ED 「Hoshi no Utsuwa」.mp3	Hoshi no Utsuwa	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253390/covers/The_Last_Naruto_the_Movie_ED_Hoshi_no_Utsuwa.jpg	1
1207	1207	1161	262		/audio/The World God Only Knows ED5 「Koi no Shirushi」.mp3	Koi no Shirushi	ED5	https://res.cloudinary.com/ddc6silap/image/upload/v1773253410/covers/The_World_God_Only_Knows_ED5_Koi_no_Shirushi.jpg	1
101	97	97	205		/audio/Bocchi the Rock! OP 「Seishun Complex」.mp3	Seishun Complex	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251598/covers/Bocchi_the_Rock_OP_Seishun_Complex.jpg	1
52	52	52	294	[00:00.00] \n[00:22.25]yozora ni oyogu tsuki datte\n[00:27.86]te wo nobaseba todoku no\n[00:32.49] \n[00:33.17]sotto furetemita atatakakute\n[00:38.82]jinwari suikomareta\n[00:43.17] \n[00:44.13]fueteku ashiato mado kara miru keshiki mo\n[00:55.20]muhyoujou ni nagarenagara\n[01:00.86]ryoute kara koboreteyuku\n[01:05.19]yurayura yureteta shirazu ni ita\n[01:12.23]kono te de furetemiru made\n[01:17.56]kaketa tsuki no shita chirabatta mono\n[01:23.18]hiroiatsumete tashikametai sono subete wo\n[01:30.49] \n[01:39.47]shizuka ni nemuru kumo datte\n[01:44.99]te wo nobaseba todoku no\n[01:49.40] \n[01:50.42]tsumetakatta sora yawarakakute\n[01:56.04]kokochiyokunatteyuku\n[02:00.20] \n[02:01.09]shiori wo hazushite mekuru tabi nagareteku\n[02:12.44]toki no naka de fueta kizu wo\n[02:18.18]ryoute de fusaidekureta\n[02:22.48]yurayura nagameta tsukandemita\n[02:29.49]omotteita yori kirei de\n[02:35.10]dareka ni tsutaetakunatta keredo\n[02:40.37]mikadzuki ga katachi wo kaeteku sono yoru made\n[02:46.92] \n[03:07.44]itsu kara subete wo wakatteiru tsumori de\n[03:18.72]tsukuridashita souzou dake\n[03:24.28]shinjitekiteitandarou\n[03:28.86]yurayura yureteta shirazu ni ita\n[03:35.62]kono te de furetemiru made\n[03:41.16]kaketa tsuki no shita chirabatta mono\n[03:46.51]hiroiatsumete tashikametai\n[03:50.77]yurayura nagameta tsukandemita\n[03:57.84]omotteita yori kirei de\n[04:03.29]dareka ni tsutaetakunatta keredo\n[04:08.61]mikadzuki ga katachi wo kaeteku sono yoru made\n	/audio/Assassination Classroom ED2 「Kaketa Tsuki」.mp3	Kaketa Tsuki	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253904/covers/Assassination_Classroom_ED2_Kaketa_Tsuki.jpg	1
123	123	123	248		/audio/Chobits ED 「Raison d_etre」.mp3	Raison d'etre	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251611/covers/Chobits_ED_Raison_d_etre.jpg	1
140	140	94	272		/audio/Code Geass ED2 「Mosaic Kakera」.mp3	Mosaic Kakera	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251610/covers/Code_Geass_ED2_Mosaic_Kakera.jpg	1
145	145	94	267		/audio/Code Geass OP Theme Song 「DICE」.mp3	DICE	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773251616/covers/Code_Geass_OP_Theme_Song_DICE.jpg	1
217	130	215	227		/audio/Devil is a Part Timer ED3 「Tsumabiku Hitori」.mp3	Tsumabiku Hitori	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773251689/covers/Devil_is_a_Part_Timer_ED3_Tsumabiku_Hitori.jpg	1
267	267	266	251		/audio/Fate Grand Order Absolute Demonic Front Babylonia  OP 「Phantom Joke」.mp3	Phantom Joke	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251920/covers/Fate_Grand_Order_Absolute_Demonic_Front_Babylonia_OP_Phantom_Joke.jpg	1
299	298	295	255		/audio/Full Metal Panic! S3 OP 「Even...if」.mp3	Even...if	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251923/covers/Full_Metal_Panic_S3_OP_Even...if.jpg	3
418	418	418	243		/audio/If it_s for My Daughter, I_d Even Defeat a Demo(1).mp3	I'm with you	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251621/covers/If_it_s_for_My_Daughter_I_d_Even_Defeat_a_Demon_Lord_OP_I_m_with_you.jpg	1
809	112	794	259		/audio/Oreimo OP 「irony」.mp3	irony	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251691/covers/Oreimo_OP_irony.jpg	1
1010	1010	1009	253		/audio/Steins Gate 0 EP23 ED 「Gate of Steiner」.mp3	Gate of Steiner	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253507/covers/Steins_Gate_0_EP23_ED_Gate_of_Steiner.jpg	1
1013	794	794	90		/audio/Oreimo S2 ED4 「Honest☆Rhapsody」.mp3	Honest☆Rhapsody	ED4	https://res.cloudinary.com/ddc6silap/image/upload/v1773253504/covers/Oreimo_S2_ED4_Honest_Rhapsody.jpg	2
1214	855	184	282		/audio/Date A Live S2 ED 「Day to Story」.mp3	Day to Story	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253489/covers/Date_A_Live_S2_ED_Day_to_Story.jpg	2
1216	1216	580	221		/audio/Miss Kobayashi's Dragon Maid S ED 「Maid with Dragons❤︎ 」.mp3	Maid with Dragons❤︎ 	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253469/covers/Miss_Kobayashi_s_Dragon_Maid_S_ED_Maid_with_Dragonsd.jpg	1
1220	1220	1220	363		/audio/Tsuki ga Kirei ED 「As the Moon so Beautiful」.mp3	As the Moon so Beautiful	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253465/covers/Tsuki_ga_Kirei_ED_As_the_Moon_so_Beautiful.jpg	1
1223	1223	1223	248		/audio/Tsukimichi Moonlit Fantasy ED 「Aa, Jinsei ni Na.mp3	Aa, Jinsei ni Namida Ari	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253496/covers/Tsukimichi_Moonlit_Fantasy_ED_Aa_Jinsei_ni_Namida_Ari.jpg	1
1224	1224	1224	277		/audio/Tsukimichi Moonlit Fantasy ED2 「Beautiful Dream.mp3	Beautiful Dreamer	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253480/covers/Tsukimichi_Moonlit_Fantasy_ED2_Beautiful_Dreamer.jpg	1
1228	1228	1228	311		/audio/Utawarerumono ED 「Madoromi no Rinne」.mp3	Madoromi no Rinne	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253493/covers/Utawarerumono_ED_Madoromi_no_Rinne.jpg	1
1234	1229	1228	227		/audio/Utawarerumono S2 OP2 「Ame Kakeru Hoshi」.mp3	Ame Kakeru Hoshi	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253484/covers/Utawarerumono_S2_OP2_Ame_Kakeru_Hoshi.jpg	2
1235	1166	1210	266		/audio/Violet Evergarden ED2 「Believe in...」.mp3	Believe in...	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253460/covers/Violet_Evergarden_ED2_Believe_in....jpg	1
133	133	131	295		/audio/Clannad ED 「Dango Daikazoku」.mp3	Dango Daikazoku	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251617/covers/Clannad_ED_Dango_Daikazoku.jpg	1
138	138	94	301		/audio/Code Geass ED Theme Song 「will-ill」.mp3	will-ill	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773251618/covers/Code_Geass_ED_Theme_Song_will-ill.jpg	1
54	54	52	283	[00:00.00] \r\n[00:03.08]Kiritsu! Rei! Lock on!\r\n[00:05.82]Kiritsu! Rei! Lock on!\r\n[00:08.52]Oh - yeah -\r\n[00:11.17]Sensei - target on!\r\n[00:14.27]Potential takai hodomen dokusai\r\n[00:19.39]Drop-out mentality hinichijou wo ryougashi\r\n[00:24.86]Bokura wa utata ne kaoshite\r\n[00:29.65]Knife kakushi motta (Kiritsu! Rei! Lock on!)\r\n[00:34.38]Hottokeba kitto dareka yatte kureru to\r\n[00:40.17]Doko ka taningo to datta\r\n[00:45.44]Dake do...\r\n[00:48.63]Mr. Teacher oshiete mikansei no bokura\r\n[00:53.53]Anata to iu furaku target uchinukeru deshou ka\r\n[00:58.91]Idomu kagiri (Kiritsu! Rei! Lock on!)\r\n[01:01.73]Kanousei wa afureta (Kiritsu! Rei! Lock on!)\r\n[01:04.54]Mr. Teacher miteite mayoi ooki bokura\r\n[01:09.39]Dare yori mo anata no tameni mou benkyouchu sa\r\n[01:15.06]Satsui dake ga (Kiritsu! Rei! Lock on!)\r\n[01:17.75]Anata e no message (Kiritsu! Rei! Lock on!)\r\n[01:20.06]Jiriki (gachide) hongan (ikuyo) revolution\r\n[01:25.92]Kiritsu! Rei! Lock on!\r\n[01:28.53]Kiritsu! Rei! Lock on!\r\n[01:31.22]Oh - yeah -\r\n[01:33.74]Sensei - target on!\r\n[01:36.78]Hana no inochi to time limit\r\n[01:41.98]Naze ni sonna ni mijikai settai na no?\r\n[01:47.57]Zasetsu kara no V-ji seichou\r\n[01:52.28]Bokura inoru bakari (Kiritsu! Rei! Lock on!)\r\n[01:57.05]Taninkara jibun demo kitai sarenai\r\n[02:02.96]Hibi ga iki wo fukikaesu...\r\n[02:08.11]... kanji?\r\n[02:11.13]Mr. Teacher miteite sorezore ni bokura\r\n[02:16.05]Anata no kotoba eiyou ni sukusuku sodatteru\r\n[02:21.74]Kinou wo yori mo (Kiritsu! Rei! Lock on!)\r\n[02:24.36]Hiyari to saseta deshou? (Kiritsu! Rei! Lock on!)\r\n[02:27.07]Mr. Teacher oshiete nejire ooki bokura\r\n[02:32.04]Eranda riyuu wo itsuka wa yomitokeru deshou ka?\r\n[02:37.72]Akira mezu ni (Kiritsu! Rei! Lock on!)\r\n[02:40.33]Kuwadatete iki masu (Kiritsu! Rei! Lock on!)\r\n[02:42.66]Jiriki (gachide) hongan (ikuyo) revolution\r\n[02:49.52] \r\n[02:59.14]Kiritsu! Rei! Lock on!\r\n[03:01.78]Kiritsu! Rei! Lock on!\r\n[03:04.40]Kiritsu! Rei! Lock on!\r\n[03:06.95]Kiritsu! Rei! Lock on!\r\n[03:09.75]Kiritsu! Rei! Lock on!\r\n[03:13.52] \r\n[03:15.22]Oh - yeah -\r\n[03:18.02]Sensei - target on!\r\n[03:21.45]Arie nai koto dakedo\r\n[03:24.47]Kitto hijou jitai dakedo\r\n[03:26.81]Fushigi (itsu no) dayo ne (hiyori)\r\n[03:29.95]Ikiteru...\r\n[03:33.20]... tte kanji\r\n[03:37.87]Mr. Teacher oshiete mikansei no bokura\r\n[03:42.74]Anata to iu furaku target uchinukeru deshou ka\r\n[03:48.35]Idomu kagiri (Kiritsu! Rei! Lock on!)\r\n[03:51.12]Kanousei wa afureta (Kiritsu! Rei! Lock on!)\r\n[03:53.72]Mr. Teacher miteite mayoi ooki bokura\r\n[03:58.72]Dare yori mo anata no tameni mou benkyouchu sa\r\n[04:04.42]Satsui dake ga (Kiritsu! Rei! Lock on!)\r\n[04:06.94]Anata e no message (Kiritsu! Rei! Lock on!)\r\n[04:09.27]Tariki (ate ni) hongan (suru no) yame masu\r\n[04:14.58]Jiriki (gachide) hongan (ikuyo) revolution\r\n[04:20.58]Kiritsu! Rei! Lock on!\r\n[04:23.00]Kiritsu! Rei! Lock on!\r\n[04:25.80]Oh - yeah -\r\n[04:28.62]Oh - yeah -\r\n[04:31.13]Sensei - target on!	/audio/Assassination Classroom OP2 「Jiriki Hongan Revo.mp3	Jiriki Hongan Revolution	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253983/covers/Assassination_Classroom_OP2_Jiriki_Hongan_Revolution.jpg	1
69	69	66	259	[ti:Bakemonogatari OP4 「Renai Circulation」]\n[ar:Kana Hanazawa]\n[al:Monogatari]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:18.79]\n[00:00.00] \n[00:04.87](se~ no!)\n[00:05.86]demo sonnan ja dame\n[00:07.63]mou sonnan ja hora\n[00:09.63]kokoro wa shinka suru yo\n[00:11.80]motto motto\n[00:29.67]kotoba ni sureba kiechau kankei nara\n[00:31.69]kotoba wo keseba ii ya tte\n[00:33.85]omotteta osoreteta\n[00:35.74]dakedo are? nanka chigau kamo...\n[00:37.73]senri no michi mo ippo kara!\n[00:39.59]ishi no you ni katai sonna ishi de\n[00:41.76]chiri mo tsumoreba Yamato Nadeshiko?\n[00:43.85]'shi' nuki de iya shinu ki de!\n[00:45.70]fuwafuwari fuwafuwaru\n[00:48.81]anata ga namae wo yobu\n[00:50.84]sore dake de\n[00:51.77]chuu e ukabu\n[00:53.76]fuwafuwaru fuwafuwari\n[00:56.76]anata ga waratte iru\n[00:58.91]sore dake de\n[00:59.93]egao ni naru\n[01:01.81]kami-sama arigatou\n[01:05.74]unmei no itazura demo\n[01:09.65]meguriaeta koto ga\n[01:13.66]shiawase na no\n[01:17.52]demo sonnan ja dame\n[01:19.65]mou sonnan ja hora\n[01:21.54]kokoro wa shinka suru yo\n[01:23.61]motto motto\n[01:25.57]sou sonnan ja ya da\n[01:27.74]nee sonnan ja mada\n[01:29.58]watashi no koto mitete ne\n[01:31.68]zutto zutto\n[01:49.69]watashi no naka no anata hodo\n[01:52.41]anata no naka no watashi no sonzai wa\n[01:54.61]madamada ookikunai koto mo\n[01:57.24]wakatteru keredo\n[01:58.62]ima kono onaji shunkan\n[02:00.37]kyouyuu shiteru jikkan\n[02:02.37]chiri mo tsumoreba Yamato Nadeshiko!\n[02:04.50]ryakushite? chiri-tsumo Yamato Nadeko!\n[02:06.59]kurakurari kurakuraru\n[02:09.63]anata wo miagetara\n[02:11.69]sore dake de\n[02:12.66]mabushisugite\n[02:14.47]kurakuraru kurakurari\n[02:17.54]anata wo omotte iru\n[02:19.42]sore dake de\n[02:20.58]tokete shimau\n[02:22.58]kami-sama arigatou\n[02:26.39]unmei no itazura demo\n[02:30.46]meguriaeta koto ga\n[02:34.46]shiawase na no\n[02:38.47]KO I SU RU KI SE TSU WA YO KU BA RI Circulation\n[02:46.71]KO I SU RU KI MO CHI WA YO KU BA RI Circulation\n[02:54.65]KO I SU RU HI TO MI WA YO KU BA RI Circulation\n[03:02.64]KO I SU RU wo TO ME WA YO KU BA RI Circulation\n[03:12.84]fuwafuwari fuwafuwaru\n[03:15.61]anata ga namae wo yobu\n[03:17.76]sore dake de\n[03:18.20]chuu e ukabu\n[03:20.17]fuwafuwaru fuwafuwari\n[03:23.13]anata ga waratte iru\n[03:25.16]sore dake de\n[03:26.14]egao ni naru\n[03:28.15]kami-sama arigatou\n[03:32.03]unmei no itazura demo\n[03:36.29]meguriaeta koto ga\n[03:40.15]shiawase na no\n[04:00.05]demo sonnan ja dame\n[04:02.00]mou sonnan ja hora\n[04:03.96]kokoro wa shinka suru yo\n[04:06.03]motto motto\n[04:08.01]sou sonnan ja ya da\n[04:09.98]nee sonnan ja mada\n[04:11.92]watashi no koto mitete ne\n[04:13.97]zutto zutto\n[04:16.61]	/audio/Bakemonogatari OP4 「Renai Circulation」.mp3	Renai Circulation	OP4	https://res.cloudinary.com/ddc6silap/image/upload/v1773253888/covers/Bakemonogatari_OP4_Renai_Circulation.jpg	1
298	298	295	259		/audio/Full Metal Panic! S3 ED 「yes」.mp3	yes	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251927/covers/Full_Metal_Panic_S3_ED_yes.jpg	3
1049	1049	1049	319		/audio/Tada Never Falls In Love ED 「Love Song」.mp3	Love Song	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253549/covers/Tada_Never_Falls_In_Love_ED_Love_Song.jpg	1
1246	1240	1240	272		/audio/Vivy_ Fluorite Eye_s Song OP4 「Galaxy Anthem」.mp3	Galaxy Anthem	OP4	https://res.cloudinary.com/ddc6silap/image/upload/v1773253534/covers/Vivy_Fluorite_Eye_s_Song_OP4_Galaxy_Anthem.jpg	1
1249	1249	1249	248		/audio/Watamote ED 「Dou Kangaetemo Watashiha Warukunai.mp3	Dou Kangaetemo Watashiha Warukunai	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253539/covers/Watamote_ED_Dou_Kangaetemo_Watashiha_Warukunai.jpg	1
1252	1252	1249	258		/audio/Watamote ED5 「Sokora no Kigurumi no Fuusen to W.mp3	Sokora no Kigurumi no Fuusen to Watashi	ED5	https://res.cloudinary.com/ddc6silap/image/upload/v1773253544/covers/Watamote_ED5_Sokora_no_Kigurumi_no_Fuusen_to_Watashi.jpg	1
92	57	92	298		/audio/Cautious Hero ED 「be perfect, plz!」.mp3	be perfect, plz!	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252185/covers/Cautious_Hero_ED_be_perfect_plz.jpg	1
93	93	93	266		/audio/Chrome Shelled Regios ED 「Yasashii Uso」.mp3	Yasashii Uso	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251594/covers/Chrome_Shelled_Regios_ED_Yasashii_Uso.jpg	1
114	112	112	214		/audio/Cells at Work S2 ED 「Fight!!」.mp3	Fight!!	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251632/covers/Cells_at_Work_S2_ED_Fight.jpg	2
126	126	123	269		/audio/Chobits OP 「Let Me Be With You」.mp3	Let Me Be With You	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251634/covers/Chobits_OP_Let_Me_Be_With_You.jpg	1
128	128	93	251		/audio/Chrome Shelled Regios OP 「Brave your truth」.mp3	Brave your truth	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253623/covers/Chrome_Shelled_Regios_OP_Brave_your_truth.jpg	1
137	137	136	262		/audio/Classroom of the Elite OP 「Caste Room」.mp3	Caste Room	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251630/covers/Classroom_of_the_Elite_OP_Caste_Room.jpg	1
142	142	94	330		/audio/Code Geass M1 ED 「More Than Words」.mp3	More Than Words	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251627/covers/Code_Geass_M1_ED_More_Than_Words.jpg	1
258	258	258	389		/audio/Ergo Proxy ED 「Paranoid Android」.mp3	Paranoid Android	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252192/covers/Ergo_Proxy_ED_Paranoid_Android.jpg	1
274	11	266	374		/audio/Fate_stay night Heaven_s Feel M1 ED 「Hana no Ut.mp3	Hana no Uta	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251932/covers/Fatestay_night_Heaven_s_Feel_M1_ED_Hana_no_Uta.jpg	1
279	279	266	298		/audio/Fate_stay night_ Unlimited Blade Works ED 「beli.mp3	believe	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253586/covers/Fatestay_night_Unlimited_Blade_Works_ED_believe.jpg	1
285	28	266	259		/audio/Fate_Zero OP 「oath sign」.mp3	oath sign	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251930/covers/FateZero_OP_oath_sign.jpg	1
104	104	104	214	[ti:Boku ga Aishita Subete no Kimi e  ED Theme  「Kumo wo Kou 」]\n[ar:Keina Suda]\n[al:Boku ga Aishita Subete no Kimi e]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:23.4.20]\n[length:03:33.68]\n[00:00.00]\n[00:20.87]Dokoka e itta seiten to madara na kurashi no naka\n[00:27.22]Minareta yokogao mado wo tsuita amaoto\n[00:33.15]Itte shimaeba subete wa toru ni taranai\n[00:37.89]Sasai na kotoba ga o wo hiite iku\n[00:45.45]Kakaeta itami no kazu nante\n[00:49.30]Oboete wa inai keredo\n[00:52.16]Tashika ni futari no ai wo sodateta\n[00:57.68]Yasuppoi hibi wo okurou ne kudaranai hanashi wo shiyou ne\n[01:03.33]Hikarabita asa wo kasanete wa shiawase da to waraou ne\n[01:08.43]Kitto saki no koto wa wakaranai ima wa tada\n[01:12.41]Shinadareta anata ga kareru koto no nai you ni uta wo utau no da\n[01:41.09]Nagusameau no wa kantan da yue ni koko ni aru no wa\n[01:46.04]Kusunda sora moyou yume ni katta shinkirou\n[01:52.80]Anata no ki wo hikou to shite\n[01:57.40]Hitori ni yogatte ita\n[02:00.40]Osanaku minikui koigokoro da\n[02:05.91]Mayoikomu yami no yukusue ni yasuraka na kokoro ga tomotta\n[02:11.61]Sashinobeta tenohira wa dou ka hanasanai you ni shiyou ne\n[02:16.78]Ame no hau ajisai wo mite wa tomo ni yureru anata no kotonoha ga\n[02:22.42]Aseru koto no nai you ni sora wo aogu no da\n[02:38.86]Sasayaki wo kawashite\n[02:41.71]Nandemo nai himitsu wo motta\n[02:44.40]Sairuiu no you na omoide da\n[02:49.32]Ruri iro wo hedatete\n[02:52.20]Gikochi naku waraiatteita\n[02:55.33]Hanayaka na egao ni mitoremashita\n[03:02.04]Hora\n[03:03.19]Yasuppoi hibi wo okurou ne kudaranai hanashi wo shiyou ne\n[03:08.78]Hikarabita asa wo kasanete wa shiawase da to waraou ne\n[03:14.16]Kitto saki no koto wa wakaranai ima wa tada\n[03:18.20]Shinadareta anata ga kareru koto no nai you ni uta wo utau no da\n[03:25.29]Areru mama de aru you ni kimi wo aisu no da\n[03:29.98]	/audio/Boku ga Aishita Subete no Kimi e  ED Theme  「Kumo wo Kou 」.mp3	Kumo wo Kou 	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253956/covers/Boku_ga_Aishita_Subete_no_Kimi_e_ED_Theme_Kumo_wo_Kou.jpg	1
35	35	34	256	[00:00.00] \n[00:15.99]Aoki ashita kako wa shiseri\n[00:19.64]Kimi wa mata kodoku wo daku\n[00:22.40]Yoru wo oou mabuta hirake\n[00:26.01]Mataki kage wo osoreru nakare\n[00:32.62]Hono kuraki hitsugi kara\n[00:38.54]Umi otosareta ningyou no you ni\n[00:45.20]Karada wa akaku kogoe\n[00:51.23]Kokoro wa yami ni ayasare sodatsu\n[00:58.20]Kimi ni boku ga mierukai\n[01:01.35]Tsunagu te no tsumetasa ni\n[01:04.31]Senketsu no tsume tateru\n[01:07.23]Mayu yosete goran yo\n[01:11.95]Kowashiaou\n[01:13.82]Saki ni tsuzuku\n[01:15.51]Nazo ni michiru ketsumatsu wo\n[01:18.54]Hane mo ashi mo mogareta mama\n[01:21.74]Kokuu no naka kuchihateru yori\n[01:25.27]Mou hitori boku ga ite\n[01:28.29]Dareka wo itai hodo aishiteirunda\n[01:34.81]Saa docchi ga\n[01:35.92]Maboroshi darou ne\n[01:38.84] \n[01:47.39]Tsunzaku zekkyou yori\n[01:53.67]Ozomashiki mono hito no sasayaki\n[02:00.28]Ashiki kotodama bakari\n[02:06.21]Kokoro ayatsuri tsutawatte yuku\n[02:13.05]Boku wa kimi ni fureteitai\n[02:16.17]Tatoe minna kiete mo\n[02:19.26]Damasarete ageyou ka\n[02:22.28]Kirei ni warai na yo\n[02:26.95]Kawashiaou\n[02:28.77]Kouru you ni\n[02:30.23]Itsuka tsuzurareru yume wo\n[02:33.30]Chi to namida ni mamiretatte\n[02:36.71]Matteru no wa zetsubou ja nai\n[02:40.13]Mou hitori kimi ga ite\n[02:43.22]Dareka wo korosu hodo kizutsuketeite mo\n[02:49.74]Nee ittai\n[02:50.56]Tsumi tte nandarou\n[02:56.66] \n[03:14.66]Aoki ashita kako wa shiseri\n[03:18.30]Boku wa mata kodoku wo shiru\n[03:21.17]Yoru wo oou mabuta hirake\n[03:24.68]Mataki kage wo osoreru nakare\n[03:28.75]Kowashiaou\n[03:30.83]Saki ni tsuzuku\n[03:32.42]Nazo ni michiru ketsumatsu wo\n[03:35.53]Hane mo ashi mo mogareta mama\n[03:38.91]Kokuu no naka kuchihateru yori\n[03:42.33]Aa koko ni bokura wa iru\n[03:45.20]Honto wa itai hodo\n[03:47.20]Ikiteitainda\n[03:51.84]Mou tokku ni kotae wa\n[03:53.60]Wakatteru ne?\n[03:59.42] \n	/audio/Another OP 「Kyoumu Densen」.mp3	Kyoumu Densen	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253624/covers/Another_OP_Kyoumu_Densen.jpg	1
119	119	118	261	[00:00.00] \n[00:13.55]Madamada kono tabi wa kitsui mono ni naru nante\n[00:19.00]Kimi ni iu to ato de mata shikararerun da\n[00:26.18]Somosomo ikiru koto sore jitai ga zankoku de\n[00:31.51]Sonna koto dare datte iya hodo shitteru to\n[00:38.44]Kimi ni wa itsuka misetai mono ga aru\n[00:44.61]sore dake wa zutto kono mune ni\n[00:51.47]Mou nido to wa fureru koto nai nanika wo ushinai nagara\n[00:58.78]Tooku kumo no mukou wo tada kimi wa mitsumete iru dake\n[01:05.29]Kitto tadoritsukeru rakuen wo ima wo shinjite iru\n[01:11.69] \n[01:16.70]Mezameta ato sugu ni asa no tsumetai kuuki wo\n[01:22.23]Omoikiri suikonde musetari mo suru\n[01:29.24]Zuibun tooku made kita mono da to furikaeri\n[01:34.78]Sukoshi dake fumarete kita michi wo omotte mo miru\n[01:41.59]Aimai demo shiawase datta kioku\n[01:47.83]Sore dake ga areba ii to iu\n[01:54.51]Mou nido to wa kanaerarenai nanika wo sagashimotome nagara\n[02:02.06]Tooi wari ni tada tsuchi ni yogorete yuku futari dake\n[02:08.40]Kitto kimi mo waraeru rakuen wo ima wa shinjitai\n[02:14.27] \n[02:44.57]Asu ni wa umi ga mirareru you ni\n[02:51.03]Sukoshi dake ashi wo hayamete\n[02:57.24]Kinou wo kuyaminaosanu you ni\n[03:03.62]Sukoshi dake toki wo hayamete\n[03:09.77] \n[03:10.44]Mou nido to wa fureru koto nai nanika wo ushinai nagara\n[03:17.81]Tooku kumo no mukou ow tada kimi wa mitsumete iru dake\n[03:24.21]Kitto tadoritsukeru rakuen wo ima mo shinjite iru\n[03:30.98] \n[03:46.25]kitto ima dake waratta kazuooku no atashi no tame	/audio/Charlotte ED2 「Rakuen Made」.mp3	Rakuen Made	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253867/covers/Charlotte_ED2_Rakuen_Made.jpg	1
160	160	159	258	[ti:Daily Lives of High School Boys ED2 「Ohisama」]\n[ar:Amesaki Annainin]\n[al:Daily Lives of High School Boys]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:15.09]\n[00:00.00]\n[00:10.53]kokoro no naka ni itsu de mo sunde'ru\n[00:15.96]kokoro no naka ni ohisama hitotsu\n[00:20.96]kimi no kao\n[00:26.27]kimi no koto\n[00:30.94]ima aenakute mo boku wa ikite iru\n[00:36.03]ima aenakute mo kimi wa iki wo shite iru\n[00:40.85]sore dake de sore dake de\n[00:45.71]juubun sa sou juubun sa\n[00:50.05]ikite ireba ikite ireba\n[00:55.64]itsuka mata aeru hazu sa\n[01:01.16]ohisama wa mite iru\n[01:10.90]ohisama wa utau yo\n[01:21.39]pappappappa rarirappappara\n[01:24.19]pappappappa rarirappa\n[01:26.62]pappappappa rarirappappa\n[01:29.20]pa pa pa pa pa pa pa\n[01:41.32]kanashii yoru ga bokura wo tsutsumu\n[01:46.29]keredomo bokura madamada yume wo mite iru\n[01:51.45]sore dake de sore dake de\n[01:56.46]juubun sa sou juubun sa\n[02:01.26]ikite ireba ikite ireba\n[02:06.21]itsuka mata mata kimi ni aeru hazu sa\n[02:11.71]ohisama wa mite iru\n[02:21.51]ohisama wa utau yo\n[02:31.12]pappappappa rarirappappara\n[02:33.83]pappappappa rarirappa\n[02:36.49]pappappappa rarirappappa\n[02:39.09]pa pa pa pa pa pa pa\n[02:41.51]pappappappa rarirappappara\n[02:44.14]pappappappa rarirappa\n[02:46.66]pappappappa rarirappappa\n[02:49.19]pa pa pa pa pa pa pa\n[03:11.18]pappappappa rarirappappara\n[03:13.09]pappappappa rarirappa\n[03:15.97]pappappappa rarirappappa\n[03:18.43]pa pa pa pa pa pa pa\n[03:20.77]pappappappa rarirappappara\n[03:23.40]pappappappa rarirappa\n[03:25.81]pappappappa rarirappappa\n[03:28.34]pa pa pa pa pa pa pa\n[03:30.65]pappappappa rarirappappara\n[03:33.32]pappappappa rarirappa\n[03:35.75]pappappappa rarirappappa\n[03:38.40]pa pa pa pa pa pa pa\n[03:40.77]pappappappa rarirappappara\n[03:43.27]pappappappa rarirappa\n[03:45.82]pappappappa rarirappappa\n[03:48.33]pa pa pa pa pa pa pa\n[03:50.53]pappappappa rarirappappara\n[03:53.50]pappappappa rarirappa\n[03:55.83]pappappappa rarirappappa\n[03:58.36]pa pa pa pa pa pa pa\n[04:00.75]shinjite iru yo ohisama hitotsu kimi no uchi made\n[04:08.50]	/audio/Daily Lives of High School Boys ED2 「Ohisama」.mp3	Ohisama	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251636/covers/Daily_Lives_of_High_School_Boys_ED2_Ohisama.jpg	1
168	164	162	274		/audio/DanMachi S3 OP 「over and over」.mp3	over and over	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251638/covers/DanMachi_S3_OP_over_and_over.jpg	3
175	175	175	218	対　　㨀　　⸀　　崀 ਀嬀　　㨀㄀㈀⸀㔀㄀崀䬀礀漀甀猀栀椀琀猀甀 渀漀 洀愀搀漀最漀猀栀椀 渀椀	/audio/Darling In The FranXX ED 「Torikago」.mp3	Torikago	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251640/covers/Darling_In_The_FranXX_ED_Torikago.jpg	1
122	122	122	300	[00:00.00] \n[00:01.23]Hello, Goodbye & Hello\n[00:05.96]Kimi ni atte ima kimi to sayonara\n[00:13.48]Hello Goodbye & Hello\n[00:17.88]Soshite kimi no inai kono sekai ni Hello\n[00:25.35] \n[00:36.90]Hontou no sayonara wo shiranakatta ano toki\n[00:49.39]Kowareyuku kokoro wa zutto kimi wo sagashiteta\n[01:01.56]Moshimo todoku no naraba tsutaetakatta koto ga takusan aru\n[01:13.75]Subete no kimochi de kimi no egao wo tayasazu\n[01:22.15]soba ni itai to chikau yo\n[01:27.32]Hello, Goodbye & Hello\n[01:32.06]kimi ni atte ima kimi ni sayonara\n[01:39.64]Hello Goodbye & Hello\n[01:43.92]soshite kimi no inai kono sekai ni Hello\n[01:51.66] \n[01:59.92]Omoide ya nukumori wa kimi e to tsudzuku ito\n[02:12.34]Tadottemo mitsukaranai sore dake wo mitsuketa\n[02:24.70]Nakushitakunai negai ichiban tooi hoshi dato omotta yo\n[02:36.74]Sora wa hirogaru asu no you ni hatenai keredo\n[02:46.67]te wo nobashitai yo\n[02:51.87]Hello, Goodbye & Hello\n[02:56.59]Kimi no koto wo itsumo wasurenai yo\n[03:04.21]Hello, Goodbye & Hello\n[03:08.57]Soshite kono michi wo aruite yukunda\n[03:15.38]Kimi wo suki ni natta toki kara hajimatteita kono tabi\n[03:30.58]Hello, Goodbye & Hello\n[03:35.16]Kimi ni atte ima kimi to sayonara\n[03:42.80]Hello, Goodbye & Hello\n[03:47.13]Soshite kimi no inai kono sekai ni Hello\n[03:54.37] \n[03:55.06]Hello, Goodbye & Hello\n[03:59.85]Kimi ni atte ima kimi ni sayonara\n[04:07.29]Hello, Goodbye & Hello\n[04:11.75]soshite kimi no inai kono sekai ni Hello\n[04:18.64] 	/audio/Children Who Chase Lost Voices ED Theme 「Hello .mp3	Hello Goodbye & Hello	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773254075/covers/Children_Who_Chase_Lost_Voices_ED_Theme_Hello_Goodbye_Hello.jpg	1
127	127	93	272		/audio/Chrome Shelled Regios ED2 「Ai no Zuellni」.mp3	Ai no Zuellni	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251625/covers/Chrome_Shelled_Regios_ED2_Ai_no_Zuellni.jpg	1
143	142	94	341	[00:00.00] \n[00:25.71]Ano hi watashi-tachi ga mita yume wo\n[00:31.82]Kimi wa mada oboete imasu ka\n[00:37.36]Tsumetai kaze no naka de\n[00:42.87]Tori-tachi ga tobisatta sora ni\n[00:46.82]Hitosuji no kumo ga ko wo egaite\n[00:52.34]Higashi e dokomademo nobite yuku\n[00:59.23]Hageshiku ikizu tomo tsuyoku\n[01:06.16]Anata aishitakatta\n[01:10.81]Sono te wo tada\n[01:13.84]Tada shizuka ni mamoru you ni\n[01:18.43]Nigitte itakatta\n[01:22.27]Please never let me go\n[01:24.91]Arigatou utsukushii hito yo\n[01:32.26]Anata to iu ashita ni\n[01:37.09]Deaeta koto shinjirareta koto subete ga\n[01:45.67]Shiawase datta\n[01:50.59]Ano hi watashi-tachi ga ita asa wo\n[01:56.15]Dokomademo yakitsukete yuku\n[02:01.75]Terikaesu hi no naka de\n[02:07.27]Hinadori ga yonde iru sora wa\n[02:11.53]Miagete iru kumo wa\n[02:14.67]Inochi wo mata kawarazu dakishimete kuremasu ka\n[02:25.23]Sayounara utsukushii hito yo\n[02:32.26]Anata to iu ashita wa\n[02:37.02]Donna toki mo kibou e to kawaru hikari wo\n[02:45.72]Tsurete kimashita\n[02:48.55]Mizu wa nagare uruoshite yuku\n[02:54.23]Soshite kono hoshi wa kyou mo aoi mama de\n[03:09.84]Nanimokamo ga katachi wo nakushita sekai wa\n[03:19.51]Nani wo watashi-tachi ni nokoshita no deshou ka\n[03:27.55]Doushite motto hayaku kizukete ita hazu na no ni\n[03:34.07]Kizutsukeai\n[03:37.91]Soredemo mata yurushiaeru no nara\n[03:58.86]Sono te wo tada\n[04:01.98]Tada shizuka ni mamoru you ni nigitte itakatta\n[04:09.55]Please never let me go\n[04:24.76]Deaeta koto shinjirareta koto subete ga\n[04:32.91]Shiawase datta\n[04:41.38]Anata aishitakatta\n[04:46.71]Sono te wo tada tada shizuka ni mamoru you ni\n[04:57.74]Hageshiku ikizu tomo tsuyoku\n[05:03.55]Anata to iu ashita wa\n[05:08.75]Donna toki mo kibou e to kawaru hikari wo\n[05:22.10]Tsurete kimashita\n[05:29.31] 	/audio/Code Geass M5 ED 「Arco」.mp3	Arco	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254148/covers/Code_Geass_M5_ED_Arco.jpg	1
188	188	184	278		/audio/Date A Live OP 「Date A Live」.mp3	Date A Live	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251651/covers/Date_A_Live_OP_Date_A_Live.jpg	1
191	191	184	232		/audio/Date A Live S3 ED 「Last Promise」.mp3	Last Promise	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251663/covers/Date_A_Live_S3_ED_Last_Promise.jpg	3
197	197	197	239		/audio/Deadman Wonderland ED 「SHINY SHINY」.mp3	SHINY SHINY	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251656/covers/Deadman_Wonderland_ED_SHINY_SHINY.jpg	1
212	209	208	244		/audio/Demon Slayer OST Shinobu_s Theme.mp3	Shinobu's Theme	OST	https://res.cloudinary.com/ddc6silap/image/upload/v1773256645/covers/Demon_Slayer_OST_Shinobu_s_Theme.jpg	1
218	218	215	244		/audio/Devil is a Part Timer OP 「ZERO!!」.mp3	ZERO!!	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251666/covers/Devil_is_a_Part_Timer_OP_ZERO.jpg	1
220	219	219	252		/audio/Domestic Girlfriend ED2 「always」.mp3	always	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251648/covers/Domestic_Girlfriend_ED2_always.jpg	1
224	224	223	258		/audio/Dororo ED2 「Yamiyo」.mp3	Yamiyo	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251670/covers/Dororo_ED2_Yamiyo.jpg	1
187	185	184	299		/audio/Date A Live ED4 「Strawberry Rain」.mp3	Strawberry Rain	ED4	https://res.cloudinary.com/ddc6silap/image/upload/v1773251645/covers/Date_A_Live_ED4_Strawberry_Rain.jpg	1
179	175	175	224	[00:00.00] \n[00:14.12]Yohō-hazure no ame ga boku-ra o nurashite\n[00:21.02]Furueteru kimi ni nan o hanashitara yoi no？\n[00:28.45]Bishonure no burezā ga tsumetaku te omotaku te\n[00:35.41]Kago o deta hinadori no muryoku-sa o kanjiteru\n[00:43.94]Saware sō datta yume wa buatsui kumo no mukō de\n[00:50.73]Mune ni hirogaru amai itami dake kamishimeta\n[00:58.38]Boku to kimi wa deawanai hō ga yokatta ka na？\n[01:04.84]Nei hoshi sae mienai yo\n[01:12.88] \n[01:15.32]Chīsana mizutamari yagate sora ni kaerunara\n[01:22.26]Isso boku-tachi mo tsurete itte kurenai ka na\n[01:29.74]Kimi no mune no uchi o shiru no ga kowaku natte\n[01:36.65]Kesaki kara ochite yuku suiteki o mite ita\n[01:45.08]Jiyū nante sa doko ni mo nai ki ga shiteta kara\n[01:52.04]Sore ga jijitsu to mae yori wakatta dake na n da\n[01:59.64]Boku to kimi wa deawanai hō ga yokatta ka na？\n[02:06.04]Nei namida mo dete konai\n[02:14.19] \n[02:28.78]Yohō-hazure no ame wa furitsuzuite ite\n[02:35.74]Aojiroi kao shiteru kimi o utsukushiku omou\n[02:42.77]Mō zenbu dō de mo yoi yo\n[02:53.17]Saware sō datta yume wa buatsui kumo no mukō de\n[03:00.10]Mune ni hirogaru amai itami dake kamishimeta\n[03:07.85]Boku to kimi wa deawanai hō ga yokatta ka na？\n[03:14.17]Nei hoshi sae mienai yo\n[03:21.18]Nei namida mo dete konai\n[03:29.03] 	/audio/Darling In The FranXX ED5 「Escape」.mp3	Escape	ED5	https://res.cloudinary.com/ddc6silap/image/upload/v1773253996/covers/Darling_In_The_FranXX_ED5_Escape.jpg	1
182	182	182	236	[00:00.00] \n[00:11.69]Tsukiakari wo sotto\n[00:14.20]Kumo ga ouikakushite\n[00:17.59]Shizuka ni kuroku\n[00:20.17]Nuritsubu sareteku\n[00:22.19]Dokomademo tsuzuite yuku\n[00:24.72]Kurayami nagame nagara\n[00:28.33]Nanimo dekinai mama de\n[00:32.47]Mata hitotsu kiete itta\n[00:37.56]Oto mo tatezu ni\n[00:40.96]Ima, sotto\n[00:42.69]Anata no yume no kakera ga\n[00:47.33]Be alive\n[00:50.76]Mou junboku na mama de\n[00:54.56]Namida wo kakusanaide\n[00:57.20]Kurikae sareteku\n[01:02.49]Zetsubou no saki ni\n[01:04.45]Kokoro karete mo\n[01:06.51]Ashita wo sakebu no nara\n[01:11.81]Me no mae wa kitto kibou da\n[01:16.69] \n[01:26.90]Me no mae fusagu yō ni\n[01:29.60]Masshiro ni somaru yuki ga\n[01:32.87]Sotto sekai o mata nurikaeteku\n[01:37.62]Oshiete yo...\n[01:38.40]Kono sekai wa doko e tsuzuite yuku no... ?\n[01:43.24]Kotae wa mitsukaranai mama\n[01:47.65]Mata hito-tsu kiete itta\n[01:52.67]Sugisatta hi no ashiato\n[01:57.99]Donna ni te o nobashite mo\n[02:02.50]Be Alive\n[02:05.83]Ima kokoro kizamarete itami to hikikae ni\n[02:12.39]Tayorinaku yureru hikari no saki de\n[02:19.69]Tatoe sekai ga itsuwari ni afurete mo\n[02:27.09]Anata dake dō ka shinjite\n[02:31.38] \n[02:51.08]Nanimokamo nakushite mo\n[02:55.89]Sore de mo tsuzuitekunara...\n[03:01.55] \n[03:04.49]Be Alive\n[03:08.00]Mō chinmoku no mama de namida o kakusanaide\n[03:14.43]Kurikaesareteku zetsubō no saki ni\n[03:21.73]Kokoro karete mo asu o sakebu no nara\n[03:28.94]Me no mae wa kitto... kibō da\n[03:33.20] \n[03:35.61]To Be Alive...\n[03:43.02] \n	/audio/Darwin_s Game ED「Alive」.mp3	Alive	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253729/covers/Darwin_s_Game_ED_Alive.jpg	1
186	185	184	229		/audio/Date A Live ED3 「SAVE MY HEART」.mp3	SAVE MY HEART	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773251695/covers/Date_A_Live_ED3_SAVE_MY_HEART.jpg	1
318	318	318	288		/audio/Ghost Hound ED 「Call My Name」.mp3	Call My Name	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252038/covers/Ghost_Hound_ED_Call_My_Name.jpg	1
625	624	623	295		/audio/Nagi no Asukara OP 「lull ~Soshite Bokura wa~」.mp3	lull ~Soshite Bokura wa~	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251712/covers/Nagi_no_Asukara_OP_lull_Soshite_Bokura_wa.jpg	1
633	633	627	140		/audio/Naruto ED14 「Pinocchio」.mp3	Pinocchio	ED14	https://res.cloudinary.com/ddc6silap/image/upload/v1773251707/covers/Naruto_ED14_Pinocchio.jpg	1
199	199	199	226	[00:00.30]Yakusoku wo kawashita kono te wo\n[00:06.58]Hanasanaide wasurenaide\n[00:09.50]Zutto watashi wa anata wo matteru\n[00:25.76]Awai amai hibi no naka kowaresou na katachi wo\n[00:37.29]Yasashiku tsutsumikondekureru basho wo mitsuketa no\n[00:48.39]Yume wo mita anata ni te ga todoku yume wo\n[00:54.93]Akiramenai tatta hitotsu no hatenai yume\n[01:03.92]Yakusoku wo kawashita kono te wo\n[01:09.75]Hanasanaide wasurenaide\n[01:12.92]Watashi wa anata wo matteru\n[01:16.43]Kagayaku kono takaramono wo\n[01:21.36]Teinei ni tsutsumikonde\n[01:24.69]Anata e okuru kara\n[01:26.61]Soko de matteite watashi ga mukau kara\n[01:33.53]Soshite mata koko ni kaettekuru wa\n[01:47.70]Yo ga akenai you na hibi no naka\n[01:53.01]Tada hitotsu negatteta\n[01:58.67]Yarusenai kawaranai kinou to onaji sora ni\n[02:04.80]Tameiki wo tsuita\n[02:10.50]Tomaranai tomarenai\n[02:16.33]Kono ashi wa tometakunai\n[02:22.07]Kono tenohira kurai no shiawase wo\n[02:27.88]Zutto mune ni shimatteoite\n[02:35.85]Wasurerarenai ano hi wo zutto\n[02:41.82]Omoidashite kurikaeshite\n[02:44.69]Yakusoku wa zutto koko ni aru yo\n[02:48.48]Kagayaku kono takaramono wo\n[02:53.47]Teinei ni tsutsumikonde\n[02:56.39]Anata to zutto tonari de\n[03:00.06]Hatenai yume anata to kanaeru kara\n[03:05.84]Soshite mata koko ni kaettekuru wa\n[03:11.73]Soko de matteite watashi ga mukau kara\n[03:17.42]Soshite mata koko ni kaettekuru wa\n[03:23.38] 	/audio/Deaimon ED 「Koko ni Aru Yakusoku」.mp3	Koko ni Aru Yakusoku	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253880/covers/Deaimon_ED_Koko_ni_Aru_Yakusoku.jpg	1
647	647	627	214		/audio/Naruto OP6 「No Boy No Cry」.mp3	No Boy No Cry	OP6	https://res.cloudinary.com/ddc6silap/image/upload/v1773251700/covers/Naruto_OP6_No_Boy_No_Cry.jpg	1
201	142	199	238	[00:00.00] \n[00:27.07]Hitori mata hitori\n[00:32.90]Toorisugiteku migi e hidari e to\n[00:40.69]Hitori hitorizutsu\n[00:46.28]Ima nani wo kangaeterun darou\n[00:52.82]Yume wo idaitari kudaitari\n[01:00.57]Koishitari nemurenaku nattari\n[01:06.38]Futsuu no jinsei nante doko ni mo nai\n[01:17.54]Sonna fuu ni mieru dake\n[01:21.02]Bokutachi wa sabishii ikimono dakara\n[01:29.22]Fue sugiteshimatta no ka na\n[01:34.78]Hitori ga futari naranda kage\n[01:41.95]Kimi wo dakishimete ii ka na\n[02:26.70]Deawanakereba ushinau\n[02:33.51]Shinpai mo shinakute yokatta\n[02:40.41]Deawazu ni itara ataeru dake no ai\n[02:50.82]Sonna yorokobi ga aru koto shirazu ni ikite\n[02:57.71]Bokutachi wa tsunagu ikimono dakara\n[03:05.56]Dareka no yume no tsuzuki wo\n[03:11.25]Akiramekirezu tsumuideyuku\n[03:19.25]Nandemo nai you na kao shite\n[03:24.63]Hitori ga futari naranda kage\n[03:31.67]Kimi wo dakishimete ii ka na\n[03:39.10] 	/audio/Deaimon OP 「Sumire」.mp3	Sumire	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251717/covers/Deaimon_OP_Sumire.jpg	1
330	330	330	283	[00:00.00] \n[00:00.70]Stand up together ugokihajimeta negai\n[00:10.32]Whenever, Wherever arata na tabidachi mukaeyou\n[00:30.66]ushinai kaketeita Soul yobisamashita Confide in you\n[00:40.07]futashika na mirai sae shinjirareru The testify\n[00:49.56]tomo ni shita hibi wo hitotsu, futatsu to atsume\n[01:00.57]saita nukumori tsuyoku nigirishime\n[01:09.41]Whenever, Wherever tagai ni yorisoi\n[01:18.71]osoreru koto nado nai yami ga futari wakatsu tomo\n[01:28.73]tashika na kodou ga sou tsugeteiru kara\n[01:37.95]futatabi deaeru made omoi yo douka kimi to tomo ni\n[01:59.10]kasuka ni ikizuita Hope oikakete wa Rely on you\n[02:08.84]fuan kakikesu you ni kimi wo mitsuketa Tragic fate\n[02:18.24]koko ni iru imi wo tsuyoku, tsuyoku kamishime\n[02:29.18]seou unmei kataku tsunagitome\n[03:15.40]Stand up together tagai ni te wo tori\n[03:24.30]obieru koto nado nai hikari ubaisararete mo\n[03:34.72]kasanaru omoi ga oboeteiru kara\n[03:43.81]futatabi deaeru made sukui yo douka kimi no tame\n[03:54.68]Whenever, Wherever tagai ni yorisoi\n[04:03.58]osoreru koto nado nai yami ga futari wakatsu tomo\n[04:14.14]tashika na kodou ga sou tsugeteiru kara\n[04:23.88]futatabi deaeru made omoi yo douka kimi to tomo ni\n	/audio/Gosick ED2「Unity」.mp3	Unity	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253744/covers/Gosick_ED2_Unity.jpg	1
579	572	572	258	[ti:Mirai OP 「Mirai no Theme」]\n[ar:Tatsurou Yamashita]\n[al:Mirai]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:17.56]\n[00:00.00]\n[00:13.99]nagai yume kara\n[00:17.25]sameta bakari no\n[00:21.54]hitomi ga boku wo mitsumete’ru\n[00:28.56]kumo no shizuku ga\n[00:31.96]orite kita ‘n da\n[00:36.29]sennen no kata ekubo\n[00:44.15]unmei no\n[00:47.07]My Baby Girl\n[00:49.00]Cute! Cute! hoozuri shite\n[00:52.09]Gyu! Gyu! dakishimetara\n[00:55.90]Sweet! Sweet! amai nioi ga suru\n[01:03.15]Cute! Cute! hitorijime no\n[01:05.97]Gyu! Gyu! ude no naka de\n[01:09.26]bokura no ai wa\n[01:11.34]tatta ima\n[01:14.06]hajimatta bakari sa\n[01:19.23]mirai e\n[01:27.42]mada nani hitotsu\n[01:30.40]egakarete’nai\n[01:34.39]masshiro na sono gayoushi ni\n[01:41.59]kagayakidashita\n[01:44.80]kimi no ha-to wa\n[01:48.83]donna iro wo erabu no darou\n[01:56.13]machiwabite\n[01:59.74]My Baby Girl\n[02:00.73]Cute! Cute! mashumaro yori\n[02:03.94]Gyu! Gyu! madore-nu yori\n[02:07.55]Sweet! Sweet! yawaraka na kuchibiru\n[02:15.78]Cute! Cute! koodori shite\n[02:19.02]Gyu! Gyu! yubi wo karame\n[02:22.60]kimi no subete wo kitto\n[02:25.89]boku ga mamotte ageru yo\n[02:32.23]mirai e\n[02:52.39]My Baby Girl\n[02:53.66]Cute! Cute! waraigoe mo\n[02:56.95]Gyu! Gyu! nakigao sae\n[03:00.76]Sweet! Sweet! adokenai panorama\n[03:07.76]Cute! Cute! ikiru koto wo\n[03:11.75]Gyu! Gyu! hajimeyou yo\n[03:15.16]bokura no ai mo yatto\n[03:18.78]ima hajimatta bakari sa\n[03:24.48]mirai e\n[03:32.22]mirai e\n[03:46.70]mirai e\n[03:48.63]	/audio/Mirai OP 「Mirai no Theme」.mp3	Mirai no Theme	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253736/covers/Mirai_OP_Mirai_no_Theme.jpg	1
679	679	627	269	[ti:Naruto Shippuden ED38 「Pino to Amelie」]\n[ar:Huwie Ishizaki]\n[al:Naruto]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:29.11]\n[00:00.00]\n[00:15.37]darenimo wakaranai boku no shoutai to yara wo\n[00:26.76]mitsukedashite dakishimetekurenai ka?\n[00:36.37]boku niwa wakarunda uso wo tsuiteiru kimi ga\n[00:47.74]naite ii yo koko ni zutto iru kara\n[00:56.44]sekaijuu ni afureteiru yasuppoi ai no kotoba\n[01:08.33]muri ni nonde sugu ni haite nanimo nai mado kara miteta\n[01:20.39]tooku no sora niwa namae mo nai hoshi ga\n[01:26.51]bokura mitai ni futatsu\n[01:32.35]natsu no kaze ni tobasareteshimawanu you\n[01:38.32]tsunaida chiisa na te wo hanasanai\n[01:51.06]"nandemo nai no" to tsuyogari wo iu kimi ga\n[02:02.34]nanka boku to niteiru ki ga shitanda\n[02:11.28]sekaijuu ni koboreteiru hontou no ai no kimochi\n[02:23.25]sagashidashite miushinatte yoake ga kuru noo matteru\n[02:35.27]migi no hoshi niwa boku no namae wo tsukete\n[02:41.63]kimi ga yonde okureyo\n[02:47.11]hidari no hoshi niwa kimi no namae ga ne\n[02:53.20]niau yo zutto soba ni iru kara\n[03:26.60]tooku no sora niwa namae mo nai hoshi ga\n[03:32.43]bokura mitai ni futatsu\n[03:38.46]natsu no kaze ni tobasareteshimawanu you\n[03:44.24]tsunaida chiisa na te wo hanasanai\n[03:53.30]	/audio/Naruto Shippuden ED38 「Pino to Amelie」.mp3	Pino to Amelie	ED38	https://res.cloudinary.com/ddc6silap/image/upload/v1773253734/covers/Naruto_Shippuden_ED38_Pino_to_Amelie.jpg	1
205	204	204	227		/audio/Death Note OP 「The World」.mp3	The World	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251722/covers/Death_Note_OP_The_World.jpg	1
91	81	85	303		/audio/Boarding School Juliet OP 「Love with you」.mp3	Love with you	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252199/covers/Boarding_School_Juliet_OP_Love_with_you.jpg	1
192	188	184	311		/audio/Date A Live S3 OP 「I swear」.mp3	I swear	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251728/covers/Date_A_Live_S3_OP_I_swear.jpg	3
406	406	406	263	[00:00.00] \n[00:00.79]kon'ya koi ni kawaru shiawase na yume de aou\n[00:07.45]kitto nee mitsukete ne\n[00:11.58]madoromi no yakusoku\n[00:17.40] \n[00:29.19]mebaete'ta nukumori atatakakute tomadou\n[00:40.04]konna kimochi wo mada anata wa wakaranai no\n[00:49.36]sono shisen ni wa imi nante betsu ni nai hazu\n[00:54.87]datte tomodachi ni shite'ru no to onaji\n[01:00.34]akegata ni kiete'ku chiisana negaiboshi\n[01:05.89]yoru no aida dake no mahou ...kizuite hoshii\n[01:11.10]kon'ya koi ni kawaru shiawase na yume de aou\n[01:17.67]kitto nee mitsukete ne\n[01:21.67]madoromi no yakusoku\n[01:26.97] \n[01:39.46]houkago wa itsu de mo tokubetsu na kuukan de\n[01:50.28]issho ni inakute mo tonari ni iru ki ga suru\n[01:59.48]kono mama futari nanigenai toki wo sugosou\n[02:05.00]motto fusawashii hajimari no mae ni\n[02:10.12]matataku hoshitachi ni anata wo sagashite'ta\n[02:15.83]sugu ni deaeru to shinjite ...koko ni iru yo\n[02:21.04]itsuka koi ni kawaru atarashii asa ga kite mo\n[02:27.66]kitto nee kienaide\n[02:31.79]hohoemi ni inoru no\n[02:37.25] \n[02:55.94]kono mama futari nanigenai toki wo sugosou\n[03:01.36]sotto mune no naka yasashisa ga michiru\n[03:06.61] \n[03:09.73]akegata ni kiete'ku chiisana negaiboshi\n[03:15.26]yoru no aida dake no mahou ...kizuite hoshii\n[03:20.31]kon'ya koi ni kawaru shiawase na yume de aou\n[03:27.21]kitto nee mitsukete ne\n[03:31.04]hohoemi wo kawasou\n[03:36.38] \n[03:36.64]matataku hoshitachi ni anata wo sagashite'ta\n[03:42.18]sugu ni deaeru to shinjite ...koko ni iru yo\n[03:47.44]itsuka koi ni kawaru atarashii asa ga kite mo\n[03:54.10]kitto nee kienaide\n[03:58.14]madoromi no yakusoku\n[04:03.13] \n	/audio/Hyouka ED 「Madoromi no Yakusoku」.mp3	Madoromi no Yakusoku	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253765/covers/Hyouka_ED_Madoromi_no_Yakusoku.jpg	1
642	642	627	293		/audio/Naruto OP 「R★O★C★K★S」.mp3	R★O★C★K★S	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252042/covers/Naruto_OP_R_O_C_K_S.jpg	1
860	856	856	307		/audio/Quintessential Quintuplets S2 ED 「Hatsukoi」.mp3	Hatsukoi	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252045/covers/Quintessential_Quintuplets_S2_ED_Hatsukoi.jpg	2
969	245	968	284		/audio/Seraph of the End OP 「X.U.」.mp3	X.U.	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252196/covers/Seraph_of_the_End_OP_X.U..jpg	1
978	139	977	262		/audio/Shigofumi OP 「Kotodama」.mp3	Kotodama	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252040/covers/Shigofumi_OP_Kotodama.jpg	1
194	194	184	242		/audio/Date A Live S4 OP 「OveR」.mp3	OveR	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251748/covers/Date_A_Live_S4_OP_OveR.jpg	4
195	195	184	222		/audio/Date A Live_ Dead or Bullet ED 「Only wish」.mp3	Only wish	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251739/covers/Date_A_Live_Dead_or_Bullet_ED_Only_wish.jpg	1
200	200	199	246		/audio/Deaimon ED2 「Orlando」.mp3	Orlando	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251742/covers/Deaimon_ED2_Orlando.jpg	1
208	208	208	300		/audio/Demon Slayer ED 「From the Edge」.mp3	From the Edge	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251734/covers/Demon_Slayer_ED_From_the_Edge.jpg	1
213	213	208	329		/audio/Demon Slayer OST 「Kamado Tanjiro no Uta」.mp3	Kamado Tanjiro no Uta	OST	https://res.cloudinary.com/ddc6silap/image/upload/v1773251732/covers/Demon_Slayer_OST_Kamado_Tanjiro_no_Uta.jpg	1
215	130	215	288	[00:00.00] \n[00:45.34]doko kara asa ni naru? shizuka na sora minai furi o shita yubikiri koyubi no saki\n[00:56.50]warawareta tsuki nara kieteyuku nda kinou no hougaku e\n[01:07.21]usotsuki okubyoumono minna matomete boku nara saiteita no wa yume no naka da\n[01:18.47]tsuki no kage ni kakushiteta hontou wa ne naiteta namida wa mou nagarenai kareteshimatta no?\n[01:29.65]nanimokamo yurusetara nagareru ka mo shirenai kedo mamoritai mono bakari da na\n[01:43.66] \n[01:46.77]itsu kara kikoeteta? boku no koe sonna ni mo furueteta? okashii ka na\n[01:57.84]utatteta dake da yo koko ni iru tte asu no hougaku e\n[02:08.52]omoide chirakaru heya ashi no fumiba mo nai nara subete nokoshite karada hitotsu de\n[02:19.81]kurai doa o kojiakete owaru tabi ni dekaketa\n[02:25.38]mawarimichi de mayotte mo sayonara koko de ii\n[02:30.92]nanimokamo mitometara mitsukaru ka mo shirenai kedo mamorenai mono bakari da na\n[02:43.24]kara ni natteita mama daiji ni shiteta no ni\n[02:54.44]yubisaki de fureta kurai de kuzureru kara\n[03:05.05] \n[03:26.80]kawarugawaru te ni shite wa nigirishimete kowashitari\n[03:37.97]ai no uta ni fusaide wa kowaku natte hanashitari kurikaeshite\n[03:49.10]tsuki no kage ni kakushiteta hontou wa ne saiteta magarikado de fumitsukete kareteshimawanaide\n[04:00.34]nanimokamo tebanashite tatta hitotsu nokoru mono o mamoreru you ni inoru yoake\n[04:14.65] \n	/audio/Devil is a Part Timer ED 「Gekka」.mp3	Gekka	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253740/covers/Devil_is_a_Part_Timer_ED_Gekka.jpg	1
98	97	97	264		/audio/Bocchi the Rock! ED2 「Karakara」.mp3	Karakara	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252205/covers/Bocchi_the_Rock_ED2_Karakara.jpg	1
107	106	107	233		/audio/Btooom! OP2 「Exist」.mp3	Exist	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252203/covers/Btooom_OP2_Exist.jpg	1
231	231	227	247		/audio/Dr. Stone S2 ED 「Koe_」.mp3	Koe?	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251763/covers/Dr._Stone_S2_ED_Koe.jpg	2
261	261	260	275		/audio/Eromanga Sensei ED2 「Natsu iro Koi Hanabi」.mp3	Natsu iro Koi Hanabi	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251756/covers/Eromanga_Sensei_ED2_Natsu_iro_Koi_Hanabi.jpg	1
262	112	260	234		/audio/Eromanga Sensei OP 「Hitorigoto」.mp3	Hitorigoto	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251760/covers/Eromanga_Sensei_OP_Hitorigoto.jpg	1
506	506	505	243		/audio/Land of the Lustrous ED2 「liquescimus」.mp3	liquescimus	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252301/covers/Land_of_the_Lustrous_ED2_liquescimus.jpg	1
772	771	771	197		/audio/Onipan! ED2 「Oniyaba!」.mp3	Oniyaba!	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252744/covers/Onipan_ED2_Oniyaba.jpg	1
1241	1241	1240	278	[ti:Vivy: Fluorite Eye's Song ED2 「Ensemble for Polaris」]\n[ar:Estella and Elizabeth]\n[al:Vivy: Fluorite Eye's Song]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:37.99]\n[00:00.00]Harukana mukashi no koto\n[00:07.96]Hito wa samayou tabi\n[00:14.51]Hikaru hokkyokusei\n[00:20.80]Sagashimashita\n[00:27.62]Yozora o miage aruku\n[00:34.50]Namida koborenu you\n[00:41.26]Kitto mata aeruto\n[00:47.64]Yakusoku o shitakara\n[00:55.72]Nodo no kawaki iyasu\n[01:02.35]Hishaku wa hokutoshichisei\n[01:08.59]Shinwa no andoromedā\n[01:15.37]Sukui no peruseusu\n[01:21.85]Konoyo no utsukushi sa o\n[01:28.99]Omoide ni atsumete\n[01:35.59]Itoshī basho e kaeru\n[01:42.05]Tōku ni hanarete mo\n[01:49.09]Sora wa tsunagaru\n[02:22.20]Ikusen nen no kanata\n[02:28.89]Anata ni nita hito ga\n[02:35.72]Ikiteita jikan o\n[02:42.19]Hoshi wa shirusu\n[02:48.79]Goranyo machi no akari\n[02:55.56]Yukkuri nemuri no naka\n[03:02.31]Minna ni sachi ōkare to\n[03:08.58]Inoru shugo wakusei\n[03:15.73]Yume o miteita toki\n[03:22.21]Hajimete koi o shitta hi\n[03:28.66]Seiza ni negai kometa\n[03:35.22]Todoku koto o shinjinagara\n[03:48.50]Harukana mukashi no koto\n[03:55.68]Hito wa samayou tabi\n[04:02.26]Hikaru hokkyokusei to\n[04:08.70]Musubareteimashita\n[04:15.59]Sora wa tsunagaru\n[04:24.72]	/audio/Vivy_ Fluorite Eye_s Song ED2 「Ensemble for Pol.mp3	Ensemble for Polaris	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253784/covers/Vivy_Fluorite_Eye_s_Song_ED2_Ensemble_for_Polaris.jpg	1
209	209	208	221		/audio/Demon Slayer Nezuko_s Theme Song.mp3	Nezuko's Theme Song	OST	https://res.cloudinary.com/ddc6silap/image/upload/v1773251753/covers/Demon_Slayer_Nezuko_s_Theme_Song.jpg	1
210	210	208	222		/audio/Demon Slayer Nezuko_s Theme.mp3	Nezuko's Theme	OST	https://res.cloudinary.com/ddc6silap/image/upload/v1773256647/covers/Demon_Slayer_Nezuko_s_Theme.jpg	1
225	225	223	230	[00:00.00] \n[00:01.13]Party is over, soredemo odoritakatta\n[00:11.82]Nemurenai kurai jounetsu no hi wa itsushika itsu no hi ni ka\n[00:23.11]Hana kara kizuiteiru homura wa itsuka kieru\n[00:28.61]Nee nanimo iranai hazu datta\n[00:31.49]Na no ni mada I’m so serious\n[00:35.07]Ah, mada maniau\n[00:41.01]Ah, tada Burn it up, baby\n[00:45.73]Sorry darling sonna ni amakunai yo\n[00:48.42]Demo kitto sonna ni warukunai yo\n[00:52.21]Give me fire\n[00:55.10]Light it up, baby moyashichau ze, yeah\n[01:09.50]Yeah-ah-ah, ah-ah-ah\n[01:12.53]Ah-ah-ah, ah-ah-ah\n[01:15.06]Yeah-ah-ah, ah-ah-ah\n[01:17.22]Ah-ah-ah, ah-ah-ah\n[01:20.33]Ah, ah-ah, ah-ah\n[01:22.77]Ah-ah, ah-ah\n[01:24.44]Moeru yo moeru yo\n[01:27.30]Hono yo moeru\n[01:29.62]Yeah! chiyo mo yachiyo kawari mo sezu ni\n[01:32.90]Hito no nari ito wo kashi zenbu moyase yaoya oshichi\n[01:35.78]Ide yo mae yo hinoko takitsukeru no ga shigoto\n[01:38.69]Gasorin to suteroido moeru sama wa omigoto\n[01:41.36]Hiasobi wa shinai nurui mane dekinai\n[01:44.64]Shiketa karuma torauma moyashitsukusu maguma dorama\n[01:47.25]Kono aku naki kawaki aoi honoo mitai\n[01:50.06]Shi wa kako no hitotsu tonari yagate subete hitotsu to nari\n[01:52.77]Love is dying, demo mada kietenai kara\n[02:03.29]Wasurete mitai\n[02:08.81]Jounetsu no hi wa itsushika itsu no hi ni ka\n[02:14.68]Karada wa kizuiteiru bokura wa itsuka kieru\n[02:20.20]Yuruyaka ni wakasa wo tokashite\n[02:22.96]Nakanai de Why so serious?\n[02:26.58]Ah, mada maniau\n[02:31.94]Ah, tada Burn it up, baby\n[02:37.19]Sorry darling sonna ni amakunai yo\n[02:40.08]Demo kitto sonna ni warukunai yo\n[02:43.74]Give me fire\n[02:46.53]Light it up, baby moyashichau ze, yeah\n[03:00.76]Yeah-ah-ah, ah-ah-ah\n[03:03.29]Ah-ah-ah, ah-ah-ah\n[03:06.66]Yeah-ah-ah, ah-ah-ah\n[03:07.67]Turn it up, turn it up tarinai\n[03:08.98]Sosogu hi ni abura!\n[03:10.54]Sorry darling, hurry up\n[03:11.80]Aa mada maniau\n[03:13.23]Sorry darling, hurry up\n[03:14.60]Aa tada burn it up\n[03:16.10]Give me fire\n[03:19.15]Light it up, baby moyashichau ze, yeah\n[03:22.84]Party is over\n[03:27.88]Soredemo odoritakatta\n[03:32.41] \n	/audio/Dororo OP 「Fire」.mp3	Fire	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253666/covers/Dororo_OP_Fire.jpg	1
105	8	105	301	[ti:Btooom! ED 「Aozoro」]\n[ar:May'n]\n[al:Btooom!]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:05:00.76]\n[00:00.00]\n[00:13.21]Iki wo sezu me wo fuseta\n[00:20.75]Hikyou na hodo kirameku aozora ga\n[00:26.11]Kono machi no zujou kara\n[00:33.12]Tomedonaku namida furaseru kara\n[00:38.13]Omoide ni wa dekinai\n[00:44.26]Au dake de ureshikatta\n[00:50.46]Kimi no koto shirazu ni kizutsukete Nobody Knows\n[01:03.26]Gomen ne watashi wo mou yurusanai de wasurete\n[01:28.57]Ano hi kara katamuita\n[01:35.66]Jikanjiku no dokoka ni kimi wa ite\n[01:41.32]Dokomademo yubi no saki\n[01:49.80]Nobashita kedo kaze shika tsukamenai\n[01:57.91]Asa mo yoru mo kokoro ga semeru no yo naze doushite\n[02:09.92]Ato sukoshi jibun sae shinjitara Can't go away\n[02:22.84]Dame da na mata nigeteru\n[02:31.22]Mitsumeteru'nda RIARU wo\n[02:49.04]Tanoshikereba yokatta soredemo tayori aeteta\n[02:56.48]Sekai ga kyuu ni\n[03:01.41]Konagona ni kuzureochi hajimete kanjiru nante\n[03:09.08]Sono mune no itami\n[03:13.73]Onegai dakara nakanai de\n[03:22.05]Omoide ni wa dekinai furimuita kao wa dare mo\n[03:35.38]Yuuyake ni kakureta SHIRUETTO Nobody Knows\n[03:47.98]Kitto kimi no kokoro mo sakenderu naze doushite\n[04:00.63]Sabishisa no fukasa ga oshieru yo Can't go away\n[04:13.41]Sou da ne ikitsuzukeru\n[04:21.90]Hohoemi aeru hi made...\n[04:29.31]Nobody knows but me...\n[04:40.78]Only you told me everything...yes, everything...\n[04:53.43]	/audio/Btooom! ED 「Aozoro」.mp3	Aozoro	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253812/covers/Btooom_ED_Aozoro.jpg	1
239	239	235	298		/audio/Eden of the East OP 「Falling Down」.mp3	Falling Down	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251781/covers/Eden_of_the_East_OP_Falling_Down.jpg	1
245	245	245	250		/audio/Eighty Six ED 「Avid」.mp3	Avid	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251775/covers/Eighty_Six_ED_Avid.jpg	1
251	251	251	265		/audio/Electromagnetic Girlfriend ED 「Taiyo」.mp3	Taiyo	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251770/covers/Electromagnetic_Girlfriend_ED_Taiyo.jpg	1
1024	1024	1009	238		/audio/Steins Gate 0 「Amadeus」.mp3	Amadeus	0	https://res.cloudinary.com/ddc6silap/image/upload/v1773251786/covers/Steins_Gate_0_Amadeus.jpg	1
144	144	94	283		/audio/Code Geass M9 ED 「Revive」.mp3	Revive	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251810/covers/Code_Geass_M9_ED_Revive.jpg	1
233	233	233	242		/audio/Dusk Maiden of Amnesia ED 「Calendrier」.mp3	Calendrier	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251802/covers/Dusk_Maiden_of_Amnesia_ED_Calendrier.jpg	1
327	70	327	190		/audio/Golden Time ED 「Sweet _ Sweet CHERRY」.mp3	Sweet & Sweet CHERRY	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252268/covers/Golden_Time_ED_Sweet_Sweet_CHERRY.png	1
334	334	333	313	[ti:Grand Blue OP 「Grand Blue」]\n[ar:Shounen no Kaze]\n[al:Grand Blue]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:05:12.45]\n[00:00.47]Atsuku nare My Friends\n[00:04.76]Taiyō to hade ni\n[00:07.65]Aoi sora tobikome\n[00:11.61]Zenbu natsu ni makasete\n[00:29.15]Atsuku nare My Friends\n[00:33.25]Taiyō to hade ni\n[00:36.43]Aoi sora tobikome\n[00:40.18]Zenbu natsu ni makasete\n[00:43.40]Kokoro harebare\n[00:47.63]Name n ja nei\n[00:51.02]Taoreta tte mae e\n[00:54.09]Zenbu natsu ni makasete\n[00:57.77]Mada mita koto nai fukai basho\n[01:01.54]Omae no koto shiritai n da motto\n[01:04.96]Tobikomu yūki ga are ba honto\n[01:08.51]Sugu ni de mo chikazukerudarō\n[01:12.12]Namima ni daibingu\n[01:14.51]Taimingu hakari atakku\n[01:16.41]Mada tarinai kiryō wa\n[01:17.90]Kiai de osu taipu\n[01:20.08]De mo tabitabi itai omoi\n[01:22.00]Hirihiri hiyake no ato mitai ni\n[01:25.51]Omoide ni shichae ba ī\n[01:27.43]Natsu kaiten hatsu taiken\n[01:29.70]ī ze ī ze ī ze!\n[01:30.67]Hadaka no renchū necchū gecchu shōbu\n[01:33.07]ī ze ī ze ī ze!\n[01:34.60]Hotetta hāto roketto sutāto\n[01:38.42]Tokonatsu no akushon tobikome\n[01:42.87]Atsuku nare My Friends\n[01:47.01]Taiyō to hade ni\n[01:50.16]Aoi sora tobikome\n[01:53.88]Zenbu natsu ni makasete\n[01:57.56]Kokoro harebare\n[02:01.48]Name n ja nei\n[02:04.67]Taoreta tte mae e\n[02:08.52]Zenbu natsu ni makasete\n[02:12.27]Mō taiyō kara nigenai\n[02:15.55]Kono natsu de kawaru n daro!\n[02:19.04]Ano suihei sen made tobikome\n[02:23.41]No More Cry\n[02:24.60]Don t My Mind Easy Come Easy Go\n[02:28.45]Fukaku mogure soko wa kirei na sango shō\n[02:33.29]Migi mo hidari mo wakarazu\n[02:37.14]Enjoy Yourself Season of Love\n[02:40.70]Ase kaite furu kaiten\n[02:43.01]ī ze ī ze ī ze!\n[02:44.23]Hadaka de kenkyū seishun enjoi shiyō!\n[02:46.63]ī ze ī ze ī ze!\n[02:48.23]Kimero supatto rasuto supāto\n[02:51.90]Tokonatsu no akushon tobikome\n[02:56.96]Atsuku nare My Friends\n[03:01.14]Taiyō to hade ni\n[03:04.04]Aoi sora tobikome\n[03:07.87]Zenbu natsu ni makasete\n[03:11.49]Kokoro harebare\n[03:15.50]Name n ja nei\n[03:18.65]Taoreta tte mae e\n[03:22.48]Zenbu natsu ni makasete\n[03:40.69]Hirogaru umi no yō na kanō-sei\n[03:42.28]Kureru natsu koso ore-ra no amōre\n[03:46.10]Harewataru sora ni chikaō ze\n[03:49.93]Natsu o kono te ni\n[03:53.64]Torokeru hodo atsui\n[03:55.77]Machi ni matta natsu ni\n[03:57.58]Kokoro no kagi hazushitobikome\n[04:01.19]Sun na ato no matsuri\n[04:03.04]Motto hotto ni gattsuri\n[04:04.61]Mabushī asu ni tobikome\n[04:08.66]Da tte moshi mo kimi ga namida no ame ni utareta tte\n[04:16.86]Sono jōnetsu hikari ni kae\n[04:22.31]Atsuku nare My Friends\n[04:26.16]Taiyō to hade ni\n[04:29.09]Aoi sora tobikome\n[04:32.76]Zenbu natsu ni makasete\n[04:36.48]Kokoro harebare\n[04:40.44]Name n ja nei\n[04:43.59]Taoreta tte mae e\n[04:47.16]Zenbu natsu ni makasete\n[04:50.32]Oh yeah!\n[04:51.64]Tobikome\n[05:02.52]Zenbu natsu ni makasete\n[05:07.68]	/audio/Grand Blue OP 「Grand Blue」.mp3	Grand Blue	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252257/covers/Grand_Blue_OP_Grand_Blue.jpg	1
769	769	766	254	[00:00.00] \n[00:10.70]Mune ni egaita sorezore no yume\n[00:16.01]Kako no itami ga mirai wo\n[00:21.06]Yonderu no ka tōzakeru ka\n[00:26.66]Wakaranai koto mo aru yo\n[00:32.09]Sore de mo itsu ka yasuragi no naka de\n[00:37.38]Subete yuruseru toki ga kurundarō\n[00:42.65]'wasurete shimae' to ī nagara\n[00:46.91]Wasurenai sonzai nan da ne boku-ra wa\n[00:52.22]Te wo nobase ba yasashi-sa ga tsuyo-sa da to\n[00:58.73]Oshiete kureru kizuna ga\n[01:02.71]Ikiru tame ni taisetsu na mono sa\n[01:09.37]Da kara modotte kuru yo\n[01:14.56]Koko e modotte kuru yo\n[01:20.94] \n[01:30.72]Chigau basho demo onaji hikari ga sora wo\n[01:36.77]terasu hazu dakara\n[01:40.99]Doko ni itemo tsutawarun da to\n[01:46.73]Shinjireba mata hashireru\n[01:51.98]Kanarazu itsuka negai ga kanau to\n[01:57.28]Dangen dekinai sekai dakedo sa\n[02:02.58]Kiraku ni mattete to kigaru ni tabidateba\n[02:07.96]Tsumetai kaze mo tsurakunai\n[02:12.23]Kokoro wa jiyuu yasashisa wo tsuyosa e to\n[02:18.52]Kaeru koto mo oboetara\n[02:22.72]Motto dareka mamoreru ki ga shite\n[02:29.25]Hitori miageru no wa kimi to tsunagaru sora\n[02:40.90] \n[03:01.33]Kaeru basho made chizu ga nakutatte\n[03:06.75]Michibiku kimi no kodou no atsusa\n[03:12.03]Omoi no ya ga kitto massugu tobu hou e\n[03:17.44]Tatoe tookutemo tookutemo...\n[03:26.76]Te wo nobaseba yasashisa ga tsuyosa da to\n[03:33.46]Oshiete kureru kizuna ga\n[03:37.54]Ikiru tame ni taisetsu na mono sa\n[03:44.00]Dakara modotte kuru yo koko e modotte\n[03:51.90]kuru yo\n[03:56.18] \n	/audio/One Punch Man S2 ED 「Chizu ga Nakutemo Modoru k.mp3	Chizu ga Nakutemo Modoru kara	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253824/covers/One_Punch_Man_S2_ED_Chizu_ga_Nakutemo_Modoru_kara.jpg	2
982	980	979	273	[00:00.00] \n[00:13.27]aishi..aishi aeru to iu no? kimi no kuchibiru wo fusagu yo\n[00:25.38]me wo tojite tsumi fukaki kuchizuke\n[00:34.11] \n[00:38.71]aishi..aishi aeru sa kitto kimi no kubisuji ni tsukitate\n[00:50.74]me wo tojite tsumi fukaki kuchizuke\n[01:00.14] \n[01:03.99]nidoto modorenai sore de ii\n[01:11.02]mayonaka wo mitsumete WINE nomihosu\n[01:19.02] \n[01:29.29]aishi..aishiau no sa motto hageshii kawaki ni kuruisou\n[01:41.12]me wo tojite tsumi fukaki kuchizuke\n[01:50.57] \n[01:54.61]omae no nioi kuruwaseru\n[02:01.55]mayonaka ni mezamete kyouki ai nomihosu\n[02:07.93]oide kono ude no naka "Acchi no yami wa nigai zo"\n[02:14.07]kimi wa madoi yurameku\n[02:20.32]yagate eien ni naru "Kocchi no yami wa amai zo"\n[02:26.72]boku wa fukaku tsukisasu\n[02:33.29] \n[02:57.73]omae no nioi kuruwaseru\n[03:04.62]mayonaka ni mezamete kyouki ai nomihosu\n[03:11.05]oide kono ude no naka "Acchi no yami wa nigai yo"\n[03:17.31]kimi wa madoi yurameku\n[03:23.48]yagate eien ni naru "Kocchi no yami wa amai zo"\n[03:29.93]boku wa fukaku tsukisasu\n[03:36.26]oide kono ude no naka "Acchi no yami wa nigai zo"\n[03:42.55]kimi wa sukoshi hohoemu\n[03:48.85]kore de eien ni naru "Kocchi no yami wa amai zo"\n[03:55.16]boku wa fukaku tsukisasu\n[04:02.57] \n	/audio/Shiki OP「Kuchizuke」.mp3	Kuchizuke	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253831/covers/Shiki_OP_Kuchizuke.jpg	1
235	235	235	247		/audio/Eden of the East ED 「futuristic imagination」.mp3	futuristic imagination	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251796/covers/Eden_of_the_East_ED_futuristic_imagination.jpg	1
236	236	235	281		/audio/Eden of the East M2 OP 「future nova」.mp3	future nova	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251790/covers/Eden_of_the_East_M2_OP_future_nova.jpg	1
248	245	245	245		/audio/Eighty Six S2 ED 「LilaS」.mp3	LilaS	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251793/covers/Eighty_Six_S2_ED_LilaS.jpg	2
254	254	254	276		/audio/Engaged to the Unidentified ED 「Masshiro World」.mp3	Masshiro World	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251799/covers/Engaged_to_the_Unidentified_ED_Masshiro_World.jpg	1
303	303	300	220		/audio/Fullmetal Alchemist Brotherhood ED4 「Shunkan Se.mp3	Shunkan Sentimental	ED4	https://res.cloudinary.com/ddc6silap/image/upload/v1773252258/covers/Fullmetal_Alchemist_Brotherhood_ED4_Shunkan_Sentimental.jpg	1
312	312	311	228		/audio/Gate S2 ED2 「Sore wa Akatsuki no you ni」.mp3	Sore wa Akatsuki no you ni	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252262/covers/Gate_S2_ED2_Sore_wa_Akatsuki_no_you_ni.jpg	2
112	112	112	241		/audio/Cells At Work ED 「CheerS」.mp3	CheerS	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251829/covers/Cells_At_Work_ED_CheerS.jpg	1
117	116	112	182		/audio/Cells at Work! Code Black OP 「Hashire!」.mp3	Hashire!	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251827/covers/Cells_at_Work_Code_Black_OP_Hashire.jpg	1
857	857	856	211		/audio/Quintessential Quintuplets Movie ED Theme 「Gotoubun no Hanayome ~Arigatou no Hana~」.mp3	Gotoubun no Hanayome ~Arigatou no Hana~	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773251834/covers/Quintessential_Quintuplets_Movie_ED_Theme_Gotoubun_no_Hanayome_Arigatou_no_Hana.jpg	1
1030	845	1009	254	[00:00.00] \r\n[00:26.56]"Time" is so sad and fleeting\r\n[00:32.35]Can't be controlled, like a river, never stops\r\n[00:39.29]"Space" is emptiness dark and so cold\r\n[00:45.42]Can you define it's presence, does it exist?\r\n[00:52.03]We drift through the heavens hatenai omoi\r\n[00:58.98]Filled with the love from up above\r\n[01:05.58]He guides my travels semaru kokugen\r\n[01:12.11]Shed a tear and leap to a new world\r\n[01:31.47]Cosmos and their creation\r\n[01:37.35]Tell me do they exist for infinity\r\n[01:44.26]Stars burn, burning so bright but they'll fade\r\n[01:50.33]How will I know?\r\n[01:51.94]Secrets kept until I die\r\n[01:57.03]Defy my destiny mamoritai mono\r\n[02:03.74]Foolish, but it's humanity\r\n[02:10.31]Imagination kiseki ni kaeru\r\n[02:16.86]Things you can't conceive\r\n[02:19.13]Revelation!\r\n[02:23.41] \r\n[02:45.58]A drop in the darkness chiisana inochi\r\n[02:52.53]Unique and precious forever\r\n[02:58.98]Bittersweet memories? mugen no setsuna\r\n[03:05.45]Make this moment last, last forever\r\n[03:11.47]We drift through the heavens hatenai omoi\r\n[03:18.39]Filled with the love from up above\r\n[03:25.02]He guides my travels semaru kokugen\r\n[03:31.32]Shed a tear and leap to a new world\r\n[03:38.24] \r\n	/audio/Steins_Gate 0 Ending Song 「GATE OF STEINER」.mp3	GATE OF STEINER	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773254117/covers/Steins_Gate_0_Ending_Song_GATE_OF_STEINER.jpg	1
1039	28	939	251	[00:00.00] \n[00:11.51]Mitomete ita okubyou na kako\n[00:16.29]Wakaranai mama ni kowagatte ita\n[00:24.33]Ushiro no jibun ga genjitsu wo ima ni utsusu\n[00:33.08]Ikutsu mono sora wo kaita koko wa kitto\n[00:40.46]Hakanai kokoro midashite\n[00:45.79]Yume de takaku tonda karada wa\n[00:51.33]Donna fuan matotte mo furiharatte iku\n[00:56.54]Nemuru chiisana omoi hirogari dashite\n[01:02.95]Kizuku yowai watashi kimi ga ireba\n[01:07.11]Kurai sekai tsuyoku ireta\n[01:12.53]Nagai yume miru kokoro wa sou eien de\n[01:18.80]I wanna always be with you\n[01:21.69]I give you everything I have\n[01:24.80] \n[01:25.30]Sagashite ita michibiku hikari\n[01:30.11]Furere ba subete omoidashite\n[01:38.03]Kakegae no nai taisetsu na ima wo kureru\n[01:46.76]Me wo toji sekai wo shitta\n[01:52.19]Sore wa itsumo atatakai no ni itakute\n[01:59.53]Tsunagu tashika na negai kasanari atte\n[02:06.14]Mieru mayoi wa ugoki hajimeta\n[02:10.20]Kimi wo mamoritakute seou kizu wa\n[02:16.65]Fukai nemuri no naka tadayotta\n[02:20.86]Kawaranai yakusoku datta\n[02:26.26]Futari shinjita kizuna wa sou senmei ni\n[02:31.66] \n[03:01.25]Koe ga todoku made namae wo yonde\n[03:07.69]Deaeta kiseki kanjitai motto\n[03:11.99]Yume de takaku tonda karada wa\n[03:18.09]Donna fuan matotte mo furiharatte iku\n[03:23.35]Nemuru chiisana omoi hirogari dashite\n[03:29.70]Kidzuku yowai watashi kimi ga ireba\n[03:33.94]Kurai sekai tsuyoku ireta\n[03:39.22]Nagai yume miru kokoro wa sou eien de\n[03:45.83]I wanna always be with you\n[03:48.63]I wanna hold you tight right now\n[03:51.29]I swear I will wipe your tears\n[03:53.82]I'll give you everything I have\n[03:59.32] \n	/audio/Sword Art Online OP 「Crossing Field」.mp3	Crossing Field	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253949/covers/Sword_Art_Online_OP_Crossing_Field.jpg	1
135	20	131	344		/audio/Clannad_ Another World ED 「Ana」.mp3	Ana	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251820/covers/Clannad_Another_World_ED_Ana.jpg	1
148	148	94	213		/audio/Code Geass OP3 「Hitomi no Tsubasa」.mp3	Hitomi no Tsubasa	OP3	https://res.cloudinary.com/ddc6silap/image/upload/v1773251817/covers/Code_Geass_OP3_Hitomi_no_Tsubasa.jpg	1
240	240	235	215		/audio/Eden of the East OP2 「Michael Ka Belial」.mp3	Michael Ka Belial	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251832/covers/Eden_of_the_East_OP2_Michael_Ka_Belial.jpg	1
315	203	314	268		/audio/Genshiken OP 「Kujibiki Unbalance」.mp3	Kujibiki Unbalance	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252271/covers/Genshiken_OP_Kujibiki_Unbalance.jpg	1
476	476	474	149		/audio/Kaze no Stigma ED3 「Tsuki Hana no Inori」.mp3	Tsuki Hana no Inori	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252273/covers/Kaze_no_Stigma_ED3_Tsuki_Hana_no_Inori.jpg	1
246	245	245	213	[ti:Eighty Six ED2 「Hands Up to the Sky」]\n[ar:SawanoHiroyuki]\n[al:86]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:32.71]\n[00:00.00]\n[00:05.89]1, 2, 3, We made it through\n[00:07.98]4 & 5, You got it too?\n[00:10.35]Karisome no yozora wo terasu\n[00:14.98]Handle it with light\n[00:16.54]Tohou monai kure ni wakare wo tsugeru\n[00:20.13]Tashika na koe wo kike\n[00:24.09]Stand up and get a start\n[00:27.18]Ki no muku mama\n[00:29.79]It's depending on your heart\n[00:31.79]Can take shivers of your scar\n[00:34.37]Hirogatta sekai ni egaite iku\n[00:38.86]Akogare wa itsuka kiete shimau no ka?\n[00:00.00][source: https://animesonglyrics.com]\n[00:44.56]Raise your hands up to the sky\n[00:48.44]Tojiteita vision ima mirai wo tsunaide\n[00:54.38]Listen up, Troublemaker\n[00:56.66]How'd you know 'bout my fever?\n[00:59.14]Donna ni yomiasatatte soko ni kotae wa nai\n[01:04.19]7, Our dream has come true\n[01:06.87]& 9, What you gonna do?\n[01:09.36]Muboubi na toiki ga ame wo furasu\n[01:13.39]Hug each other tight\n[01:15.37]Toru nitaranai sasai na henka mo\n[01:18.74]Yorokobi aeru hi ga kuru nara\n[01:23.28]Stand up and get a start\n[01:25.91]Kimagure demo ii\n[01:28.48]It's depending on your heart\n[01:31.08]Can take shivers of your scar\n[01:33.50]Tsumasakidachi shite nozoiteita renzu no sono saki ni\n[01:40.83]Odoru purizumu no you ni\n[01:43.40]Raise your hands up to the sky\n[01:47.65]Tokihanatsu dimension arata na peeji hiraite\n[01:53.66]Listen up, Troublemaker\n[01:55.86]How'd you know 'bout my fever\n[01:58.38]Donna ni aishiteitatte oto ni noserenai\n[02:03.59]Smile with me, with your white teeth\n[02:06.19]Sunao ni to feel so free\n[02:08.59]Koko kara kawaru nara\n[02:11.05]Rewrite the codes of memories\n[02:13.50]Smile with me, with delight please\n[02:15.95]Sunao ni to feel so free\n[02:18.26]Korekara kawaru kara\n[02:20.70]Rewrite the chords of melodies\n[02:23.92]Stand up and get a start\n[02:27.57]Ki no muku mama\n[02:29.73]It's depending on your heart\n[02:32.05]Can take shivers of your scar\n[02:34.49]Hirogatta sekai ni egaite iku\n[02:39.08]Akogare wa itsuka kiete shimau no ka?\n[02:44.90]Raise your hands up to the sky\n[02:48.66]Tojiteita vision ima mirai wo tsunaide\n[02:54.66]Listen up, Troublemaker\n[02:57.07]How'd you know 'bout my fever?\n[02:59.52]Donna ni yomiasatatte soko ni kotae wa nai\n[03:04.42]Raise your hands up to the sky\n[03:08.37]Tokihanatsu dimension arata na peeji hiraite\n[03:14.69]Listen up, Troublemaker\n[03:17.06]How'd you know 'bout my fever\n[03:19.57]Donna ni aishiteitatte oto ni noserenai\n[03:24.31]	/audio/Eighty Six ED2 「Hands Up to the Sky」.mp3	Hands Up to the Sky	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253860/covers/Eighty_Six_ED2_Hands_Up_to_the_Sky.jpg	1
263	263	263	263	[00:00.00] \n[00:01.04]Kyou mo ikite iru no desu\n[00:03.35]Boku wa boku no mamori kata wo\n[00:08.24]Youyaku shitta no desu\n[00:12.50] \n[00:22.69]Taikutsu na genjou sore to aijou\n[00:25.33]Kanjou, dou shiyou\n[00:26.72]Itsu made tatte mo sadamaranai yo\n[00:29.63]Boku wa boku na no ni naa\n[00:32.30]Taisetsu na hito mo koi mo ai mo\n[00:34.87]Sei mo, dou shiyou\n[00:36.30]Itsu made tatte mo mamori kirenai yo\n[00:39.41]Itsuka wa kiete shimau\n[00:41.70]Yahari boku wa hitori de wa\n[00:46.45]Kakae kirenai mono bakari de\n[00:51.38]Tsuyoku narenai karada ni\n[00:56.11]Tsuyosa wo motomete\n[01:00.56]Kono tayorinai tsubasa hirogete\n[01:05.23]Mukae ni kitan da yo\n[01:07.79]Ai ni kitan da yo\n[01:10.30]Ima wa mada tobenai tori dakedo\n[01:15.31]Saitei de mo, kimi dake wa mamoreru you ni\n[01:20.27]Saitei de mo, kimi dake wa mamoreru you ni\n[01:25.08] \n[01:30.46]Yuuutsu na mouningu\n[01:31.92]Sore to surou ni kawari hajimeta\n[01:34.50]Itsu made tatte mo waraenai naa\n[01:37.44]Sekai ga kusari sou nan da\n[01:39.89]Kanashii monogatari nante\n[01:44.39]Osanai koro ni kikiakita yo\n[01:49.47]Yasashii dareka no sasayaki de\n[01:54.26]Namida ga deta ima\n[01:58.84]Mou kakusenai nanika wo kakae\n[02:03.46]Mukae ni ikun da yo\n[02:06.17]Ai ni ikun da yo\n[02:08.30]Ima wa mada tsutaerarenai kedo\n[02:13.36]Saiaku de mo, boku dake wa koko ni iru kara\n[02:18.37]Saiaku de mo, boku dake wa koko ni iru kara\n[02:26.56]Ushinau mono ga kimi da to shitara\n[02:35.32]Boku ga sekai no dokoka ni\n[02:38.66]Kimi dake no ibasho wo tsukutte ageru\n[02:46.13]Ushinau mono ga boku da to shitara\n[02:54.76]Boku ga kimi wo mamoreta to iu\n[02:59.78]Akashi ni naru deshou\n[03:06.58]Kono tayorinai tsubasa hirogete\n[03:11.30]Mukae ni kitan da yo\n[03:14.01]Ai ni kitan da yo\n[03:16.43]Ima wa mada tobenai tori dakedo\n[03:21.49]Saitei de mo, kimi dake wa mamoreru you ni\n[03:26.04]Mou kakusenai nanika wo kakae\n[03:30.76]Mukae ni ikun da yo\n[03:33.15]Ai ni ikun da yo\n[03:35.79]Ima wa mada tsutaerarenai kedo\n[03:40.69]Saiaku de mo, boku dake wa koko ni iru kara\n[03:45.64]Saiaku de mo, boku dake wa koko ni iru kara\n[03:54.72] \n[04:01.67]Kyou mo ikite iru no desu\n[04:03.95]Boku wa boku no mamori kata wo shirimashita\n[04:11.06]Soshite kimi no soba ni iru to kimemashita\n[04:19.54] \n	/audio/Even If the World Ends Tomorrow ED Theme 「Ashit.mp3	Ashita Sekai ga Owaru toshitemo	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253845/covers/Even_If_the_World_Ends_Tomorrow_ED_Theme_Ashita_Sekai_ga_Owaru_toshitemo.jpg	1
905	905	904	267		/audio/Re_Zero ED2 「Stay Alive」.mp3	Stay Alive	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251846/covers/ReZero_ED2_Stay_Alive.jpg	1
1132	1132	361	214		/audio/The Melancholy of Haruhi Suzumiya ED 「Hare Hare.mp3	Hare Hare Yukai	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251852/covers/The_Melancholy_of_Haruhi_Suzumiya_ED_Hare_Hare_Yukai.jpg	1
1139	226	1139	259		/audio/The Night is Short, Walk on Girl ED 「Kouya wo A.mp3	Kouya wo Aruke	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251855/covers/The_Night_is_Short_Walk_on_Girl_ED_Kouya_wo_Aruke.jpg	1
921	921	919	203		/audio/Rising of the Shield Hero OP2 「FAITH」.mp3	FAITH	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251843/covers/Rising_of_the_Shield_Hero_OP2_FAITH.jpg	1
924	921	919	210		/audio/Rising of The Shield Hero S2 OP 「Bring Back 」.mp3	Bring Back 	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251849/covers/Rising_of_The_Shield_Hero_S2_OP_Bring_Back.jpg	2
929	928	928	288		/audio/Rosario+Vampire OP 「COSMIC LOVE」.mp3	COSMIC LOVE	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251840/covers/Rosario_Vampire_OP_COSMIC_LOVE.jpg	1
229	229	227	249		/audio/Dr. Stone OP 「Good Morning World!」.mp3	Good Morning World!	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251904/covers/Dr._Stone_OP_Good_Morning_World.jpg	1
237	235	235	267		/audio/Eden of the East Movie ED 「Light Prayer」.mp3	Light Prayer	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251901/covers/Eden_of_the_East_Movie_ED_Light_Prayer.jpg	1
253	253	252	341	[00:02.66] Os iusti meditabitur sapientiam,\n[00:17.84] Et lingua eius loquetur indicium.\n[00:27.14] Beatus vir qui suffert tentationem,\n[00:38.40] Quoniam cum probates fuerit accipiet coronam vitae.\n[00:48.98] Kyrie, fons bonitatis\n[00:57.67] Kyrie, ignis divine, eleison\n[01:11.08] O quam sancta, quam serena\n[01:21.85] Quam benigma, quam amoena esse Virgo creditur\n[01:35.35] O quam sancta, quam serena, quam benigma, quam amoena\n[01:53.89] O castitatis lilium\n[02:01.98] Ahhh... Ahhh...\n[02:50.77] Kyrie, fons bonitatis\n[02:59.04] Kyrie, ignis divine, eleison\n[03:12.64] O quam sancta, quam serena\n[03:23.60] Quam benigma, quam amoena\n[03:30.91] O castitatis lilium	/audio/Elfen Lied OP 「Lilium」.mp3	Lilium	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251910/covers/Elfen_Lied_OP_Lilium.jpg	1
539	539	539	160		/audio/Lovely Complex ED 「Kiss」.mp3	Kiss	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251858/covers/Lovely_Complex_ED_Kiss.jpg	1
964	964	964	233		/audio/Seirei Gensouki ED 「Elder flower」.mp3	Elder flower	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251863/covers/Seirei_Gensouki_ED_Elder_flower.jpg	1
1144	234	1140	252		/audio/The Petgirl of Sakurasou OP2 「Yume no Tsuzuki」.mp3	Yume no Tsuzuki	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251873/covers/The_Petgirl_of_Sakurasou_OP2_Yume_no_Tsuzuki.jpg	1
1172	624	1171	223		/audio/To Love Ru Darkness S2 OP 「secret arms」.mp3	secret arms	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251878/covers/To_Love_Ru_Darkness_S2_OP_secret_arms.jpg	2
238	238	235	295		/audio/Eden of the East Movie OP 「invisible」.mp3	invisible	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251906/covers/Eden_of_the_East_Movie_OP_invisible.jpg	1
244	242	241	221		/audio/ef ~ A Tale of Memories S2 OP 「ebullient future.mp3	ebullient future (English)	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251912/covers/ef_A_Tale_of_Memories_S2_OP_ebullient_future_English.jpg	2
270	270	266	284		/audio/Fate Grand Order Wandering Agateram ED Theme 「Dokuhaku」.mp3	Dokuhaku	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773251578/covers/Fate_Grand_Order_Wandering_Agateram_ED_Theme_Dokuhaku.jpg	1
277	273	266	248	[ti:Fate/stay night OP 「disillusion」]\n[ar:Tainaka Sachi]\n[al:Fate]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:07.51]\n[00:00.00] \n[00:22.63]Yume ni mite ita\n[00:25.68]Ano hi mo kage ni\n[00:28.80]Todokanai sakebi\n[00:34.44]Asu no jibun wa\n[00:37.04]Nante egaite mo\n[00:40.07]Kienai negai ni nureru\n[00:48.68]Kobore ochiru kakera wo\n[00:54.66]Tsukamu sono te de\n[01:00.20]Yureru kokoro kakaete\n[01:05.85]Tobi konde ike yoru e\n[01:14.42]Dareka wo ate ni shite mo\n[01:20.10]Motomeru mono ja nai no dakara\n[01:25.73]Hontou no jibun wa koko ni irutte\n[01:31.46]Me wo tojite inaide\n[02:05.53]Kaze ni makarete\n[02:08.45]Garakuta jimita\n[02:11.50]Natsukashii egao\n[02:17.20]Asu no jibun nara\n[02:19.86]Nante inotte mo\n[02:23.04]Toozakaru kotae wa kasumu\n[02:31.52]Kogoesou na karada to\n[02:37.54]Hitohira no omoi\n[02:42.97]Kuchihateru sono maeni\n[02:48.76]Tobi koete ike yoru wo\n[02:57.19]Dareka wo ate ni shite mo\n[03:02.94]Motomeru mono ja nai no dakara\n[03:08.64]Hontou no jibun wa koko ni irutte\n[03:14.27]Me wo tojite inaide\n[03:20.11]Dare ka no tame ni ikite\n[03:26.19]Kono toki ga subete de ii deshou\n[03:31.97]Misekake no jibun wa sotto sutete\n[03:37.59]Tada ari no mama de\n[03:43.92]	/audio/Fate_stay night OP 「disillusion」.mp3	disillusion	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253917/covers/Fatestay_night_OP_disillusion.jpg	1
234	234	234	235		/audio/Dusk Maiden of Amnesia OP 「CHOIR JAIL」.mp3	CHOIR JAIL	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251888/covers/Dusk_Maiden_of_Amnesia_OP_CHOIR_JAIL.jpg	1
242	242	241	238	[00:00.00] \n[00:13.92]Why am I standing alone in the twilight\n[00:20.24]Let me go, no more lonely nights\n[00:26.78]I take a deep breath under the hazy sky\n[00:33.02]Feel like losing, but it’s gonna be alright\n[00:39.49]Break through the night, go and try to fight\n[00:45.37]Don’t be afraid, now is the time\n[00:55.56]Be alive, take it\n[00:58.57]I surely feel my heartbeat\n[01:01.80]There’s no limit to my reach\n[01:08.18]I say good-bye to my tears that I don’t need\n[01:14.57]So believe in my dream\n[02:15.68]Don’t look back to the sorrow I left behind\n[02:21.79]Here’s my real intention I hide\n[02:28.23]I wish you were here, and so just right by my side\n[02:34.59]Need to be strong enough to swallow my pride\n[02:41.05]I have been looking for my own style\n[02:47.05]Don’t give it up, here comes the life\n[02:57.10]Be alive, take it\n[03:00.10]I have learned a great deal\n[03:03.45]Brighten our sweet memories\n[03:10.02]Hope there will be a future for you and me\n[03:16.20]So believe in your dream\n[03:22.42]Be alive, take it\n[03:25.73]Promise to find, yes I will\n[03:29.18]Shining wings filled with wishes\n[03:35.52]Fly high, make it\n[03:38.59]Get to the new world that I seek\n[03:42.14]Someday, so I believe\n[03:48.68] 	/audio/ef ~ A Tale of Memories OP 「euphoric field (Eng.mp3	euphoric field (English)	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251883/covers/ef_A_Tale_of_Memories_OP_euphoric_field_English.jpg	1
255	255	254	271		/audio/Engaged to the Unidentified OP 「Tomadoi Recipe」.mp3	Tomadoi Recipe	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251897/covers/Engaged_to_the_Unidentified_OP_Tomadoi_Recipe.jpg	1
259	259	258	278		/audio/Ergo Proxy OP 「Kiri」.mp3	Kiri	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251891/covers/Ergo_Proxy_OP_Kiri.jpg	1
260	260	260	275		/audio/Eromanga Sensei ED 「adrenaline!!!」.mp3	adrenaline!!!	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251915/covers/Eromanga_Sensei_ED_adrenaline.jpg	1
455	455	455	255		/audio/Joshikausei ED 「silent days」.mp3	silent days	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252274/covers/Joshikausei_ED_silent_days.jpg	1
269	142	266	273		/audio/Fate Grand Order First Order Ending Theme「Shikisai」.mp3	Shikisai	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773251941/covers/Fate_Grand_Order_First_Order_Ending_Theme_Shikisai.jpg	1
276	11	266	301		/audio/Fate_stay night Heaven_s Feel M3 ED 「Haru wa Yu.mp3	Haru wa Yuku	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251937/covers/Fatestay_night_Heaven_s_Feel_M3_ED_Haru_wa_Yuku.jpg	1
284	95	266	288		/audio/Fate_Zero ED 「MEMORIA」.mp3	MEMORIA	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251943/covers/FateZero_ED_MEMORIA.jpg	1
296	295	295	219		/audio/Full Metal Panic! OP 「Tomorrow」.mp3	Tomorrow	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251939/covers/Full_Metal_Panic_OP_Tomorrow.jpg	1
457	79	456	293		/audio/Just Because OP 「over and over 」.mp3	over and over 	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252277/covers/Just_Because_OP_over_and_over.jpg	1
467	467	464	228		/audio/Kaguya Sama_ Love is War S3 ED 「Heart wa Oteage.mp3	Heart wa Oteage	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252282/covers/Kaguya_Sama_Love_is_War_S3_ED_Heart_wa_Oteage.jpg	3
468	468	464	156		/audio/Kaguya Sama_ Love is War S3 ED2 「My Nonfiction」.mp3	My Nonfiction	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252276/covers/Kaguya_Sama_Love_is_War_S3_ED2_My_Nonfiction.jpg	3
479	479	478	286		/audio/Kids on the Slope OP 「Sakamichi No Melody」.mp3	Sakamichi No Melody	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252279/covers/Kids_on_the_Slope_OP_Sakamichi_No_Melody.jpg	1
289	104	289	209	[00:00.00] Waraenai hibi o tadottatte\n[00:04.31] Kawaranai ima o norottatte\n[00:07.32] Chū ni matta kotoba ga\n[00:10.51] Anata o sukuenai no darō\n[00:26.65] Todokanai mama no keshiki o\n[00:29.54] Atatamaru koto nai itami to\n[00:32.82] Kata o yoseatte aruite ita\n[00:35.95] Tōi tokoro e ikeru yō ni\n[00:40.29] Anata no iu "kibō" da to ka\n[00:43.26] Yume ni mita risō nara ba\n[00:46.63] Donna ni tsumetaku tatte\n[00:49.66] Aishite miseru yo\n[00:52.83] Waraenai hibi o tadottatte\n[00:55.97] Kawaranai ima o norottatte\n[00:59.04] Chū ni matta kotoba ga\n[01:02.17] Anata o sukuenai no darō\n[01:05.64] Fugainai koe de sakenda tte\n[01:08.76] Netsu o motsu yoru ni kawatte iku\n[01:12.07] Kono te ga hanarete mo\n[01:14.91] Mata aruite ikeru yō ni\n[01:30.08] Wakachiau koto nai kotoba ga\n[01:33.51] Futo kizuku tabi ni fuete ita\n[01:36.69] Ima to mukiatte kawatte iku\n[01:39.93] Sono sugata o mite ite hoshī\n[01:43.86] Anata no iu mirai wa\n[01:47.36] Tada, kono te ni osamaranakute\n[01:50.67] Donna ni tsukurottatte\n[01:53.62] Sono emi no oku o utagatte shimaudarō\n[02:00.18] Owaranai hibi no mukō da tte\n[02:03.25] Sukuenai kurai no urei da tte\n[02:06.34] Kono yubi ga mogaku hodo\n[02:09.77] Tōku nijinde shimau no darō\n[02:12.73] Sawarenai omoi no iro nante\n[02:15.79] Shiritaku wa nai to omotte ita\n[02:19.11] Anata ga inakute mo yume o mite itai no ni\n[02:25.27] Katadotta yō na fukō ga anata o osounara\n[02:31.65] Kono tenohira de furete itai na\n[02:38.02] Tsukurotte haita kotoba ga dare ka o norounara\n[02:44.58] Kuchi o tsugunde sa\n[02:50.48] Waraenai hibi o tadottatte\n[02:53.80] Kawaranai ima o norottatte\n[02:56.81] Chū ni matta kotoba ja\n[03:00.26] Anata o sukuenai no darō\n[03:03.43] Fugainai koe de sakenda tte\n[03:06.60] Netsu o motsu yoru ni kawatte iku\n[03:09.79] Kono te ga hanarete mo\n[03:12.88] Mata aruite ikeru yō ni\n[03:16.34] Sayonara wa iwazu ni\n[03:19.15] Doko ka de mata aeru yō ni\n[03:23.00] 	/audio/Fire Force ED 「veil」.mp3	veil	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253693/covers/Fire_Force_ED_veil.jpg	1
294	294	294	219	[00:00.00] \r\n[00:28.10]sugisatta hibi wa kou yatte\r\n[00:30.77]toki ga kite najindeku you de\r\n[00:34.16]kitzukanaide furi de oite ikareta mama\r\n[00:38.58]souzou no koukei ga mirai to shinjita\r\n[00:45.43]datte naite yatto koe ni dashite\r\n[00:52.45]dare datte uso wo nageite\r\n[00:55.64]kuchi ni sureba mijikai you de\r\n[00:58.99]honto wa igai to kantan dattari shite\r\n[01:03.55]yurun da hyoujou ga hoho ni kirameita\r\n[01:09.97]sonna hi ga yume wo egaite ite\r\n[01:16.04]soshite kinomuku mama ni ho wo dashita\r\n[01:21.95]namae nado nai ga nagai michi wo kita\r\n[01:26.51]yureru omoi ga akashi nan da\r\n[01:30.37]sono koe de nagusamete kurenai ka\r\n[01:34.94]yobu koe ga hyoushiki no you na\r\n[01:38.74]hikari ya iro wo daite \r\n[01:41.69]saa arukou arukou arukou\r\n[02:03.13]itsu datte boku wa marumatte \r\n[02:06.48]nani mo kamo nagesuteru hou de\r\n[02:09.39]mihanasareru no ni narete shimatta no ka na\r\n[02:14.16]urunda shouchou ni dare mo kitzukanai ga\r\n[02:20.71]nanka sore de ii to omotte ite\r\n[02:26.91]douka kiri no nai kono chiguhagu moyou ni\r\n[02:33.49]douka imi yo are to negatte ita\r\n[02:39.60]nee boku wo okoshite \r\n[02:42.45]mioto shite nagarete ita mono ga koishikute\r\n[02:48.81]miotoshite sagashi ni ikun da\r\n[02:53.13]kore kara   kore kara\r\n[03:08.18]namae nado nai ga nagai michi wo kita\r\n[03:12.60]yureru omoi ga akashi nan da\r\n[03:16.39]sono koe de nagusamete kurenai ka\r\n[03:21.01]yobu koe ga hyoushiki no you na\r\n[03:25.04]hikari ya iro wo daite\r\n[03:27.72]saa arukou arukou arukou	/audio/Flavors of Youth 「Walk」.mp3	Walk	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253806/covers/Flavors_of_Youth_Walk.jpg	1
153	145	94	230		/audio/Code Geass S2 OP2 「WORLD END」.mp3	WORLD END	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252285/covers/Code_Geass_S2_OP2_WORLD_END.jpg	2
155	155	154	161		/audio/Combatants will be Dispatched OP 「No.6」.mp3	No.6	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251955/covers/Combatants_will_be_Dispatched_OP_No.6.jpg	1
295	295	295	256		/audio/Full Metal Panic! ED 「Karenai Hana」.mp3	Karenai Hana	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251965/covers/Full_Metal_Panic_ED_Karenai_Hana.jpg	1
304	304	300	266	[00:14.450]ano hi kara zutto\r\n[00:17.940]nakanai to kimetekita kedo\r\n[00:22.970]itami wo kasanete mo\r\n[00:28.110]nanika wo yurusezu ni ita\r\n\r\n[00:34.230]mou modorenai ikutsumo no hibi\r\n[00:38.800]boku wa mada nanimo dekizu ni\r\n[00:43.450]kimi no ita kioku no kakera\r\n[00:49.150]mata hitotsu kieteyuku\r\n\r\n[00:55.330]kyou yori motto\r\n[00:57.980]tsuyoku naritai\r\n[01:00.580]kono koe ga itsuka todoku you ni\r\n\r\n[01:05.690]arukitsuzukete\r\n[01:08.200]kaze ga yandara\r\n[01:11.070]kimi wo sagashite sora miageru yo\r\n[01:16.280]yoake no saki ni hikari ga sasu yo\r\n\r\n[01:32.510]kono mune no dokoka\r\n[01:36.320]tojikometeta hazu no koto mo\r\n[01:40.940]ima nara sukoshi dake\r\n[01:45.140]wakaru you na ki ga shita\r\n\r\n[01:52.020]doko made mo tsuzuiteku michi\r\n[01:56.760]atarashii keshiki ga fuete mo\r\n[02:01.290]kimi wa mou doko ni mo inai\r\n[02:06.970]tada toki ga sugiru dake\r\n\r\n[02:13.430]kyou yori motto\r\n[02:15.920]tsuyoku naritai\r\n[02:18.480]yatto mitsuketa omoi no tame ni\r\n\r\n[02:23.570]namida no tsubu ga\r\n[02:26.040]ame ni natte mo\r\n[02:28.720]kawarazu hikaru hoshi miageru yo\r\n[02:34.140]nagareru kumo ga irozuiteku yo\r\n\r\n[03:00.120]ki ga tsukeba boku wa mata\r\n[03:02.540]otona ni natteku kedo\r\n[03:05.050]ima demo wakaranai koto bakari de\r\n[03:09.830]sore demo tooi sora no kanata ni wa\r\n[03:14.290]tsunagaru to shinjiteru\r\n\r\n[03:22.390]kyou yori motto\r\n[03:24.830]tsuyoku naritai\r\n[03:27.400]kono koe ga kimi ni todoku you ni\r\n\r\n[03:32.420]arukitsuzukete\r\n[03:34.850]kaze ga yandara\r\n[03:37.600]kotae sagashite sora miageru yo\r\n[03:42.790]yoake no saki ni hikari ga sasu yo\r\n[03:51.550]niji ga kakaru yo\r\n\r\nsource: https://www.animesonglyrics.com/full-metal-alchemist-2009/ray-of-light	/audio/Fullmetal Alchemist Brotherhood ED5 「Ray of Lig.mp3	Ray of Light	ED5	https://res.cloudinary.com/ddc6silap/image/upload/v1773254101/covers/Fullmetal_Alchemist_Brotherhood_ED5_Ray_of_Light.jpg	1
449	447	448	305		/audio/Jobless Reincarnation OP2 「Mezame no Uta」.mp3	Mezame no Uta	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252287/covers/Jobless_Reincarnation_OP2_Mezame_no_Uta.jpg	1
477	474	474	287		/audio/Kaze no Stigma OP 「blast of wind」.mp3	blast of wind	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252284/covers/Kaze_no_Stigma_OP_blast_of_wind.jpg	1
1218	1218	992	266		/audio/Silver Spoon OP 「kiss you」.mp3	kiss you	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251971/covers/Silver_Spoon_OP_kiss_you.jpg	1
178	175	175	241		/audio/Darling In The FranXX ED4 「Hitori」.mp3	Hitori	ED4	https://res.cloudinary.com/ddc6silap/image/upload/v1773251952/covers/Darling_In_The_FranXX_ED4_Hitori.jpg	1
271	16	266	291		/audio/Fate_stay night ED 「Anata ga Ita Mori」.mp3	Anata ga Ita Mori	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251962/covers/Fatestay_night_ED_Anata_ga_Ita_Mori.jpg	1
275	11	266	271		/audio/Fate_stay night Heaven_s Feel M2 ED 「I beg you」.mp3	I beg you	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251963/covers/Fatestay_night_Heaven_s_Feel_M2_ED_I_beg_you.jpg	1
280	28	266	243		/audio/Fate_stay night_ Unlimited Blade Works ED2 「THI.mp3	THIS ILLUSION	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251968/covers/Fatestay_night_Unlimited_Blade_Works_ED2_THIS_ILLUSION.jpg	1
282	279	266	96		/audio/Fate_stay night_ Unlimited Blade Works S2 ED2 「.mp3	ring your bell (in the silence)	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251957/covers/Fatestay_night_Unlimited_Blade_Works_S2_ED2_ring_your_bell_in_the_silence.jpg	2
286	286	266	271		/audio/Fate_Zero S2 ED 「Sora wa Takaku Kaze wa Utau」.mp3	Sora wa Takaku Kaze wa Utau	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251959/covers/FateZero_S2_ED_Sora_wa_Takaku_Kaze_wa_Utau.jpg	2
287	279	266	316		/audio/Fate_Zero S2 ED2 「Manten」.mp3	Manten	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251966/covers/FateZero_S2_ED2_Manten.jpg	2
292	292	289	227		/audio/Fire Force OP2 「MAYDAY」.mp3	MAYDAY	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251969/covers/Fire_Force_OP2_MAYDAY.jpg	1
278	273	266	239		/audio/Fate_stay night OP2 「Kirameku Namida wa Hoshi n.mp3	Kirameku Namida wa Hoshi ni	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251977/covers/Fatestay_night_OP2_Kirameku_Namida_wa_Hoshi_ni.jpg	1
281	182	266	260		/audio/Fate_stay night_ Unlimited Blade Works OP 「idea.mp3	ideal white	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251974/covers/Fatestay_night_Unlimited_Blade_Works_OP_ideal_white.jpg	1
1005	1005	1002	291	[00:00.00] \n[00:15.84]Neiki yori sotto yoake ga kuru\n[00:23.58]Kimi no yume wa ima mori wo kakeru\n[00:31.16]Mezamete akari wo sagasu shigusa\n[00:38.14]Nakushita nara mitsuketeageyou\n[00:45.93]Kimi to boku no mirai ni kakureteiru\n[00:56.37]saa koko e\n[00:59.87]Te wo tsunaidara hodokenai yo\n[01:07.70]Kimi to tooku e\n[01:11.19]Haruka na hi no kioku ni saita\n[01:19.38]Aoi kuni wo miru sutoorii\n[01:26.16]Kagayaku hitomi tsutaeyou\n[01:33.56] \n[01:44.75]hieta moya no iro amai haoto\n[01:52.34]Furueru katasaki ni ai ga tomaru\n[02:00.11]Omoi wo aa dare ga habamu darou\n[02:07.19]Hi ga sashitara atomodori shinai\n[02:14.81]Ayamachi demo eranda michi wo yuku yo\n[02:25.65]daiji na kotoba wo kiita\n[02:33.03]Kaze ga hakobu sora no yakusoku\n[02:40.47]Toki ga kimi wo tsuresaru no nara\n[02:48.56]Ima kou shite tada futari\n[02:57.79] \n[03:15.91]mamoru mono wa kimi no egao\n[03:23.43]Tameshite miru kokoro no tsuyosa wo\n[03:31.73]Aa kimi ga furimuku\n[03:42.89]soshite ima hajimaru asa wo utau tori yo\n[03:54.37]saa koko e\n[03:57.89]Te wo tsunaidara hodokenai yo\n[04:05.55]Kimi to tooku e\n[04:09.51]Haruka na hi no kioku ni saita\n[04:17.44]Aoi kuni wo miru sutoorii\n[04:24.23]Kagayaku hitomi miru sutoorii\n[04:31.95]Kagayaku hitomi sono utagoe tsutaeyou\n[04:43.56] \n	/audio/Spice and Wolf S2 OP 「Mitsu no Yoake」.mp3	Mitsu no Yoake	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254073/covers/Spice_and_Wolf_S2_OP_Mitsu_no_Yoake.jpg	2
283	11	266	232		/audio/Fate_stay night_ Unlimited Bladeworks S2 OP 「Br.mp3	Brave Shine	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251978/covers/Fatestay_night_Unlimited_Bladeworks_S2_OP_Brave_Shine.jpg	2
288	279	266	257		/audio/Fate_Zero S2 OP 「to the beginning」.mp3	to the beginning	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251972/covers/FateZero_S2_OP_to_the_beginning.jpg	2
290	290	289	254		/audio/Fire Force ED2 「Nounai」.mp3	Nounai	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251975/covers/Fire_Force_ED2_Nounai.jpg	1
341	339	339	230	[ti:Guilty Crown OP 「Euterpe」]\n[ar:EGOIST]\n[al:Guilty Crown]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:48.88]\n[00:00.00]\n[00:23.49]Saita no no hana yo\n[00:31.57]Aa douka oshiete okure\n[00:38.91]Hito wa naze kizutsukeatte\n[00:46.87]Arasou no deshou\n[00:55.44]Rinto saku hana yo\n[01:03.47]Soko kara nani ga mieru\n[01:10.90]Hito wa naze yurushiau koto\n[01:18.94]Dekinai no deshou\n[01:30.99]Ame ga sugite natsu wa\n[01:35.66]Ao wo utsushita\n[01:39.46]Hitotsu ni natte\n[01:47.47]Chiisaku yureta\n[01:51.67]Watashi no mae de\n[01:55.56]Nanimo iwazu ni\n[02:19.63]Karete yuku tomo ni\n[02:27.37]Omae wa nani wo omou\n[02:35.01]Kotoba wo motanu sono ha de\n[02:41.50]Nanto ai wo tsutaeru\n[02:55.17]Natsu no hi wa kagette\n[02:59.70]Kaze ga nabiita\n[03:03.65]Futatsu kasanatte\n[03:11.60]Ikita akashi wo\n[03:15.56]Watashi wa utaou\n[03:19.82]Na mo naki mono no tame\n[03:31.27]	/audio/Guilty Crown OP 「Euterpe」.mp3	Euterpe	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253588/covers/Guilty_Crown_OP_Euterpe.jpg	1
272	16	266	305		/audio/Fate_stay night ED2 「Hikari」.mp3	Hikari	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251980/covers/Fatestay_night_ED2_Hikari.jpg	1
880	880	871	260	[00:00.00] \n[00:08.91]Watashi wa watashi to, hagureru wake ni wa ikanai kara\n[00:16.79]Itsuka mata aimashou. sono hi made sayonara koigokoro yo\n[00:27.30] \n[00:43.92]Uso wo tsuku gurai nara, nanimo hanashite kurenakute ii\n[00:47.70]Anata wa satteiku no, sore dake wa wakatteiru kara\n[00:51.71]Mitsumeatta watashi wa, kawaii onna ja nakatta ne\n[00:55.44]Semete saigo wa egao de kazarasete\n[00:59.06]Namida ga kanashimi wo tokashite, afureru mono da to shitara\n[01:03.34]Sono shizuku mo, mou ichido nomihoshiteshimaitai\n[01:07.29]Rin to shita itami mune ni, todomaritsuzukeru kagiri\n[01:11.46]Anata wo wasurezu ni irareru deshou\n[01:14.88]Yurushite ne koigokoro yo, amai yume wa nami ni sarawareta no\n[01:22.90]Itsuka mata aimashou. sono hi made sayonara koigokoro yo\n[01:33.20] \n[01:39.73]Toki wo kasanerugoto ni, hitotsuzutsu anata wo shitteitte\n[01:43.63]Sara ni toki wo kasanete, hitotsuzutsu wakaranakunatte\n[01:47.64]Ai ga kieteiku no o, yuuhi ni tatoetemitari shite\n[01:51.60]Soko ni tashika ni nokoru saudaaji\n[01:55.13]Omoi wo tsumuida kotoba made, kage wo seowasu no naraba\n[01:59.24]Umi no soko de mono iwanu kai ni naritai \n[02:03.45]Dare ni mo jama wo sarezu ni, umi ni kaeretara ii no ni\n[02:07.28]Anata wo hissori to omoidasasete\n[02:10.85]Akiramete koigokoro yo, aoi kitai wa watashi wo kirisaku dake\n[02:18.78]Ano hito ni tsutaete... sabishii... daijoubu... sabishii\n[02:27.40]Kurikaesareru yoku aru hanashi\n[02:35.37]Deai to wakare naku mo warau mo suki mo kirai mo\n[02:43.35] \n[02:59.13]Yurushite ne koigokoro yo, amai yume wa nami ni sarawareta no\n[03:06.65]Itsuka mata aimashou. sono hi made sayonara koigokoro yo\n[03:14.92]Anata no soba de wa, eien wo tashika ni kanjita kara\n[03:22.87]Yozora wo kogashite, watashi wa ikita wa koigokoro to\n[03:35.26] \n	/audio/Relife ED7 「Saudade」.mp3	Saudade	ED7	https://res.cloudinary.com/ddc6silap/image/upload/v1773253937/covers/Relife_ED7_Saudade.jpg	1
1045	359	939	269	[00:00.00] \n[00:07.37]Oh-oh-oh, oh-oh-oh\n[00:14.00]Oh-oh-oh, oh-oh-oh\n[00:21.04]So this is me omo sugiru yoroi de\n[00:27.40]Arukenakunatta okubyou na yuusha\n[00:34.24]Aisaretakute mamoritakute furutta ken wa\n[00:40.66]Sashidasareta te ni sasatte nukenai yo\n[00:46.04]Mada ienai mama\n[00:49.67]Life goes on\n[00:52.03]Oh, everything turns to ash to ash\n[00:55.40]Inochi wa kanata wo mezasu\n[00:58.48]Kizutsuketa tsumi to itami hikizutte\n[01:05.12]And everything turns to dust to dust\n[01:08.22]Taorete tsuchi ni kaeru toki\n[01:11.43]Semete chiisana hana ga hora sakimasu you ni\n[01:18.01]Forget-me-not\n[01:19.15]Oh-oh-oh\n[01:22.09]Oh-oh-oh\n[01:25.73]How do I escape me no mae no kaibutsu ni\n[01:32.22]Mukiaenai mama nigedashita yuusha\n[01:39.09]Hajikko nante nai konna hoshi no ue da\n[01:46.15]Megurimegutte onaji basho\n[01:51.05]Tada kurikaeshite\n[01:54.61]Life goes on\n[01:56.84]Oh, everything turns to ash to ash\n[02:00.32]Inochi wa akashi wo sagasu\n[02:03.45]Kiba wo muku unmei ni nomare kietatte\n[02:09.95]And everything turns to dust to dust\n[02:13.15]Nige tsuzuketa wadachi mo itsuka\n[02:16.38]Dareka ga aruku tame no michi ni kawaru nara\n[02:22.79]Forget-me-not\n[02:24.91]Haikokyuu no shinkaigyo\n[02:28.40]Kaze ni umaku norenai tori mo\n[02:32.93]Dokoka de tabi wo shiteiru no ka na\n[02:37.26]Deau koto wa nakutemo\n[02:40.85]Soko ni iru sore dake de sore dake de ii yo\n[02:53.57] \n[03:06.63]Karada wa hai e kawatte kioku wa chiri e to kashite\n[03:13.02]Rekishi no ichimoji mo mitasazu owaru dake\n[03:19.63]Sore demo kanata wo mezasu sore demo akashi wo sagasu\n[03:26.08]Ikita riyuu wo shiritakute imi wo nokoshitakute\n[03:32.21]Oh, everything turns to ash to ash\n[03:35.99]Inochi wa kanata wo mezasu\n[03:39.05]Kieru koto nai tsumi to itami dakishimete\n[03:45.56]And everything turns to dust to dust\n[03:48.73]Taorete tsuchi ni kaeru toki\n[03:52.02]Semete chiisana hana ga hora sakimasu you ni\n[03:58.66]Forget-me-not\n[03:59.74]Oh-oh-oh, oh-oh-oh\n[04:05.01]Forget-me-not\n[04:06.10]Oh-oh-oh, oh-oh-oh\n[04:08.25]Forget-me-not\n[04:12.37]Ash to ash, dust to dust\n[04:15.57]Douka wasurenai de\n[04:19.73] \n	/audio/Sword Art Online _ Alicization ED2 「Forget me n.mp3	Forget me not	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253940/covers/Sword_Art_Online_Alicization_ED2_Forget_me_not.jpg	1
273	273	266	219		/audio/Fate_stay night ED3 「Kimi to no Ashita」.mp3	Kimi to no Ashita	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773251982/covers/Fatestay_night_ED3_Kimi_to_no_Ashita.jpg	1
323	321	320	214		/audio/Goblin Slayer Movie ED 「Static」.mp3	Static	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251988/covers/Goblin_Slayer_Movie_ED_Static.jpg	1
366	366	365	250	[00:00.00] \r\n[00:19.78]Hello my dear\r\n[00:24.14]Unmei wa fu jōri tte sono tōri de\r\n[00:34.46]Hello my dear\r\n[00:39.01]Tatoe dō mogaite mo\r\n[00:42.43]Sekai wa waraudarō\r\n[00:45.86] \r\n[00:47.60]Tell me why\r\n[00:48.98]Itsu mo sakimawari shite kono te o\r\n[00:52.94]Hirogete mattete mo\r\n[00:55.50]You fall out of my hand\r\n[00:58.98]You always fall out of my hand\r\n[01:03.59]Todoki sō de todokanai\r\n[01:06.33]Kuzureochitekumy world\r\n[01:09.84]I can t touch you again\r\n[01:16.83]Just a little more time\r\n[01:19.65]Stay along\r\n[01:23.05]Mada kaerenai yo alone alone alone\r\n[01:32.30]Nei mō kore ijō nanimo dekinai\r\n[01:37.64]I m tired\r\n[01:39.51]Kono sekai no hate made let go...\r\n[01:57.72] \r\n[02:01.98]Even if you re far away\r\n[02:05.19]Even if this is just a lost game\r\n[02:09.77]Under the same rain\r\n[02:13.06]I m crying out your name\r\n[02:18.01]Hello my dear\r\n[02:22.85]What if no one is home\r\n[02:26.12]I ve gotta go home alone\r\n[02:29.52] \r\n[02:30.75]Just a little more time\r\n[02:33.54]Stay along\r\n[02:36.77]Mada kaerenai yo alone alone alone\r\n[02:46.32]Nei mō kore ijō nanimo dekinai\r\n[02:51.55]I m tired\r\n[02:53.36]Kono sekai no hate made\r\n[03:00.20]Just a little more time\r\n[03:03.12]Stay along\r\n[03:06.32]Mada kaerenai yo alone alone alone\r\n[03:15.79]Nei mō kore ijō nanimo dekinai\r\n[03:21.14]I m tired\r\n[03:22.89]Kono sekai no hate madelet go...\r\n[03:42.91] \r\n[03:45.18]Nei mō kore ijō nanimo nai nara\r\n[03:52.30]Sono sekai no hate de mata...\r\n[04:00.47] \r\n	/audio/Hello World Insert Song「Lost Game」.mp3	Lost Game	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773254119/covers/Hello_World_Insert_Song_Lost_Game.jpg	1
250	250	245	295		/audio/Eighty Six S2 OP 「Kyoukaisen」.mp3	Kyoukaisen	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252000/covers/Eighty_Six_S2_OP_Kyoukaisen.jpg	2
310	310	310	260		/audio/Garakawa Restore the World ED 「Yume no Tsubomi」.mp3	Yume no Tsubomi	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251992/covers/Garakawa_Restore_the_World_ED_Yume_no_Tsubomi.jpg	1
1173	1173	1173	291		/audio/Toilet Bound Hanako Kun ED 「Tiny Light」.mp3	Tiny Light	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252004/covers/Toilet_Bound_Hanako_Kun_ED_Tiny_Light.jpg	1
1201	1061	1061	196		/audio/Teasing Master Takagi San S3 ED5 「Joyful」.mp3	Joyful	ED5	https://res.cloudinary.com/ddc6silap/image/upload/v1773252002/covers/Teasing_Master_Takagi_San_S3_ED5_Joyful.jpg	3
314	314	314	244		/audio/Genshiken ED 「Biidama」.mp3	Biidama	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251995/covers/Genshiken_ED_Biidama.jpg	1
316	316	314	228		/audio/Genshiken OP2 「My Pace Daioh」.mp3	My Pace Daioh	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251996/covers/Genshiken_OP2_My_Pace_Daioh.jpg	1
319	319	318	202		/audio/Ghost Hound OP 「Main Theme」.mp3	Main Theme	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251998/covers/Ghost_Hound_OP_Main_Theme.jpg	1
320	320	320	212		/audio/Goblin Slayer ED 「Gin no Kisei」.mp3	Gin no Kisei	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251991/covers/Goblin_Slayer_ED_Gin_no_Kisei.jpg	1
378	266	266	223	[ti:Fate Grand Order Absolute Demonic Front: Babylonia  ED3 「Tell me」]\n[ar:milet]\n[al:Fate]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:23.4.20]\n[length:03:43.03]\n[00:00.00]\n[00:01.44]If you need me I’m here\n[00:04.50]I’ve been waiting for you\n[00:07.79]Shimitsuita koe ga mada omoidaseru to\n[00:14.22]Itsuwarenai yo machigaeta to shitemo\n[00:20.69]Kurikaeshite shimau yo mata\n[00:25.73]Kotaete namida imi wo please now\n[00:32.04]Tojikoemtai kara\n[00:37.50]So just tell me now, just tell me now\n[00:43.88]Why are you crying now?\n[00:47.29]Nido to wa modorenai sore demo\n[00:50.94]Just tell me now, please tell me now\n[00:56.65]Mada koko ni itai\n[00:59.56]Karesou na hana hitorikiri demo\n[01:03.82]Anata ga oshiete kureta no my name\n[01:10.64]I need you, I need you right here\n[01:18.31]Mitsukete kureta sore dake de ii yo\n[01:24.58]Eienn ga owatte zenbu kietemo\n[01:30.86]Watteteku shallow mou daremo inai yo\n[01:37.32]Demo nokotteiru no your touch\n[01:42.65]Hodoite your tight rope, just hear me out\n[01:48.67]Dakishimetai kara\n[01:54.24]So just tell me now, just tell me now\n[02:01.02]Why are you crying now?\n[02:04.05]Nido to kanawanai negai demo\n[02:07.49]Just tell me now, please tell me now\n[02:13.21]And touch me now\n[02:16.94]Doko ni mo ikenai sore demo\n[02:22.21]I don’t wanna wake up from this sweet sweet dream ’cause (my love)\n[02:27.83]Ari no mama no watashi mo anata sae ite kuretara\n[02:34.85]Atokata mo naku owaru saigo datta to shitemo\n[02:40.56]Minogasanai yo I know\n[02:45.50]So Just tell me now, please tell me now\n[02:51.97]Why are you crying now?\n[02:55.13]I feel you everywhere, so I\n[02:58.63]I gotta tell you now, gotta tell you now\n[03:04.62]Why am I crying now?\n[03:07.76]Nido to wa modorenai sore demo\n[03:11.63]Just tell me now, please tell me now\n[03:17.40]Mada koko ni itai\n[03:20.53]Karesou na hana hitorikiri demo\n[03:24.15]I’m dreaming ’bout you every night, but you’re not by my side\n[03:31.43]I need you, I need you right here\n[03:36.53]	/audio/Fate Grand Order Absolute Demonic Front Babylonia  ED3 「Tell me」.mp3	Tell me	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253770/covers/Fate_Grand_Order_Absolute_Demonic_Front_Babylonia_ED3_Tell_me.jpg	1
380	295	295	240		/audio/Full Metal Panic! S2 OP 「Minami Kaze」.mp3	Minami Kaze	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252127/covers/Full_Metal_Panic_S2_OP_Minami_Kaze.jpg	2
331	331	330	297	[00:00.00] \n[00:01.06]Loneliness Fighting back again\n[00:04.24]Seems to be like it never ends\n[00:08.58]Give us hope through the love of\n[00:10.81]peaceful shine on me\n[00:16.88] \n[00:23.66]tsuyoku furi yamanu ame ni\n[00:29.61]egao wasureta mama kurushimi surechigau sekai\n[00:38.44]arasoi to itsuwari no naka de\n[00:45.79]kokoro karasu no nara\n[00:52.92]arekuruu nami ni ukabu hana no you ni\n[01:00.09]Lead the way arashi wo norikoete\n[01:07.51]kare yuku daichi wo fumishimeru you ni\n[01:14.90]Go ahead massugu ayumidaseru\n[01:26.13] \n[01:30.47]koko ni atta hazu no yume to\n[01:36.11]wasureteita nozomi\n[01:40.11]sabitsuita mune tsukisasaru\n[01:45.01]fukaku oshikomeru sakebi\n[01:50.79]nani mo shinjirarezu itami kara nigedasu you ni\n[01:59.76]utagai to nikushimi wo daita\n[02:07.12]ima wo nageku yori mo\n[02:14.01]fukisusabu kaze ni utau tori no you ni\n[02:21.35]Sing away sora takaku hibikase\n[02:28.86]shizumi yuku sora ni hikari tomosu you ni\n[02:36.23]Look ahead kagayaki wo misuete\n[02:48.11] \n[03:28.34]yorokobi to shiawase no kioku torimodosu you ni\n[03:42.66]dare mo ga minna sagashi motome te wo nobasu hikari Ah\n[04:01.13]dokomademo tsuzuku owarinaki hibi ni\n[04:08.58]oshiminaku kono mi azukete\n[04:15.99]arekuruu nami ni ukabu hana no you ni\n[04:23.28]Lead the way arashi wo norikoete\n[04:30.67]kare yuku daichi wo fumishimeru you ni\n[04:38.13]Go ahead massugu ayumidaseru\n[04:50.35] \n	/audio/Gosick ED「Resuscitated Hope」.mp3	Resuscitated Hope	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253966/covers/Gosick_ED_Resuscitated_Hope.jpg	1
379	279	266	312	[ti:Fate/stay night: Unlimited Blade Works S2 ED 「ring your bell」]\n[ar:Kalafina]\n[al:Fate]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:05:12.38]\n[00:10.65]Itsuka kokoro ga kieteyuku nara\n[00:16.02]Semete koe no kagiri\n[00:20.33]Koufuku to zetsubou o utaitai\n[00:31.73]Bokura o matsu unmei wa\n[00:37.50]Itsudemo tada\n[00:39.94]Inochi ga yume o mite kakenukeru\n[00:47.38]Ima no tsudzuki\n[00:53.01]Kimi ga naita yoru wa sono naka ni\n[00:58.72]Tooi mirai no kagayaki o kakushiteta\n[01:05.45]Shizukesa ga kimi o matsu\n[01:09.66]Mabushii oka\n[01:12.94]Kitto yukeru\n[01:15.84]Kimi no chihei e\n[01:21.78]Ring your bell, and raise your song\n[01:39.04]Kimi ga sonna ni hoshigatteita\n[01:44.59]Hikari ga kieteyuku\n[01:49.05]Nandodemo sono toki o shitteiru\n[02:00.28]Aojiroi michi no ue ni tachifusagari\n[02:08.58]Mirai e iku ashi o tomeru nowa\n[02:15.93]Kimi no kokoro dake\n[02:21.60]Yoake wa mada tooi\n[02:25.87]Akarui hoshi mo mienai\n[02:29.99]Dakara mado o hiraite\n[02:34.04]Kaze ni norihibiku darou\n[02:38.09]Ashita o yobu kimi no shirabe\n[02:44.18]Kimi no naka e\n[02:50.22]Ring your bell\n[03:13.10]Kimi e tsudzuiteta michi no\n[03:20.18]Kimi kara tsudzuiteyuku michi no\n[03:27.59]Mabushisa wa kitto kienai kara\n[03:44.56]Kimi ga naita yoru no mukou niwa\n[03:50.66]Mada nanimo nai\n[03:53.09]Hajimari ga hirogaru\n[03:56.85]Kaze ni norikieru darou\n[04:00.99]Ashita o yobu kimi no shirabe\n[04:07.24]Tooi chihei e\n[04:12.96]Kodama o nokoshite\n[04:18.90]Ring your bell, and raise your song\n[04:33.73]	/audio/Fate_stay night_ Unlimited Blade Works S2 ED 「r.mp3	ring your bell	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253688/covers/Fatestay_night_Unlimited_Blade_Works_S2_ED_ring_your_bell.jpg	2
463	20	463	272		/audio/Kaginado ED 「Chiisana Kiseki」.mp3	Chiisana Kiseki	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252290/covers/Kaginado_ED_Chiisana_Kiseki.jpg	1
1141	1141	1140	265		/audio/The Petgirl of Sakurasou ED2 「Prime number ~Kim.mp3	Prime number ~Kimi to Dearu Hi~	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252007/covers/The_Petgirl_of_Sakurasou_ED2_Prime_number_Kimi_to_Dearu_Hi.jpg	1
883	883	871	236		/audio/Relife OP「Button」.mp3	Button	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252005/covers/Relife_OP_Button.jpg	1
204	204	204	300		/audio/Death note ED 「Alumina」.mp3	Alumina	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252035/covers/Death_note_ED_Alumina.jpg	1
301	301	300	257		/audio/Fullmetal Alchemist Brotherhood ED2 「Let it Out.mp3	Let it Out	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252025/covers/Fullmetal_Alchemist_Brotherhood_ED2_Let_it_Out.jpg	1
814	799	794	91		/audio/Oreimo S2 ED13 「The last Ceremony」.mp3	The last Ceremony	ED13	https://res.cloudinary.com/ddc6silap/image/upload/v1773252023/covers/Oreimo_S2_ED13_The_last_Ceremony.jpg	2
305	305	300	256		/audio/Fullmetal Alchemist Brotherhood OP 「Again」.mp3	Again	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252027/covers/Fullmetal_Alchemist_Brotherhood_OP_Again.jpg	1
311	311	311	265		/audio/Gate ED 「Prism Communicate」.mp3	Prism Communicate	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252033/covers/Gate_ED_Prism_Communicate.jpg	1
313	312	311	216		/audio/Gate S2 OP 「Sekai wo Koete」.mp3	Sekai wo Koete	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252031/covers/Gate_S2_OP_Sekai_wo_Koete.jpg	2
321	321	320	204		/audio/Goblin Slayer ED2 「Though Our Paths May Diverge.mp3	Though Our Paths May Diverge	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252010/covers/Goblin_Slayer_ED2_Though_Our_Paths_May_Diverge.jpg	1
322	321	320	164		/audio/Goblin Slayer ED3 「Within」.mp3	Within	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252022/covers/Goblin_Slayer_ED3_Within.jpg	1
326	326	326	215		/audio/Golden Boy ED 「Study A Go! Go!」.mp3	Study A Go! Go!	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252019/covers/Golden_Boy_ED_Study_A_Go_Go.jpg	1
328	70	327	90	[00:00.00] \n[00:15.79]Chigau yo mou chigautteba... aa mada kidzukanai no ne...\n[00:22.62]Ni, san jikan mo mae kara sono ude ni furetai no ni...\n[00:29.02]I do not need forever love I can not believe forever love\n[00:35.88]Sakebitai kimochi wa hora komaru hodo aru no ni\n[00:42.56]Doushite doushite chittomo aa satotte kurenai no?\n[00:48.88]Nee hontou ni hontou ni watashi ni koishiteru?\n[00:56.06]Kosobayui kotoba wa iranai...\n[01:01.74]Haneikyuu teki ni aishite yo gosennen go nado kyoumi wa nai\n[01:08.19]Watashi ENDORESU de wa nai no itsuka wa shinu no yo?\n[01:14.94]Eien ni aishiteru yo nante iwarete mo ureshikunai\n[01:21.58]Mazu wa watashi wo shinu made aisuru koto dake wo kangaete\n	/audio/Golden Time ED2 「Hanneikyuuteki ni Aishite yo♡」.mp3	Hanneikyuuteki ni Aishite yo♡	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252008/covers/Golden_Time_ED2_Hanneikyuuteki_ni_Aishite_yoa.jpg	1
333	333	333	207		/audio/Grand Blue ED 「Konpeki no Alfine」.mp3	Konpeki no Alfine	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252015/covers/Grand_Blue_ED_Konpeki_no_Alfine.jpg	1
335	335	335	282		/audio/Grimgar of Fantasy and Ash ED 「Harvest」.mp3	Harvest	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252029/covers/Grimgar_of_Fantasy_and_Ash_ED_Harvest.jpg	1
336	335	335	310		/audio/Grimgar of Fantasy and Ash ED2 「Cultivate」.mp3	Cultivate	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252021/covers/Grimgar_of_Fantasy_and_Ash_ED2_Cultivate.jpg	1
264	263	263	181	[00:00.00] \n[00:33.32]Kimi no inai sekai de\n[00:35.28]Boku ga ikiru to sureba\n[00:37.23]Sore wa sore wa totemo\n[00:38.82]Igokochi ga warui koto darou\n[00:41.04]Itoshii hito no tame nara\n[00:42.88]Nandemo dekiru tsumori sa\n[00:44.83]Tada sore wa\n[00:46.08]Kimi ga tonari ni ite kureta\n[00:49.01]Ra, no hanashi dakara.\n[00:52.23]Konna uta kimochi ga warui dake dakara\n[00:56.16]Aa yoyuu wo motte hito wo\n[01:00.25]Suki ni nareru hito tte kono yo ni iru no kana\n[01:05.54] \n[01:12.13]Kimi no motte iru mono\n[01:13.96]Boku ni sukoshi kudasai\n[01:15.89]Sore ga kitto\n[01:17.17]Futari wo tsunagu nanika ni naru darou\n[01:19.83]Itoshii hito ga kono mama\n[01:21.75]Dareka no itoshii hito ni naru no wo\n[01:24.70]Damatte miteru no wa iya dakara\n[01:28.14]Tte, hanashi nan dakedo sa.\n[01:31.31]Kore tte yappari kimochi warui kana\n[01:34.78]Aa risou nante mono wa\n[01:38.74]Hayai uchi ni sutete shimau no ga raku darou na\n[01:44.40] \n[01:58.18]Kimi to no koi wo nozomi nagara\n[02:02.16]Dareka no fukou wo negai tsutsu aru yo\n[02:06.22]Sonna boku no omoitsuki mo\n[02:09.95]Kekkyoku wa kimi ga tonari ni ite kureta\n[02:14.11]Ra, no hanashi dakara.\n[02:17.36]Konna uta kimochi ga warui dake dakara\n[02:21.36]Aa yoyuu wo motte hito wo\n[02:25.40]Suki ni nareru hito tte kono yo ni iru no kana\n[02:30.68] \n	/audio/Even If the World Ends Tomorrow Theme Song 「Ra,.mp3	Ra, No Hanashi	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773254005/covers/Even_If_the_World_Ends_Tomorrow_Theme_Song_Ra_No_Hanashi.jpg	1
325	325	325	271	[00:00.30]Here we come\n[00:03.39]Hello my world\n[00:05.96]Every nightmare call on me\n[00:13.87]Here we come\n[00:16.50]Hello my world\n[00:19.28]Every nightmare call on me\n[00:25.05]In this night\n[00:27.84]Give a reason\n[00:30.57]Disappointed in a love\n[00:59.10]In this world\n[01:04.74]human after all\n[01:10.33]Is this call - Confirm it to me\n[01:21.68]In this world\n[01:27.24]human after all\n[01:32.90]Is this call - Confirm it to me\n[01:55.49]uu…\n[02:06.78]Here we come\n[02:09.44]Hello my world\n[02:12.21]Every nightmare call on me\n[02:17.96]In this night\n[02:20.78]Give a reason\n[02:23.43]Disappointed in a love\n[02:51.38]uu…\n[02:57.60]Here we come\n[03:00.16]Hello my world\n[03:02.97]Every nightmare call on me\n[03:08.43]In this night\n[03:11.48]Give a reason\n[03:14.18]Disappointed in a love\n[03:26.11]uu…\n[03:42.82]In this world\n[03:48.42]human after all\n[03:54.12]In this world\n[03:59.72]human after all\n[04:15.99]uu…\n[04:25.15] 	/audio/God Eater ED2 「Human After All」.mp3	Human After All	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252052/covers/God_Eater_ED2_Human_After_All.jpg	1
458	458	458	259		/audio/Kabaneri of the Iron Fortress ED 「ninelie」.mp3	ninelie	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252298/covers/Kabaneri_of_the_Iron_Fortress_ED_ninelie.jpg	1
481	481	66	353		/audio/Kizumonogatari M2 ED 「etoile et toi」.mp3	etoile et toi	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252299/covers/Kizumonogatari_M2_ED_etoile_et_toi.jpg	1
1187	1018	1185	374		/audio/Tokyo Ravens OP 「X-encounter」.mp3	X-encounter	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252047/covers/Tokyo_Ravens_OP_X-encounter.jpg	1
1285	665	1284	350		/audio/Your Lie in April ED2 「Orange」.mp3	Orange	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252049/covers/Your_Lie_in_April_ED2_Orange.jpg	1
339	339	339	278		/audio/Guilty Crown ED 「Departures」.mp3	Departures	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252054/covers/Guilty_Crown_ED_Departures.jpg	1
452	447	448	263		/audio/Jobless Reincarnation OP5 「Tooku no Komori no U.mp3	Tooku no Komori no Uta 	OP5	https://res.cloudinary.com/ddc6silap/image/upload/v1773252056/covers/Jobless_Reincarnation_OP5_Tooku_no_Komori_no_Uta.jpg	1
340	66	339	324		/audio/Guilty Crown ED2 「 Kokuhaku」.mp3	 Kokuhaku	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252060/covers/Guilty_Crown_ED2_Kokuhaku.jpg	1
345	345	344	226		/audio/Haganai OP 「Zannenkei Rinjinbu」.mp3	Zannenkei Rinjinbu	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252068/covers/Haganai_OP_Zannenkei_Rinjinbu.jpg	1
347	347	346	151		/audio/Haibane Renmei OP 「Free Bird」.mp3	Free Bird	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252083/covers/Haibane_Renmei_OP_Free_Bird.jpg	1
353	353	349	262		/audio/Hanasaku Iroha ED5 「Hanasaku Iroha」.mp3	Hanasaku Iroha	ED5	https://res.cloudinary.com/ddc6silap/image/upload/v1773252077/covers/Hanasaku_Iroha_ED5_Hanasaku_Iroha.jpg	1
354	130	354	244		/audio/Hanasaku Iroha ED6 「Hi Leap」.mp3	Hi Leap	ED6	https://res.cloudinary.com/ddc6silap/image/upload/v1773252081/covers/Hanasaku_Iroha_ED6_Hi_Leap.jpg	1
356	130	349	264		/audio/Hanasaku the Movie ED 「Kagefumi」.mp3	Kagefumi	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252063/covers/Hanasaku_the_Movie_ED_Kagefumi.jpg	1
357	357	357	213		/audio/Handyman Saitou in Another World  OP 「kaleidoscope」.mp3	kaleidoscope	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252070/covers/Handyman_Saitou_in_Another_World_OP_kaleidoscope.jpg	1
363	185	363	193		/audio/Heaven_s Lost Property ED6 「Natsu-iro no Nancy」.mp3	Natsu-iro no Nancy	ED6	https://res.cloudinary.com/ddc6silap/image/upload/v1773252066/covers/Heaven_s_Lost_Property_ED6_Natsu-iro_no_Nancy.jpg	1
365	365	365	318		/audio/Hello World ED 「NEW WORLD」.mp3	NEW WORLD	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252073/covers/Hello_World_ED_NEW_WORLD.jpg	1
371	371	369	66	[00:00.00] \r\n[00:06.49]Sokoni yukeba, donna yumemo kanauto yuuyo\r\n[00:17.30]Daremonina yukitagaruga, harakana sekai\r\n[00:27.85]Sono kunino nawa Gandhara\r\n[00:30.52]Dokokani aru Utopia\r\n[00:33.11]Doushitara yukeruno darou? Oshiete hoshii\r\n[00:39.85]*In Gandhara, Gandhara\r\n[00:42.43]They say it was in India\r\n[00:45.07]Gandhara, Gandhara\r\n[00:47.65]Ai no kuni Gandhara\r\n[00:59.65] 	/audio/Her Blue Sky 「GANDHARA - Aoi」.mp3	GANDHARA - Aoi	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773252058/covers/Her_Blue_Sky_GANDHARA_-_Aoi.jpg	1
337	335	335	234		/audio/Grimgar of Fantasy and Ash OP 「Knew Day」.mp3	Knew Day	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252101/covers/Grimgar_of_Fantasy_and_Ash_OP_Knew_Day.jpg	1
342	66	339	334		/audio/Guilty Crown OP2 「My Dearest」.mp3	My Dearest	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252097/covers/Guilty_Crown_OP2_My_Dearest.jpg	1
344	344	344	233		/audio/Haganai ED 「Watashi no Kimochi」.mp3	Watashi no Kimochi	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252090/covers/Haganai_ED_Watashi_no_Kimochi.jpg	1
350	130	349	227		/audio/Hanasaku Iroha ED2 「Tsukikage to Buranko」.mp3	Tsukikage to Buranko	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252089/covers/Hanasaku_Iroha_ED2_Tsukikage_to_Buranko.jpg	1
352	130	349	259		/audio/Hanasaku Iroha ED4 「Saibou Kioku」.mp3	Saibou Kioku	ED4	https://res.cloudinary.com/ddc6silap/image/upload/v1773252085/covers/Hanasaku_Iroha_ED4_Saibou_Kioku.jpg	1
359	359	359	289		/audio/Happy Sugar Life ED 「SWEET HURT」.mp3	SWEET HURT	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252095/covers/Happy_Sugar_Life_ED_SWEET_HURT.jpg	1
362	362	361	258		/audio/Haruhi Suzumiya OST 「Lost my music」.mp3	Lost my music	OST	https://res.cloudinary.com/ddc6silap/image/upload/v1773252087/covers/Haruhi_Suzumiya_OST_Lost_my_music.jpg	1
364	364	363	258		/audio/Heaven_s Lost Property OP 「Ring My Bell」.mp3	Ring My Bell	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252106/covers/Heaven_s_Lost_Property_OP_Ring_My_Bell.jpg	1
372	372	372	274		/audio/Higehiro ED 「Plastic Smile」.mp3	Plastic Smile	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252098/covers/Higehiro_ED_Plastic_Smile.jpg	1
373	373	372	266		/audio/Higehiro OP 「Omoide Shiritori」.mp3	Omoide Shiritori	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252092/covers/Higehiro_OP_Omoide_Shiritori.jpg	1
381	312	311	226		/audio/Gate OP 「Sore wa Akatsuki no you ni」.mp3	Sore wa Akatsuki no you ni	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252113/covers/Gate_OP_Sore_wa_Akatsuki_no_you_ni.jpg	1
387	387	385	267		/audio/Higurashi Gou OP 「I believe what you said」.mp3	I believe what you said	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252107/covers/Higurashi_Gou_OP_I_believe_what_you_said.jpg	1
402	185	402	281		/audio/Hitsugi no Chaika S2 OP 「Shikkoku wo Nuritsubus.mp3	Shikkoku wo Nuritsubuse	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252111/covers/Hitsugi_no_Chaika_S2_OP_Shikkoku_wo_Nuritsubuse.jpg	2
411	411	411	200		/audio/I can_t understand what my Husband is saying ED.mp3	Iikagen ni Shite, Anata	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252109/covers/I_can_t_understand_what_my_Husband_is_saying_ED_Iikagen_ni_Shite_Anata.jpg	1
437	437	437	229		/audio/Isekai Quartet ED 「Isekai Girls♡Talk」.mp3	Isekai Girls♡Talk	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252153/covers/Isekai_Quartet_ED_Isekai_GirlsaTalk.jpg	1
377	377	251	312		/audio/Electromagnetic Girlfriend ED2 「Door」.mp3	Door	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252124/covers/Electromagnetic_Girlfriend_ED2_Door.jpg	1
383	383	338	204		/audio/Ground Control to Psychoelectric Girl OP 「Os-Uc.mp3	Os-Uchuujin	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252120/covers/Ground_Control_to_Psychoelectric_Girl_OP_Os-Uchuujin.jpg	1
427	427	427	91		/audio/Inu x Boku SS ED 「Rakuen no Photograph」.mp3	Rakuen no Photograph	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252157/covers/Inu_x_Boku_SS_ED_Rakuen_no_Photograph.jpg	1
444	444	443	260		/audio/Isshuukan Friends OP 「Niji no Kakera」.mp3	Niji no Kakera	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252155/covers/Isshuukan_Friends_OP_Niji_no_Kakera.jpg	1
1175	1175	1175	238	[00:00.00] \n[00:07.28]Machi wa nemuredo tatemono wa zutto kensetsu chuu sa\n[00:14.51]Toshi keikaku suikou chuu\n[00:16.97]Kamiau hebi moofingu shita kanjousen\n[00:21.76]Endorufin aotte yuke yo goo goo goo\n[00:26.56]Yoru no sora ni joushou suru tamashii\n[00:31.28]Koushin to shinkou wa jouki wo isshita kuizu no you da\n[00:40.57]Kuizu no you da\n[00:46.05]Mada karappo na ashita wa\n[00:51.99]Kagiri naku kuro ni chikai gurei\n[00:55.71]Nanika ni mo narezu ni\n[01:01.52]Kagiri naku kuro ni chikai gurei\n[01:04.76]Chuutou demo indo demo afurika demo\n[01:09.77]Housou suru shouchou wa touzen ni choukousou\n[01:14.51]Kyou to iu hi wa michiyuku suii\n[01:19.31]Karappo na ashita ni shippo wo maite\n[01:24.04]Yasashisa wo kisou kyodai na kuuki seijouki\n[01:28.66]Kono te no geemu ni wa oya no douha ga hitsuyou da\n[01:32.25]Shousan mo naku kake ni deta kuizu no you da\n[01:38.09]Kuizu no you da\n[01:43.68]Mada karappo na ashita wa\n[01:49.47]Kagiri naku kuro ni chikai gurei\n[01:53.27]Nanika ni mo narezu ni\n[01:59.20]Kagiri naku kuro ni chikai gurei\n[02:02.92]Aa konya kimi ga hoshii no sa seijatachi\n[02:12.51]Aa owari tsugete hoshii no sa seijatachi\n[02:21.92]Aa konya kimi ga hoshii no sa\n[02:28.92] \n[02:31.27]Kuizu no you da\n[02:36.00] \n[02:40.97]Kuizu no you da\n[02:45.61] \n[02:50.55]Kuizu no you da\n[02:55.64]Mada karappo na ashita wa\n[03:01.45]Kagiri naku kuro ni chikai gurei\n[03:05.31]Nanika ni mo narezu ni\n[03:11.14]Kagiri naku kuro ni chikai gurei\n[03:14.88]Aa konya kimi ga hoshii no sa seijatachi\n[03:24.50]Aa owari tsugete hoshii no sa seijatachi\n[03:34.20] \n[03:35.98]Seijatachi\n[03:38.70] \n	/audio/Tokyo Ghoul ED 「Seijatachi」.mp3	Seijatachi	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254067/covers/Tokyo_Ghoul_ED_Seijatachi.jpg	1
386	385	385	264		/audio/Higurashi Gou ED2 「Fukisokusei Entropy」.mp3	Fukisokusei Entropy	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252115/covers/Higurashi_Gou_ED2_Fukisokusei_Entropy.jpg	1
389	389	385	302		/audio/Higurashi Kai OP 「Naraku no Hana」.mp3	Naraku no Hana	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252121/covers/Higurashi_Kai_OP_Naraku_no_Hana.jpg	1
390	389	385	264		/audio/Higurashi OP 「Higurashi no Naku Koro ni」.mp3	Higurashi no Naku Koro ni	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252118/covers/Higurashi_OP_Higurashi_no_Naku_Koro_ni.jpg	1
394	389	385	329	[ti:Higurashi Sotsu ED2 「you -Sotsugyou-」]\n[ar:Eiko Shimamiya ]\n[al:Higurashi]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:23.4.20]\n[length:05:28.82]\n[00:00.00]\n[00:11.84]Hateshinaku tsudzuku ikusen no monogatari\n[00:17.20]Daisuki na kimi no tame utau yo\n[00:44.88]Itsudatte itsudatte isshoni sugoshita\n[00:50.26]Yawaraka na hidamari no youna hibi\n[00:55.92]Koboreta setsunasa no kakera wo dakishime\n[01:01.34]Mankai no sakura ni senaka osare\n[01:06.51]Wake mo naku waraikoroge\n[01:12.22]Hashai de kaetta tanbo michi\n[01:17.86]Kawaranai kono miharashi mo\n[01:23.12]Sukoshi dake, miosame da ne\n[01:28.37]Kyou wa kimi no sotsugyou no hi da yo\n[01:34.19]"Mata nanika no naku koro ni"\n[01:39.60]Hanamuke no kotoba wo tabanete okuru yo\n[01:45.43]Bokura dake no ganbari monogatari\n[01:51.05]Kimi to isshoni mekutta kono KARENDAA\n[01:56.49]Ashita kara wa hitori de mekuru yo\n[02:46.28]Kimi ga kono sekai ni umareta sono toki\n[02:51.62]Boku mo onaji sekai de mezameta\n[02:57.27]Guuzen ga hitsuzen ni kawatte iku you ni\n[03:02.56]Futatsu no kokoro ga kasanariatta\n[03:08.11]Futari de utau kono uta mo\n[03:13.58]POKETTO ni shimaikonde\n[03:19.26]Ashita ga kagiriau koto\n[03:24.68]Shiranai furi shite jareatta\n[03:30.29]Hare no sugata yakitsukete harari\n[03:35.49]"Mata nanika no naku koro ni"\n[03:41.04]Matsurihayashi ga tooku chikaku ni hibiku\n[03:46.88]Minna no kokoro wo tomoshite iku\n[03:52.35]Nidoto modorenai keshiki ga toozakaru\n[03:57.84]Chiisana mune no itami wo yadoshite\n[04:25.57]Higurashi ga sato ni hibikiatte\n[04:30.81]Somaru yamahana to hoshidzukiyo\n[04:36.51]Itetsuku kazahana wo norikoete\n[04:41.77]Sakura wa sakihokoru\n[04:47.17]Hanamuke no kotoba wo tabanete okuru yo\n[04:53.10]Bokura dake no ganbari monogatari\n[04:58.58]Kimi no utau ikusen no kinou to ashita wa\n[05:04.04]Hana to natte "boku" he furisosogu deshou\n[05:09.70]	/audio/Higurashi Sotsu ED2 「you -Sotsugyou-」.mp3	you -Sotsugyou-	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253873/covers/Higurashi_Sotsu_ED2_you_-Sotsugyou-.jpg	1
397	14	396	90		/audio/Hinamatsuri ED2 「Shashinchou」.mp3	Shashinchou	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252117/covers/Hinamatsuri_ED2_Shashinchou.jpg	1
401	401	400	252		/audio/Hitsugi no Chaika S2 ED 「Watashi wa Omae no Nak.mp3	Watashi wa Omae no Naka ni Iru	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252126/covers/Hitsugi_no_Chaika_S2_ED_Watashi_wa_Omae_no_Naka_ni_Iru.jpg	2
388	388	385	251		/audio/Higurashi Kai ED 「Taishou.a」.mp3	Taishou.a	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252130/covers/Higurashi_Kai_ED_Taishou.a.jpg	1
405	405	405	260		/audio/Howl_s Moving Castle OP 「The Promise of the Wor.mp3	The Promise of the World	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252131/covers/Howl_s_Moving_Castle_OP_The_Promise_of_the_World.jpg	1
408	408	406	252	[00:00.00] \n[00:03.63]taikutsu na madobe ni fukikomu kaze ni\n[00:08.97]kao wo shikameta no wa terekusasa no uragaeshi\n[00:18.24] \n[00:25.41]aimai ni unazuku tenohira no kyou\n[00:30.88]egaite'ru jibun wa sukoshi oogesa de\n[00:36.09]nanika kawarisou na ki ga shite iru yo\n[00:41.47]kokoro ni yobikakeru kimi no sei da ne\n[00:47.94]kumorizora nozoita yokan\n[00:53.42]te wo nobasou itsu yori mo chikarazuyoi yuuki de\n[01:01.90]hikari mo kage mo mada tookute sore de mo bokura wa\n[01:09.13]yasashisa no riyuu ga shiritai\n[01:12.82]ima wa dare no namae de mo nai kagayaki no kanata e\n[01:20.19]zenbu kako ni naru mae ni mitsuke ni ikou\n[01:29.07] \n[01:37.16]kono sekai wa marude tayorinai ne to\n[01:42.58]usobuku boku no me wo karakau you ni\n[01:47.94]kimi ga mite'ru sora wa naniiro darou?\n[01:53.36]kitto aoku takaku kiyoraka na hazu\n[01:59.86]surechigai chikazukinagara\n[02:05.43]itsu no hi ka tomadoi mo uketomete iketara\n[02:13.73]kotoba no mama ja modokashikute dakara nando de mo\n[02:21.01]bukiyou ni kasanete shimau ne\n[02:24.59]yorokobi mo kanashimi mo koko de imi ga umareru koto\n[02:32.18]futari kizukihajimete'ru sono riyuu mo\n[02:40.06] \n[02:58.66]kotoba no mama ja modokashikute\n[03:03.16]nando de mo bukiyou ni kasanete shimau yo\n[03:09.29]koe ni naranai setsunasa goto\n[03:13.95]kono omoi, kimi ni todoke\n[03:20.31]hikari mo kage mo mada tookute sore de mo bokura wa\n[03:27.58]yasashisa no riyuu ga shiritai\n[03:31.15]ima wa dare no namae de mo nai kagayaki no kanata e\n[03:38.51]zenbu kako ni naru mae ni mitsuke ni ikou\n[03:46.44]kimi ga kako ni naru mae ni mitsukeru kara\n[03:46.68] \n[03:55.81] \n	/audio/Hyouka OP 「Yasashisa no Riyuu」.mp3	Yasashisa no Riyuu	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253640/covers/Hyouka_OP_Yasashisa_no_Riyuu.jpg	1
1176	1176	1175	241	[00:00.000]oshiete oshiete yo sono shikumi wo\r\n[00:09.385]boku no naka ni dare ga iru no kowareta kowareta yo kono sekai de\r\n[00:23.681]kimi ga warau nani mo miezu ni\r\n\r\n[00:43.402]kowareta boku nante sa iki wo tomete\r\n[00:48.432]hodokenai mou hodokenai yo shinjitsu sae\r\n[00:56.652]freeze\r\n\r\n[00:57.484]kowaseru kowasenai kurueru kuruenai\r\n[01:01.150]anata wo mitsuke te\r\n\r\n[01:03.920]yurete yuganda sekai ni dandan boku wa\r\n[01:08.290]sukitotte mienakunatte\r\n[01:11.890]mitsukenaide boku no koto wo mitsumenaide\r\n[01:19.050]dareka ga egaita sekai no nake de\r\n[01:22.494]anata wo kizutsuketaku wa nai yo\r\n[01:26.132]oboeteite boku no koto wo\r\n[01:34.926]azayaka na mama\r\n\r\n[01:44.010]mugen ni hirogaru kodoku ga karamaru\r\n[01:47.334]mujaki ni waratta kioku ga sasunda\r\n[01:50.950]ugokenai hodokenai ugokenai hodokenai\r\n[01:54.434]ugokenai ugokenai yo\r\n[01:57.230]unravelling the world\r\n\r\n[02:26.604]kawatteshimatta kaerenakatta\r\n[02:29.984]futatsu ga karameru futari ga horobiru\r\n[02:33.438]kowaseru kowasenai kurueru kuruenai\r\n[02:36.934]anata wo kegasenai yo\r\n\r\n[02:40.074]yurete yuganda sekai ni dandan boku wa\r\n[02:44.138]sukitotte mienakunatte\r\n[02:47.718]mitsukenaide boku no koto wo mitsumenaide\r\n[02:54.904]dareka ga shikunda kodoku na wana ni\r\n[02:58.384]mirai ga hodoketeshimau mae ni\r\n[03:01.934]omoidashite boku no koto wo\r\n[03:09.458]azayaka na mama\r\n\r\n[03:12.944]wasurenaide wasurenaide wasurenaide wasurenaide\r\n[03:20.138]kaeteshimatta koto ni paralyze kaerarenai koto darake paradise\r\n[03:26.994]oboeteite boku no koto wo\r\n\r\n[03:37.500]oshiete oshiete\r\n[03:44.644]boku no naka ni dare ga iru no\r\n\r\n\r\nsource: http://www.lyricsondemand.com/tvthemes/tokyoghoullyrics.html	/audio/Tokyo Ghoul OP 「Unravel」.mp3	Unravel	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254092/covers/Tokyo_Ghoul_OP_Unravel.jpg	1
433	433	433	205		/audio/Invaders of the Rokujoma!_ ED 「Koi wa Milk Tea」.mp3	Koi wa Milk Tea	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252159/covers/Invaders_of_the_Rokujoma_ED_Koi_wa_Milk_Tea.jpg	1
460	245	458	263		/audio/Kabaneri of the Iron Fortress Movie ED 「ninelie.mp3	ninelie	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252161/covers/Kabaneri_of_the_Iron_Fortress_Movie_ED_ninelie.jpg	1
70	70	66	272		/audio/Bakemonogatari OP5 「Sugar Sweet Nightmare」.mp3	Sugar Sweet Nightmare	OP5	https://res.cloudinary.com/ddc6silap/image/upload/v1773252138/covers/Bakemonogatari_OP5_Sugar_Sweet_Nightmare.jpg	1
348	348	348	276	[00:00.00] \n[00:14.31]Kotoba de tsutaerarenai kedo\n[00:19.89]Anata to sugoshite kita hi wa\n[00:24.74]Sugoku shiawase de\n[00:28.28]Anata ni totte watashi wa\n[00:33.25]Nanimo dekinai keredo\n[00:40.24]Korobisou na watashi wo hiku sono te ni\n[00:47.62]Atataka na anata no ondo wasurenai yo ima mo\n[00:58.31]Konomama anata no inai sekai demo\n[01:05.37]Hajime kara shirazu ni nemuru nara\n[01:11.18]Anata no omoide wo me wo tojireba sugu ni\n[01:19.97]Kanjiru ima ga ii\n[01:24.78] \n[01:28.97]Douka subete ni omoidashite\n[01:34.41]Ii koto mo ya na kioku mo\n[01:39.23]Soko ni ita akashi\n[01:42.76]Deaeta koto soredake de\n[01:47.91]Issho ni ikite yukeru\n[01:54.86]Namae wo yobugoe kaze ni kesareteku\n[02:02.64]Tookute mo yobu hito ga iru\n[02:06.20]Soredake de ureshii\n[02:12.97]Konomama watashi no inai sekai demo\n[02:20.13]Anata ga shiawase de ireru you\n[02:25.67]Anata ga watashi wo hitsuyou to suru no nara\n[02:34.61]Mamotte iru kara\n[02:39.09]Hanarete ite mo\n[02:42.18]Aenakute mo\n[02:45.17]Kono kokoro wa anata wo omou\n[02:50.87]Mimamotteru yo\n[02:54.08]Donna toki mo\n[02:57.18]Anata ga watashi wo omou nara\n[03:02.11]Soba ni iru yo\n[03:06.30] \n[03:11.66]Konomama anata no inai sekai demo\n[03:18.43]Hajime kara shirazu ni nemuru nara\n[03:24.24]Anata no omoide wo me wo tojireba sugu ni\n[03:33.00]Kanjiru ima ga ii\n[03:37.43]Konomama watashi no inai sekai demo\n[03:44.37]Anata ga shiawase de ireru you\n[03:50.05]Anata ga watashi wo hitsuyou to suru no nara\n[03:58.90]Watashi wa egao de mimamotte iru kara ne\n[04:12.59] \n	/audio/Hal ED Theme 「Owaranai Uta」.mp3	Owaranai Uta	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773254116/covers/Hal_ED_Theme_Owaranai_Uta.jpg	1
447	447	447	230		/audio/Jobless Reincarnation ED 「Only」.mp3	Only	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252164/covers/Jobless_Reincarnation_ED_Only.jpg	1
472	472	472	259		/audio/Kanojo mo Kanojo ED 「Pinky Hook」.mp3	Pinky Hook	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252166/covers/Kanojo_mo_Kanojo_ED_Pinky_Hook.jpg	1
528	528	528	292	[00:00.00] \n[00:19.86]Nee yubisaki de anata wo kanjite\n[00:31.17]Nee anata to miteita kono keshiki\n[00:45.52]Tsutawaru yasashisa ni mi wo yudanete\n[00:55.01]Eien nado nai wakatteita tsumori da yo\n[01:09.83]Namae wo yobu anata no koe wo\n[01:15.54]Mune no oku ni shimatteoku kara\n[01:21.48]Hirakareta tobira no mukou gawa de\n[01:27.45]Koborenu youni kienai youni\n[01:45.81]Nee ano yoru ni togireta kotoba wo\n[01:57.94]Nee sono saki wo shiritakute kita yo\n[02:11.37]Tatoe kawaranai ashita demo\n[02:20.83]Shinjiru koto de shizuka ni arukihajimeta\n[02:35.68]Anata he to afuredashita mono\n[02:41.42]Kono toki ni tometeokitai kara\n[02:47.29]Kieteyuku koto no nai youni\n[02:53.30]Tsugi no peeji ni sotto shirusu kara\n[03:26.01]Hakanai sekai de mitsuketa kioku no kakera\n[03:37.17]Sore ha anata no kata koshi ni mieta keshiki\n[03:51.71]Namae wo yobu anata no koe wo\n[03:57.94]Saigo no yoru ni shimatteiku kara\n[04:03.87]Hirakareta tobira no mukou gawa de\n[04:09.84]Koborenu youni kienai youni\n[04:19.59] 	/audio/Looking Up at the Half-Moon ED 「Kioku no Kakera.mp3	Kioku no Kakera	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254127/covers/Looking_Up_at_the_Half-Moon_ED_Kioku_no_Kakera.jpg	1
510	510	510	245	[ti:Life Lessons with Uramichi Oniian ED 「Dream on」]\n[ar:Mamoru Miyano]\n[al:Life Lessons with Uramichi Oniian]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:05.08]\n[00:00.00]\n[00:02.23]Dream on, dream on\n[00:06.48]Keep on, keep on\n[00:09.74]Kimi to sa\n[00:10.64]Dream on, dream on\n[00:14.64]Sā ima\n[00:16.09]Keep on, keep on\n[00:20.03]Hōzue o tsuite mado no soto o miteita\n[00:24.63]Boku no hitorigoto ni neko ga nya ato henji shita\n[00:28.06]"sono mama de īnda "\n[00:33.05]Kimi no ano natsukashī koe mitaida\n[00:37.41]Jikan ga tsukuru otona no seorī\n[00:44.06]Hibi ni oitsukitakute\n[00:48.30]Hataki tsubushita\n[00:50.86]Tonight is the night!\n[00:54.84]Bokura mae yori mo\n[00:57.56]Dream on miyouyo\n[00:59.69]Yumenara kitto mou ichiho ashioto narashite\n[01:05.55]Odorou sou kono oto no naka de nioi ga shita\n[01:11.80]Atarashī iro mouichido\n[01:14.56]Dream on, dream on, dream on\n[01:17.84]Issho ni keep on, keep on, keep on\n[01:22.36]Kimi to sa Dream on, dream on, dream on\n[01:26.77]Todoke ima keep on, keep on\n[01:30.05]Sā toki o koeteike dream on\n[01:33.25]Te ni shita mono shitsu kushita mono\n[01:36.79]Zenbu kazoete mo shiyō ga naikarasa\n[01:40.88]Bukakkou na hou ga bokurarashī kamone\n[01:44.14]Hora nani ga " bokurarashī " nante\n[01:47.47]Bokura de kimerya īnda\n[01:49.88]Kodomo no koro egaita chizu ga\n[01:57.77]Yaburete mo kōshite tsuyoku\n[02:01.71]Dōnika shiteru , daijoubu\n[02:06.25]Bokura mae yori mo\n[02:08.86]Dream on miyouyo\n[02:11.08]Yumenara kitto mō ichi ho ashioto narashite\n[02:16.77]Odorō sō ko no oto no naka de nioi ga shita\n[02:23.04]Atarashī iro mōichido\n[02:28.25]Sing with me now\n[02:30.62]Hooh, kimi to dreaming on\n[02:40.32]Now just keep on\n[02:43.30]Jikan ga tsukuru otona no seorī\n[02:49.99]Hibi ni oitsukitakute\n[02:53.76]Hataki tsubushita\n[02:56.70]Tonight is the night!\n[03:00.16]Bokura mae yori mo\n[03:02.51]Dream on miyouyo\n[03:04.68]Yume nara kitto mou ippo ashioto narashite\n[03:10.44]Odorou sou kono oto no naka de nioi ga shita\n[03:16.58]Atarashī iro mouichido\n[03:19.51]Dream on, dream on, dream on\n[03:22.74]Issho ni keep on, keep on, keep on\n[03:27.24]Kimi to sa Dream on, dream on, dream on\n[03:31.67]Todoke ima keep on, keep on\n[03:34.96]Sā toki o koeteike dream on\n[03:41.55]Dreaming on wooh..\n[03:55.89]	/audio/Life Lessons with Uramichi Oniian ED 「Dream on」.mp3	Dream on	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254122/covers/Life_Lessons_with_Uramichi_Oniian_ED_Dream_on.jpg	1
185	185	184	235	[ti:Date A Live ED2 「SAVE THE WORLD」]\r\n[ar:Iori Nomizu]\r\n[al:Date A Live]\r\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\r\n[ve:22.5.26]\r\n[length:03:55.12]\r\n[00:00.79]Dakara\r\n[00:01.89]Mata aemasu ka?\r\n[00:04.57]Shinjitekuremasu ka?\r\n[00:07.48]Koi ni nite hinaru mono de...\r\n[00:11.99]SAVE THE WORLD\r\n[00:19.04]Sekai ga owaru mae ni kiru or kisu\r\n[00:25.21]Kimi ga warattekuretara ureshii no desu.\r\n[00:30.52]Mada koi no "ko" no ji mo shiranai no ni\r\n[00:36.31]Aa dou shite chuutoriaru mo naku jissen\r\n[00:42.14]Kimochi dake furaingu shite saizensen\r\n[00:47.71]Kuuru na kimi hajikare panikku!\r\n[00:53.52]Koukando no nami ni furimawasarete\r\n[00:59.33]Asobareteru? omocha mocha sore ika!?\r\n[01:08.06]It's long way\r\n[01:09.45]Hateshinasugiru kimi e no michinori wo\r\n[01:15.58]Zensokuryoku de hashiritsuzukeru yo\r\n[01:21.25]Mata aemasu ka? shinjitekuremasu ka?\r\n[01:27.08]Koi ni nite hinaru mono de... SAVE THE WORLD\r\n[01:38.56]Furetakute\r\n[01:40.37]Dakedo chikazukenakute\r\n[01:44.26]Nayami dake ga ruupu shiteku\r\n[01:49.03]Jiko apiiru fuhatsu jishin soushitsu\r\n[01:55.76]Susumu tabi ni tawawa wana mou dame daa\r\n[02:04.50]Oh my god!\r\n[02:05.80]Kagayakisugiru kimi e no sakamichi wa\r\n[02:11.28]Kanari kewashii dakedo ikanakucha\r\n[02:17.12]Kimi no kokoro wo misetekuremasu ka?\r\n[02:22.76]Koi ni nite hinaru mono de... SAVE THE WORLD\r\n[02:33.33]"mata aemasu ka? shinjitekuremasu ka?"\r\n[03:04.83]It's long way\r\n[03:06.33]Hateshinasugiru kimi e no michinori wo\r\n[03:11.93]Zensokuryoku de hashiritsuzukeru yo\r\n[03:17.70]Mata aemasu ka? shinjitekuremasu ka?\r\n[03:23.46]Koi ni nite hinaru mono de... SAVE THE WORLD\r\n[03:37.71]Sekai ga owaru mae ni kiru or kisu\r\n[03:43.46]Kimi ga warattekuretara ureshii no desu\r\n[03:48.20]	/audio/Date A Live ED2 「SAVE THE WORLD」.mp3	SAVE THE WORLD	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773254153/covers/Date_A_Live_ED2_SAVE_THE_WORLD.jpg	1
462	339	458	289		/audio/Kabaneri of the Iron Fortress OP 「KABANERI OF T.mp3	KABANERI OF THE IRON FORTRESS	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252170/covers/Kabaneri_of_the_Iron_Fortress_OP_KABANERI_OF_THE_IRON_FORTRESS.jpg	1
768	768	766	230	[00:00.00] \n[00:09.21]ONE PUNCH!\n[00:16.73](Three! Two! One! Kill shot!)\n[00:18.39]sanjou! hisshou! shijou saikyou\n[00:22.20]nan dattenda? FURASUTOREESHON ore wa tomaranai\n[00:25.71]ONE PUNCH! kanryou! rensen renshou\n[00:29.71]ore wa katsu! tsune ni katsu! asshou!\n[00:33.34]Power! Get the power! GIRIGIRI genkai made\n[00:40.28]HERO ore wo tataeru koe ya kassai nante hoshiku wa nai sa\n[00:47.76]HERO dakara hitoshirezu aku to tatakau\n[00:53.57](Nobody knows who he is.)\n[00:54.98]sora ooi oshiyoseru teki ore wa se wo muke wa shinai\n[01:02.46]HERO naraba yuruginaki kakugo shita tame kuridase tekken\n[01:14.59] \n[01:17.63](Three! Two! One! Fight back!)\n[01:19.33]sanjou! Go on! seiseidoudou!\n[01:23.24]dou nattenda? nanimo kanji nee mohaya teki i nee!\n[01:26.82]JUSTICE! shikkou mondou muyou!\n[01:30.72]ore ga tatsu! aku wo tatsu! gasshou!\n[01:34.38]Power! Get the power! ADORENARIN afuredasu ze!\n[01:41.74]Power! Get the power! kitaeta waza wo buchikamase!\n[01:50.33]HERO donna ni tsuyoi yatsu mo chippoke na gaki dattanda\n[01:57.93]HERO yowaki onore norikoe tsuyoku naru\n[02:03.83](Nobody knows who he is.)\n[02:05.37]kami yodoru kobushi kakagete ore wa tsukisusumu dake sa\n[02:12.72]HERO itsuka haiboku ni odei nameru made tatakau HERO\n[02:24.51]ore wa akiramenai sono mune ni asu wo egaki\n[02:31.37]mezame yuku sekai e ima maiagare tsuyoku takaku\n[02:38.94]donna toki demo nani ga attemo\n[02:43.04] \n[02:53.10]HERO ore wo tataeru koe ya kassai nante hoshiku wa nai sa\n[03:00.80]HERO dakara hitoshirezu aku to tatakau\n[03:06.50](Nobody knows who he is.)\n[03:08.17]kami yadoru kobushi kakagete ore wa tsukisusumu dake sa\n[03:15.59]HERO itsuka haiboku ni odei nameru made tatakau HERO\n[03:29.26]kodoku na HERO\n[03:35.40]I wanna be a saikyou HERO!\n[03:40.89] \n	/audio/One Punch Man OP 「THE HERO !!」.mp3	THE HERO !!	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254139/covers/One_Punch_Man_OP_THE_HERO.jpg	1
810	794	794	102		/audio/Oreimo S2 ED 「Kanjou-sen loop」.mp3	Kanjou-sen loop	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252172/covers/Oreimo_S2_ED_Kanjou-sen_loop.jpg	2
38	38	36	271	[00:00.00] \r\n[00:22.17]Kudarizaka fumikiri made atashi wa muchuu de hashitta\r\n[00:32.76]Kono koi wo saegiru you ni densha wa sugisatta\r\n[00:43.54]Tooi hi no kioku umi no kagayaki kisetsu wa meguru\r\n[00:51.92]Hikoukigumo ni me wo hosomete\r\n[00:56.34]Chiisaku yureta himawari\r\n[01:01.83]Sayonara mo ienai mama\r\n[01:08.12]Honno suu miri no sukima de sotto kusuburu itami\r\n[01:17.93]Manatsu ni kieta hanabi ga namida no saki ni utsureba\r\n[01:29.38]I will kitto omoidasu wa\r\n[01:35.04]Anata ni todoke kono basho de\r\n[01:39.53]Atashi wa matteiru\r\n[01:46.19] \r\n[01:56.54]Henji nara iranai yo to\r\n[02:02.07]Usotsuki ne atashi\r\n[02:07.20]Sunahama ni hitori shagamikondara\r\n[02:12.71]Tsumetaku ashita wo\r\n[02:15.42]Mata yokan saseteshimau no ni\r\n[02:20.06]Suiheisen no mukou ni yukkuri to shizundeyuku\r\n[02:31.68]Naiteshimaeba sukoshi dake sunao ni nareru\r\n[02:41.56]Fureta yubisaki ga fui ni\r\n[02:46.99]Hodoketeyuku samishisa ni\r\n[02:53.18]I will sotto me wo tojiru no\r\n[02:58.70]Anata ni todoke kono basho de\r\n[03:03.08]Atashi wa matteiru\r\n[03:09.26] \r\n[03:19.13]Chiisaku yureta himawari\r\n[03:24.78]Ano hi no mama no atashi wa\r\n[03:31.15]Nobita maegami mo mitometakunai\r\n[03:36.20]Nani mo kawattenai\r\n[03:42.54] \r\n[03:43.61]Kaze no oto ni furikaeru\r\n[03:49.02]Kyou mo mada mitsukerarenai\r\n[03:55.03]I will sotto negatte miru\r\n[04:00.63]Anata ni todoke kono basho de\r\n[04:05.20]Atashi wa matteiru\r\n[04:12.51] \r\n	/audio/Ao haru ride 「I Will」.mp3	I Will	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773254158/covers/Ao_haru_ride_I_Will.jpg	1
79	79	79	261		/audio/Black Bullet ED 「Tokohana」.mp3	Tokohana	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252178/covers/Black_Bullet_ED_Tokohana.jpg	1
100	97	97	272		/audio/Bocchi the Rock! ED4 「Korogaru Iwa, Kimi ni Asa ga Furu 」.mp3	Korogaru Iwa, Kimi ni Asa ga Furu 	ED4	https://res.cloudinary.com/ddc6silap/image/upload/v1773252180/covers/Bocchi_the_Rock_ED4_Korogaru_Iwa_Kimi_ni_Asa_ga_Furu.jpg	1
106	106	105	202		/audio/Btooom! OP 「No pain, No game」.mp3	No pain, No game	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252175/covers/Btooom_OP_No_pain_No_game.jpg	1
923	919	919	244	[ti:Rising of The Shield Hero S2 ED 「Yuzurenai 」]\n[ar:Chiai Fujikawa]\n[al:Rising of The Shield Hero]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:23.4.20]\n[length:04:04.41]\n[00:01.19]Tokei no hari ga modorou to\n[00:04.08]Kataku na mono mitsuketa yo\n[00:06.62]Kimi no chikara ni naritai to\n[00:09.38]Tagai ni negau omoi kizuna\n[00:11.99]Tatoe zero ni kaerou tomo\n[00:14.51]Tatoe sekai no hate kara demo\n[00:17.34]Kimi no moto e to toki wo kakete\n[00:19.84]Hitori ni shinai to yakusoku shiyou\n[00:22.81]Kono me wa\n[00:25.24]Kimi wo mimamoru tame\n[00:27.87]Kono koe wa\n[00:30.40]Kimi wo michibiku tame\n[00:33.25]Kono te wa\n[00:35.79]Kimi wo dakishimeru tame\n[00:38.55]Kono toki ga kimi no ashita ni imi wo nasu you ni\n[00:45.41]Shinjiru koto\n[00:47.81]Sore dake de\n[00:51.22]Bokura doko made mo\n[00:54.43]Tsuyoku nareru\n[00:57.21]Kimi ga oshiete kureta\n[01:01.50]Ano hi kara\n[01:02.55]Kawaranu hikari ga\n[01:07.22]Tatoe futari wo wakatsu toki ga kitemo\n[01:14.64]Kanarazu mata kimi wo mitsukeru kara\n[01:29.49]Yureru nibasha ni yokotawari\n[01:31.95]Nagareru hoshi wo kazoeatta\n[01:34.63]Surikomareta kodoku ya fuan\n[01:37.21]Itsushika yokaze ni magire kieta\n[01:40.02]Kimi wa nemuri ni tsuku mae ni\n[01:42.45]Donna sekai wo negau no?\n[01:45.28]Subete wo wasurete shimau mae ni\n[01:47.99]Hitotsu demo ooku kanaetain da\n[01:50.66]Kono me wa\n[01:53.24]Kimi wo mimamoru tame\n[01:55.90]Kono koe wa\n[01:58.56]Kimi wo michibiku tame\n[02:01.25]Konote wa\n[02:03.88]Kimi wo dakishimeru tame\n[02:06.42]Kono toki ga futari no mirai ni hana wo soeru you ni\n[02:42.80]Itsu kara darou\n[02:46.75]Kimi no mirai ga\n[02:49.02]Boku nashi no mirai de\n[02:51.86]Ii hazu ga nakute\n[02:54.55]Ii hazu ga nakute\n[02:57.39]Subete ni aragattemo\n[03:01.59]Kimi no tonari wa yuzurenai yo\n[03:08.90]Shinjiru koto\n[03:11.88]Sore dake de\n[03:15.22]Bokura doko made mo\n[03:18.58]Tsuyoku nareru\n[03:21.22]Kimi ga oshiete kureta\n[03:25.35]Ano hi kara\n[03:26.52]Kawaranu hikari ga\n[03:31.11]Tatoe futari wo wakatsu toki ga kitemo\n[03:38.77]Kanarazu mata kimi wo mitsukeru kara\n[03:51.82]	/audio/Rising of The Shield Hero S2 ED 「Yuzurenai 」.mp3	Yuzurenai 	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254155/covers/Rising_of_The_Shield_Hero_S2_ED_Yuzurenai.jpg	2
398	398	396	90		/audio/Hinamatsuri ED3 「Hajimete no Kimochi」.mp3	Hajimete no Kimochi	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252144/covers/Hinamatsuri_ED3_Hajimete_no_Kimochi.jpg	1
400	185	400	281		/audio/Hitsugi no Chaika OP 「DARAKENA」.mp3	DARAKENA	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252149/covers/Hitsugi_no_Chaika_OP_DARAKENA.jpg	1
410	410	410	181		/audio/I can_t understand what my Husband is saying ED(1).mp3	Okusama no Blues	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252151/covers/I_can_t_understand_what_my_Husband_is_saying_ED2_Okusama_no_Blues.jpg	1
518	20	516	303	[00:00.00] \n[00:22.10]Sore wa mou yuki no you na tsumetasa de\n[00:32.04]Kono kokoro no netsu wo jojo ni ubatteku\n[00:42.13]Nanimokamo wo shitte subete wo nakushite\n[00:52.46]Soredemo ii to tsukamou toshite mita\n[01:01.60]Hitotsume wa mabushisa\n[01:06.59]Futatsume wa atatakasa\n[01:11.83]Sore ijou wa mou wagamama ni naru\n[01:22.00]Arigatou yasashisa no naka ni aru kagayaki wo\n[01:32.21]Kore dake aru nara mou juubun da yo\n[01:43.57]Doko ni ikou zutto mayoi tsuzuketeta\n[01:53.49]Aruite kita michi mo furikaeru to kie\n[02:03.65]Makkura na sekai ni tomoru hi wo mitsuketa\n[02:14.34]Hashiri dashita sono hikari ni mukai\n[02:23.25]Hitotsu dake chikau yo\n[02:28.34]Sarigiwa wa isagiyoku\n[02:33.44]Nanno miren mo nokosanaide yuku\n[02:43.70]Hito wa mina tsunagareru\n[02:48.56]Atataka na tenohira de\n[02:53.90]Amanojaku datta konna te demo\n[03:05.13]Haru ga owaru\n[03:09.92]Nagai yume to sugisatta\n[03:17.68]Natsu mo aki mo\n[03:22.57]Honto wa minna to itakatta\n[03:52.85]Arigatou takusan no\n[03:57.56]Arigatou omoide wo\n[04:02.74]Kore ijou wa mou wagamama ni naru\n[04:12.95]Arigatou kimi-tachi no naka ni aru kagayaki wo\n[04:23.33]Konna ni kuretara mou juubun da yo\n[04:34.83] 	/audio/Little Busters!_ EX ED2 「Saya_s Song」.mp3	Saya's Song	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773254215/covers/Little_Busters_EX_ED2_Saya_s_Song.jpg	1
1044	95	939	250	[00:00.00] \n[00:15.33]Kimi ga akaku moeru taiyou naraba\n[00:19.19]Boku wa yoru ni saku aoi hana\n[00:22.77]Kaze ni yurete sora wo miagete wa\n[00:26.58]Asa no tsuyu ni nureru\n[00:30.14]Te wo nobashite todokanakute\n[00:33.99]Sonna kimi ga hohoenderu\n[00:37.93]Boku mo itsuka dareka wo mamoru\n[00:41.47]Tsuyosa ga hoshii\n[00:44.76]Kanashimi mo yowasa mo subete uketomete kita mune ni\n[00:52.63]Zutto mienai kizu wo nokoshi kakaete kita no\n[00:59.47]Senakagoshi no keshiki janaku te kimi no sono mabushisa wo\n[01:07.62]Itsuka tonari de kanjiraretara\n[01:12.28]Kakushiteita sono kizu wo\n[01:16.47]Sukoshi demo iyasetara ii na\n[01:21.70]The Iris to you\n[01:25.26] \n[01:37.19]Osanai koro kara tanoshii koto\n[01:41.06]Sagasu no wa sugoku tokui datta\n[01:44.75]Kyou wo taiyou ga yasashige ni\n[01:48.40]Nanimokamo wo terasu\n[01:51.99]Boku wa itsumo majime sugite\n[01:55.86]Kimi ga itsumo warau kara\n[01:59.66]Konna hibi ga\n[02:01.37]Zutto tsuzuita nara ii no ni na\n[02:06.85]Sasaete kureta sono ude ni amaete mitemo ii ka na\n[02:14.58]Mune no aoi hanabira ga sotto chirihajimeta\n[02:21.66]Doushite ima ni natte subete ga itoshiku omoerun darou\n[02:29.51]Kasumu keshiki no saki ni mieta nakiwarai\n[02:36.25]Sonna fuu ni dou ka warawanaide hoshii kara\n[02:43.41]The Iris to you\n[02:46.93] \n[02:49.40]Hontō wa ne itsu da tte\n[02:55.73]Taisetsu de urayamashiku te\n[02:59.16]Zutto gawa ni itai n da yo\n[03:04.33]Kanashimi mo yowasa mo subete\n[03:08.63]Uketomete kita mune ni\n[03:12.19]Zutto mienai kizu o nokoshi\n[03:16.87]Kakaete kita no?\n[03:19.14]Senakagoshi no keshiki ja naku te\n[03:23.46]Kimi no sono mabushi-sa o\n[03:27.12]Itsu mo soba de kanjiteta kara\n[03:31.72]Itsu ka mata sono kizu o\n[03:35.93]Sukoshi demo iyasetanara ī na\n[03:41.17]The Iris to you\n[03:46.44] \n	/audio/Sword Art Online _ Alicization ED 「Iris」.mp3	Iris	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253671/covers/Sword_Art_Online_Alicization_ED_Iris.jpg	1
1079	1061	1061	309		/audio/Teasing Master Takagi San S3 ED3 「Himawari no Y.mp3	Himawari no Yakusoku	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253264/covers/Teasing_Master_Takagi_San_S3_ED3_Himawari_no_Yakusoku.jpg	3
1120	279	1116	301		/audio/The Garden of Sinners_ Paradox Paradigm ED 「Spr.mp3	Sprinter	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773256653/covers/The_Garden_of_Sinners_Paradox_Paradigm_ED_Sprinter.jpg	1
1145	1145	1140	235		/audio/The Petgirl of Sakurasou OP3 「I call your name .mp3	I call your name again	OP3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253342/covers/The_Petgirl_of_Sakurasou_OP3_I_call_your_name_again.jpg	1
417	417	414	233	[00:00.00] \r\n[00:00.39]konya mo kuuchuu yuuei "anta mo gizensha kai"\r\n[00:03.54]seigi ga nandatte shitate agerya ii\r\n[00:07.10]owaranu haido ando shiiku "jikiru wa doko da"\r\n[00:10.21]shokushou shite waratta koe mo nai mama\r\n[00:14.89] \r\n[00:26.62]mata kawaribae mo nai usuyogoreta tenjou\r\n[00:29.81]kono te wo nobashite shimaeba\r\n[00:33.14]eikyuu ni furerarenu hodo no hedatari da to\r\n[00:36.37]zetsubou wo ajiwaun da\r\n[00:39.73]mada mi tsuzuketetai hakuchuu yume de aru hodo\r\n[00:43.12]fuka gyakusei no kesshou\r\n[00:46.33]sonna waishou na genshou\r\n[00:48.21]ID midashite shouto saseru aironii\r\n[00:52.68]kimi ga dareka, boku ga dareka\r\n[00:58.19]"damashite yo"\r\n[00:59.81]daishou koukai kanjou ron sekai ga yureru\r\n[01:03.26]toritomenai handou de rinto ochiteiku\r\n[01:06.73]noudou de ikiteru no? ikasareteru no?\r\n[01:09.88]akumu no koutei darou Mr. fikusaa\r\n[01:13.01]kekkandarake no shounen mo daremo mina\r\n[01:16.45]kurutta souse senjou de tada odotteiru\r\n[01:19.82]owaranu haido ando shiiku "jikiru wa doko da"\r\n[01:22.94]kansei da nante zutto sasenaide\r\n[01:26.19]kotae wo kowashita... "yurushite yo"\r\n[01:29.24] \r\n[01:42.65]kansei majika no gekijou yosou doori no kuukyo\r\n[01:45.98]ato wan shiin ga tarinai\r\n[01:49.18]hontou ni shiranakatta? kizuiteitan janai no?\r\n[01:52.50]kizutsuku no wo osoretan da\r\n[01:55.81]chiguhagu na fukanshou akuukan wo mau hodo\r\n[01:59.11]miushinatteiku kokkyou\r\n[02:02.37]kieirisou na kaiko\r\n[02:04.07]sotto nagashite shoutou... toumei na namida\r\n[02:08.67]koko ga dokoka, asu ga dokoka\r\n[02:14.29]"boka shite yo"\r\n[02:15.91]taishou guuzou yuushinron risei ga yureru\r\n[02:19.36]kaketa sekai no chuushinde ai ga hoeteiru\r\n[02:22.65]honnou de shinjiteiru no? surikaeteiru no?\r\n[02:25.92]ryoushin no bousou darou Mr. fikushon\r\n[02:29.14]kekkan no suketa hyoujou de hito wa mina\r\n[02:32.61]sai wo nageta no nara chi wo konomu kara\r\n[02:36.03]kono mama saigo made kakuretai\r\n[02:38.88]"aa mou nee dareka to\r\n[02:41.86]kizutsukeawanai you ni ikitete itai dake"\r\n[02:45.90]sou mushizu ga hashiru you na kono serifu\r\n[02:51.02]soredemo itai yami no naka ni\r\n[02:55.67]mou sukoshi dake de nanika mitsukereru\r\n[02:59.10]konkyo nai kakushin ga aru kara\r\n[03:06.09]itsudatte\r\n[03:08.84]daishou koukai kanjouron sekai ga yureru\r\n[03:12.47]toritomenai handou de rinto ochiteiku\r\n[03:15.77]noudou de ikiteru no? ikasareteru no?\r\n[03:19.04]akumu no koutei darou Mr. fikusaa\r\n[03:22.17]kekkan darake no shounen mo daremo mina\r\n[03:25.64]kurutta souse senjou de tada odotteiru\r\n[03:28.98]owaranu haido ando shiiku "jikiru wa doko da"\r\n[03:32.10]kansei da nante zutto sasenaide\r\n[03:35.32]kotae wo kowashita... "zurui darou?"\r\n[03:38.61] \r\n	/audio/ID_Invaded OP 「Mr.Fixer」.mp3	Mr.Fixer	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254157/covers/IDInvaded_OP_Mr.Fixer.jpg	1
1147	1147	1147	149	Akaramu sora ga kyou wa konna ni kowai\r\nShiranakereba shiawase de irareta?\r\nAtatakai tomoshibi hitotsu mata ochiru\r\n\r\nKou yatte shiranu ma ni ushinatteta\r\nAno yasashii koe shinjite shimatta no\r\nBoku ni wa sore dake datta\r\n\r\nKokoro nakuseba raku ni nareru nante\r\nSonna no uso sono mama kowarechau\r\n\r\nAmai yami nageitemo tasuke wa konai\r\n\r\n"Aishite kure" nante ne ima sara\r\nUgoke motsureru ashi\r\nKono ori wo nukero\r\nAshita wo tsukamu tame ni\r\nZetsubou wo kakenukero\r\n\r\nHotobashiru ase to moeru kokoro de\r\nTashika ni bokura wa ishi wo motte ikiteru\r\n\r\nKou yatte neratteru\r\nAkirame wa shinai\r\nKando wo takamete\r\nJikkuri yareba ii\r\nKirihirake chakujitsu ni\r\nToki ga shoumei suru darou\r\n\r\n	/audio/The Promised Neverland ED 「Zettai Zetsumei」.mp3	Zettai Zetsumei	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253344/covers/The_Promised_Neverland_ED_Zettai_Zetsumei.jpg	1
420	420	420	290		/audio/In this Corner of the World ED 「Migite no Uta」.mp3	Migite no Uta	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252231/covers/In_this_Corner_of_the_World_ED_Migite_no_Uta.jpg	1
421	420	421	290		/audio/In this Corner of the World OP 「Kanashikute Yar.mp3	Kanashikute Yarikirenai	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252224/covers/In_this_Corner_of_the_World_OP_Kanashikute_Yarikirenai.jpg	1
428	428	427	89		/audio/Inu x Boku SS ED2 「Kimi wa」.mp3	Kimi wa	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252216/covers/Inu_x_Boku_SS_ED2_Kimi_wa.jpg	1
430	430	427	91		/audio/Inu x Boku SS ED4 「SM Hantei Forum」.mp3	SM Hantei Forum	ED4	https://res.cloudinary.com/ddc6silap/image/upload/v1773252215/covers/Inu_x_Boku_SS_ED4_SM_Hantei_Forum.jpg	1
438	58	437	277		/audio/Isekai Quartet ED2 「Hollow Veil」.mp3	Hollow Veil	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252210/covers/Isekai_Quartet_ED2_Hollow_Veil.jpg	1
439	439	437	224		/audio/Isekai Quartet OP 「Isekai Quartet」.mp3	Isekai Quartet	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252227/covers/Isekai_Quartet_OP_Isekai_Quartet.jpg	1
440	440	437	247		/audio/Isekai Quartet S2 ED 「Ponkotsu! Isekai Theatre」.mp3	Ponkotsu! Isekai Theatre	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252213/covers/Isekai_Quartet_S2_ED_Ponkotsu_Isekai_Theatre.jpg	2
441	57	437	90		/audio/Isekai Quartet S2 ED2 「Sweet Pass」.mp3	Sweet Pass	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252230/covers/Isekai_Quartet_S2_ED2_Sweet_Pass.jpg	2
442	439	437	224		/audio/Isekai Quartet S2 OP 「Isekai Showtime」.mp3	Isekai Showtime	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252222/covers/Isekai_Quartet_S2_OP_Isekai_Showtime.jpg	2
446	12	445	246		/audio/I_ve Always Liked You OP 「Koi-iro ni Sake」.mp3	Koi-iro ni Sake	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252251/covers/I_ve_Always_Liked_You_OP_Koi-iro_ni_Sake.jpg	1
448	447	448	281		/audio/Jobless Reincarnation OP 「Tabibito no Uta」.mp3	Tabibito no Uta	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252244/covers/Jobless_Reincarnation_OP_Tabibito_no_Uta.jpg	1
450	447	448	312		/audio/Jobless Reincarnation OP3 「Keishou no Uta」.mp3	Keishou no Uta	OP3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252247/covers/Jobless_Reincarnation_OP3_Keishou_no_Uta.jpg	1
454	454	453	121		/audio/Josee, the Tiger and the Fish OP 「Take Me Far A.mp3	Take Me Far Away	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252240/covers/Josee_the_Tiger_and_the_Fish_OP_Take_Me_Far_Away.jpg	1
459	11	458	244		/audio/Kabaneri of the Iron Fortress ED2 「Through My B.mp3	Through My Blood	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252234/covers/Kabaneri_of_the_Iron_Fortress_ED2_Through_My_Blood.jpg	1
469	465	464	269		/audio/Kaguya Sama_ Love is War S3 OP 「GIRI GIRI」.mp3	GIRI GIRI	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252249/covers/Kaguya_Sama_Love_is_War_S3_OP_GIRI_GIRI.jpg	3
471	471	470	236		/audio/Kakushigoto OP 「Chiisana Hibi」.mp3	Chiisana Hibi	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252242/covers/Kakushigoto_OP_Chiisana_Hibi.jpg	1
475	475	474	234		/audio/Kaze no Stigma ED2 「Matataki no Kiwoku」.mp3	Matataki no Kiwoku	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252238/covers/Kaze_no_Stigma_ED2_Matataki_no_Kiwoku.jpg	1
480	480	480	331		/audio/Kimi wo Aishita Hitori no Boku e  ED Theme 「Shion」.mp3	Shion	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773252236/covers/Kimi_wo_Aishita_Hitori_no_Boku_e_ED_Theme_Shion.jpg	1
422	422	422	271	[00:00.00] \n[00:22.04]Ano hi kimi to jukei zu no katasumi de\n[00:28.76]Deau yakusoku o shiteita nee\n[00:36.25]Moshi mo koko de niji o ukaberunara\n[00:43.38]Naniiro de sora o nurō\n[00:49.50] \n[00:53.90]Sabaku no suna o kazoete tsuki mo michikake teku\n[00:57.94]Namae no nai mono nado doko ni mo nai\n[01:03.42] \n[01:04.65]Taema naku tsuzuiteru toi ni kotae\n[01:08.26]Atarashī gobanme no kisetsu o iku\n[01:11.73]Hakobareta inochi ja nai erande kita\n[01:15.36]Unmei no imi ga ima kodama shiteru\n[01:18.90]Kimi no koe ga kikoeru kono basho dake de\n[01:26.30]Iki o shite iru zutto \n[01:33.87] \n[01:43.72]Onaji ryō no jikan ga nagarete iku\n[01:50.43]Da kedo sore wa chigau haya-sa de\n[01:57.88]Yume no soto de kimi wa kangaeteru\n[02:05.15]Kokoro ga kita michi no koto\n[02:11.19] \n[02:23.12]Umi no aosa ni somerare\n[02:25.10]Soyogu kaze ga hō ni\n[02:26.83]Ondo no nai mono nado doko ni mo nai\n[02:32.34] \n[02:33.64]Kanashī no ni warau no wa uso ja nai yo\n[02:37.08]Furueteru yubisaki no netsu de wakaru\n[02:40.72]Asobi nara raku na no ni sono subete de\n[02:44.29]Uketomeru da kara ima sekai ni naru\n[02:47.77]Mikake yori mo tsuyoi yo\n[02:52.40]Daijōbu da yo watashi ga soba ni iru\n[03:02.76] \n[03:12.73]Konya wa doko de nemuri ni tsuku no?\n[03:19.85]Jukei zu no katasumi kimi o matsu yo\n[03:26.11] \n[03:26.55]Sabaku no suna o kazoete\n[03:29.11]Tsuki mo michikake teku\n[03:30.94]Namae no nai mono nado doko ni mo nai\n[03:38.07] \n[03:39.30]Taema naku tsuzuiteru toi ni kotae\n[03:42.84]Atarashī mata hajimete no kisetsu e\n[03:46.37]Hakobareta inochi ja nai erande kita\n[03:50.09]Unmei no ikisaki ni kodama shiteru\n[03:53.57]Kimi no koe ga kikoeru watashi no naka de\n[04:00.88]Soko ga kokoro sa\n[04:03.50]Kitto kitto\n[04:12.26] \n	/audio/Infinite Dendrogram ED 「Reverb」.mp3	Reverb	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253900/covers/Infinite_Dendrogram_ED_Reverb.jpg	1
425	425	424	255		/audio/Inou Battle wa Nichijou-kei no Naka de OP 「OVERLAPPERS」.mp3	OVERLAPPERS	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252218/covers/Inou_Battle_wa_Nichijou-kei_no_Naka_de_OP_OVERLAPPERS.jpg	1
164	164	162	265		/audio/Danmachi OP 「Hey World」.mp3	Hey World	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252328/covers/Danmachi_OP_Hey_World.jpg	1
166	164	162	90		/audio/Danmachi S2 OP 「HELLO to DREAM」.mp3	HELLO to DREAM	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252325/covers/Danmachi_S2_OP_HELLO_to_DREAM.jpg	2
494	488	488	254		/audio/Kokoro Connect_ Michi Random ED 「I Scream Choco.mp3	I Scream Chocolatl	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252305/covers/Kokoro_Connect_Michi_Random_ED_I_Scream_Chocolatl.jpg	1
508	344	508	289		/audio/Le Portrait de petit Cosette ED 「Houseki」.mp3	Houseki	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252307/covers/Le_Portrait_de_petit_Cosette_ED_Houseki.jpg	1
511	511	510	172		/audio/Life Lessons with Uramichi Oniian OP 「ABC Taish.mp3	ABC Taishou	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252320/covers/Life_Lessons_with_Uramichi_Oniian_OP_ABC_Taishou.jpg	1
512	512	512	283		/audio/Life with an ordinary guy who Reincarnated into(1).mp3	Akatsuki no Salaryman	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252335/covers/Life_with_an_ordinary_guy_who_Reincarnated_into_a_total_fantasy_Knockout_OP_Akatsuki_no_Salaryman.jpg	1
514	514	514	181	[ti:Link Click ED 「OverThink」]\n[ar:Fan Ka]\n[al:Link Click]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:00.98]\n[00:00.00]\n[00:15.20]Xiangle shi’er miao de dianhua wo meiyou jie\n[00:16.72]zhi xiang yao zai yanhuo xia bi shang yan\n[00:18.15]rang zhouwei nihongdeng guang tui hou xie\n[00:19.79]xingkong xia caineng kan qing ni de lian\n[00:21.59]xiang jiangyao zhuidi de boli jiubei\n[00:22.89]monianzhe fan zhongli piaofu\n[00:24.50]wo keqiu nenggou hui dao congqian\n[00:25.96]dan que bei zhe kuangchao si si yao zhu\n[00:27.57]zhe jiu jiaopian de qiwei hai miman zai wo zhe wuzi li\n[00:30.32]zhe ruogan nian guoqule wo shifou hai neng zuo wo ziji\n[00:33.70]I got lost in the history that I’m living in\n[00:36.53]or maybe I should just quit overthinkin\n[00:40.02]wuyishi kanle kan wo de youshou\n[00:43.14]na luoye lueguole wo de xiukou\n[00:46.14]mei laideji shoucang zhe tianhou\n[00:49.02]wo muguang zenme you bei tou zou\n[00:52.15]U should really stop thinkin bout it，\n[00:54.53]stop thinkin bout it，stop\n[00:56.03]stop thinkin bout it\n[00:57.15]why ya mind overclouded\n[00:59.28]tuoli xianshi de mengjing hua wei qipao\n[01:01.84]shizhong de wo xuyao zenyang caineng zi bao\n[01:04.62]so stop thinkin bout it，\n[01:06.50]stop thinkin bout it，stop\n[01:08.00]stop thinkin bout it\n[01:09.06]why ya mind overclouded\n[01:11.25]zai zhe shijian de fengxi tingzhi sikao\n[01:13.88]wo mingbai duoshao fannao dou shi yongrenzirao\n[01:16.56]yay\n[01:21.44]re play, re play\n[01:24.38]ci wo san ge zhongtou lai de jihui\n[01:27.57]time flies, we stay\n[01:30.64]buyao zhi sheng yueguang jie wo yiwei\n[01:33.94]dang women dou hua zuo diandian chen’ai\n[01:36.82]huo shi bai zhi shang de yi’ersan xing shu zi\n[01:39.63]chouchu bu qian zhan zai mingyun de men wai\n[01:42.69]sisuo shi zenyang cunzai de wuzhi\n[01:45.49]jiluzhe zai na shijian zhou jintou de gushi\n[01:47.38]ke zai wo muzhi ming\n[01:48.88]yi zhayan chana jian chuanbo dao wu zhijing\n[01:51.95]No one steps in the same river twice\n[01:54.45]ni de yiqie dou bei na shijian zhi yan momo de zhushi yea\n[01:58.07]wo bu zhidao\n[01:59.09]wo zhishi juede hen chao\n[02:00.64]shoubiao gen bu shang zhe shijie xing se fenrao yea\n[02:03.75]wo bu zhidao\n[02:04.90]man I ain’t sure now\n[02:06.41]all I know’s that I should really\n[02:08.16]ugh ugh\n[02:09.66]stop thinkin bout it，\n[02:11.16]stop thinkin bout it，stop\n[02:12.72]stop thinkin bout it\n[02:13.85]why ya mind overclouded\n[02:15.97]tuoli xianshi de mengjing hua wei qipao\n[02:18.60]shizhong de wo xuyao zenyang caineng zi bao\n[02:21.35]so stop thinkin bout it，\n[02:22.85]stop thinkin bout it，stop\n[02:24.60]stop thinkin bout it\n[02:25.72]why ya mind overclouded\n[02:27.91]zai zhe shijian de fengxi tingzhi sikao\n[02:30.72]wo mingbai duoshao fannao dou shi yongrenzirao\n[02:32.80]U should really stop thinkin bout it，\n[02:34.99]stop thinkin bout it，stop\n[02:36.55]stop thinkin bout it\n[02:37.74]why ya mind overclouded\n[02:45.45]stop thinkin bout it，\n[02:46.95]stop thinkin bout it，stop\n[02:48.34]stop thinkin bout it\n[02:49.52]why ya mind overclouded\n[02:53.59]yayy\n[02:55.15]	/audio/Link Click ED 「OverThink」.mp3	OverThink	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252311/covers/Link_Click_ED_OverThink.jpg	1
171	171	96	324		/audio/Darker than Black ED2 「Dreams」.mp3	Dreams	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252329/covers/Darker_than_Black_ED2_Dreams.jpg	1
172	96	96	282		/audio/Darker than Black OP 「Howling」.mp3	Howling	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252326/covers/Darker_than_Black_OP_Howling.jpg	1
180	175	175	266		/audio/Darling In The FranXX ED6 「Darling」.mp3	Darling	ED6	https://res.cloudinary.com/ddc6silap/image/upload/v1773252324/covers/Darling_In_The_FranXX_ED6_Darling.jpg	1
346	346	346	230		/audio/Haibane Renmei ED 「Blue Flow」.mp3	Blue Flow	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252353/covers/Haibane_Renmei_ED_Blue_Flow.jpg	1
349	349	349	263		/audio/Hanasaku Iroha ED 「Hazy」.mp3	Hazy	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252351/covers/Hanasaku_Iroha_ED_Hazy.jpg	1
351	130	349	264		/audio/Hanasaku Iroha ED3 「Yumeji」.mp3	Yumeji	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252349/covers/Hanasaku_Iroha_ED3_Yumeji.jpg	1
470	470	470	334	[ti:Kakushigoto ED 「Kimi wa Tennenshoku」]\n[ar:Eiichi Ootaka]\n[al:Kakushigoto]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:05:06.98]\n[00:00.00]\n[00:39.50]Kuchibiru tsun to togarasete\n[00:46.62]Nanika takuramu hyoujou wa\n[00:53.48]Wakare no kehai wo poketto ni kakushiteita kara\n[01:07.31]Tsukue no hashi no poraroido\n[01:14.16]Shashin ni hanashikaketetara\n[01:21.08]Sugisatta toki shaku dakedo ima yori mabushii\n[01:33.43]Omoide wa monokuroomu iro wo tsukete kure\n[01:47.15]Mou ichido soba ni kite hanayaide\n[01:55.51]Uruwashi no Color Girl\n[02:02.35]Yoake made nagadenwa shite juwaki motsu te ga shibireta ne\n[02:16.50]Mimimoto ni fureta sasayaki wa ima mo wasurenai\n[02:28.92]Omoide wa monokuroomu iro wo tsukete kure\n[02:41.81]Mou ichido soba ni kite hanayaide\n[02:50.62]Uruwashi no Color Girl\n[03:21.08]Hiraita hon wo kao ni nose\n[03:28.35]Hitori utouto nemuru no sa\n[03:35.24]Ima yumemakura ni kimi to au tokimeki wo negau\n[03:49.33]Nagisa wo suberu dingii de\n[03:56.27]Te wo furu kimi no koyubi kara\n[04:03.25]Nagaredasu niji no maboroshi de sora wo somete kure\n[04:15.66]Omoide wa monokuroomu iro wo tsukete kure\n[04:29.46]Mou ichido soba ni kite hanayaide\n[04:38.05]Uruwashi no Color Girl\n[04:41.45]	/audio/Kakushigoto ED 「Kimi wa Tennenshoku」.mp3	Kimi wa Tennenshoku	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253959/covers/Kakushigoto_ED_Kimi_wa_Tennenshoku.jpg	1
482	482	66	363		/audio/Kizumonogatari M3 ED 「etoile et toi (edition le.mp3	etoile et toi (edition le blanc)	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252303/covers/Kizumonogatari_M3_ED_etoile_et_toi_edition_le_blanc.jpg	1
486	486	486	247		/audio/Kokkoku ED 「Asayake to Nettaigyo」.mp3	Asayake to Nettaigyo	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252318/covers/Kokkoku_ED_Asayake_to_Nettaigyo.jpg	1
360	359	359	287		/audio/Happy Sugar Life ED2 「Canaria」.mp3	Canaria	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252357/covers/Happy_Sugar_Life_ED2_Canaria.jpg	1
361	361	361	279		/audio/Haruhi Suzumiya Insert Song 「God knows...」.mp3	God knows...	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773252361/covers/Haruhi_Suzumiya_Insert_Song_God_knows....jpg	1
496	496	495	179		/audio/Komi Can't Communicate S2 OP 「Ao 100-iro 」.mp3	Ao 100-iro 	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252369/covers/Komi_Can_t_Communicate_S2_OP_Ao_100-iro.jpg	2
498	497	495	326		/audio/Komi Can_t Communicate ED2 「Hikare Inochi」.mp3	Hikare Inochi	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252362/covers/Komi_Can_t_Communicate_ED2_Hikare_Inochi.jpg	1
513	513	512	250		/audio/Life with an ordinary guy who Reincarnated into.mp3	"FA"NTASY to!	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252366/covers/Life_with_an_ordinary_guy_who_Reincarnated_into_a_total_fantasy_Knockout_ED_FANTASY_to.jpg	1
516	516	516	277		/audio/Little Busters! ED 「Alicemagic」.mp3	Alicemagic	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252373/covers/Little_Busters_ED_Alicemagic.jpg	1
517	516	516	276		/audio/Little Busters! OP 「Little Busters!」.mp3	Little Busters!	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252390/covers/Little_Busters_OP_Little_Busters.jpg	1
519	516	516	314		/audio/Little Busters!_ Refrain ED2 「Song for friends」.mp3	Song for friends	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252396/covers/Little_Busters_Refrain_ED2_Song_for_friends.jpg	1
524	524	523	237		/audio/Log Horizon OP 「database」.mp3	database	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252404/covers/Log_Horizon_OP_database.jpg	1
536	532	532	249		/audio/Love, Chunibyo and Other Delusions Movie_ Rikka(1).mp3	Secret Survivor	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252398/covers/Love_Chunibyo_and_Other_Delusions_Movie_Rikka_Version_ED_Secret_Survivor.jpg	1
543	543	543	197		/audio/Maid Sama ED 「Yokan」.mp3	Yokan	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252393/covers/Maid_Sama_ED_Yokan.jpg	1
544	543	543	209		/audio/Maid Sama ED2 「∞ Loop」.mp3	∞ Loop	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252395/covers/Maid_Sama_ED2_Loop.jpg	1
550	547	546	252		/audio/Maison Ikkoku ED5 「Sayonara no Sobyou」.mp3	Sayonara no Sobyou	ED5	https://res.cloudinary.com/ddc6silap/image/upload/v1773252401/covers/Maison_Ikkoku_ED5_Sayonara_no_Sobyou.jpg	1
552	552	546	238		/audio/Maison Ikkoku OP 「Kanashimi yo Konnichiwa」.mp3	Kanashimi yo Konnichiwa	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252384/covers/Maison_Ikkoku_OP_Kanashimi_yo_Konnichiwa.jpg	1
564	479	557	306		/audio/March comes in like a Lion S2 OP 「Flag wo Tater.mp3	Flag wo Tatero	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252379/covers/March_comes_in_like_a_Lion_S2_OP_Flag_wo_Tatero.jpg	2
575	573	573	283		/audio/Mirai Nikki ED3 「Happy End」.mp3	Happy End	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252387/covers/Mirai_Nikki_ED3_Happy_End.jpg	1
816	794	794	91		/audio/Oreimo S2 ED15 「Thank You」.mp3	Thank You	ED15	https://res.cloudinary.com/ddc6silap/image/upload/v1773252391/covers/Oreimo_S2_ED15_Thank_You.jpg	2
374	71	207	370		/audio/Death Parade ED 「Last Theater」.mp3	Last Theater	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252359/covers/Death_Parade_ED_Last_Theater.jpg	1
385	385	385	257		/audio/Higurashi Gou ED 「Kamisama no Syndrome」.mp3	Kamisama no Syndrome	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252412/covers/Higurashi_Gou_ED_Kamisama_no_Syndrome.jpg	1
396	396	396	298		/audio/Hinamatsuri ED 「Sake to Ikura to 893 to Musume」.mp3	Sake to Ikura to 893 to Musume	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252407/covers/Hinamatsuri_ED_Sake_to_Ikura_to_893_to_Musume.jpg	1
483	368	483	232		/audio/Knight_s and Magic ED 「You _ I」.mp3	You & I	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252372/covers/Knight_s_and_Magic_ED_You_I.jpg	1
495	48	495	228	[ti:Komi Can't Communicate S2 ED 「Koshaberi Biyori」]\n[ar:FantasticYouth]\n[al:Komi Can't Communicate]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:23.4.20]\n[length:03:47.72]\n[00:00.00]\n[00:09.00]Magarikado wa sugu soko ni\n[00:10.99]Mou mieteiru no ni\n[00:13.17]Kizukarenai you ni\n[00:15.08]Kokoro no naka de kaunto shiteru\n[00:17.66]Hibiku kutsuoto wa hitotsu dake\n[00:19.87]Mienai parameetaa ga\n[00:21.83]Ki ni natte shikata ga nai mama\n[00:23.91]Itsudatte kyakuseki kara dareka wo miteru\n[00:27.86]Sabishigari no uta wo mimi ni tsumekonde\n[00:31.88]Kusuguttai kangaegoto wo shite\n[00:34.99]Nando datte te wo toriaesou da\n[00:38.70]Angai daijoubu angai daijoubu\n[00:43.92]Sotto fumidasu to\n[00:45.53]Nurikaerarete yuku\n[00:48.17]Shitteru hazu no keshiki\n[00:50.34]Itsumo yori shizuka de\n[00:52.38]Sore demo tashika ni\n[00:53.65]Sugite yuku kaze no naka de\n[00:56.41]Kimi no koe de kao wo ageta\n[00:58.65]Kamiawanai buhin\n[01:01.44]Nigirishimete\n[01:02.45]Kimi no iro wa naniiro?\n[01:04.02]Sukoshi koe ni dashite mitakunatte\n[01:06.39]Demo aa, yappari iwanakutemo ii yo\n[01:09.75]Mazariau\n[01:10.99]Shingou no nai kousaten mitai ni jinwari to\n[01:14.37]Hirogaru tokeru\n[01:15.81]Ryoute ippai ni kimi no kotoba kakaete\n[01:18.91]Shiritai mite mitai furetai\n[01:21.23]Boyaketa renzu no mukou kara\n[01:23.74]Kocchi ni te wo futteru\n[01:24.87]Kao ga mienai dareka ga.\n[01:38.57]Michibiki wo matteru dake de\n[01:40.65]Tatta hitori de\n[01:42.54]Tsuttatteta rouka\n[01:44.16]Misukasarechau you na ki ga shiteru\n[01:47.14]Mabataki ga kodou ni kawaru\n[01:49.18]Mabuta no ue ni kyou mo\n[01:51.10]Ki ni natte shikata ga nai kimi no\n[01:53.21]Mada yomitori kirenai kao wo utsusu\n[01:57.01]Mado kara nagarekonde kita kazamuki wo\n[02:01.57]Nandaka ishiki suru you ni natte\n[02:05.82]Kotae no nai you na amai hanashi wo\n[02:08.22]Kimi ni mo iesou da kimi ni mo iesou da\n[02:13.60]Kisetsu no iro to nioi ga tsuyoku natteku\n[02:17.69]Fureta shunkan ni motto azayaka ni\n[02:22.07]Mune ga takanaru no wa yume no hajimari mitai ni\n[02:25.86]Te wo sotto nigirare nagara\n[02:28.05]Hora kokochiyoku, nagasareteku\n[02:32.80]Kimi no oto, donna oto?\n[02:34.53]Sukoshi mimi sumashite mitakunatte\n[02:36.90]Itsuka motto kikoete kuru no ka na\n[02:40.08]Kasanariau\n[02:41.42]Chiguhagu na kokyuu demo\n[02:43.36]Itoshiku omoeru you na\n[02:45.33]Hibi ga kirameku\n[02:46.82]Ryoute ippai kimi e no hanataba kakae\n[02:49.72]Michishirube nanka nakutemo\n[02:51.86]Ippo zutsu susunderu “jibun” no koto ga\n[02:55.71]Suki ni nareru sonna toki ga kuru kara\n[02:59.10]Asayake to yuuyake no dochira mo mitakute\n[03:03.41]Sonna chiisana yokubari ga\n[03:06.45]Sukoshi, mata honno sukoshi tte bokura wo unagasu\n[03:16.54]Kimi no iro wa naniiro?\n[03:18.84]Kimi no iro wa naniiro?\n[03:20.37]Sukoshi koe ni dashite mitakunatte\n[03:22.75]Demo aa, yappari iwanakutemo ii yo\n[03:26.10]Mazariau\n[03:27.31]Shingou no nai kousaten mitai ni jinwari to\n[03:31.11]Hirogaru tokeru\n[03:32.31]Ryoute ippai ni kimi no kotoba kakaete\n[03:35.09]Shiritai mite mitai furetai\n[03:38.00]Boyaketa renzu no mukou kara\n[03:40.32]Kocchi ni te wo futteru\n[03:41.72]Kao ga mienai dareka ga.	/audio/Komi Can't Communicate S2 ED 「Koshaberi Biyori」.mp3	Koshaberi Biyori	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252364/covers/Komi_Can_t_Communicate_S2_ED_Koshaberi_Biyori.jpg	2
577	573	573	235		/audio/Mirai Nikki OP2 「Dead END」.mp3	Dead END	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252386/covers/Mirai_Nikki_OP2_Dead_END.jpg	1
490	488	488	231	[00:00.00] \n[00:37.23]Nagare ochiteiku IMA ga\n[00:39.92]Tokei no suna naraba\n[00:42.71]Okizari ni shita KAKO wa\n[00:45.23]Doko e kieta no?\n[00:48.08]Kondaku shita kioku\n[00:50.68]Haibiru no tsumetasa\n[00:53.43]Itsumo me wo sorashita shayou no sora\n[00:58.83]Namida de boyaketeta karappo no\n[01:02.09]setsunasa ni\n[01:03.98]Jibun wo motometeita hazu na no ni\n[01:09.66]Everything Randomize\n[01:11.10]Utagau kara nigedasu koto mo dekinai\n[01:15.07]Nomikudashite wa mune ga itamu, nigai\n[01:18.42]yowasa SARUBEIJI\n[01:20.50]Everything Randomize\n[01:23.27]Rifujin no umi obore nagara\n[01:25.80]Nobashita te de tashikameta no wa\n[01:28.72]nokoshite kita "Itsuka"?\n[01:32.18] \n[01:36.62]Kuchikazu ga heru tabi ni ikiba no nai omoi ga\n[01:41.89]Sono shitsuryou wo mashite shihai shite yui\n[01:47.42]Tameiki no shirosa\n[01:50.08]Denchigire no RAITO\n[01:52.68]Jojo ni ukabi agatteiku SEKAI\n[01:58.25]Muishiki ni tada hakidashita sono namae ni wa\n[02:03.52]Kawai wo motometeta wake ja nai\n[02:08.52]Jaa doushite?\n[02:12.91] \n[02:30.96]Tashikame ni yuku yo ima kara\n[02:33.40]Kotae, ketsumatsu wo\n[02:35.98]Sore ga zutto kawaranai (Motto)\n[02:40.32]Ikikata dakara\n[02:43.04]Omoide ga oshiete kureta koto (Imademo)\n[02:49.70]Hitotsu dake te ni shite\n[02:53.66]Everything Randomize\n[02:55.07]Itami no naka taisetsu na mono wo\n[02:58.07]motomete\n[02:59.15]Koi no zanshi mo mata yakusoku mo tsurai\n[03:02.47]KAKO mo SARUBEIJI\n[03:04.47]Everything Randomize\n[03:07.07]Fumidasu goto katachi kaeru\n[03:09.91]Yukusaki wo erabitoru no wa machigai\n[03:13.62]naku "Jibun"\n[03:15.24]Everything Randomize\n[03:16.54]Oite kita KAKO furikiru hodo ni kasoku shite\n[03:20.65]Hoshigaru mama nozomeba ii tadoritsukeru\n[03:24.71]Kara SHIMPURU ni\n[03:26.54]Randomize\n[03:28.72]Rifujin no umi obore nagara\n[03:31.41]Nobashita te de tashikameta no wa\n[03:34.36]nokoshite kita "Yuuki"\n[03:38.00] \n	/audio/Kokoro Connect ED3 「Salvage」.mp3	Salvage	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253853/covers/Kokoro_Connect_ED3_Salvage.jpg	1
491	108	488	305	[00:00.00] \n[00:16.31]Kokoro no sukima wo chotto yoko kitte\n[00:22.35]Mabataki no SUPIIDO de kasanareba\n[00:28.22]Toorisugiru hibi ga gyutto te wo nigiru\n[00:34.14]Tachidomatteru tsuyogari ni aizu shite\n[00:40.32]Mitsumeru to tsutawatte iku nara\n[00:46.13]Maboroshi mo kieru yo ne sugu ni\n[00:54.90]Fui ni KONEKUTO sekai ga kawaru\n[00:58.09]Biidama goshi ni nozoitara\n[01:00.90]Ima yori motto kagayaku keshiki\n[01:04.13]Nani ga soko de mieru?\n[01:06.85]Yurete KONEKUTO mata chigau sora\n[01:10.18]Tobidasu jikan wa niji no iro\n[01:12.88]Kizuita ndayo hajimari no oto\n[01:16.20]Nogasanai de kiite\n[01:22.46] \n[01:24.70]Bokutachi ga eranda mirai tsunagu yo\n[01:29.00] \n[01:35.88]Kokoro no sukima wo chotto umete mite\n[01:41.82]Atarashii ashita ga yatte kuru nara\n[01:47.65]Itsumo doori massugu arukanai de\n[01:53.72]Zensokuryoku gyaku he yuku no mo ii ne\n[01:59.81]nobasu te ni tsutawatte yuku kara\n[02:05.82]hontou no egao misete sugu ni\n[02:13.79] \n[02:14.25]Fui ni KONEKUTO sekai ga mawaru\n[02:17.57]Kakera ni natta fukashigi he\n[02:20.48]Tomadoi nagara chikazuite yuku\n[02:23.75]Dare ga soko de mieru?\n[02:26.48]Yurete KONEKUTO karuyaka na sora\n[02:29.67]Tobikomu yuuki wo ageru yo\n[02:32.33]Kasuka ni hibiku hajimari no oto\n[02:35.64]Nogasanai de kiite\n[02:41.85] \n[02:44.29]Kako mo mirai mo zenbu tsunaide\n[02:48.74] \n[03:12.02]Donna katachi? kokoro no iremono tte\n[03:17.77]Kantan ni dete icchau no kana\n[03:23.83]Tashikameyou bokutachi no shinjitsu\n[03:29.57]Akareta DOA ni hitasura mukau dake\n[03:36.48] \n[03:41.48]Kitto KONEKUTO shikai ga hareru\n[03:47.32]Uchuu no saki wo mitsuketa mitai\n[03:53.41]Itsuka KONEKUTO mada tarinai ne\n[03:59.39]Dareka no kimochi shitte yuku nara\n[04:02.90] \n[04:05.54]Fui ni KONEKUTO sekai ga kawaru\n[04:08.68]Biidama goshi ni nozoitara\n[04:11.40]Ima yori motto kagayaku keshiki\n[04:14.68]Nani ga soko de mieru?\n[04:17.41]Yurete KONEKUTO mata chigau sora\n[04:20.66]Tobidasu jikan wa niji no iro\n[04:23.50]Kizuita ndayo hajimari no oto\n[04:26.45]Nogasanai de kiite\n[04:33.16] \n[04:35.29]Muda na koto demo zenbu\n[04:38.14]Matomete hikari ni shite\n[04:41.28]Bokutachi de eranda mirai tsunagu yo\n[04:45.52] \n	/audio/Kokoro Connect OP 「Paradigm」.mp3	Paradigm	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253874/covers/Kokoro_Connect_OP_Paradigm.jpg	1
525	523	523	293		/audio/Log Horizon S2 ED 「Wonderful Wonder World」.mp3	Wonderful Wonder World	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252432/covers/Log_Horizon_S2_ED_Wonderful_Wonder_World.jpg	2
527	527	523	216		/audio/Log Horizon S3 OP 「Different」.mp3	Different	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252434/covers/Log_Horizon_S3_OP_Different.jpg	3
530	530	530	265		/audio/Lord Marksman and Vanadis ED 「Schwarzer Bogen」.mp3	Schwarzer Bogen	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252430/covers/Lord_Marksman_and_Vanadis_ED_Schwarzer_Bogen.jpg	1
531	234	530	266		/audio/Lord Marksman and Vanadis OP 「Ginsen no Kaze」.mp3	Ginsen no Kaze	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252426/covers/Lord_Marksman_and_Vanadis_OP_Ginsen_no_Kaze.jpg	1
542	540	539	97		/audio/Lovely Complex OP2 「Hey! Say!」.mp3	Hey! Say!	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252422/covers/Lovely_Complex_OP2_Hey_Say.jpg	1
548	548	546	158		/audio/Maison Ikkoku ED3 「Get Down」.mp3	Get Down	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252420/covers/Maison_Ikkoku_ED3_Get_Down.jpg	1
553	548	546	218	[ti:Maison Ikkoku OP2 「Alone Again (Naturally)」]\n[ar:Gilbert O'Sullivan]\n[al:Maison Ikkoku]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:23.4.20]\n[length:03:38.49]\n[00:00.00]\n[00:12.97]In a little while from now\n[00:15.80]If I'm not feeling any less sour\n[00:18.50]I promise myself to treat myself\n[00:21.28]And visit a nearby tower\n[00:24.17]And climbing to the top\n[00:26.80]Will throw myself off\n[00:29.51]In an effort to\n[00:30.72]Make it clear to whoever\n[00:32.80]Wants to know what it's like When you're shattered\n[00:35.31]Left standing in the lurch at a church\n[00:38.66]Were people saying, My God, that's tough\n[00:42.09]She stood him up\n[00:43.34]No point in us remaining\n[00:46.34]We may as well go home\n[00:49.01]As I did on my own\n[00:51.66]Alone again, naturally\n[00:57.55]To think that only yesterday\n[01:00.11]I was cheerful, bright and gay\n[01:02.86]Looking forward to who wouldn't do\n[01:05.74]The role I was about to play\n[01:08.36]But as if to knock me down\n[01:11.00]Reality came around\n[01:13.84]And without so much as a mere touch\n[01:16.49]Cut me into little pieces\n[01:19.61]Leaving me to doubt\n[01:21.48]Talk about, God in His mercy\n[01:25.02]Oh, if he really does exist\n[01:27.96]Why did he desert me\n[01:30.68]In my hour of need\n[01:33.19]I truly am indeed\n[01:35.86]Alone again, naturally\n[01:41.60]It seems to me that\n[01:42.73]There are more hearts broken in the world\n[01:45.95]That can't be mended\n[01:48.04]Left unattended\n[01:51.34]What do we do\n[01:54.53]What do we do\n[02:37.24]Alone again, naturally\n[02:43.27]Looking back over the years\n[02:45.87]And whatever else that appears\n[02:48.68]I remember I cried when my father died\n[02:51.44]Never wishing to hide the tears\n[02:54.20]And at sixty-five years old\n[02:56.71]My mother, God rest her soul\n[02:59.58]Couldn't understand why the only man\n[03:02.40]She had ever loved had been taken\n[03:05.45]Leaving her to start\n[03:07.45]With a heart so badly broken\n[03:10.99]Despite encouragement from me\n[03:13.51]No words were ever\n[03:16.57]And when she passed away\n[03:19.01]I cried and cried all day\n[03:21.91]Alone again, naturally\n[03:27.53]Alone again, naturally\n[03:32.84]	/audio/Maison Ikkoku OP2 「Alone Again (Naturally)」.mp3	Alone Again (Naturally)	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252445/covers/Maison_Ikkoku_OP2_Alone_Again_Naturally.jpg	1
561	479	557	276		/audio/March comes in like a Lion OP2 「Sayonara Bystan.mp3	Sayonara Bystander	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252453/covers/March_comes_in_like_a_Lion_OP2_Sayonara_Bystander.jpg	1
562	562	557	262		/audio/March comes in like a Lion S2 ED 「Kafune」.mp3	Kafune	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252449/covers/March_comes_in_like_a_Lion_S2_ED_Kafune.jpg	2
567	368	566	273		/audio/Masamune Kun no Revenge OP 「Wagamama MIRROR HEA.mp3	Wagamama MIRROR HEART	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252457/covers/Masamune_Kun_no_Revenge_OP_Wagamama_MIRROR_HEART.jpg	1
569	408	568	273		/audio/Mashiroiro Symphony OP 「Authentic symphony」.mp3	Authentic symphony	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252444/covers/Mashiroiro_Symphony_OP_Authentic_symphony.jpg	1
574	574	573	253		/audio/Mirai Nikki ED2 「Filament」.mp3	Filament	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252440/covers/Mirai_Nikki_ED2_Filament.jpg	1
576	576	573	240		/audio/Mirai Nikki OP 「Kuusou Mesorogiwi」.mp3	Kuusou Mesorogiwi	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252442/covers/Mirai_Nikki_OP_Kuusou_Mesorogiwi.jpg	1
580	580	580	247		/audio/Miss Kobayashi's Dragon Maid ED 「Ishukan Communication」.mp3	Ishukan Communication	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252438/covers/Miss_Kobayashi_s_Dragon_Maid_ED_Ishukan_Communication.jpg	1
581	581	580	277		/audio/Miss Kobayashi's Dragon Maid OP 「Aozoro no Rhapsody」.mp3	Aozoro no Rhapsody	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252455/covers/Miss_Kobayashi_s_Dragon_Maid_OP_Aozoro_no_Rhapsody.jpg	1
582	582	580	205		/audio/Miss Kobayashi's Dragon Maid S  ED2 「Ishukan♡Relationship」.mp3	Ishukan♡Relationship	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252452/covers/Miss_Kobayashi_s_Dragon_Maid_S_ED2_IshukanaRelationship.jpg	1
584	401	584	260		/audio/Hitsugi no Chaika ED 「Kairaku Genri」.mp3	Kairaku Genri	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252447/covers/Hitsugi_no_Chaika_ED_Kairaku_Genri.jpg	1
641	641	627	288		/audio/Naruto ED9 「Nakushita Kotoba」.mp3	Nakushita Kotoba	ED9	https://res.cloudinary.com/ddc6silap/image/upload/v1773252451/covers/Naruto_ED9_Nakushita_Kotoba.jpg	1
432	432	427	91		/audio/Inu x Boku SS ED6 「Taiyou tp Tsuki」.mp3	Taiyou tp Tsuki	ED6	https://res.cloudinary.com/ddc6silap/image/upload/v1773252471/covers/Inu_x_Boku_SS_ED6_Taiyou_tp_Tsuki.jpg	1
560	557	557	319		/audio/March comes in like a Lion OP 「Answer」.mp3	Answer	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252477/covers/March_comes_in_like_a_Lion_OP_Answer.jpg	1
563	563	557	251		/audio/March comes in like a Lion S2 ED2 「I AM STANDIN.mp3	I AM STANDING	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252474/covers/March_comes_in_like_a_Lion_S2_ED2_I_AM_STANDING.jpg	2
565	267	557	285		/audio/March comes in like a Lion S2 OP2 「Haru Ga Kite.mp3	Haru Ga Kite Bokura	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252461/covers/March_comes_in_like_a_Lion_S2_OP2_Haru_Ga_Kite_Bokura.jpg	2
566	408	566	282		/audio/Masamune Kun no Revenge ED 「Elemental World」.mp3	Elemental World	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252472/covers/Masamune_Kun_no_Revenge_ED_Elemental_World.jpg	1
571	571	571	250		/audio/Midori Days OP 「Sentimental」.mp3	Sentimental	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252462/covers/Midori_Days_OP_Sentimental.jpg	1
583	581	580	293		/audio/Miss Kobayashi's Dragon Maid S  OP 「Ai no Supreme」.mp3	Ai no Supreme	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252476/covers/Miss_Kobayashi_s_Dragon_Maid_S_OP_Ai_no_Supreme.jpg	1
587	447	448	300		/audio/Jobless Reincarnation ED2 「Kaze to Iku MIchi」.mp3	Kaze to Iku MIchi	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252459/covers/Jobless_Reincarnation_ED2_Kaze_to_Iku_MIchi.jpg	1
591	591	516	257		/audio/Little Busters!_ Refrain ED 「Kimi to no Nakushi.mp3	Kimi to no Nakushi Mono	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252494/covers/Little_Busters_Refrain_ED_Kimi_to_no_Nakushi_Mono.jpg	1
592	137	532	280		/audio/Love, Chunibyo and Other Delusions Movie_ Take .mp3	Journey	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252483/covers/Love_Chunibyo_and_Other_Delusions_Movie_Take_on_Me_OP_Journey.jpg	1
597	167	595	235		/audio/Mob Psycho 100 Season 2 ED 2「Memosepia」.mp3	Memosepia	2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252503/covers/Mob_Psycho_100_Season_2_ED_2_Memosepia.jpg	1
603	603	602	254		/audio/Monster Girl Doctor OP 「Campanella Hibiku Sora .mp3	Campanella Hibiku Sora de	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252506/covers/Monster_Girl_Doctor_OP_Campanella_Hibiku_Sora_de.jpg	1
605	605	604	233		/audio/Monthly Girls_ Nozaki Kun OP 「Kimi ja Nakya Dan.mp3	Kimi ja Nakya Dance Mitai	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252504/covers/Monthly_Girls_Nozaki_Kun_OP_Kimi_ja_Nakya_Dance_Mitai.jpg	1
606	606	606	189		/audio/Mushishi OP 「The Sore Feet」.mp3	The Sore Feet	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252489/covers/Mushishi_OP_The_Sore_Feet.jpg	1
608	608	608	245		/audio/My Bride is a Mermaid ED2 「Dan Dan Dan」.mp3	Dan Dan Dan	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252501/covers/My_Bride_is_a_Mermaid_ED2_Dan_Dan_Dan.jpg	1
610	610	610	216		/audio/My Dressup Darling ED 「Koi no Yukue」.mp3	Koi no Yukue	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252490/covers/My_Dressup_Darling_ED_Koi_no_Yukue.jpg	1
615	615	615	209		/audio/My Next Life as a Villainess ED 「BAD END」.mp3	BAD END	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252485/covers/My_Next_Life_as_a_Villainess_ED_BAD_END.jpg	1
616	19	615	269		/audio/My Next Life as Villainess OP 「Otome no Route w.mp3	Otome no Route wa Hitotsu janai!	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252487/covers/My_Next_Life_as_Villainess_OP_Otome_no_Route_wa_Hitotsu_janai.jpg	1
618	19	615	233		/audio/My next life as Villainess S2 OP 「Andante ni Ko.mp3	Andante ni Koi wo Shitei!	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252492/covers/My_next_life_as_Villainess_S2_OP_Andante_ni_Koi_wo_Shitei.jpg	2
621	70	621	279		/audio/My Senpai is Annoying ED 「Niji ga Kakaru made n.mp3	Niji ga Kakaru made no Hanashi	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252496/covers/My_Senpai_is_Annoying_ED_Niji_ga_Kakaru_made_no_Hanashi.jpg	1
436	436	435	270	対　　㨀　　⸀　　崀 ਀嬀　　㨀㄀㔀⸀㌀㔀崀吀愀琀漀攀戀愀	/audio/Irozuku Sekai no Ashita Kara OP 「17 Sai」.mp3	17 Sai	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252466/covers/Irozuku_Sekai_no_Ashita_Kara_OP_17_Sai.jpg	1
557	557	557	341		/audio/March comes in like a Lion ED 「Fighter」.mp3	Fighter	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252480/covers/March_comes_in_like_a_Lion_ED_Fighter.jpg	1
558	558	557	246		/audio/March comes in like a Lion ED2 「Nyaa Shougi Ond.mp3	Nyaa Shougi Ondo	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252478/covers/March_comes_in_like_a_Lion_ED2_Nyaa_Shougi_Ondo.jpg	1
570	570	500	140		/audio/Megumin - Konosuba ED (Miraie Remix).mp3	Miraie Remix	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252481/covers/Megumin_-_Konosuba_ED_Miraie_Remix.jpg	1
474	474	474	252		/audio/Kaze no Stigma ED 「Hitorikiri no Sora」.mp3	Hitorikiri no Sora	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252534/covers/Kaze_no_Stigma_ED_Hitorikiri_no_Sora.jpg	1
602	602	602	272		/audio/Monster Girl Doctor ED 「Yasashisa no Namae」.mp3	Yasashisa no Namae	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252514/covers/Monster_Girl_Doctor_ED_Yasashisa_no_Namae.jpg	1
604	604	604	220		/audio/Monthly Girls_ Nozaki Kun ED 「Ura Omote Fortune.mp3	Ura Omote Fortune	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252507/covers/Monthly_Girls_Nozaki_Kun_ED_Ura_Omote_Fortune.jpg	1
607	607	606	218		/audio/Mushishi S2 OP 「Shiver」.mp3	Shiver	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252508/covers/Mushishi_S2_OP_Shiver.jpg	2
609	608	608	220		/audio/My Bride is a Mermaid OP 「Romantic Summer」.mp3	Romantic Summer	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252512/covers/My_Bride_is_a_Mermaid_OP_Romantic_Summer.jpg	1
613	613	612	290		/audio/My Little Monster OP 「Q_A Recital!」.mp3	Q&A Recital!	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252524/covers/My_Little_Monster_OP_Q_A_Recital.jpg	1
614	614	614	250		/audio/My Neighbor Totoro ED Theme 「Tonari no Totoro」.mp3	Tonari no Totoro	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773252520/covers/My_Neighbor_Totoro_ED_Theme_Tonari_no_Totoro.jpg	1
617	617	615	252		/audio/My next life as Villainess S2 ED 「give me ♡ me」.mp3	give me ♡ me	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252538/covers/My_next_life_as_Villainess_S2_ED_give_me_a_me.jpg	2
623	79	623	294		/audio/Nagi no Asukara ED 「Aqua Terrarium」.mp3	Aqua Terrarium	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252547/covers/Nagi_no_Asukara_ED_Aqua_Terrarium.jpg	1
624	624	623	331		/audio/Nagi no Asukara ED3 「lull ~Earth color of a cal.mp3	lull ~Earth color of a calm~	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252586/covers/Nagi_no_Asukara_ED3_lull_Earth_color_of_a_calm.jpg	1
626	624	623	257		/audio/Nagi no Asukara OP2 「ebb and flow」.mp3	ebb and flow	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252548/covers/Nagi_no_Asukara_OP2_ebb_and_flow.jpg	1
628	628	627	221		/audio/Naruto ED 「Wind」.mp3	Wind	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252578/covers/Naruto_ED_Wind.jpg	1
629	629	627	193		/audio/Naruto ED10 「Speed」.mp3	Speed	ED10	https://res.cloudinary.com/ddc6silap/image/upload/v1773252590/covers/Naruto_ED10_Speed.jpg	1
630	630	627	228		/audio/Naruto ED11 「Soba Ni Iru Kara」.mp3	Soba Ni Iru Kara	ED11	https://res.cloudinary.com/ddc6silap/image/upload/v1773252552/covers/Naruto_ED11_Soba_Ni_Iru_Kara.jpg	1
631	631	627	294		/audio/Naruto ED12 「Parade」.mp3	Parade	ED12	https://res.cloudinary.com/ddc6silap/image/upload/v1773252558/covers/Naruto_ED12_Parade.jpg	1
632	628	627	312		/audio/Naruto ED13 「Yellow Moon」.mp3	Yellow Moon	ED13	https://res.cloudinary.com/ddc6silap/image/upload/v1773252568/covers/Naruto_ED13_Yellow_Moon.jpg	1
634	634	627	199		/audio/Naruto ED15 「Scenario」.mp3	Scenario	ED15	https://res.cloudinary.com/ddc6silap/image/upload/v1773252588/covers/Naruto_ED15_Scenario.jpg	1
636	636	627	212		/audio/Naruto ED3 「Viva Rock」.mp3	Viva Rock	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252570/covers/Naruto_ED3_Viva_Rock.jpg	1
643	226	627	246		/audio/Naruto OP2 「Haruka Kanata」.mp3	Haruka Kanata	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252561/covers/Naruto_OP2_Haruka_Kanata.jpg	1
648	648	627	253		/audio/Naruto OP7 「Namikaze Satellite」.mp3	Namikaze Satellite	OP7	https://res.cloudinary.com/ddc6silap/image/upload/v1773252573/covers/Naruto_OP7_Namikaze_Satellite.jpg	1
649	145	627	200		/audio/Naruto OP8 「Re_member」.mp3	Re:member	OP8	https://res.cloudinary.com/ddc6silap/image/upload/v1773252584/covers/Naruto_OP8_Remember.jpg	1
650	650	627	299		/audio/Naruto Shippuden ED 「Shooting Star」.mp3	Shooting Star	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252581/covers/Naruto_Shippuden_ED_Shooting_Star.jpg	1
654	633	627	211		/audio/Naruto Shippuden ED13 「Jitensha」.mp3	Jitensha	ED13	https://res.cloudinary.com/ddc6silap/image/upload/v1773252543/covers/Naruto_Shippuden_ED13_Jitensha.jpg	1
658	365	627	223		/audio/Naruto Shippuden ED18 「Yokubou o Sakebe!!!!」.mp3	Yokubou o Sakebe!!!!	ED18	https://res.cloudinary.com/ddc6silap/image/upload/v1773252576/covers/Naruto_Shippuden_ED18_Yokubou_o_Sakebe.jpg	1
659	659	627	219		/audio/Naruto Shippuden ED19 「Place to Try」.mp3	Place to Try	ED19	https://res.cloudinary.com/ddc6silap/image/upload/v1773252541/covers/Naruto_Shippuden_ED19_Place_to_Try.jpg	1
478	222	478	358	[00:00.00] \n[00:24.56]Ano sakamichi de\n[00:27.71]Kimi wo matteita\n[00:34.62]Houkago no yakusoku ni\n[00:39.67]Tooku nijimu sayonara\n[00:46.99]Furimuku kage\n[00:49.29]Namae wo yobu koe ga shite\n[00:56.00]Natsu no owari ni\n[00:59.80]Kizuki mo shinaide\n[01:02.89]Boku wa kimi dake mitsumeta\n[01:08.78]Yowakute ibitsu de\n[01:12.46]Sugu ni kowaresou na\n[01:18.24]Ano koro no boku ni ne\n[01:21.64]Chiisana tsubasa wo \n[01:25.04]Kimi ga kure ta nda\n[01:31.12]Yuuyami kashida sora ni\n[01:35.63]Kasuka na hikari sagashiteiru\n[01:41.14]Kimi ga suki da to\n[01:44.24]Suki da to ieta nara\n[01:53.84]Kyoukasho no sumi ni\n[01:57.55]Kaita tegami wa\n[02:03.43]Itsu made mo todokazu ni\n[02:10.32]Ano hi no mama\n[02:29.58]Kokoro de wa mada\n[02:33.16]Kimi wo matteita\n[02:39.40]Sewashinaku\n[02:42.38]Sugite yuku hibi no\n[02:46.56]Dokoka de kitto\n[02:52.01]Kawatta no wa\n[02:54.37]Boku no hou nano kana\n[03:00.86]Utsuru subete ga\n[03:04.79]Tanin no kao shite\n[03:07.49]Shirajirashiku shizunda\n[03:13.93]"Zurusa mo tsukuroi sae mo\n[03:18.80]Shikata nai sa"\n[03:23.08]Tsubuyaita kotoba wa\n[03:26.49]Ikiba wo nakushite\n[03:29.88]Futto tokete kieta\n[03:35.74]Yuuyami ukanda hoshi wa\n[03:40.56]Marude ano hi no kimi no youni\n[03:46.24]Tayorinai ima wo\n[03:49.03]Yasashiku terashiteru\n[03:55.24]Wasurenai yo\n[03:58.16]Utsurou kaze ni\n[04:01.41]Itsuka no yume ga kagende mo\n[04:05.81]Kizutsuite mo\n[04:10.29]Soredemo kawaranai\n[04:13.66]Taisetsu na mono daite\n[04:19.87]Bokura wa kyou wo ikiru\n[04:23.21]GARASU wa kudakete\n[04:26.81]Mune ni sasatta mama\n[04:32.55]Nibuku itamu keredo\n[04:35.97]KIRAKIRA mabayui hikari\n[04:40.96]Ranhansha suru\n[04:45.25]Yuuyami magireta machi e\n[04:50.11]Nagai sakamichi aruite yuku\n[04:55.61]Kimi no kakera wa\n[04:58.30]Itsumo koko ni aru kara\n[05:09.27]Bokura no te to te ga\n[05:12.34]Musunda seiza wa\n[05:18.11]Hanarete mo\n[05:22.09]Hanarete mo\n[05:25.67]Kagayaiteru\n[05:29.64] 	/audio/Kids on the Slope ED 「Altair」.mp3	Altair	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252530/covers/Kids_on_the_Slope_ED_Altair.jpg	1
595	595	595	217		/audio/Mob Psycho 100 ED「Refrain Boy」.mp3	Refrain Boy	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252527/covers/Mob_Psycho_100_ED_Refrain_Boy.jpg	1
599	167	595	188		/audio/Mob Psycho 100 Season 2 ED 4「Ikiru Hitobito」.mp3	Ikiru Hitobito	4	https://res.cloudinary.com/ddc6silap/image/upload/v1773252510/covers/Mob_Psycho_100_Season_2_ED_4_Ikiru_Hitobito.jpg	1
540	540	539	267		/audio/Lovely Complex ED2 「BON BON」.mp3	BON BON	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252660/covers/Lovely_Complex_ED2_BON_BON.jpg	1
635	635	627	249		/audio/Naruto ED2 「Harmonia」.mp3	Harmonia	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252595/covers/Naruto_ED2_Harmonia.jpg	1
644	644	627	241		/audio/Naruto OP3 「Kanashimi wo Yasashisani ni」.mp3	Kanashimi wo Yasashisani ni	OP3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252593/covers/Naruto_OP3_Kanashimi_wo_Yasashisani_ni.jpg	1
664	586	627	238		/audio/Naruto Shippuden ED23 「MOTHER」.mp3	MOTHER	ED23	https://res.cloudinary.com/ddc6silap/image/upload/v1773252605/covers/Naruto_Shippuden_ED23_MOTHER.jpg	1
666	666	627	232		/audio/Naruto Shippuden ED25 「I Can Hear」.mp3	I Can Hear	ED25	https://res.cloudinary.com/ddc6silap/image/upload/v1773252615/covers/Naruto_Shippuden_ED25_I_Can_Hear.jpg	1
669	669	627	257		/audio/Naruto Shippuden ED28 「Niji」.mp3	Niji	ED28	https://res.cloudinary.com/ddc6silap/image/upload/v1773252603/covers/Naruto_Shippuden_ED28_Niji.jpg	1
670	666	627	240		/audio/Naruto Shippuden ED29 「FLAME」.mp3	FLAME	ED29	https://res.cloudinary.com/ddc6silap/image/upload/v1773252608/covers/Naruto_Shippuden_ED29_FLAME.jpg	1
671	671	627	247		/audio/Naruto Shippuden ED30 「Never Change」.mp3	Never Change	ED30	https://res.cloudinary.com/ddc6silap/image/upload/v1773252619/covers/Naruto_Shippuden_ED30_Never_Change.jpg	1
673	673	627	233		/audio/Naruto Shippuden ED32 「Spinning World」.mp3	Spinning World	ED32	https://res.cloudinary.com/ddc6silap/image/upload/v1773252633/covers/Naruto_Shippuden_ED32_Spinning_World.jpg	1
674	674	627	251		/audio/Naruto Shippuden ED33 「Kotoba no Iranai Yakusok.mp3	Kotoba no Iranai Yakusoku	ED33	https://res.cloudinary.com/ddc6silap/image/upload/v1773252626/covers/Naruto_Shippuden_ED33_Kotoba_no_Iranai_Yakusoku.jpg	1
677	677	627	288		/audio/Naruto Shippuden ED36 「Sonna Kimi, Konna Boku」.mp3	Sonna Kimi, Konna Boku	ED36	https://res.cloudinary.com/ddc6silap/image/upload/v1773252618/covers/Naruto_Shippuden_ED36_Sonna_Kimi_Konna_Boku.jpg	1
678	678	627	221		/audio/Naruto Shippuden ED37 「Ao no Lulluby」.mp3	Ao no Lulluby	ED37	https://res.cloudinary.com/ddc6silap/image/upload/v1773252642/covers/Naruto_Shippuden_ED37_Ao_no_Lulluby.jpg	1
680	680	627	208		/audio/Naruto Shippuden ED39 「Tabidachi no Uta」.mp3	Tabidachi no Uta	ED39	https://res.cloudinary.com/ddc6silap/image/upload/v1773252652/covers/Naruto_Shippuden_ED39_Tabidachi_no_Uta.jpg	1
681	681	627	243		/audio/Naruto Shippuden ED4 「Mezamero! Yasei」.mp3	Mezamero! Yasei	ED4	https://res.cloudinary.com/ddc6silap/image/upload/v1773252623/covers/Naruto_Shippuden_ED4_Mezamero_Yasei.jpg	1
684	306	627	311		/audio/Naruto Shippuden ED6 「Broken Youth」.mp3	Broken Youth	ED6	https://res.cloudinary.com/ddc6silap/image/upload/v1773252649/covers/Naruto_Shippuden_ED6_Broken_Youth.jpg	1
685	685	627	247		/audio/Naruto Shippuden ED7 「Long Kiss Good Bye」.mp3	Long Kiss Good Bye	ED7	https://res.cloudinary.com/ddc6silap/image/upload/v1773252640/covers/Naruto_Shippuden_ED7_Long_Kiss_Good_Bye.jpg	1
686	686	627	214		/audio/Naruto Shippuden ED8 「BACCHIKOI!!!」.mp3	BACCHIKOI!!!	ED8	https://res.cloudinary.com/ddc6silap/image/upload/v1773252646/covers/Naruto_Shippuden_ED8_BACCHIKOI.jpg	1
688	688	627	212		/audio/Naruto Shippuden OP10 「newsong」.mp3	newsong	OP10	https://res.cloudinary.com/ddc6silap/image/upload/v1773252613/covers/Naruto_Shippuden_OP10_newsong.jpg	1
690	690	627	239		/audio/Naruto Shippuden OP12 「Moshimo」.mp3	Moshimo	OP12	https://res.cloudinary.com/ddc6silap/image/upload/v1773252629/covers/Naruto_Shippuden_OP12_Moshimo.jpg	1
693	693	627	239		/audio/Naruto Shippuden OP15 「Guren」.mp3	Guren	OP15	https://res.cloudinary.com/ddc6silap/image/upload/v1773252610/covers/Naruto_Shippuden_OP15_Guren.jpg	1
695	695	627	249		/audio/Naruto Shippuden OP17 「Kaze」.mp3	Kaze	OP17	https://res.cloudinary.com/ddc6silap/image/upload/v1773252634/covers/Naruto_Shippuden_OP17_Kaze.jpg	1
697	226	627	231		/audio/Naruto Shippuden OP19 「Blood Circulator」.mp3	Blood Circulator	OP19	https://res.cloudinary.com/ddc6silap/image/upload/v1773252650/covers/Naruto_Shippuden_OP19_Blood_Circulator.jpg	1
701	700	627	250		/audio/Naruto Shippuden OP5 「Hotaru no Hikari」.mp3	Hotaru no Hikari	OP5	https://res.cloudinary.com/ddc6silap/image/upload/v1773252658/covers/Naruto_Shippuden_OP5_Hotaru_no_Hikari.jpg	1
712	712	708	91		/audio/Nichijou ED13 「Let_s search for Tomorrow」.mp3	Let's search for Tomorrow	ED13	https://res.cloudinary.com/ddc6silap/image/upload/v1773252654/covers/Nichijou_ED13_Let_s_search_for_Tomorrow.jpg	1
730	112	723	272		/audio/Nisekoi OP 「CLICK」.mp3	CLICK	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252655/covers/Nisekoi_OP_CLICK.jpg	1
484	484	484	233		/audio/Koi to Uso ED 「Can_t you say」.mp3	Can't you say	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252600/covers/Koi_to_Uso_ED_Can_t_you_say.jpg	1
509	509	508	287		/audio/Le Portrait de petit Cosette OP 「Main Theme」.mp3	Main Theme	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252598/covers/Le_Portrait_de_petit_Cosette_OP_Main_Theme.jpg	1
529	528	528	247		/audio/Looking Up at the Half-Moon OP 「Aoi Koufuku」.mp3	Aoi Koufuku	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252664/covers/Looking_Up_at_the_Half-Moon_OP_Aoi_Koufuku.jpg	1
545	545	543	222		/audio/Maid Sama OP 「My Secret」.mp3	My Secret	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252669/covers/Maid_Sama_OP_My_Secret.jpg	1
586	586	427	235		/audio/Inu x Boku SS OP 「Nirvana」.mp3	Nirvana	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252719/covers/Inu_x_Boku_SS_OP_Nirvana.jpg	1
704	306	627	251		/audio/Naruto Shippuden OP8 「Diver」.mp3	Diver	OP8	https://res.cloudinary.com/ddc6silap/image/upload/v1773252688/covers/Naruto_Shippuden_OP8_Diver.jpg	1
710	710	708	100		/audio/Nichijou ED11 「Sora ga Konna ni Aoi to wa」.mp3	Sora ga Konna ni Aoi to wa	ED11	https://res.cloudinary.com/ddc6silap/image/upload/v1773252691/covers/Nichijou_ED11_Sora_ga_Konna_ni_Aoi_to_wa.jpg	1
711	708	708	90		/audio/Nichijou ED12 「Yuuki Hitotsu wo Tomo ni Shite」.mp3	Yuuki Hitotsu wo Tomo ni Shite	ED12	https://res.cloudinary.com/ddc6silap/image/upload/v1773252694/covers/Nichijou_ED12_Yuuki_Hitotsu_wo_Tomo_ni_Shite.jpg	1
713	713	708	90		/audio/Nichijou ED14 「Tabidachi no hi ni」.mp3	Tabidachi no hi ni	ED14	https://res.cloudinary.com/ddc6silap/image/upload/v1773252707/covers/Nichijou_ED14_Tabidachi_no_hi_ni.jpg	1
714	708	708	92		/audio/Nichijou ED2 「Tsubasa wo Kudasai」.mp3	Tsubasa wo Kudasai	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252674/covers/Nichijou_ED2_Tsubasa_wo_Kudasai.jpg	1
715	715	708	90		/audio/Nichijou ED3 「Kikyuu ni Notte Dokomademo」.mp3	Kikyuu ni Notte Dokomademo	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252686/covers/Nichijou_ED3_Kikyuu_ni_Notte_Dokomademo.jpg	1
716	708	708	90		/audio/Nichijou ED4 「 My Ballad」.mp3	 My Ballad	ED4	https://res.cloudinary.com/ddc6silap/image/upload/v1773252679/covers/Nichijou_ED4_My_Ballad.jpg	1
718	718	708	90		/audio/Nichijou ED7 「Yasei no Uma」.mp3	Yasei no Uma	ED7	https://res.cloudinary.com/ddc6silap/image/upload/v1773252699/covers/Nichijou_ED7_Yasei_no_Uma.jpg	1
720	720	708	90		/audio/Nichijou ED9 「 Sudachi no Uta」.mp3	 Sudachi no Uta	ED9	https://res.cloudinary.com/ddc6silap/image/upload/v1773252671/covers/Nichijou_ED9_Sudachi_no_Uta.jpg	1
726	726	723	256		/audio/Nisekoi ED4 「Order x Order」.mp3	Order x Order	ED4	https://res.cloudinary.com/ddc6silap/image/upload/v1773252683/covers/Nisekoi_ED4_Order_x_Order.jpg	1
728	728	723	110		/audio/Nisekoi ED6 「Souzou Diary」.mp3	Souzou Diary	ED6	https://res.cloudinary.com/ddc6silap/image/upload/v1773252680/covers/Nisekoi_ED6_Souzou_Diary.jpg	1
732	732	723	235		/audio/Nisekoi S2 ED 「Aimai Hertz」.mp3	Aimai Hertz	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252696/covers/Nisekoi_S2_ED_Aimai_Hertz.jpg	2
734	727	723	90		/audio/Nisekoi S2 ED4 「Matado-rabu」.mp3	Matado-rabu	ED4	https://res.cloudinary.com/ddc6silap/image/upload/v1773252703/covers/Nisekoi_S2_ED4_Matado-rabu.jpg	2
738	28	723	273		/audio/Nisekoi S2 OP 「Rally Go Round」.mp3	Rally Go Round	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252677/covers/Nisekoi_S2_OP_Rally_Go_Round.jpg	2
742	234	740	292		/audio/No Game No Life_ Zero ED Theme 「THERE IS A REAS.mp3	THERE IS A REASON	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773252735/covers/No_Game_No_Life_Zero_ED_Theme_THERE_IS_A_REASON.jpg	1
745	745	743	253		/audio/Nodame Cantabile OP 「Allegro Cantabile」.mp3	Allegro Cantabile	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252739/covers/Nodame_Cantabile_OP_Allegro_Cantabile.jpg	1
748	748	746	291		/audio/Non Non Biyori Nonstop ED 「Tadaima」.mp3	Tadaima	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252730/covers/Non_Non_Biyori_Nonstop_ED_Tadaima.jpg	1
749	130	746	271		/audio/Non Non Biyori Nonstop OP 「Tsugihagi Moyou 」.mp3	Tsugihagi Moyou 	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252732/covers/Non_Non_Biyori_Nonstop_OP_Tsugihagi_Moyou.jpg	1
751	746	746	331		/audio/Non Non Biyori Repeat ED 「Okaeri」.mp3	Okaeri	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252741/covers/Non_Non_Biyori_Repeat_ED_Okaeri.jpg	1
755	639	753	295		/audio/Noragami ED 「Heart Realize」.mp3	Heart Realize	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252717/covers/Noragami_ED_Heart_Realize.jpg	1
763	763	763	262		/audio/Omamori Himari ED 「Beam My Beam」.mp3	Beam My Beam	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252711/covers/Omamori_Himari_ED_Beam_My_Beam.jpg	1
767	766	766	303		/audio/One Punch Man ED2 「Kanashimitachi wo Dakishimet.mp3	Kanashimitachi wo Dakishimete	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252728/covers/One_Punch_Man_ED2_Kanashimitachi_wo_Dakishimete.jpg	1
775	775	775	273		/audio/Ore Monogatari ED 「Shiawase no Arika」.mp3	Shiawase no Arika	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252714/covers/Ore_Monogatari_ED_Shiawase_no_Arika.jpg	1
555	555	546	242		/audio/Maison Ikkoku OP5 「Hidamari」.mp3	Hidamari	OP5	https://res.cloudinary.com/ddc6silap/image/upload/v1773252725/covers/Maison_Ikkoku_OP5_Hidamari.jpg	1
559	559	557	290		/audio/March comes in like a Lion ED3 「orion」.mp3	orion	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252720/covers/March_comes_in_like_a_Lion_ED3_orion.jpg	1
572	572	572	354		/audio/Mirai ED 「Uta no Kisha」.mp3	Uta no Kisha	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252721/covers/Mirai_ED_Uta_no_Kisha.jpg	1
611	39	610	90		/audio/My Dressup Darling OP 「San San Days」.mp3	San San Days	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252773/covers/My_Dressup_Darling_OP_San_San_Days.jpg	1
753	639	753	265		/audio/Noragami Aragoto ED「Nirvana」.mp3	Nirvana	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252745/covers/Noragami_Aragoto_ED_Nirvana.jpg	1
758	758	757	201		/audio/Now and Then, Here and There OP 「Ima, Soko Ni I.mp3	Ima, Soko Ni Iru Boku	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252753/covers/Now_and_Then_Here_and_There_OP_Ima_Soko_Ni_Iru_Boku.jpg	1
764	764	763	236		/audio/Omamori Himari ED2 「Sakamichi no Hate」.mp3	Sakamichi no Hate	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252752/covers/Omamori_Himari_ED2_Sakamichi_no_Hate.jpg	1
765	765	763	279		/audio/Omamori Himari OP 「Oshichau zo!!」.mp3	Oshichau zo!!	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252754/covers/Omamori_Himari_OP_Oshichau_zo.jpg	1
766	766	766	240		/audio/One Punch Man ED 「Hoshi yori Saki ni Mitsukete .mp3	Hoshi yori Saki ni Mitsukete Ageru	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252756/covers/One_Punch_Man_ED_Hoshi_yori_Saki_ni_Mitsukete_Ageru.jpg	1
777	777	777	228		/audio/Oregairu Band OST 「Bitter Bitter Sweet」.mp3	Bitter Bitter Sweet	OST	https://res.cloudinary.com/ddc6silap/image/upload/v1773252760/covers/Oregairu_Band_OST_Bitter_Bitter_Sweet.jpg	1
778	778	777	279		/audio/Oregairu ED 「Hello Alone」.mp3	Hello Alone	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252767/covers/Oregairu_ED_Hello_Alone.jpg	1
781	79	623	299		/audio/Nagi no Asukara ED2 「Mitsuba no Musubime」.mp3	Mitsuba no Musubime	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252790/covers/Nagi_no_Asukara_ED2_Mitsuba_no_Musubime.jpg	1
784	644	627	274		/audio/Naruto Shippuden ED3 「KIMI MONOGATARI」.mp3	KIMI MONOGATARI	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252763/covers/Naruto_Shippuden_ED3_KIMI_MONOGATARI.jpg	1
786	786	627	213		/audio/Naruto Shippuden OP4 「CLOSER」.mp3	CLOSER	OP4	https://res.cloudinary.com/ddc6silap/image/upload/v1773252784/covers/Naruto_Shippuden_OP4_CLOSER.jpg	1
788	725	723	215		/audio/Nisekoi S2 ED2 「TrIGgER」.mp3	TrIGgER	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252758/covers/Nisekoi_S2_ED2_TrIGgER.jpg	2
791	79	777	271		/audio/Oregairu S2 OP 「Harumodoki」.mp3	Harumodoki	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252804/covers/Oregairu_S2_OP_Harumodoki.jpg	2
792	792	777	208		/audio/Oregairu S3 ED 「Diamond no Jundo」.mp3	Diamond no Jundo	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252807/covers/Oregairu_S3_ED_Diamond_no_Jundo.jpg	3
794	794	794	90		/audio/Oreimo ED 「Imouto Please!」.mp3	Imouto Please!	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252788/covers/Oreimo_ED_Imouto_Please.jpg	1
798	794	794	90		/audio/Oreimo ED13 「READY」.mp3	READY	ED13	https://res.cloudinary.com/ddc6silap/image/upload/v1773252777/covers/Oreimo_ED13_READY.jpg	1
799	799	794	90		/audio/Oreimo ED14 「Inochi Mijikashi Koi se to Otome」.mp3	Inochi Mijikashi Koi se to Otome	ED14	https://res.cloudinary.com/ddc6silap/image/upload/v1773252793/covers/Oreimo_ED14_Inochi_Mijikashi_Koi_se_to_Otome.jpg	1
801	794	794	101		/audio/Oreimo ED16 「keep on runnin」.mp3	keep on runnin	ED16	https://res.cloudinary.com/ddc6silap/image/upload/v1773252801/covers/Oreimo_ED16_keep_on_runnin.jpg	1
802	794	794	90		/audio/Oreimo ED2 「Shine!」.mp3	Shine!	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252800/covers/Oreimo_ED2_Shine.jpg	1
803	794	794	88		/audio/Oreimo ED3 「Horaizumu」.mp3	Horaizumu	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252765/covers/Oreimo_ED3_Horaizumu.jpg	1
804	804	794	90		/audio/Oreimo ED4 「Shiroi Kokoro」.mp3	Shiroi Kokoro	ED4	https://res.cloudinary.com/ddc6silap/image/upload/v1773252780/covers/Oreimo_ED4_Shiroi_Kokoro.jpg	1
806	799	794	90		/audio/Oreimo ED7 「Masquerade!」.mp3	Masquerade!	ED7	https://res.cloudinary.com/ddc6silap/image/upload/v1773252781/covers/Oreimo_ED7_Masquerade.jpg	1
808	794	794	90		/audio/Oreimo ED9 「Suki nanda mon!!」.mp3	Suki nanda mon!!	ED9	https://res.cloudinary.com/ddc6silap/image/upload/v1773252805/covers/Oreimo_ED9_Suki_nanda_mon.jpg	1
812	804	794	90		/audio/Oreimo S2 ED11 「Omou Koto」.mp3	Omou Koto	ED11	https://res.cloudinary.com/ddc6silap/image/upload/v1773252797/covers/Oreimo_S2_ED11_Omou_Koto.jpg	2
813	813	794	91		/audio/Oreimo S2 ED12 「Honto no Kimochi」.mp3	Honto no Kimochi	ED12	https://res.cloudinary.com/ddc6silap/image/upload/v1773252808/covers/Oreimo_S2_ED12_Honto_no_Kimochi.jpg	2
815	794	794	91		/audio/Oreimo S2 ED14 「will」.mp3	will	ED14	https://res.cloudinary.com/ddc6silap/image/upload/v1773252795/covers/Oreimo_S2_ED14_will.jpg	2
876	876	871	244		/audio/Relife ED3 「Timing」.mp3	Timing	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252789/covers/Relife_ED3_Timing.jpg	1
612	612	612	320		/audio/My Little Monster ED 「White Wishes」.mp3	White Wishes	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252776/covers/My_Little_Monster_ED_White_Wishes.jpg	1
750	130	746	270		/audio/Non Non Biyori OP 「Nanairo Biyori」.mp3	Nanairo Biyori	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252748/covers/Non_Non_Biyori_OP_Nanairo_Biyori.jpg	1
672	672	627	238		/audio/Naruto Shippuden ED31 「Dame Dame da」.mp3	Dame Dame da	ED31	https://res.cloudinary.com/ddc6silap/image/upload/v1773252882/covers/Naruto_Shippuden_ED31_Dame_Dame_da.jpg	1
818	818	794	91		/audio/Oreimo S2 ED3 「Zutto...」.mp3	Zutto...	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252843/covers/Oreimo_S2_ED3_Zutto....jpg	2
819	794	794	92		/audio/Oreimo S2 ED5 「Keep」.mp3	Keep	ED5	https://res.cloudinary.com/ddc6silap/image/upload/v1773252837/covers/Oreimo_S2_ED5_Keep.jpg	2
822	799	794	90		/audio/Oreimo S2 ED8 「Setsuna no Destiny」.mp3	Setsuna no Destiny	ED8	https://res.cloudinary.com/ddc6silap/image/upload/v1773252815/covers/Oreimo_S2_ED8_Setsuna_no_Destiny.jpg	2
823	794	794	90		/audio/Oreimo S2 ED9 「answer」.mp3	answer	ED9	https://res.cloudinary.com/ddc6silap/image/upload/v1773252853/covers/Oreimo_S2_ED9_answer.jpg	2
824	112	794	294		/audio/Oreimo S2 OP 「reunion」.mp3	reunion	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252817/covers/Oreimo_S2_OP_reunion.jpg	2
826	826	826	280		/audio/Oreshura ED 「W_Wonder tale」.mp3	W:Wonder tale	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252836/covers/Oreshura_ED_WWonder_tale.jpg	1
827	827	826	94		/audio/Oreshura OP 「Girlish Lover」.mp3	Girlish Lover	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252824/covers/Oreshura_OP_Girlish_Lover.jpg	1
831	831	828	221		/audio/Overlord S2 OP 「Go Cry Go」.mp3	Go Cry Go	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252855/covers/Overlord_S2_OP_Go_Cry_Go.jpg	2
838	838	838	181		/audio/Patema Inverted ED Theme 「Patema Inverse」.mp3	Patema Inverse	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773252826/covers/Patema_Inverted_ED_Theme_Patema_Inverse.jpg	1
844	844	843	275		/audio/Plastic Memories ED2 「Asayake no Starmine」.mp3	Asayake no Starmine	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252820/covers/Plastic_Memories_ED2_Asayake_no_Starmine.jpg	1
845	845	843	258	[ti:Plastic Memories OP 「Ring of Fortune」]\n[ar:Eri Sasaki]\n[al:Plastic Memories]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:18.14]\n[00:00.10]Hikari wo atsumete Yozora no kanata e\n[00:27.66]Sayonara no omoide wo\n[00:33.82]Hitomi ni tataete Mitsumeru yume Tooku\n[00:40.07]Kowarete shimau Utakata no memorii\n[00:45.85]Samishisa no namida Sotto fukou\n[00:51.21]Nobashita te wa kanransha Yasashiku toraete\n[00:58.29]Mezame souna Kioku no kakera\n[01:04.33]Utsumuite Kiete hoshii to inoru kedo\n[01:09.61]Kimi ga mitsuketekureta kono koe wo\n[01:15.67]Ugokidashita tokei no hari\n[01:18.37]Sekai wa yagate irodzuite\n[01:22.61]Purasutikkuna kokoro ga kagayaki dasu yo\n[01:28.63]Wasurenaide Oboeteite\n[01:33.70]Itsuka mata meguriaeru hi made Zutto\n[01:48.61]Yuugure Tomoru hikari\n[01:54.56]Chiisana gondora nobotteyuku Sora e\n[02:00.60]Tonari ni suwaru Kimi no nukumori ni\n[02:06.49]Naze ka na Namida ga hoho wo tsutau\n[02:11.70]Meguri mawaru kanransha Shizuka ni yurarete\n[02:18.86]Mune no oku ga Harisake sou de\n[02:24.80]Mado no soto Nagareru kumo Miageteta\n[02:30.02]Zutto kono mama futari Yorisotte\n[02:36.24]Unmei no wa Kurikaeseba Omoi wa yagate tsunagaru yo\n[02:43.07]Kotae wo sagashi Mirai e negai tsudzukeru\n[02:49.10]Mayowanaide Shinjiteite\n[02:54.49]Omoide wa honmono ni naru kara\n[03:10.88]Koware sou na Kioku no subete\n[03:16.51]Utsumuite Kienu you ni to inoru kedo\n[03:21.74]Konya Yume no jikan wa owari tsugeru\n[03:27.93]Kowakunai yo Sekai wa mada yasashiku irodzuiteru kara\n[03:33.78]Kimi ga mitsuketekureta kono kotoba wo\n[03:40.01]Unmei no wa Kurikaeseba\n[03:42.82]Omoi wa yagate tsunagaru yo\n[03:47.04]Purasutikkuna kokoro ga mitasareteiku\n[03:53.10]Wasurenai yo Oboeteru yo\n[03:58.15]Itsuka mata meguriaeru hi made Zutto\n[04:08.47]	/audio/Plastic Memories OP 「Ring of Fortune」.mp3	Ring of Fortune	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252839/covers/Plastic_Memories_OP_Ring_of_Fortune.jpg	1
847	57	846	264		/audio/Police in a Pod OP 「Shiranakya」.mp3	Shiranakya	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252827/covers/Police_in_a_Pod_OP_Shiranakya.png	1
848	848	848	252		/audio/Princess Connect! Re_Dive ED 「Soredemo Tomo Ni .mp3	Soredemo Tomo Ni Aruite Iku	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252846/covers/Princess_Connect_ReDive_ED_Soredemo_Tomo_Ni_Aruite_Iku.jpg	1
849	848	848	281		/audio/Princess Connect! Re_Dive ED2 「Connecting Happy.mp3	Connecting Happy!!	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252850/covers/Princess_Connect_ReDive_ED2_Connecting_Happy.jpg	1
854	185	854	271		/audio/Problem Children Are Coming From Another World,(1).mp3	Black † White	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252841/covers/Problem_Children_Are_Coming_From_Another_World_Aren_t_They_OP_Black_White.jpg	1
858	857	856	250		/audio/Quintessential Quintuplets Movie OP 「Gotoubun no Kiseki」.mp3	Gotoubun no Kiseki	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252868/covers/Quintessential_Quintuplets_Movie_OP_Gotoubun_no_Kiseki.jpg	1
862	862	862	258		/audio/Real Girl ED 「HiDE the BLUE」.mp3	HiDE the BLUE	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252862/covers/Real_Girl_ED_HiDE_the_BLUE.jpg	1
863	863	862	97		/audio/Real Girl OP 「Daiji na Koto」.mp3	Daiji na Koto	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252859/covers/Real_Girl_OP_Daiji_na_Koto.jpg	1
864	232	862	334		/audio/Real Girl S2 ED 「Hagan」.mp3	Hagan	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252858/covers/Real_Girl_S2_ED_Hagan.jpg	2
866	866	866	326		/audio/Rec ED 「Devotion」.mp3	Devotion	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252870/covers/Rec_ED_Devotion.jpg	1
873	308	871	300		/audio/Relife ED11 「PIECES OF A DREAM 」.mp3	PIECES OF A DREAM 	ED11	https://res.cloudinary.com/ddc6silap/image/upload/v1773252879/covers/Relife_ED11_PIECES_OF_A_DREAM.jpg	1
877	877	871	227		/audio/Relife ED4 「HONEY」.mp3	HONEY	ED4	https://res.cloudinary.com/ddc6silap/image/upload/v1773252865/covers/Relife_ED4_HONEY.jpg	1
879	879	871	152		/audio/Relife ED6 「Sunny Day Sunday」.mp3	Sunny Day Sunday	ED6	https://res.cloudinary.com/ddc6silap/image/upload/v1773252873/covers/Relife_ED6_Sunny_Day_Sunday.jpg	1
884	884	871	210		/audio/Relife Special ED2 「CHE. R. RY」.mp3	CHE. R. RY	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252872/covers/Relife_Special_ED2_CHE._R._RY.jpg	1
1161	1161	1161	260	[00:00.00] \n[00:14.97]KOI NO SHIRUSHI kimi no me ni mitsuketa no ano hi\n[00:21.08]kidzuita toki mune no jishaku mawari dashita\n[00:26.95]Sagashite ita tokimeki ni yatto deaetta no\n[00:32.55]doko ni itemo mitsukedasu yo mou nidoto mayowanai\n[00:38.80]Kitto futari wa unmei da yo nan'oku mo no hito ga ite\n[00:44.46]deau no wa KOMPYUUTA demo muri\n[00:50.13]Heibon sugiru mainichi ni PIRIODO wo utta no\n[00:55.92]tameiki sotsugyou dekiru no yatto\n[01:02.67]Aozora ga mabushii kimi ga iru fuukei wa\n[01:09.11]shiawase no OORA afuredasu no tomaranai yo\n[01:14.87]Eki mae no funsui niji wo tsukutte iru yo\n[01:20.58]kimi wo matsu jikan sae mo kakegaenai PURESHASU na toki\n[01:29.39]KOI NO SHIRUSHI watashi ni mo mitsukete kureta ne\n[01:35.03]onaji kimochi onaji kakera wakeatteru\n[01:41.11]Haguresou na toki datte daijoubu dayo ne?\n[01:46.78]doko ni itemo mitsukedashite sou watashi koko ni iru\n[01:52.91]Te wo tsunaidara mirai no DOA sutto aita ki ga suru no\n[01:58.58]mou nanimo kowai mono nai kara\n[02:04.21]Atarashii yume fukurande mainichi ga Merry-Go-Round\n[02:10.21]aenai toki ni wa setsunai kedo\n[02:18.15]Ame no hi mo suki dayo kimi no kasa atatakai\n[02:24.65]itoshisa eien nakunaranai shinjiteru yo\n[02:30.48]Ameagari no sora ni niji wo miagete futari\n[02:36.24]itsumademo te wo tsunaide arukitai yo hikari no naka wo\n[02:56.65]Aozora ga mabushii kimi ga iru fuukei wa\n[03:02.48]shiawase no OORA afuredasu no tomaranai yo\n[03:08.28]Eki mae no funsui niji wo tsukutte iru yo\n[03:13.94]kimi wo matsu jikan sae mo kakegaenai PURESHASU na toki\n[03:20.45]Ame no hi mo suki da yo kimi no kasa atatakai\n[03:25.68]itoshisa eien nakunaranai shinjiteru yo\n[03:31.96]Ameagari no sora ni niji wo miagete futari\n[03:37.68]itsumademo te wo tsunaide arukitai yo hikari no naka wo\n[03:46.58] 	/audio/The World God Only Knows ED 「Koi no Shirushi」.mp3	Koi no Shirushi	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253938/covers/The_World_God_Only_Knows_ED_Koi_no_Shirushi.jpg	1
779	435	777	269		/audio/Oregairu OP 「Yukitoki」.mp3	Yukitoki	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252811/covers/Oregairu_OP_Yukitoki.jpg	1
793	435	777	281		/audio/Oregairu S3 OP 「Megumi no Ame」.mp3	Megumi no Ame	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252813/covers/Oregairu_S3_OP_Megumi_no_Ame.jpg	3
817	804	794	90		/audio/Oreimo S2 ED2 「Filter」.mp3	Filter	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252829/covers/Oreimo_S2_ED2_Filter.jpg	2
727	727	723	245		/audio/Nisekoi ED5 「Hanagonomi」.mp3	Hanagonomi	ED5	https://res.cloudinary.com/ddc6silap/image/upload/v1773252934/covers/Nisekoi_ED5_Hanagonomi.jpg	1
868	868	868	250		/audio/Record of Ragnarok ED 「Fukahi」.mp3	Fukahi	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252895/covers/Record_of_Ragnarok_ED_Fukahi.jpg	1
871	871	871	236		/audio/Relife ED 「Iijyuu Rider」.mp3	Iijyuu Rider	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252890/covers/Relife_ED_Iijyuu_Rider.jpg	1
872	872	871	294		/audio/Relife ED10 「Asu e no Tobira」.mp3	Asu e no Tobira	ED10	https://res.cloudinary.com/ddc6silap/image/upload/v1773252887/covers/Relife_ED10_Asu_e_no_Tobira.jpg	1
885	885	871	287		/audio/Relife Special ED3 「LA•LA•LA LOVE SONG」.mp3	LA•LA•LA LOVE SONG	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252891/covers/Relife_Special_ED3_LA_LA_LA_LOVE_SONG.jpg	1
888	464	888	252		/audio/Rent A Girlfriend ED 「Kokuhaku Bungee Jump」.mp3	Kokuhaku Bungee Jump	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252900/covers/Rent_A_Girlfriend_ED_Kokuhaku_Bungee_Jump.jpg	1
890	110	888	227		/audio/Rent A Girlfriend OP 「Centimeter」.mp3	Centimeter	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252886/covers/Rent_A_Girlfriend_OP_Centimeter.jpg	1
893	591	893	277		/audio/Rewrite ED3 「Sunbright」.mp3	Sunbright	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252906/covers/Rewrite_ED3_Sunbright.jpg	1
894	27	893	273		/audio/Rewrite ED4 「Word of Dawn」.mp3	Word of Dawn	ED4	https://res.cloudinary.com/ddc6silap/image/upload/v1773252916/covers/Rewrite_ED4_Word_of_Dawn.jpg	1
895	895	893	316		/audio/Rewrite ED6 「Yami no Kanata e 」.mp3	Yami no Kanata e 	ED6	https://res.cloudinary.com/ddc6silap/image/upload/v1773252950/covers/Rewrite_ED6_Yami_no_Kanata_e.jpg	1
899	182	899	280		/audio/Re_CREATORS ED 「NEWLOOK」.mp3	NEWLOOK	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252920/covers/ReCREATORS_ED_NEWLOOK.jpg	1
900	900	899	242		/audio/Re_CREATORS ED2 「world Étude」.mp3	world Étude	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252918/covers/nbvaliduox0a5oa93sie.jpg	1
901	156	899	238		/audio/Re_CREATORS ED3 「Rubikon」.mp3	Rubikon	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252943/covers/ReCREATORS_ED3_Rubikon.jpg	1
902	245	899	226		/audio/Re_CREATORS OP 「gravityWall」.mp3	gravityWall	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252947/covers/ReCREATORS_OP_gravityWall.jpg	1
903	245	899	254		/audio/Re_CREATORS OP2 「sh0ut」.mp3	sh0ut	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252921/covers/ReCREATORS_OP2_sh0ut.jpg	1
907	111	904	251		/audio/Re_Zero EP7 Insert Song 「STRAIGHT BET」.mp3	STRAIGHT BET	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773252931/covers/ReZero_EP7_Insert_Song_STRAIGHT_BET.jpg	1
908	908	904	360		/audio/Re_Zero Insert Song 「Wishing」.mp3	Wishing	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773252929/covers/ReZero_Insert_Song_Wishing.jpg	1
912	905	904	211		/audio/Re_Zero OST EP8 「Bouya no Yume yo」.mp3	Bouya no Yume yo	EP8	https://res.cloudinary.com/ddc6silap/image/upload/v1773252927/covers/ReZero_OST_EP8_Bouya_no_Yume_yo.jpg	1
913	58	904	307		/audio/Re_Zero S2 ED 「Memento」.mp3	Memento	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252948/covers/ReZero_S2_ED_Memento.jpg	2
914	58	904	279		/audio/Re_Zero S2 ED2 「Believe in you」.mp3	Believe in you	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252913/covers/ReZero_S2_ED2_Believe_in_you.jpg	2
915	905	904	298		/audio/Re_Zero S2 EP15 Insert Song 「Door」.mp3	Door	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773252915/covers/ReZero_S2_EP15_Insert_Song_Door.png	2
916	916	904	311		/audio/Re_Zero S2 EP23 Insert Song 「Anata no Shiranai .mp3	Anata no Shiranai Koto	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773252903/covers/ReZero_S2_EP23_Insert_Song_Anata_no_Shiranai_Koto.jpg	2
917	234	904	255		/audio/Re_Zero S2 OP 「Realize」.mp3	Realize	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252907/covers/ReZero_S2_OP_Realize.jpg	2
918	916	904	288		/audio/Re_Zero S2 OP2 「Long shot」.mp3	Long shot	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252912/covers/ReZero_S2_OP2_Long_shot.jpg	2
927	927	925	249		/audio/Robotic_Notes OP2 「Hoko No Messiah」.mp3	Hoko No Messiah	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252945/covers/Robotic_Notes_OP2_Hoko_No_Messiah.jpg	1
928	928	928	275		/audio/Rosario+Vampire ED 「Dancing in the velvet moon」.mp3	Dancing in the velvet moon	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252925/covers/Rosario_Vampire_ED_Dancing_in_the_velvet_moon.jpg	1
737	737	723	251		/audio/Nisekoi S2 ED7 「Crayon Cover」.mp3	Crayon Cover	ED7	https://res.cloudinary.com/ddc6silap/image/upload/v1773252939/covers/Nisekoi_S2_ED7_Crayon_Cover.jpg	2
856	856	856	290		/audio/Quintessential Quintuplets ED2 「Gobun no Ichi」.mp3	Gobun no Ichi	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252898/covers/Quintessential_Quintuplets_ED2_Gobun_no_Ichi.jpg	1
881	881	871	341		/audio/Relife ED8 「Yuki no Hana」.mp3	Yuki no Hana	ED8	https://res.cloudinary.com/ddc6silap/image/upload/v1773252894/covers/Relife_ED8_Yuki_no_Hana.jpg	1
773	773	773	316		/audio/Orange ED 「Mirai」.mp3	Mirai	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252992/covers/Orange_ED_Mirai.jpg	1
934	934	934	219		/audio/Saga of Tanya the Evil ED 「Los! Los! Los!」.mp3	Los! Los! Los!	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252995/covers/Saga_of_Tanya_the_Evil_ED_Los_Los_Los.jpg	1
935	935	934	268		/audio/Saga of Tanya the Evil ED2 「Sensen no Realism」.mp3	Sensen no Realism	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252960/covers/Saga_of_Tanya_the_Evil_ED2_Sensen_no_Realism.jpg	1
936	111	934	221		/audio/Saga of Tanya the Evil Movie ED 「Remembrance」.mp3	Remembrance	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252986/covers/Saga_of_Tanya_the_Evil_Movie_ED_Remembrance.jpg	1
938	130	938	231		/audio/Sankarea OP 「Esoragoto」.mp3	Esoragoto	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252980/covers/Sankarea_OP_Esoragoto.jpg	1
940	286	939	303		/audio/SAO 2 ED 「Startear」.mp3	Startear	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253008/covers/SAO_2_ED_Startear.jpg	1
943	359	939	267		/audio/SAO Alicization_ War of Underworld OP2 「ANIMA」.mp3	ANIMA	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253002/covers/SAO_Alicization_War_of_Underworld_OP2_ANIMA.jpg	1
945	945	939	227		/audio/SAO Movie and Alicization 「Longing」.mp3	Longing	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773252956/covers/SAO_Movie_and_Alicization_Longing.jpg	1
946	28	939	283		/audio/SAO Ordinal Scale ED Theme 「Catch the Moment」.mp3	Catch the Moment	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773252954/covers/SAO_Ordinal_Scale_ED_Theme_Catch_the_Moment.jpg	1
948	28	939	244		/audio/SAO Progressive_ Aria of a Starless Night ED 「Y.mp3	Yuke	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252971/covers/SAO_Progressive_Aria_of_a_Starless_Night_ED_Yuke.jpg	1
950	43	950	314		/audio/Say I Love You ED 「slow dance」.mp3	slow dance	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252977/covers/Say_I_Love_You_ED_slow_dance.jpg	1
952	952	950	328		/audio/Say I Love You OP 「Friendship」.mp3	Friendship	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252997/covers/Say_I_Love_You_OP_Friendship.jpg	1
956	956	956	227		/audio/School Rumble ED2 「School Rumble 4 Ever」.mp3	School Rumble 4 Ever	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252984/covers/School_Rumble_ED2_School_Rumble_4_Ever.jpg	1
957	957	956	223		/audio/School Rumble OP 「Scramble」.mp3	Scramble	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252965/covers/School_Rumble_OP_Scramble.jpg	1
958	958	956	180		/audio/School Rumble OP2 「Umi no Otoko wa yo」.mp3	Umi no Otoko wa yo	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252998/covers/School_Rumble_OP2_Umi_no_Otoko_wa_yo.jpg	1
960	960	956	255		/audio/School Rumble S2 ED3 「Futari wa Wasurechau (ENG.mp3	Futari wa Wasurechau (ENG)	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252968/covers/School_Rumble_S2_ED3_Futari_wa_Wasurechau_ENG.jpg	2
961	959	956	195		/audio/School Rumble S2 OP 「Sentimental Generation」.mp3	Sentimental Generation	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253003/covers/School_Rumble_S2_OP_Sentimental_Generation.jpg	2
963	963	962	223		/audio/Scum_s Wish OP 「Uso No Hibana」.mp3	Uso No Hibana	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253006/covers/Scum_s_Wish_OP_Uso_No_Hibana.jpg	1
966	966	966	265		/audio/Senryu Girl ED 「Ordinary Love」.mp3	Ordinary Love	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252976/covers/Senryu_Girl_ED_Ordinary_Love.jpg	1
971	81	968	316		/audio/Seraph of the End_ Battle in Nagoya OP 「Two sou.mp3	Two souls -toward the truth-	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253020/covers/Seraph_of_the_End_Battle_in_Nagoya_OP_Two_souls_-toward_the_truth-.jpg	1
979	979	979	291		/audio/Shiki ED 「Walk no Yakusoku」.mp3	Walk no Yakusoku	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253013/covers/Shiki_ED_Walk_no_Yakusoku.jpg	1
988	988	985	90		/audio/Shirobako OP 「I_m Sorry EXODUS」.mp3	I'm Sorry EXODUS	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253018/covers/Shirobako_OP_I_m_Sorry_EXODUS.jpg	1
990	990	985	233		/audio/Shirobako OP3 「TREASURE BOX」.mp3	TREASURE BOX	OP3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253011/covers/Shirobako_OP3_TREASURE_BOX.jpg	1
1000	1000	1000	281		/audio/Somali and the Forest Spirit ED 「Kokoro Somali」.mp3	Kokoro Somali	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253015/covers/Somali_and_the_Forest_Spirit_ED_Kokoro_Somali.jpg	1
930	928	928	267		/audio/Rosario+Vampire S2 ED 「Trinity Cross」.mp3	Trinity Cross	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252951/covers/Rosario_Vampire_S2_ED_Trinity_Cross.jpg	2
932	932	932	276		/audio/Sabikui Bisco ED 「Houkou」.mp3	Houkou	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252975/covers/Sabikui_Bisco_ED_Houkou.jpg	1
933	933	932	219		/audio/Sabikui Bisco OP 「Kaze no Oto Sae Kikoenai」.mp3	Kaze no Oto Sae Kikoenai	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252963/covers/Sabikui_Bisco_OP_Kaze_no_Oto_Sae_Kikoenai.jpg	1
968	245	968	308		/audio/Seraph of the End ED 「scaPEGoat」.mp3	scaPEGoat	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253049/covers/Seraph_of_the_End_ED_scaPEGoat.jpg	1
989	14	985	239		/audio/Shirobako OP2 「COLORFUL BOX」.mp3	COLORFUL BOX	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253052/covers/Shirobako_OP2_COLORFUL_BOX.jpg	1
992	307	992	240		/audio/Silver Spoon ED 「Hello Especially」.mp3	Hello Especially	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253036/covers/Silver_Spoon_ED_Hello_Especially.jpg	1
993	993	992	216		/audio/Silver Spoon S2 ED 「Oto No Naru Houe」.mp3	Oto No Naru Houe	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253055/covers/Silver_Spoon_S2_ED_Oto_No_Naru_Houe.jpg	2
996	256	995	230		/audio/Sing Yesterday for Me ED2 「Aoibashi」.mp3	Aoibashi	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253023/covers/Sing_Yesterday_for_Me_ED2_Aoibashi.jpg	1
1002	1002	1002	290		/audio/Spice and Wolf ED 「Ringo Biyori」.mp3	Ringo Biyori	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253027/covers/Spice_and_Wolf_ED_Ringo_Biyori.jpg	1
1006	1006	1006	222		/audio/Spirited Away ED Theme 「Itsumo Nando demo」.mp3	Itsumo Nando demo	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253122/covers/Spirited_Away_ED_Theme_Itsumo_Nando_demo.jpg	1
1014	1014	837	222	[ti:Parasyte OP 「Let Me Hear」]\n[ar:Fear, and Loathing in Las Vegas]\n[al:Parasyte]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:41.73]\n[00:00.10]You guys do not notice that we are gifted just by being humans\n[00:06.28]We are absolute predators\n[00:09.79]We do not even have any enemies\n[00:13.93]Maybe there are other animals watching us\n[00:17.31]And thinking that someday “we will beat them down”\n[00:32.38]Oh We have the brains to think hard\n[00:34.54]Wear our favorite clothes\n[00:37.26]We are at no doubt human beings\n[00:41.27]Many small lives\n[00:42.75]They were born\n[00:43.91][They were born]\n[00:44.03]With the fate\n[00:45.33]Of dying for someone\n[00:49.04]A human baby\n[00:50.98]When will they find out\n[00:53.29]That at the point they were born, we are\n[00:58.42](the) winners of Earth\n[01:01.12]Aa hitori naiteita tonari no kimi ga toikakeru\n[01:12.03]Dakara bokura yorisoi ikiru kirameku made\n[01:19.57]For what have I been living for？\n[01:21.16]When will I find out the answer？\n[01:22.51]An answer that is only for you\n[01:23.56]What will myself and (the) first scenery I saw Look like？\n[01:32.02]It’s my face, my face\n[01:39.67]Shut up! I read this inside the book I read before\n[01:45.20]According (to) Maslow\n[01:47.70]There are five steps (in a) human’s desire\n[01:50.96]To live a long long life to stay safe and to receive\n[01:54.63]Love from others\n[01:56.27]To get respect from\n[01:58.28]Others, To get closer\n[01:59.97]To your ideal\n[02:01.95]That’s what it said\n[02:03.97]No matter how hard other animals try,\n[02:07.54]They probably can’t go over the first step\n[02:10.87]That is how intelligent we are and, (an animal) filled with greed\n[02:23.78]But that is probably why we can still live\n[02:26.31]On the top of the food chain\n[02:28.16]In this blue planet although we have weak bodies\n[02:33.97]Aa mata kimi no me ni itsumo no asa ga utsurikomu\n[02:45.09]Nagareru namida ga kiete yuku\n[02:51.44]For what to live for\n[02:55.13]Think deeply as you live yeah\n[02:58.08]Cuz you humans are (the) only ones that can do this on Earth\n[03:02.93]Atarashii kotae wo\n[03:07.60]What is it that you want to get in your right hands?\n[03:13.69]Let me hear\n[03:16.08]Tell me your new answer\n[03:17.24]Prove that you are different from monkies\n[03:18.85]If there is nothing to crave for, humans will die in a way\n[03:20.51]Don’t you think so too？\n[03:23.50]Let me hear, Let me hear, Let me hear\n[03:31.44]	/audio/Parasyte OP 「Let Me Hear」.mp3	Let Me Hear	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253105/covers/Parasyte_OP_Let_Me_Hear.jpg	1
1016	206	1016	92		/audio/Record of Ragnarok OP 「Kamigami」.mp3	Kamigami	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253076/covers/Record_of_Ragnarok_OP_Kamigami.jpg	1
1017	636	871	254		/audio/Relife Special ED 「Hana」.mp3	Hana	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253093/covers/Relife_Special_ED_Hana.jpg	1
1020	1020	938	315		/audio/Sankarea ED 「Above your hand」.mp3	Above your hand	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253102/covers/Sankarea_ED_Above_your_hand.jpg	1
1022	1022	976	310		/audio/Shichisei no Subaru ED 「Starlight」.mp3	Starlight	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253110/covers/Shichisei_no_Subaru_ED_Starlight.jpg	1
1025	1025	1009	306		/audio/Steins Gate ED 「Toki Tsukasadoru Juuni no Meiya.mp3	Toki Tsukasadoru Juuni no Meiyaku	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253063/covers/Steins_Gate_ED_Toki_Tsukasadoru_Juuni_no_Meiyaku.jpg	1
1029	1024	1009	309		/audio/Steins Gate_ Movie OP 「Anata no Eranda Kono Tok.mp3	Anata no Eranda Kono Toki Wo	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253125/covers/Steins_Gate_Movie_OP_Anata_no_Eranda_Kono_Toki_Wo.jpg	1
1031	1024	1009	272		/audio/Steins_Gate ED4 「Another Heaven」.mp3	Another Heaven	ED4	https://res.cloudinary.com/ddc6silap/image/upload/v1773253116/covers/Steins_Gate_ED4_Another_Heaven.jpg	1
1032	572	1032	305		/audio/Summer Wars ED Theme 「Bokura no Natsu no Yume」.mp3	Bokura no Natsu no Yume	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253098/covers/Summer_Wars_ED_Theme_Bokura_no_Natsu_no_Yume.jpg	1
1033	562	1033	330		/audio/Sweetness and Lightning ED 「Maybe」.mp3	Maybe	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253081/covers/Sweetness_and_Lightning_ED_Maybe.jpg	1
1034	1034	1033	219		/audio/Sweetness and Lightning OP 「Harebare Fanfare」.mp3	Harebare Fanfare	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253120/covers/Sweetness_and_Lightning_OP_Harebare_Fanfare.jpg	1
1035	28	939	288		/audio/Sword art Online 2 ED3 「Shirushi」.mp3	Shirushi	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253090/covers/Sword_art_Online_2_ED3_Shirushi.jpg	1
1036	95	939	245		/audio/Sword Art Online 2 OP 「Ignite」.mp3	Ignite	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253084/covers/Sword_Art_Online_2_OP_Ignite.jpg	1
1037	941	939	290		/audio/Sword Art Online ED 「Yume Sekai」.mp3	Yume Sekai	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253114/covers/Sword_Art_Online_ED_Yume_Sekai.jpg	1
1040	95	939	288		/audio/Sword Art Online OP2 「Innocence」.mp3	Innocence	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253070/covers/Sword_Art_Online_OP2_Innocence.jpg	1
1073	1061	1061	364		/audio/Teasing Master Takagi San S2 ED5 「STARS」.mp3	STARS	ED5	https://res.cloudinary.com/ddc6silap/image/upload/v1773253133/covers/Teasing_Master_Takagi_San_S2_ED5_STARS.jpg	2
1075	1061	1061	184		/audio/Teasing Master Takagi San S2 ED7 「Yasashii Kimo.mp3	Yasashii Kimochi	ED7	https://res.cloudinary.com/ddc6silap/image/upload/v1773253131/covers/Teasing_Master_Takagi_San_S2_ED7_Yasashii_Kimochi.jpg	2
972	972	972	272		/audio/Serial Experiments Lain ED 「Tooi Sakebi」.mp3	Tooi Sakebi	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253060/covers/Serial_Experiments_Lain_ED_Tooi_Sakebi.jpg	1
976	433	976	255		/audio/Shichisei no Subaru OP 「360° Hoshi no Orchestra.mp3	360° Hoshi no Orchestra	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253039/covers/fko563i2wwdsuuttdnyx.jpg	1
977	977	977	297		/audio/Shigofumi ED 「Chain」.mp3	Chain	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253044/covers/Shigofumi_ED_Chain.jpg	1
1043	941	939	336		/audio/Sword Art Online S2 OP3 「Separate Ways」.mp3	Separate Ways	OP3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253149/covers/Sword_Art_Online_S2_OP3_Separate_Ways.jpg	2
1046	941	939	290		/audio/Sword Art Online_ Alicization - War of Underwor.mp3	Resolution	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253158/covers/Sword_Art_Online_Alicization_-_War_of_Underworld_OP_Resolution.jpg	1
1047	28	939	223		/audio/Sword Art Online_ Alicization OP 「ADAMAS」.mp3	ADAMAS	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253171/covers/Sword_Art_Online_Alicization_OP_ADAMAS.jpg	1
1050	1050	1050	269		/audio/Taisho Otome Fairy Tale ED 「Makogoro ni Kanade」.mp3	Makogoro ni Kanade	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253193/covers/Taisho_Otome_Fairy_Tale_ED_Makogoro_ni_Kanade.jpg	1
1055	1054	1054	209		/audio/Tamako Love Story ED2 「Koi no Uta」.mp3	Koi no Uta	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253175/covers/Tamako_Love_Story_ED2_Koi_no_Uta.jpg	1
1057	1054	1054	233		/audio/Tamako Market ED 「Neguse」.mp3	Neguse	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253197/covers/Tamako_Market_ED_Neguse.jpg	1
1060	1060	1059	223		/audio/Tanaka kun is always Listless OP 「Utatane Sunsh.mp3	Utatane Sunshine	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253179/covers/Tanaka_kun_is_always_Listless_OP_Utatane_Sunshine.jpg	1
1061	1061	1061	240		/audio/Teasing Master Takagi San ED 「Kimagure Romantic.mp3	Kimagure Romantic	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253187/covers/Teasing_Master_Takagi_San_ED_Kimagure_Romantic.jpg	1
1063	1061	1061	246		/audio/Teasing Master Takagi San ED3 「Jitensha」.mp3	Jitensha	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253183/covers/Teasing_Master_Takagi_San_ED3_Jitensha.jpg	1
1067	1061	1067	279		/audio/Teasing Master Takagi San ED7 「Deatta Koro no Y.mp3	Deatta Koro no You ni	ED7	https://res.cloudinary.com/ddc6silap/image/upload/v1773253151/covers/Teasing_Master_Takagi_San_ED7_Deatta_Koro_no_You_ni.jpg	1
1069	1061	1061	325		/audio/Teasing Master Takagi San S2 ED 「Kanade」.mp3	Kanade	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253139/covers/Teasing_Master_Takagi_San_S2_ED_Kanade.jpg	2
1074	1061	1061	197		/audio/Teasing Master Takagi San S2 ED6 「Anata Ni」.mp3	Anata Ni	ED6	https://res.cloudinary.com/ddc6silap/image/upload/v1773253144/covers/Teasing_Master_Takagi_San_S2_ED6_Anata_Ni.jpg	2
1086	31	1085	307		/audio/Terror in Resonance OP 「Trigger」.mp3	Trigger	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253200/covers/Terror_in_Resonance_OP_Trigger.jpg	1
1087	1087	1087	287		/audio/Texhnolyze ED 「Tsuki no Uta」.mp3	Tsuki no Uta	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253215/covers/Texhnolyze_ED_Tsuki_no_Uta.jpg	1
1088	14	1087	284		/audio/Texhnolyze ED2 「Walking Through the Empty Age」.mp3	Walking Through the Empty Age	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253232/covers/Texhnolyze_ED2_Walking_Through_the_Empty_Age.jpg	1
1093	933	1092	264		/audio/The Ancient Magus Bride OP 「Here」.mp3	Here	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253228/covers/The_Ancient_Magus_Bride_OP_Here.jpg	1
1096	1096	1096	167		/audio/The Anthem of the Heart Insert Song 「Watashino .mp3	Watashino Koe	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253226/covers/The_Anthem_of_the_Heart_Insert_Song_Watashino_Koe.jpg	1
1100	1099	1098	335		/audio/The Day I Become God ED 「Goodbye Seven Seas」.mp3	Goodbye Seven Seas	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253209/covers/The_Day_I_Become_God_ED_Goodbye_Seven_Seas.jpg	1
1101	1099	1098	270		/audio/The Day I Become God ED3 「Natsunagi」.mp3	Natsunagi	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253204/covers/The_Day_I_Become_God_ED3_Natsunagi.jpg	1
1104	1104	1103	238		/audio/The Duke of Death and His Maid OP 「Mangetsu to .mp3	Mangetsu to Silhouette no Yoru	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253221/covers/The_Duke_of_Death_and_His_Maid_OP_Mangetsu_to_Silhouette_no_Yoru.jpg	1
1108	1107	1107	253		/audio/The Familiar of Zero S2 ED 「Suki!_ Kirai!_ Suki.mp3	Suki!? Kirai!? Suki!?	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253212/covers/The_Familiar_of_Zero_S2_ED_Suki_Kirai_Suki.jpg	2
1123	279	1116	280		/audio/The Garden of Sinners_ Remaining Sense of Pain .mp3	Kizuato	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773256651/covers/The_Garden_of_Sinners_Remaining_Sense_of_Pain_ED_Kizuato.jpg	1
830	111	828	293		/audio/Overlord S2 ED 「HYDRA」.mp3	HYDRA	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253160/covers/Overlord_S2_ED_HYDRA.jpg	2
836	836	836	288		/audio/Paprika ED 「Byakkoya」.mp3	Byakkoya	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253165/covers/Paprika_ED_Byakkoya.jpg	1
842	842	841	277		/audio/Perfect Blue OP 「Ai no Tenshi」.mp3	Ai no Tenshi	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253163/covers/Perfect_Blue_OP_Ai_no_Tenshi.jpg	1
1042	95	939	213		/audio/Sword Art Online Progressive Scherzo of Deep Night  ED Theme 「Shinzou」.mp3	Shinzou	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253192/covers/Sword_Art_Online_Progressive_Scherzo_of_Deep_Night_ED_Theme_Shinzou.jpg	1
493	493	488	262	[00:00.00] \n[00:15.97]Aozora miageta kyōmomata aeru ni\n[00:21.90]Kaze o kitte suberikonda densha\n[00:27.88]Shabon-iro no nioi hidamari no hodō ni\n[00:33.94]Kokoro o hayamete ku\n[00:40.29]Hōkago rōka ni hibiku shigunaru\n[00:46.07]Arifureta heya (sekai) ga\n[00:49.08]Kira meite yuku yo\n[00:54.69]Hashiridashita kimi e no kimochi wa\n[01:00.80]Mune no oku o ki ~yunto shimetsukeru\n[01:06.82]Tomerarenai dokidoki afureru\n[01:12.74]Kimi no koto nē mottooshiete\n[01:19.44]Todoki-sō? Todoke taiso tto-kun ni konekuto\n[01:29.09] \n[01:43.19]Yūgure kawa-zoi ashita ni tsudzuku nda ne\n[01:48.96]Kata narabete yasashī hodōkyō\n[01:54.85]Hachimitsu kagebōshi rintoshita sugao ni\n[02:00.91]Kokoro ga oto o tateta\n[02:07.05]Kotoba ni shinakute mi hibiku shigunaru\n[02:12.93]Mada shiranu michi (sekai) e\n[02:16.16]Tobira ga hiraku yo\n[02:21.66]Hashiridashita kimi e no kimochi wa\n[02:27.67]Niji o Torēsu (E ga) ite sora ni maiagaru\n[02:33.81]Mō kakusenai kimochi afureru\n[02:39.71]Watashi no hō nē kotchi kidzuite\n[02:46.10]Todoki-sō? Todoke taiso tto-kun ni konekuto\n[02:55.57] \n[03:19.07]Ima no yori chikadzuite keshiki ga kawattara\n[03:25.07]Atarashī mirai (ji bun) aeru ki ga shita\n[03:33.74]Hashiridashita kimi e no kimochi wa\n[03:39.72]Mune no oku o ki ~yunto shimetsukeru\n[03:45.75]Tomerarenai dokidoki afureru\n[03:51.81]Kimi no koto nē mottooshiete\n[03:58.08]Todoki-sō? Todoke taiso tto-kun to konekuto\n[04:07.92] \n	/audio/Kokoro Connect OP3 「Kimochi Signal」.mp3	Kimochi Signal	OP3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253672/covers/Kokoro_Connect_OP3_Kimochi_Signal.jpg	1
1076	447	1061	243		/audio/Teasing Master Takagi San S2 OP 「Zero Centimet.mp3	Zero Centimeter	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253262/covers/Teasing_Master_Takagi_San_S2_OP_Zero_Centimeter.jpg	2
1080	1061	1061	155		/audio/Teasing Master Takagi San S3 ED4 「Gakuen Tengok.mp3	Gakuen Tengoku	ED4	https://res.cloudinary.com/ddc6silap/image/upload/v1773253245/covers/Teasing_Master_Takagi_San_S3_ED4_Gakuen_Tengoku.jpg	3
1083	1061	1061	252		/audio/Teasing Master Takagi San S3 ED8 「Hana」.mp3	Hana	ED8	https://res.cloudinary.com/ddc6silap/image/upload/v1773253256/covers/Teasing_Master_Takagi_San_S3_ED8_Hana.jpg	3
1085	11	1085	294		/audio/Terror in Resonance ED 「Dare ka, Umi wo」.mp3	Dare ka, Umi wo	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253254/covers/Terror_in_Resonance_ED_Dare_ka_Umi_wo.jpg	1
1090	1090	1090	273		/audio/The Ambition of Oda Nobuna ED 「Hikari」.mp3	Hikari	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253253/covers/The_Ambition_of_Oda_Nobuna_ED_Hikari.jpg	1
1094	8	1092	247		/audio/The Ancient Magus Bride OP2 「You」.mp3	You	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253249/covers/The_Ancient_Magus_Bride_OP2_You.jpg	1
1099	1099	1098	286		/audio/The Day I Become a God OP 「Kimi to Iu Shinwa」.mp3	Kimi to Iu Shinwa	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253259/covers/The_Day_I_Become_a_God_OP_Kimi_to_Iu_Shinwa.jpg	1
1105	1105	1105	239		/audio/The Dungeon of Black Company ED 「World is Mine」.mp3	World is Mine	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253235/covers/The_Dungeon_of_Black_Company_ED_World_is_Mine.png	1
1113	1109	1107	250		/audio/The Familiar of Zero S4 OP 「I_ll Be There For Y.mp3	I'll Be There For You	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253288/covers/The_Familiar_of_Zero_S4_OP_I_ll_Be_There_For_You.jpg	4
1114	1114	1114	289		/audio/The Fruit of Grisaia ED 「Eden_s Song」.mp3	Eden's Song	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253289/covers/The_Fruit_of_Grisaia_ED_Eden_s_Song.jpg	1
1115	1018	1115	229		/audio/The Fruit of Grisaia OP 「The Fruit of Grisaia 」.mp3	The Fruit of Grisaia 	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253299/covers/The_Fruit_of_Grisaia_OP_The_Fruit_of_Grisaia.jpg	1
1116	279	1116	283		/audio/The Garden of Sinners_ Epilogue ED 「snow fallin.mp3	snow falling	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253277/covers/The_Garden_of_Sinners_Epilogue_ED_snow_falling.jpg	1
1118	279	1116	384		/audio/The Garden of Sinners_ Murder Speculation B ED .mp3	Seventh Heaven	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773256656/covers/The_Garden_of_Sinners_Murder_Speculation_B_ED_Seventh_Heaven.jpg	1
1121	279	1116	307		/audio/The Garden of Sinners_ Recalled out Summer ED 「.mp3	Alleluia	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253268/covers/The_Garden_of_Sinners_Recalled_out_Summer_ED_Alleluia.jpg	1
1122	1122	1116	173		/audio/The Garden of Sinners_ Recalled out Summer ~ext.mp3	dolce	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253273/covers/The_Garden_of_Sinners_Recalled_out_Summer_extra_chorus_ED_dolce.jpg	1
1125	222	1125	290		/audio/The Garden of Words 「Rain」.mp3	Rain	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253266/covers/The_Garden_of_Words_Rain.jpg	1
1126	1126	1126	270		/audio/The Girl from the Other Side ED 「Touch of Hope」.mp3	Touch of Hope	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253295/covers/The_Girl_from_the_Other_Side_ED_Touch_of_Hope.jpg	1
1128	1128	1128	231		/audio/The Idaten Deities Know Only Peace ED 「Raika」.mp3	Raika	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253293/covers/The_Idaten_Deities_Know_Only_Peace_ED_Raika.jpg	1
1130	581	1130	240		/audio/The Kawai Complex OP 「Itsuka no, Ikutsuka no Ki.mp3	Itsuka no, Ikutsuka no Kimi to no Sekai	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253303/covers/The_Kawai_Complex_OP_Itsuka_no_Ikutsuka_no_Kimi_to_no_Sekai.jpg	1
1131	1131	1130	244		/audio/The Kawaii Complex ED 「My Sweet Shelter」.mp3	My Sweet Shelter	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253279/covers/The_Kawaii_Complex_ED_My_Sweet_Shelter.jpg	1
1135	1132	361	234		/audio/The Melancholy of Haruhi Suzumiya S2 ED 「Tomare.mp3	Tomare!	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253283/covers/The_Melancholy_of_Haruhi_Suzumiya_S2_ED_Tomare.jpg	2
1148	1147	1147	173		/audio/The Promised Neverland ED2 「Lamp」.mp3	Lamp	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253312/covers/The_Promised_Neverland_ED2_Lamp.jpg	1
1154	1154	1154	213		/audio/The Secret World of Arrietty ED 「Arrietty_s Son.mp3	Arrietty's Song	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253315/covers/The_Secret_World_of_Arrietty_ED_Arrietty_s_Song.jpg	1
1156	1156	1156	234		/audio/The Vampire Dies in No Time ED 「Strangers」.mp3	Strangers	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253319/covers/The_Vampire_Dies_in_No_Time_ED_Strangers.jpg	1
497	497	495	211	[ti:Komi Can't Communicate ED 「Sympathy」]\n[ar:Kitri]\n[al:Komi Can't Communicate]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:30.79]\n[00:00.00]\n[00:07.98]Madogiwa de miru gogo no yume\n[00:11.04]Nazeka kyoushitsu ni wa futari kiri de\n[00:15.62]Kaoru kami fuseta matsuge mo\n[00:18.28]Naname yonjuugodo kara hitorijime\n[00:22.37]Ase ga nijimideru juugoji\n[00:25.59]Kore wa atsusa ka natsu no shiwaza ka te wo nobaseba todokisou na\n[00:33.06]Yaku ichi meetoru saki ga mada tooi\n[00:37.32]Kuuru na hito? yasashii hito?\n[00:39.42]Himitsu wa mamoru taipu?\n[00:41.11]Imeeji dake de kimetsukeru koto wa gohatto\n[00:45.03]Nakayoku naritai kainaka atama de kangaeru mae ni\n[00:49.30]Hanashikakete mimashou\n[00:53.63]Aa kanchigai datte ii no ii no\n[00:57.56]Honmono no shinpashii futari\n[01:01.07]Kyou wa tokubetsu na koto ga kitto kitto\n[01:04.97]Okorisou na yokan natsu no dorama\n[01:23.54]Chaimu de okita juurokuji\n[01:26.63]Kore wa ki no sei? kimi to me ga atte\n[01:31.00]Akai hoho shinayaka na yubi\n[01:33.85]Hakadoranai shukudai kimi no sei\n[01:38.48]Tatoeba ima oikaketara\n[01:39.81]Donna koto ga okiru no\n[01:41.93]Imeeji dake de wa owaraserarenai mondai\n[01:45.51]Kotae ni chikazuku kainaka\n[01:47.28]Atama de kangaeru mae ni\n[01:49.91]Mukaiatte mimashou\n[01:54.11]Aa kanchigai datte ii no ii no\n[01:57.99]Honmono no shinpashii futari\n[02:01.41]Kyou wa tokubetsu na koto ga kitto kitto\n[02:05.84]Okorisou na yokan natsu no dorama\n[02:25.02]Hikitomete miru houkago\n[02:28.43]Semishigure ni kakikesarete\n[02:32.14]Mizu no awa? soretomo?\n[02:38.30]Aa kanchigai datte ii no ii no\n[02:43.58]Honmono no shinpashii futari\n[02:46.66]Kyou wa tokubetsu na koto ga kitto kitto\n[02:51.03]Okorisou na yokan\n[02:53.40]Kakushin ni naru toki yo tomare\n[02:57.29]Natsu no dorama\n[02:59.98]	/audio/Komi Can_t Communicate ED 「Sympathy」.mp3	Sympathy	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254188/covers/Komi_Can_t_Communicate_ED_Sympathy.jpg	1
1150	1150	1150	255		/audio/The Royal Tutor ED 「Prince Night」.mp3	Prince Night	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253374/covers/The_Royal_Tutor_ED_Prince_Night.jpg	1
1151	1151	1150	224		/audio/The Royal Tutor OP 「Shoppai Namida」.mp3	Shoppai Namida	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253349/covers/The_Royal_Tutor_OP_Shoppai_Namida.jpg	1
1153	500	1152	171		/audio/The Ryuo_s Work is Never Done! OP 「Korekara」.mp3	Korekara	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253363/covers/The_Ryuo_s_Work_is_Never_Done_OP_Korekara.jpg	1
1155	1154	1154	243		/audio/The Secret World of Arrietty OP 「The Neglected .mp3	The Neglected Garden	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253355/covers/The_Secret_World_of_Arrietty_OP_The_Neglected_Garden.jpg	1
1157	1157	1156	260		/audio/The Vampire Dies in No Time OP 「Dies in No Time.mp3	Dies in No Time	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253327/covers/The_Vampire_Dies_in_No_Time_OP_Dies_in_No_Time.jpg	1
1158	1158	1158	187		/audio/The Way of the Househusband ED 「Kiwami Moto Kai.mp3	Kiwami Moto Kaido	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253366/covers/The_Way_of_the_Househusband_ED_Kiwami_Moto_Kaido.jpg	1
1160	1160	1160	219		/audio/The Wind Rises ED 「Hikouki Gumo」.mp3	Hikouki Gumo	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253321/covers/The_Wind_Rises_ED_Hikouki_Gumo.jpg	1
1162	1162	1161	214		/audio/The World God Only Knows ED2 「Tatte Ichido no K.mp3	Tatte Ichido no Kiseki	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253335/covers/The_World_God_Only_Knows_ED2_Tatte_Ichido_no_Kiseki.jpg	1
1163	1163	1161	221		/audio/The World God Only Knows ED3 「Happy Crescent」.mp3	Happy Crescent	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253340/covers/The_World_God_Only_Knows_ED3_Happy_Crescent.jpg	1
1165	1165	1161	92		/audio/The World God Only Knows OP 「God only knows Dai.mp3	God only knows Daisanmaku	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253358/covers/The_World_God_Only_Knows_OP_God_only_knows_Daisanmaku.jpg	1
1166	1166	1166	293		/audio/The World_s Finest Assassin gets reincarnated i(1).mp3	A Promise	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253352/covers/The_World_s_Finest_Assassin_gets_reincarnated_in_another_world_as_an_Aristocrat_ED_A_Promise.jpg	1
1169	1169	1168	256		/audio/The _Hentai_ Prince and the Stony Cat OP 「Fanta.mp3	Fantastic future	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253330/covers/The_Hentai_Prince_and_the_Stony_Cat_OP_Fantastic_future.jpg	1
1171	1171	1171	262		/audio/To Love Ru Darkness S2 ED 「Gardens」.mp3	Gardens	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253371/covers/To_Love_Ru_Darkness_S2_ED_Gardens.jpg	2
1177	1177	1175	234		/audio/Tokyo Ghoul Re_ ED 「HALF」.mp3	HALF	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253427/covers/Tokyo_Ghoul_Re_ED_HALF.jpg	1
1179	1147	1175	177		/audio/Tokyo Ghoul Re_ OP 「Asphyxia」.mp3	Asphyxia	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253380/covers/Tokyo_Ghoul_Re_OP_Asphyxia.jpg	1
1181	1181	1175	217		/audio/Tokyo Ghoul √A S2 OP 「Munou」.mp3	Munou	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253424/covers/Tokyo_Ghoul_A_S2_OP_Munou.jpg	2
1182	1181	1175	251		/audio/Tokyo Ghoul_Re S2 ED 「Rakuen no Kimi」.mp3	Rakuen no Kimi	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253386/covers/Tokyo_GhoulRe_S2_ED_Rakuen_no_Kimi.jpg	2
1184	96	1183	250		/audio/Tokyo Magnitude 8.0 OP 「Kimi no Uta」.mp3	Kimi no Uta	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253420/covers/Tokyo_Magnitude_8.0_OP_Kimi_no_Uta.jpg	1
1185	619	1185	318		/audio/Tokyo Ravens ED 「Kimi ga Emu Yuugure」.mp3	Kimi ga Emu Yuugure	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253393/covers/Tokyo_Ravens_ED_Kimi_ga_Emu_Yuugure.jpg	1
1188	1188	1185	233		/audio/Tokyo Ravens OP2 「~Outgrow~」.mp3	~Outgrow~	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253400/covers/Tokyo_Ravens_OP2_Outgrow.jpg	1
1192	1192	1191	92		/audio/Toradora OP 「Pre-Parade」(ENG).mp3	Pre-Parade	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253418/covers/Toradora_OP_Pre-Parade_ENG.jpg	1
1194	70	1191	90		/audio/Toradora OP2 「Silky Heart」.mp3	Silky Heart	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253388/covers/Toradora_OP2_Silky_Heart.jpg	1
1199	605	1049	213		/audio/Tada Never Falls In Love OP 「Otomodachi Film」.mp3	Otomodachi Film	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253378/covers/Tada_Never_Falls_In_Love_OP_Otomodachi_Film.jpg	1
1208	1208	1208	300		/audio/Tokyo Godfathers ED 「Ode to Joy」.mp3	Ode to Joy	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253408/covers/Tokyo_Godfathers_ED_Ode_to_Joy.jpg	1
1209	1209	1209	223		/audio/Tsugu Tsugumomo ED 「Haru, Kanade」.mp3	Haru, Kanade	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253413/covers/Tsugu_Tsugumomo_ED_Haru_Kanade.jpg	1
980	980	979	292		/audio/Shiki ED2 「Gekka Reijin」.mp3	Gekka Reijin	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253433/covers/Shiki_ED2_Gekka_Reijin.jpg	1
1041	1041	939	197		/audio/Sword Art Online Ordinal Scale 「Smile for You」.mp3	Smile for You	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253505/covers/Sword_Art_Online_Ordinal_Scale_Smile_for_You.jpg	1
1183	1183	1183	230		/audio/Tokyo Magnitude 8.0 ED 「M_elody」.mp3	M/elody	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253429/covers/Tokyo_Magnitude_8.0_ED_Melody.jpg	1
1186	1171	1185	246		/audio/Tokyo Ravens ED2 「Break a spell」.mp3	Break a spell	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253431/covers/Tokyo_Ravens_ED2_Break_a_spell.jpg	1
1211	690	1211	298		/audio/Wandering Son OP 「Itsudatte」.mp3	Itsudatte	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253462/covers/Wandering_Son_OP_Itsudatte.jpg	1
1212	1212	1212	291		/audio/Words Bubble up like a Soda Pop Theme Song 「YAM.mp3	YAMAZAKURA	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253476/covers/Words_Bubble_up_like_a_Soda_Pop_Theme_Song_YAMAZAKURA.jpg	1
1213	1213	1213	238		/audio/Yamada Kun and the Seven Witches OP 「Kuchizuke .mp3	Kuchizuke Diamond	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253482/covers/Yamada_Kun_and_the_Seven_Witches_OP_Kuchizuke_Diamond.jpg	1
1215	1215	385	340		/audio/Higurashi ED 「Why, or why not 」.mp3	Why, or why not 	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253464/covers/Higurashi_ED_Why_or_why_not.jpg	1
1217	792	777	263		/audio/Oregairu S2 ED 「Everyday World」.mp3	Everyday World	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253451/covers/Oregairu_S2_ED_Everyday_World.jpg	2
1219	1219	1209	196		/audio/Tsugu Tsugumomo OP 「Kaze Fukeba Tsukiyo no Hate.mp3	Kaze Fukeba Tsukiyo no Hate ni	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253491/covers/Tsugu_Tsugumomo_OP_Kaze_Fukeba_Tsukiyo_no_Hate_ni.jpg	1
1222	1220	1220	288		/audio/Tsuki ga Kirei 「Hatsukoi」.mp3	Hatsukoi	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253458/covers/Tsuki_ga_Kirei_Hatsukoi.jpg	1
1225	1225	1224	217	[ti:Tsukimichi Moonlit Fantasy OP 「Gamble」]\n[ar:syudou]\n[al:Tsukimichi Moonlit Fantasy]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:37.10]\n[00:00.20]Kanchigai no kotoba o\n[00:03.49]Tadatada sakende koko ni kimashita\n[00:05.94]Donatte natta kono uta mo\n[00:08.31]Anata nara shinjitekuremasu ka?\n[00:20.88]"yappa īya" no tsuzuki o\n[00:23.00]Anata to mitai to omoimashita\n[00:25.57]Mirai ni moratta kono michi o\n[00:28.00]Kokorokara shinjite īndesuka?\n[00:30.36]Kokoronai na mo nai bitoku mo chi mo nai yatsu ga\n[00:33.63]Yaiyai mata ittatte\n[00:35.19]Waruikedo zenbu ga meshi no tane dakara\n[00:37.95]Issō moukaru nda\n[00:40.01]Demo tantan to shigoku mattou na\n[00:44.59]Michi o kappo shite tatte kanpeki hanai\n[00:47.43]Nando saketa tte yan dari shinai\n[00:50.21]Hinan hihan no samidare\n[00:53.99]Sōdesu ka\n[00:55.05]Jā mou īkara zenin damare\n[00:57.72]Mayonaka igai demo kaisei\n[01:00.07]Ore wa yoru nante kakenai mirai ni kakeru\n[01:04.98]Kizutsuita omoi sae nenryō nanda\n[01:07.33]Sainō ya nodo o karasazu ni kutabaru\n[01:10.21]Jōdan janaidaro\n[01:13.93]Sō atashi wa hanninmae busaiku tada bonjin\n[01:17.07]Tensei sae negatta gōnin\n[01:19.47]Mirai mirai ni te o furi renda\n[01:23.87]Mirai mirai ni te o furi renda\n[01:36.81]Mou niban dashi daijoubu\n[01:38.97]Sukoshi dake honne de hanasou ka\n[01:41.36]Shakai ya gakkō de tsuchikatta\n[01:43.74]Jōshiki wa taigai usodatta\n[01:46.28]"gaku no nai kane nai shinyō sura nai yatsu ni\n[01:48.86]Nacchattara dō sunno?"\n[01:51.29]Sonna koto itte ashita moshi kyū ni\n[01:53.93]Shinjimattatte ī katte hanashi\n[02:00.42]Doudesu ka?\n[02:01.39]Jā mou īkara zengaku kakero\n[02:03.93]Meippai shōbu o hatte\n[02:06.32]Yobousen nante haranai mirai wa hareru\n[02:10.95]Kono jinsei koso ga nani yori mo gyanburu\n[02:13.50]Kakegae nai isshounanda\n[02:16.21]Kakenaito mottainaidaro\n[02:19.81]ā ima demo hanshinhangi kasu ne kura teinou\n[02:23.26]Intānetto rep dōjin\n[02:25.44]Jasui mo ai mo matomete rentō\n[02:37.67]Demo honshin ja ima mo meisō chū\n[02:42.25]Dakedo fuan nara mugen jikan wa yūgen\n[02:45.09]Shōmonai yatsu o kamatteiru yōna\n[02:47.52]Jikan hanēze bakatare\n[02:51.71]Soudesu ka\n[02:53.55]Jā mō īkara zenin damare\n[02:56.59]Mayonaka igai demo kaisei\n[02:58.94]Ore wa yoru nante kakenai mirai ni kakeru\n[03:03.54]Kizu tsuita omoi sae nenryouna nda\n[03:06.14]Sainou ya nodo o karasazu ni kutabaru\n[03:09.41]Joudan janaidaro\n[03:12.45]Sou atashi wa hanninmae busaiku tada bonjin\n[03:15.74]Tensei sae negatta gōnin\n[03:18.17]Mirai mirai ni te o furi renda\n[03:22.76]Mirai mirai ni te o furi renda\n[03:27.25]Kanchigai no kotoba o\n[03:29.89]Madamada sakendeku tsumoridesuga\n[03:32.42]Waracchimau youna sama mo\n[03:34.82]Anata nara aishite kuremasu ka?\n[03:37.53]	/audio/Tsukimichi Moonlit Fantasy OP 「Gamble」.mp3	Gamble	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253448/covers/Tsukimichi_Moonlit_Fantasy_OP_Gamble.jpg	1
1227	878	1226	208		/audio/Usagi Drop OP 「Sweet Drops」.mp3	Sweet Drops	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253456/covers/Usagi_Drop_OP_Sweet_Drops.jpg	1
1230	1229	1228	328		/audio/Utawarerumono OP 「Musouka」.mp3	Musouka	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253498/covers/Utawarerumono_OP_Musouka.jpg	1
1233	1229	1228	262		/audio/Utawarerumono S2 OP 「Fuantei na Kamisama」.mp3	Fuantei na Kamisama	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253487/covers/Utawarerumono_S2_OP_Fuantei_na_Kamisama.jpg	2
1236	74	1210	335		/audio/Violet Evergarden Movie 2 ED 「WILL」.mp3	WILL	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253474/covers/Violet_Evergarden_Movie_2_ED_WILL.jpg	1
1237	74	1210	236		/audio/Violet Evergarden Movie 2 ED2 「Mirai no Hito e」.mp3	Mirai no Hito e	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253445/covers/Violet_Evergarden_Movie_2_ED2_Mirai_no_Hito_e.jpg	1
1238	1102	1210	308		/audio/Violet Evergarden Movie ED Theme 「Amy」.mp3	Amy	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253453/covers/Violet_Evergarden_Movie_ED_Theme_Amy.jpg	1
1239	74	1210	300		/audio/Violet Evergarden OP 「Sincerely」.mp3	Sincerely	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253502/covers/Violet_Evergarden_OP_Sincerely.jpg	1
1240	1240	1240	345		/audio/Vivy_ Fluorite Eye_s Song ED 「Fluorite Eye_s So.mp3	Fluorite Eye's Song	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253467/covers/Vivy_Fluorite_Eye_s_Song_ED_Fluorite_Eye_s_Song.jpg	1
1242	1242	1240	220		/audio/Vivy_ Fluorite Eye_s Song Insert Song 「Harmony .mp3	Harmony of One's Heart	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253494/covers/Vivy_Fluorite_Eye_s_Song_Insert_Song_Harmony_of_One_s_Heart.jpg	1
1243	1243	1240	227		/audio/Vivy_ Fluorite Eye_s Song OP 「Happy Together」.mp3	Happy Together	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253500/covers/Vivy_Fluorite_Eye_s_Song_OP_Happy_Together.jpg	1
1269	74	1268	318		/audio/WorldEnd ED2 「Kinema」.mp3	Kinema	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253478/covers/WorldEnd_ED2_Kinema.jpg	1
983	18	983	229		/audio/Shimoneta ED 「Inner Urge」.mp3	Inner Urge	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253441/covers/Shimoneta_ED_Inner_Urge.jpg	1
984	984	983	273		/audio/Shimoneta OP 「B Chiku Sentai SOX」.mp3	B Chiku Sentai SOX	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253435/covers/Shimoneta_OP_B_Chiku_Sentai_SOX.jpg	1
994	232	992	238		/audio/Silver Spoon S2 OP 「LIFE」.mp3	LIFE	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253443/covers/Silver_Spoon_S2_OP_LIFE.jpg	2
1012	794	794	90		/audio/Oreimo ED5 「Orange」.mp3	Orange	ED5	https://res.cloudinary.com/ddc6silap/image/upload/v1773253509/covers/Oreimo_ED5_Orange.jpg	1
1221	1220	1220	224		/audio/Tsuki ga Kirei OP 「Imakoko」.mp3	Imakoko	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253516/covers/Tsuki_ga_Kirei_OP_Imakoko.jpg	1
1244	1240	1240	292		/audio/Vivy_ Fluorite Eye_s Song OP2 「A Tender Moon Te.mp3	A Tender Moon Tempo	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253514/covers/Vivy_Fluorite_Eye_s_Song_OP2_A_Tender_Moon_Tempo.jpg	1
1245	1240	1240	294		/audio/Vivy_ Fluorite Eye_s Song OP3 「Sing My Pleasure.mp3	Sing My Pleasure	OP3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253523/covers/Vivy_Fluorite_Eye_s_Song_OP3_Sing_My_Pleasure.jpg	1
1247	1247	1247	327		/audio/Voices of a Distant Star ED Theme 「Through The .mp3	Through The Years And Far Away	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253526/covers/Voices_of_a_Distant_Star_ED_Theme_Through_The_Years_And_Far_Away.jpg	1
1250	1250	1249	245		/audio/Watamote ED2 「Musou Renka」.mp3	Musou Renka	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253541/covers/Watamote_ED2_Musou_Renka.jpg	1
1253	1253	1249	199		/audio/Watamote OP 「Watashi ga Motenai no wa Dou Kanga.mp3	Watashi ga Motenai no wa Dou Kangaete mo Omaera ga Warui	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253552/covers/Watamote_OP_Watashi_ga_Motenai_no_wa_Dou_Kangaete_mo_Omaera_ga_Warui.jpg	1
1256	1254	1254	259		/audio/Weathering with you 「We_ll Be Alright」.mp3	We'll Be Alright	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253521/covers/Weathering_with_you_We_ll_Be_Alright.jpg	1
1257	1257	1257	247		/audio/Welcome to the NHK ED 「Odoru Akachan Ningen」.mp3	Odoru Akachan Ningen	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253519/covers/Welcome_to_the_NHK_ED_Odoru_Akachan_Ningen.jpg	1
1259	126	1257	245		/audio/Welcome to the NHK OP 「Puzzle」.mp3	Puzzle	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253535/covers/Welcome_to_the_NHK_OP_Puzzle.jpg	1
1260	1260	1260	255		/audio/When Marnie Was There ED 「Fine on the Outside」.mp3	Fine on the Outside	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253528/covers/When_Marnie_Was_There_ED_Fine_on_the_Outside.jpg	1
1262	1262	1262	191		/audio/Why the hell are you here, Teacher!_ ED 「Ringo-.mp3	Ringo-iro Memories	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253533/covers/Why_the_hell_are_you_here_Teacher_ED_Ringo-iro_Memories.jpg	1
1264	1264	1264	253		/audio/Wise Man_s Grandchild ED 「Attouteki Vivid Days」.mp3	Attouteki Vivid Days	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253542/covers/Wise_Man_s_Grandchild_ED_Attouteki_Vivid_Days.jpg	1
1265	1265	1264	239		/audio/Wise Man_s Grandchild OP 「Ultimate☆Magic」.mp3	Ultimate☆Magic	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253524/covers/Wise_Man_s_Grandchild_OP_Ultimate_Magic.jpg	1
1266	1266	1266	311		/audio/Wolf Children 「Mother_s Song」.mp3	Mother's Song	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253553/covers/Wolf_Children_Mother_s_Song.jpg	1
1267	1267	1212	207		/audio/Words Bubble up like a Soda Pop ED 「Cider no Yo.mp3	Cider no You ni Kotoba ga Wakiagaru	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253518/covers/Words_Bubble_up_like_a_Soda_Pop_ED_Cider_no_You_ni_Kotoba_ga_Wakiagaru.jpg	1
1274	464	1273	266		/audio/Wotakoi ED2 「Ashita mo Mata」.mp3	Ashita mo Mata	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253537/covers/Wotakoi_ED2_Ashita_mo_Mata.jpg	1
1276	1276	1276	227		/audio/Ya Boy Kongming! ED 「Kibun Joujou」.mp3	Kibun Joujou	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253529/covers/Ya_Boy_Kongming_ED_Kibun_Joujou.jpg	1
1278	1278	1276	204	[ti:Ya Boy Kongming! OP 「Ya Boy Kongming!」]\n[ar:QUEENDOM]\n[al:Ya Boy Kongming!]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:23.54]\n[00:00.00] \n[00:10.86]Chan chan\n[00:11.53]Ai chikichiki banban\n[00:12.73]Ai chikichiki chanchan\n[00:15.25]Aa chikichiki banban\n[00:17.21]Ai chuki chukichuki banban\n[00:18.52]High chikichiki banban\n[00:20.39]Ai chikichiki chanchan\n[00:22.10]Aa chikichiki banban\n[00:23.98]Ai chukichuki\n[00:25.02]Neko mo shakushi mo\n[00:29.05]Minna kimagure de tsurai\n[00:32.16]Yoeba tekiira\n[00:35.85]Aranu mousou renzoku de piikan\n[00:39.64]Yume wa pandora hora aketaku naru\n[00:43.90]Minna kitai shite paripi yo\n[00:47.10]Konya fujiyama noboranya wakaranai\n[00:51.34]Kessen mo shuumatsu no shukumei\n[00:55.11]Chan chan\n[00:55.97]Ai chikichiki banban\n[00:58.61]Nanimo mottai burazu tanoshime fever tonight\n[01:03.00]Chan chan\n[01:03.56]Ai chikichiki banban!\n[01:05.79]Nando mushakusha shitatte party tonight\n[01:10.67]Chan chan\n[01:11.23]Aa chikichiki banban\n[01:12.99]Orokamono hodo high tokasu kanzen shakai\n[01:17.75]Chan chan\n[01:18.44]Ai chikichiki banban\n[01:20.89]Minna suupaasutaa no tamago sa diva tonight\n[01:25.16]Gurasu age guramarasu shinai?\n[01:28.58]Demo mo dakedo mo mina iranai hands up\n[01:32.70]Rinri de rinrin shinai!\n[01:36.01]Japaniizu puriti hisoka ni ima futtou\n[01:40.23]Gurasu age gurashiasu shitai\n[01:43.28]Nomeba nori yoku akkerakan to sezu, yeah\n[01:47.77]Buranku sute baunsu shite janpu\n[01:50.91]Yume makishimamu atsuku dancing, oh yeah\n[01:57.03]Itsumo risei wa doushite okubyou gachide\n[01:58.83]Enerugii wo mitase senbon tekiira\n[02:00.70]Song! Love! Sooraade sora tobu juutan\n[02:02.72]Massakasama shite mukanaide\n[02:04.56]Inki ja damе infure shitamae\n[02:06.54]Daradara suru ma ni ending jinsеi\n[02:08.31]Miren wa no shining kidou\n[02:10.26]Hani koromo kisezu souryokusen\n[02:12.09]Oh baby, kozakashii ne\n[02:13.86]Ha-ha-ha-high issei tekiira\n[02:15.78]"Mae dake muiterya ii desho?"\n[02:17.53]"Moe sakacchau kedo ii desho?"\n[02:19.38]Mou sukoshi play god mou sukoshi bang out\n[02:21.27]Asu ga kurukedo kigen wa dou dai?\n[02:23.37]Hora hora jikai ni supotto atenna\n[02:25.15]"Itsu made utau kida?"\n[02:26.50]Hachi jikan!\n[02:29.30]Chan chan\n[02:30.43]Ai chikichiki banban\n[02:32.49]Ai chikichiki chanchan\n[02:33.93]Aa chikichiki banban\n[02:35.87]Ai chuki chukichuki banban\n[02:37.11]High chikichiki banban\n[02:38.92]Ai chikichiki chanchan\n[02:40.85]Aa chikichiki banban\n[02:42.60]Ai chukichuki\n[02:44.08]Chan chan\n[02:45.14]Aa chikichiki banban\n[02:47.21]Orokamono hodo high tokasu kanzen shakai\n[02:51.93]Chan chan\n[02:52.69]Ai chikichiki banban\n[02:54.71]Minna suupaasutaa no tamago sa diva tonight\n[02:59.38]Chan chan\n[03:00.29]Ai chikichiki banban\n[03:01.21]Ai chikichiki chanchan\n[03:03.24]Aa chikichiki banban\n[03:05.09]Ai chuki chukichuki banban\n[03:06.90]High chikichiki banban\n[03:08.79]Ai chikichiki chanchan\n[03:10.62]Aa chikichiki banban\n[02:12.55]Ai chukichuki\n[03:15.97] 	/audio/Ya Boy Kongming! OP 「Ya Boy Kongming!」.mp3	Ya Boy Kongming!	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253554/covers/Ya_Boy_Kongming_OP_Ya_Boy_Kongming.jpg	1
1279	1034	1213	310		/audio/Yamada Kun and the Seven Witches ED 「CANDY MAGI.mp3	CANDY MAGIC	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253531/covers/Yamada_Kun_and_the_Seven_Witches_ED_CANDY_MAGIC.jpg	1
538	137	532	374		/audio/Love, Chunibyo and Other Delusions Movie_ Take (1).mp3	Kokoro no Namae	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253559/covers/Love_Chunibyo_and_Other_Delusions_Movie_Take_on_Me_ED_Kokoro_no_Namae.jpg	1
896	895	893	287		/audio/Rewrite OP 「Philosophyz」.mp3	Philosophyz	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253557/covers/Rewrite_OP_Philosophyz.jpg	1
1051	1051	1050	189		/audio/Taisho Otome Fairy Tale OP 「Otome no Kokoroe」.mp3	Otome no Kokoroe	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253547/covers/Taisho_Otome_Fairy_Tale_OP_Otome_no_Kokoroe.jpg	1
1066	1061	1061	236		/audio/Teasing Master Takagi San ED6 「Ai Uta」.mp3	Ai Uta	ED6	https://res.cloudinary.com/ddc6silap/image/upload/v1773253546/covers/Teasing_Master_Takagi_San_ED6_Ai_Uta.jpg	1
1200	447	1061	260		/audio/Teasing Master Takagi San Movie OP Theme 「Hajimari no Natsu」.mp3	Hajimari no Natsu	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253636/covers/Teasing_Master_Takagi_San_Movie_OP_Theme_Hajimari_no_Natsu.jpg	1
90	90	66	257		/audio/Bakemonogatari OP3 「ambivalent world」.mp3	ambivalent world	OP3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253579/covers/Bakemonogatari_OP3_ambivalent_world.jpg	1
600	167	595	224		/audio/Mob Psycho 100 Season 2 ED「Gray」.mp3	Gray	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253589/covers/Mob_Psycho_100_Season_2_ED_Gray.jpg	1
699	699	627	273		/audio/Naruto Shippuden OP20 「Kara no Kokoro」.mp3	Kara no Kokoro	OP20	https://res.cloudinary.com/ddc6silap/image/upload/v1773253580/covers/Naruto_Shippuden_OP20_Kara_no_Kokoro.jpg	1
795	795	794	90		/audio/Oreimo ED10 「lie, Tomu wa Imouto ni Taishite Se.mp3	lie, Tomu wa Imouto ni Taishite Seiteki na Koufun wo Oboete imasu	ED10	https://res.cloudinary.com/ddc6silap/image/upload/v1773253669/covers/Oreimo_ED10_lie_Tomu_wa_Imouto_ni_Taishite_Seiteki_na_Koufun_wo_Oboete_imasu.jpg	1
811	805	794	92		/audio/Oreimo S2 ED10 「Arifureta Mirai he」.mp3	Arifureta Mirai he	ED10	https://res.cloudinary.com/ddc6silap/image/upload/v1773253593/covers/Oreimo_S2_ED10_Arifureta_Mirai_he.jpg	2
1023	1023	1009	331		/audio/Steins Gate 0 OST 「A Song played by the Stars」.mp3	A Song played by the Stars	OST	https://res.cloudinary.com/ddc6silap/image/upload/v1773253595/covers/Steins_Gate_0_OST_A_Song_played_by_the_Stars.jpg	1
1091	75	1090	232		/audio/The Ambition of Oda Nobuna OP 「Link」.mp3	Link	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253567/covers/The_Ambition_of_Oda_Nobuna_OP_Link.jpg	1
1097	1097	1097	300		/audio/The Boy and the Beast ED Theme 「Starting Over」.mp3	Starting Over	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253574/covers/The_Boy_and_the_Beast_ED_Theme_Starting_Over.jpg	1
1102	1102	361	311		/audio/The Disappearance of Haruhi Suzumiya ED 「Yasash.mp3	Yasashii Boukyaku	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253584/covers/The_Disappearance_of_Haruhi_Suzumiya_ED_Yasashii_Boukyaku.jpg	1
1109	1109	1107	240		/audio/The Familiar of Zero S2 OP 「I SAY YES」.mp3	I SAY YES	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253601/covers/The_Familiar_of_Zero_S2_OP_I_SAY_YES.jpg	2
1112	1110	1107	237		/audio/The Familiar of Zero S4 ED 「Kiss Shite↑ Agenai↓.mp3	Kiss Shite↑ Agenai↓	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253604/covers/cvlmrtorv5wnk3downmj.jpg	4
1137	1137	1137	237		/audio/The Misfit of Demon King Academy ED 「Hamidashim.mp3	Hamidashimono	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253602/covers/The_Misfit_of_Demon_King_Academy_ED_Hamidashimono.jpg	1
1140	234	1140	253		/audio/The Petgirl of Sakurasou ED 「DAYS of DASH」.mp3	DAYS of DASH	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253590/covers/The_Petgirl_of_Sakurasou_ED_DAYS_of_DASH.jpg	1
1273	464	1273	281		/audio/Wotakoi ED 「Kimi no Tonari」.mp3	Kimi no Tonari	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253582/covers/Wotakoi_ED_Kimi_no_Tonari.jpg	1
1284	1284	1284	284		/audio/Your Lie In April ED 「Kirameki」.mp3	Kirameki	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253565/covers/Your_Lie_In_April_ED_Kirameki.jpg	1
1287	1287	1284	269		/audio/Your Lie in April OP2 「Nanairo Symphony」.mp3	Nanairo Symphony	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253562/covers/Your_Lie_in_April_OP2_Nanairo_Symphony.jpg	1
1291	1254	1288	409		/audio/Your Name 「Sparkle」.mp3	Sparkle	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253563/covers/Your_Name_Sparkle.jpg	1
1293	845	1293	278		/audio/Yuru Camp ∆ ED 「Fuyu Biyori」.mp3	Fuyu Biyori	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253576/covers/Yuru_Camp_ED_Fuyu_Biyori.jpg	1
167	167	162	226		/audio/Danmachi S3 ED 「Evergreen」.mp3	Evergreen	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253596/covers/Danmachi_S3_ED_Evergreen.jpg	3
393	234	385	254		/audio/Higurashi Sotsu ED 「Missing Promise」.mp3	Missing Promise	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253592/covers/Higurashi_Sotsu_ED_Missing_Promise.jpg	1
499	499	495	212	[ti:Komi Can't Communicate OP 「Cindrella」]\n[ar:Cider Girl]\n[al:Komi Can't Communicate]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:32.30]\n[00:00.00]Sasai na yorokobi tachi wo sodatete ikimasen ka\n[00:23.05]Anata no kao ga sukoshi samishisou de\n[00:30.37]Jooku no hitotsu demo ietara naa\n[00:37.42]Afureru kimochi ni tomadotte wa\n[00:41.47]Nando mo shitatameru raburetaa\n[00:45.14]Itsu made marumete suteteiru no\n[00:52.52]Me to me aeba fushigi na mon de\n[00:56.08]Muri shite warattemo barete shimau na\n[01:00.12]Hai kabuttemo daijoubu anata ga iru no naraba\n[01:07.20]Ki no kiita koto wa ienai kedo\n[01:10.88]Issho ni neko ni ai ni ikimasen ka\n[01:14.82]Sasai na yorokobi tachi wo sodatete ikimasen ka\n[01:23.78]Netemo sametemo mune ga kurushii no wa\n[01:31.30]Ato sukoshi yuuki wo dasenai kara\n[01:38.42]Ima wa mada kono mama kizukanai furi de\n[01:42.56]Bibidi babidi buu mahou wo moa en moa\n[01:46.44]Chikazuku hodo wakan naku natte kabocha mo baka ni naru\n[01:53.69]Ganbattemo kanashii toki ni wa\n[01:57.31]Yorimichi shi nagara kaerimasen ka\n[02:01.44]Yuuyake ni inori wo komete ashita wa waraeru you ni\n[02:23.37]Sakura no hana umi no aosa ochiba to yuki no juutan\n[02:30.77]Hitori ja ki zukenai utsukushisa wo shitta\n[02:38.33]Amakute nigai aji mo shitta\n[02:45.53]Itsuka owari ga kite shimaeba sorezore no michi wo ayunde iku kara\n[02:53.13]Hai kabutteru baai janai shinderera ja aru mai shi\n[02:59.95]Kore kara mo anata no tonari ga ii\n[03:03.78]Nante koto no nai hibi wo sugoshite\n[03:07.97]Sasai na yorokobi tachi wo sodatete ikimasen ka	/audio/Komi Can_t Communicate OP 「Cindrella」.mp3	Cindrella	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253664/covers/Komi_Can_t_Communicate_OP_Cindrella.jpg	1
317	316	314	96		/audio/Genshiken OVA OP 「Seishun to shite」.mp3	Seishun to shite	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253611/covers/Genshiken_OVA_OP_Seishun_to_shite.jpg	1
324	321	320	211	[ti:Goblin Slayer OP 「Rightfully」]\n[ar:Mili]\n[al:Goblin Slayer]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:31.05]\n[00:00.00]\n[00:20.68]Chained onto me\n[00:23.53]My adolescent dreams\n[00:27.08]Pulling, dragged me deep\n[00:32.99]All my body exposed\n[00:37.85]Marked up by your shadows\n[00:42.28]Tighten up\n[00:43.81]Numb your senses\n[00:45.00]No fairness is needed for pigs\n[00:47.91]Laughters above\n[00:50.54]Playful smiles\n[00:53.36]Die gets rolled\n[00:55.79]Bathe in sorrow\n[00:58.30]My tomorrow is built upon your flesh\n[01:02.24]Slay the last of your kind\n[01:03.58]To reclaim what’s rightfully mine\n[01:06.26]Each time we'll enter\n[01:07.44]First time to make this\n[01:08.72]Final dungeon\n[01:09.93]Munen'na mirai no\n[01:11.29]I have a reason\n[01:12.54]Don’t part the rivers\n[01:13.91]Surround them off with their heads\n[01:16.64]Christen my motive\n[01:17.98]First time to notice\n[01:19.25]Final dungeon Murete mayou\n[01:21.93]I hide among you\n[01:23.21]Facing my fire\n[01:24.53]At night I’m dreaming\n[01:25.89]Nagai yume no kotoha\n[01:29.29]I still dream of you\n[01:36.50]Will you be disappointed that I’m not who I used to be\n[01:44.20]Will you hold me tightly\n[01:48.44]Chained onto me\n[01:50.84]My adolescent dreams\n[01:54.39]Pulling, dragged me deep\n[01:59.36]All my body exposed\n[02:04.92]Marked up by your shadows\n[02:09.69]Piece by piece the tables turn and turn again\n[02:14.76]In this eternal game\n[02:19.05]Biscuits with clotted cream and milk tea\n[02:23.61]Time to roll your d-20\n[02:25.72]Gods nor demons ready to admit defeat\n[02:30.54]Eat up\n[02:31.94]Grind your teeth\n[02:32.15]They’re not that much smarter than us\n[02:36.20]Laughters above\n[02:38.82]Playful smiles\n[02:41.47]Die gets rolled\n[02:44.14]Swallow your fate\n[02:46.20]Lubricate our blades with blood and tears\n[02:50.35]And your piercing screams are music to celebrate\n[02:54.76]Infiltrate, penetrate\n[02:57.23]Soon we’ll have you destroyed\n[02:58.96]Back to the old days\n[03:01.08]Slay the last of your kind\n[03:02.35]To reclaim what’s rightfully mine\n[03:05.75]Each time we'll enter\n[03:06.95]First time to make this\n[03:08.27]Final dungeon Munen'na mirai no\n[03:10.71]I have a reason\n[03:12.01]Don’t part the rivers\n[03:13.32]Surround them off with their heads\n[03:16.01]Christen my motive\n[03:17.28]First time to notice\n[03:18.54]Final dungeon Murete mayou\n[03:21.24]I hide among you\n[03:22.67]Facing my fire\n[03:23.94]At night I’m dreaming\n[03:25.17]Nagai yume no kotoha\n[03:28.64]	/audio/Goblin Slayer OP 「Rightfully」.mp3	Rightfully	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253629/covers/Goblin_Slayer_OP_Rightfully.jpg	1
445	445	445	330		/audio/I_ve Always Liked You ED 「Ippun Ichibyou Kimi t.mp3	Ippun Ichibyou Kimi to Boku no	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253619/covers/I_ve_Always_Liked_You_ED_Ippun_Ichibyou_Kimi_to_Boku_no.jpg	1
578	578	573	248		/audio/Mirai Nikki OP3 「Kyouki Chinden」.mp3	Kyouki Chinden	OP3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253607/covers/Mirai_Nikki_OP3_Kyouki_Chinden.jpg	1
744	744	743	378		/audio/Nodame Cantabile ED2 「Sagittarius」.mp3	Sagittarius	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253610/covers/Nodame_Cantabile_ED2_Sagittarius.jpg	1
805	805	794	90		/audio/Oreimo ED6 「MAEGAMI」.mp3	MAEGAMI	ED6	https://res.cloudinary.com/ddc6silap/image/upload/v1773253616/covers/Oreimo_ED6_MAEGAMI.jpg	1
850	848	848	237		/audio/Princess Connect! Re_Dive OP 「Lost Princess」.mp3	Lost Princess	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253608/covers/Princess_Connect_ReDive_OP_Lost_Princess.jpg	1
944	95	939	291		/audio/SAO Extra Edition OST 「Nijino Oto」.mp3	Nijino Oto	OST	https://res.cloudinary.com/ddc6silap/image/upload/v1773253615/covers/SAO_Extra_Edition_OST_Nijino_Oto.jpg	1
1117	279	1116	283		/audio/The Garden of Sinners_ Murder Speculation A ED .mp3	Kimi ga Hikari ni Kaete Iku	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253618/covers/The_Garden_of_Sinners_Murder_Speculation_A_ED_Kimi_ga_Hikari_ni_Kaete_Iku.jpg	1
1142	1142	1140	140	[ti:The Petgirl of Sakurasou ED3 「Kyou no Hi wa Sayounara」]\n[ar:Sakurasou Prime Caste]\n[al:The Petgirl of Sakurasou]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:02:19.46]\n[00:00.00]\n[00:14.90]Itsumademo taeru koto naku\n[00:22.39]Tomodachi de iyou\n[00:29.89]Asu no hi wo yume mite\n[00:36.64]Kibou no michi wo\n[00:44.64]Sora wo tobu tori no you ni\n[00:52.13]Jiyuu ni ikiru\n[00:59.40]Kyou no hi wa sayounara\n[01:06.15]Mata au hi made\n[01:29.15]Shinjiau yorokobi wo\n[01:36.64]Taisetsu ni shiyou\n[01:44.14]Kyou no hi wa sayounara\n[01:50.89]Mata au hi made\n[01:58.39]Mata au hi made\n[02:06.83]	/audio/The Petgirl of Sakurasou ED3 「Kyou no Hi wa Say.mp3	Kyou no Hi wa Sayounara	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253626/covers/The_Petgirl_of_Sakurasou_ED3_Kyou_no_Hi_wa_Sayounara.jpg	1
1167	1167	1166	215	[ti:The World's Finest Assassin gets reincarnated in another world as an Aristocrat OP 「Dark Seeks Light」]\n[ar:Yui Ninomiya]\n[al:The World's Finest Assassin]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:34.46]\n[00:01.87]Rightness corroded.\n[00:03.09]Remaining regret.\n[00:04.24]Demolish this story!\n[00:06.10]Dark seeks light\n[00:07.03]Fubyoudou na sei wo igamiau\n[00:09.65]Hisoka ni zuretetta flic-flac\n[00:12.32]Kyouran no “seigi no hiiroo” wa\n[00:15.04]Dokuzen wo ouka shiteiru\n[00:17.33]Kojireta mirai no arika to\n[00:20.03]Meiyo to nanmanbun no aijou\n[00:22.61]Koboreta inochi ni imi wo sagashiteta\n[00:28.06]“Tell me the meaning of life”\n[00:33.03]“Fallen tears, fail to reach”\n[00:38.02]Bakageta rinri zenbu garakuta de\n[00:40.70]Juuboku de are to kami-sama kidori?\n[00:43.30]Risou gensou unmei wa seiron?\n[00:45.78]Kudakete kusarihateta aphorism\n[00:48.33]Junsui kannen no shisou\n[00:50.43]Iratsukun da mou\n[00:51.56]Nanimo kamo sakasama no sekai dattan da\n[00:55.72]Iki wo tomete, ima\n[00:58.15]Zutto tsumetai kurayami tadayou\n[01:00.84]Koroshi korosareta “boku” aishitai\n[01:03.29]Ito de tsurare ayatsurareta\n[01:06.09]Sonna “mono” wa iya nan da!\n[01:08.80]Kitto itami ga ai wo tsukuru kara\n[01:11.21]Fureta zetsubou wo kowaseru you ni sakebu kara\n[01:16.05]Break the world!\n[01:18.95]Dark seeks light\n[01:29.63]Our stupid habits!\n[01:31.25]Honto kudaranai\n[01:32.94]Nagashi nagasare karappo no tragedy\n[01:35.55]Fuyou fukyuu no Love?\n[01:37.27]Mou nanimo kamo ga iranai jan!\n[01:40.09]Hopeless.\n[01:41.22]“Tell me the meaning of life”\n[01:45.88]“Fallen tears, fail to reach”\n[01:51.13]“If there is a god now”\n[01:55.13]“grant that…please”\n[01:59.01]“ERROR”\n[02:01.09]Yotei chouwa no sei wo nazotteru\n[02:03.83]Tojikomerareta risei wa barabara\n[02:06.42]Tanjun meikai, rifujin na kaitou\n[02:08.86]“gisei wa tsukimono” rashii? dirty!\n[02:11.36]Arikitari na sainou\n[02:13.54]Nukedasun da saa\n[02:14.92]Katayaburi no shigeki motometerun desho\n[02:18.66]Sono te de tsukande!\n[02:21.20]Zutto samayoi tsuzukeru kokoro ga\n[02:23.95]Ashita wo sagashita mama agaiteru\n[02:26.48]Kako wo idaki, ima wo nonda\n[02:29.22]“ii ko” no mama ja dame desho!\n[02:31.82]Kitto kage ga hikari wo tsukuru kara\n[02:34.42]Fureta yasashisa wo kaeseru you ni susumu kara\n[02:39.19]Change the world!\n[02:41.47]Dark seeks light\n[02:43.51]Zutto tsumetai kurayami tadayou\n[02:47.06]Koroshi korosareta “boku” aishitai\n[02:49.49]Ito de tsurare ayatsurareta\n[02:52.17]Sonna “mono” ni sayonara!\n[02:54.66]Kitto itami ga ai wo tsukuru kara\n[02:57.40]Fureta zetsubou wo kowaseru you ni sakebu kara\n[03:02.15]Break the world!\n[03:05.67]Dark seeks light\n[03:08.32]Rightness corroded.\n[03:09.48]Remaining regret.\n[03:10.79]Demolish this story!\n[03:12.16]Dark seeks light\n[03:13.42]Rightness corroded.\n[03:14.83]Remaining regret.\n[03:16.04]Demolish this story!\n[03:17.71]Dark seeks light\n[03:18.85]Rightness corroded.\n[03:20.08]Remaining regret.\n[03:21.24]Demolish this story!\n[03:22.61]Dark seeks light\n[03:24.02]Rightness corroded.\n[03:25.19]Remaining regret.\n[03:26.32]Demolish this story!\n[03:28.15]Dark seeks light\n[03:30.03]	/audio/The World_s Finest Assassin gets reincarnated i.mp3	Dark Seeks Light	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253627/covers/The_World_s_Finest_Assassin_gets_reincarnated_in_another_world_as_an_Aristocrat_OP_Dark_Seeks_Light.jpg	1
1170	279	1170	358		/audio/Time of Eve ED Theme 「I Have A Dream」.mp3	I Have A Dream	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253621/covers/Time_of_Eve_ED_Theme_I_Have_A_Dream.jpg	1
500	500	500	265	[00:00.00] \n[00:07.71]Sore de mo bokura wa susumudarō\n[00:13.75]Tsumetai namida ga hō o nurashite mo\n[00:19.68]Saku hana wa fuyu o shiru\n[00:25.04]Daijōbu soba ni iru That' s a promise forever.\n[00:31.47]Mune ni nagareiku Melody\n[00:37.44]Kimi to utaitsuzukeru Symphony\n[00:43.40]Koko de tokihanatsu mahō ga\n[00:49.45]Ichi miri dake dare ka no kyō yurasu n da\n[00:54.90]Hashire gyutto kokoro tsunaide\n[00:58.02]Sagashite n da mugen no Rainbow\n[01:01.06]Azayaka sugiru kono sekai ni motto shukufuku o!\n[01:07.24]Negai wa itsu ka Emotion\n[01:09.84]Shinjitsu wa itsu mo Question\n[01:13.04]Sore de mo tsuzukudarō kono subarashī sekai wa\n[01:22.56] \n[01:22.84]Akirametaku nai yume nara ba\n[01:28.79]Kizutsuku koto nado kowaku nai sa\n[01:34.60]Saku hana wa ai o shiru\n[01:40.09]Daijōbu koko ni aru I am looking every day.\n[01:46.47]Sora ni nagareiku Melody\n[01:52.43]Kimi to mezashitsuzukeru Wonderland\n[01:58.37]Zutto mamoritai kibō ga\n[02:04.35]Ichi miri dake asu o kitto ugokasu\n[02:09.98]Hashire gutto yowasa o koete\n[02:12.94]Mitsuketa n da hito-tsu no Starlight\n[02:16.03]Sasayaka sugiru ano mirai ni motto jōnetsu o!\n[02:22.24]Meikyū no hate ni Station\n[02:24.93]Kurayami o saite Solution\n[02:28.17]Doko made ikerudarō kono tsumi fukaki sekai o\n[02:38.84] \n[03:04.65]Mune ni shimiwataru Melody\n[03:10.27]Boku o furuitataseru Sympathy\n[03:16.36]Kimi ga egaita kiseki wa\n[03:22.21]Ichi miri dake dare ka no kyō yurasu n da\n[03:29.43]Hashire gyutto kokoro tsunaide\n[03:32.40]Mitsuketa n da muteki no Potion\n[03:35.64]Hareyaka sugiru kono sekai ni motto shukufuku o!\n[03:41.77]Negai wa itsu ka Emotion\n[03:44.43]Shinjitsu wa itsu mo Question\n[03:47.54]Bokura wa tsumugudarō kono subarashī sekai o\n[03:57.27] \n	/audio/Konosuba movie ED Theme 2 「1 Millimeter Symphon.mp3	1 Millimeter Symphony	2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253978/covers/Konosuba_movie_ED_Theme_2_1_Millimeter_Symphony.jpg	1
502	500	500	243	[00:00.00]kimi to mita sekai\n[00:02.04]saa hajimari no kane ga naru\n[00:07.40]We are fantastic dreamer!\n[00:12.02] \n[00:24.82]mujaki ni tewatasareta rifujin na mirai wo\n[00:30.43]asobi tsukuseru kakugo ga dekita kana?\n[00:35.20]tokei no hari wa minai\n[00:38.43]kokoro ga kizamu RIZUMU dake shinjite mite yo\n[00:44.07]hazumu RIZUMU for Life tsunagattekunda\n[00:48.61]hora KOKO wo shinjite iinda yo\n[00:53.13]subarashiki sekai!!\n[00:55.06]saa hajimari no shirabe wo narase\n[01:00.61]zenryoku de ima wo tsukai hataseba\n[01:05.58]irotsuku no sa itsudatte\n[01:09.80]genkai sae mo oikoshite kimi no te dake nigitte\n[01:14.66]sousa We are fantastic dreamer!\n[01:20.74] \n[01:25.68]nandemo ARI de ii janai\n[01:28.87]yokubari na kurai ga dareka wo sukuu mahou ni naru rashii\n[01:36.09]"joushiki hazure" nante sa\n[01:39.40]fumihazusenai yatsura no tei no ii iiwake desho?\n[01:45.29]sagase hikari for Smile kowagatte naide\n[01:49.35]sou kimi wa hitori janainda yo\n[01:54.02]kaete yuke sekai\n[01:56.13]ima shukufuku no neiro wo narase\n[02:01.56]zankoku na ashita nante kyoumi nainda yo\n[02:06.56]yuke, kanousei wa dare datte\n[02:10.77]hitomi ni yadotterunda\n[02:13.29]hajimeyou yo koe ni dashite\n[02:15.58]todoke We are fantastic dreamer!\n[02:21.83] \n[02:31.83]kaketa tokoro ga aru kara\n[02:37.02]umeaeru koto ga ureshiinda\n[02:41.34]nee dare datte, hora kimi datte\n[02:44.01]kono te tsunaide dokomade mo ikeru nara\n[02:49.87]kitai shitaku naru desho?\n[02:55.11] \n[03:17.17]subarashii sekai...\n[03:18.86] \n[03:19.69]subarashiki sekai!!\n[03:21.55]hora mabayui hikari no FANFAARE\n[03:27.17]bokura wo itsudemo matte irunda yo\n[03:32.16]mou tamerau koto wa nainda\n[03:36.44]nankai datte yokubatte\n[03:38.89]subete te ni irerunda\n[03:41.32]yukou We are fantastic dreamer!\n[03:47.65] \n	/audio/Konosuba OP 「Fantastic Dreamer」.mp3	Fantastic Dreamer	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253947/covers/Konosuba_OP_Fantastic_Dreamer.jpg	1
409	409	406	265	[00:00.00] \n[00:20.87]Fukuzatsu ni kamaeta kyou ga iki wo nonde sumashiteru\n[00:27.36]Mi ni oboe aru ndarou? kimi wa dou shitai?\n[00:33.72]Nanimo nakatta soburi de kabau itami wa mou\n[00:40.28]Kokorozuyoi kurai ni sekasu nda\n[00:46.19]Tsukande koboshite fukanzen na bokutachi ga\n[00:52.78]Hikatte mienai mirai no jibun wo tsukureru nara\n[01:02.63]Mezameru mama hashire shinkirou wo oikoshite\n[01:09.25]Kawaritai mama hashire jiyuu na iwakan de\n[01:15.61]Todokisou na kagayaki to ima wo erandeikou\n[01:22.98]Toutatsuten wa shiranai fukai asai kokyuu wo kasanete\n[01:31.59] \n[01:33.12]Hitogomi wo kiraeba soko wa urusasugiru seijaku de\n[01:39.88]Kimazusou ni warau kimi wa boku da ne\n[01:45.86]Mimi wo fusaidemita tte mune wo utsu oto dake\n[01:52.62]Maru de kodomo mitai ni shoujiki na nda\n[01:58.51]Hodoite sukutte atarashiku narou ka\n[02:05.07]Yuganda taiyou ni asebamu yume nara owatta kara\n[02:14.89]Tomaranai mama hashire mukaikaze mo oikoshite\n[02:21.60]Wakaritai mama hashire akogareta supiido de\n[02:28.13]Todokisou na kagayaki ga ima wo terashiteiru\n[02:35.56]Kanshou nante iranai nigai amai kioku ga te wo furu\n[02:43.97] \n[02:44.03]Rinkaku wa mou boyaketeitta\n[02:50.70]Itsuka mata, mirai de aeru hazu\n[02:56.57] \n[03:14.14]Tsukande koboshite fukanzen na bokutachi ga\n[03:20.74]Midashita hikari no kanata ni yukeru made\n[03:29.06]Mezameru mama hashire shinkirou wo oikoshite\n[03:35.61]Kawaritai mama hashire jiyuu na iwakan de\n[03:42.09]Todokisou na kagayaki to ima wo erandeikou\n[03:49.42]Toutatsuten wa shiranai fukai asai kokyuu wo kasanete\n[03:56.14]Kaze ni furete hitotsu ni naru kimi wa dare wo matteiru no?\n[03:58.42]Hashitteku\n[04:01.89] \n[04:02.71]Kaze no naka de hitotsu ni naru you're my dream\n[04:07.34]Mikansei no sutoraido\n[04:11.48] \n	/audio/Hyouka OP2 「Mikansei Stride」.mp3	Mikansei Stride	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253638/covers/Hyouka_OP2_Mikansei_Stride.jpg	1
515	515	514	175	[ti:Link Click OP 「Dive Back In Time」]\n[ar:Bai Sha JAWS]\n[al:Link Click]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:02:54.48]\n[00:00.00]\n[00:00.78]It didn't take too long to realize\n[00:03.30]Something has changed in the back of my mind\n[00:06.52]Your eyes\n[00:07.73]There ain't nowhere left to hide behind\n[00:10.01]Time no longer flew like it was\n[00:12.26]When the flash froze everything before\n[00:15.38]Without you\n[00:16.61]I don't know if I could take this road\n[00:19.70]Chase you to the end of the world\n[00:22.12]Just to say your name once more\n[00:24.41]If I had only got it right before\n[00:32.17]Every minute that I dialed back in time\n[00:34.59]Every single existence rewinds\n[00:36.81]Something secretive hidden inside\n[00:39.06]Your mind\n[00:41.45]All the heartaches and the smiles never faded\n[00:43.46]I know you'll be by my side when we make it\n[00:46.13]Come back from the dive back in time\n[00:50.19]Dive dive\n[00:52.54]Dive back in time\n[00:54.83]Dive dive\n[00:57.49]Dive back in time\n[00:59.85]Dive dive\n[01:01.53]Dive back in time\n[01:06.40]Here's to all the mistakes I never made\n[01:09.48]All the twists and turns I'm always late to\n[01:13.22]My fate\n[01:14.43]If it ain't for your misguided taste\n[01:16.75]I'd turn out so ordinary\n[01:18.95]Fabulously un-addictively bore out my own brain\n[01:23.45]Hey out of my way\n[01:25.91]Every minute that I dialed back in time\n[01:28.03]Every single existence rewinds\n[01:30.23]Something secretive hidden inside\n[01:32.32]Your mind\n[01:34.77]All the heartaches and the smiles never faded\n[01:36.98]I know you'll be by my side when we make it\n[01:39.55]Come back from the dive back in time\n[01:43.47]Dive dive\n[01:46.22]Dive back in time\n[01:49.15]Dive dive\n[01:51.38]Dive back in time\n[01:52.95]Dive dive\n[01:55.10]Dive back in time\n[02:00.80]Well don't you feel sorry\n[02:02.77]I'll love where I'm going now\n[02:05.50]Cuz I'm about to lose my\n[02:07.33]Cuz I'm about to lose my\n[02:09.71]Cuz I'm about to lose my mind\n[02:12.66]Every minute that I dialed back in time\n[02:14.86]Every single existence rewinds\n[02:17.06]Something secretive hidden inside\n[02:19.14]Your mind\n[02:21.67]All the heartaches and the smiles never faded\n[02:23.83]I know you'll be by my side when we make it\n[02:26.29]Come back from the dive back in time\n[02:30.46]Dive dive\n[02:33.11]Dive back in time\n[02:34.59]Dive dive\n[02:36.74]Dive back in time\n[02:39.69]Dive dive\n[02:41.65]Dive back in time\n[02:46.46]	/audio/Link Click OP 「Dive Back In Time」.mp3	Dive Back In Time	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254006/covers/Link_Click_OP_Dive_Back_In_Time.jpg	1
1021	1021	956	191	[ti:School Rumble ED 「Onna no Ko Otoko no Ko」]\n[ar:Yuko Ogura]\n[al:School Rumble]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:10.77]\n[00:00.00]\n[00:03.69]Otoko no ko wa onna no ko no koto itsumo oikaketeru\n[00:09.59]Ichi-nichi-juu onna no ko no koto bakari kangaeteru\n[00:15.61]Dakedo otoko no ko wa yappari sukoshi baka de\n[00:20.07]Zen zen onna no ko no kimochi nante hora wakaranai mitai\n[00:27.44]Uu hontou ni dame yo ne obaka-san\n[00:30.58]Oshiete hoshii no obakasan-san\n[00:33.49]Sou kono yo de ichi-ban\n[00:34.54]Taisetsuna koto wa\n[00:36.37]Yappari taimingu dato omou kedo...nanchite na\n[00:53.93]Onna no ko mo otoko no ko no koto naze ka suki ni naru no\n[00:59.95]Hi-to-ban-juu nemurenai nante kurai muchuu ni naru\n[01:05.81]Dakedo otoko no ko wa yappari itsumo baka de\n[01:10.41]Zen zen onna no ko no kokoro nante mada wakaranai mitai\n[01:16.73]Nee, hontou ni hontou ni obaka-san\n[01:20.21]Oshiete ageyo ka obaka-san\n[01:23.07]Sou kono yo de ichiban\n[01:24.77]Taisetsuna koto wa\n[01:26.14]Zettai hazushicha ikenai koto wa ne\n[01:29.22]Yappari taimingu dato omou deshou\n[01:35.15]Sou suki dato iu no mo deeto wo suru no mo\n[01:38.16]Nani wo suru no demo\n[01:40.91]Uu kisu toka suru no mo sayonara iu no mo donna to ki ni demo\n[01:46.83]Sou kono yo de ichi-ban taisetsuna koto wa\n[01:49.97]Yappari taimingu dato omou no de\n[01:55.21]Omou no de...konnichiwa\n[02:10.96]Sou suki dato iu no mo deeto wo suru no mo\n[02:13.96]Nani wo suru no demo\n[02:16.68]Uu kisu toka suru no mo sayonara iu no mo donna to ki ni demo\n[02:22.65]Sou kono yo de ichi-ban taisetsuna koto wa\n[02:25.72]Yappari taimingu dato omoubena\n[02:30.91]Omoubena, omoubena, omoubena\n[02:39.50]Pon poko rin\n[02:43.80]Ra ra ra ra..\n[03:07.50]	/audio/School Rumble ED 「Onna no Ko Otoko no Ko」.mp3	Onna no Ko Otoko no Ko	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253642/covers/School_Rumble_ED_Onna_no_Ko_Otoko_no_Ko.jpg	1
1197	1024	1009	242		/audio/Steins Gate 0 OP 「Fatima」.mp3	Fatima	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253639/covers/Steins_Gate_0_OP_Fatima.jpg	1
1277	1277	1276	302	[ti:Ya Boy Kongming!  Insert Song 「Be Crazy for Me」]\n[ar:96Neko]\n[al:Ya Boy Kongming!]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:05:02.04]\n[00:00.00]\n[00:34.03]Be crazy for me Make me shine on you\n[00:37.38]You’re gonna see me When you hear my music\n[00:40.82]I’ll be there for you No matter where you go\n[00:44.28]How do you see me from your point of view\n[00:47.44]I steal your heart\n[00:51.58]I’ll take you higher\n[00:53.58]Are you crazy for me?\n[00:57.71]I’ll take you higher\n[01:00.49]Are you crazy for me?\n[01:02.60]Let me go my own way ’cause I believe you\n[01:06.01]Mikansei no mama jya iya na no\n[01:09.38]Don’t let it fade away I’ll make it come true\n[01:12.84]Demo tsukamu ni wa tarinai no\n[01:16.31]Kanousei nara mugendai\n[01:19.12]Kakete mite, uragiranai\n[01:23.18]Sono omoi ni wa kotaetai\n[01:26.28]Kimi no koe de bring it to me\n[01:30.36]Be crazy for me Make me shine on you\n[01:33.90]You’re gonna see me When you hear my music\n[01:37.51]I’ll be there for you No matter where you go\n[01:40.90]How do you see me from your point of view\n[01:44.15]Oh baby tell me Everything’s alright\n[01:47.66]I hope nobody Wastes his time tonight\n[01:51.22]Make you feel so good I’ll never let you go\n[01:54.60]If you leave me I don’t forgive you\n[01:57.84]I steal your heart\n[02:02.06]I’ll take you higher\n[02:04.00]Are you crazy for me?\n[02:08.32]I’ll take you higher\n[02:10.90]Are you crazy for me?\n[02:12.99]I wanna rock with you We feel the heatbeat\n[02:16.34]Tokei nanka hazushichaeba\n[02:19.81]I sing a song for you party at it’s peak\n[02:23.19]Yumemi gokochi ni sasetageru\n[02:26.58]Moriagannakya tsumannai\n[02:29.71]Me no mae ni kimi ga iru no\n[02:33.54]Seippai tada tsutaetai\n[02:36.61]Kono subete wo show you my soul\n[02:40.98]Be crazy for me Make me shine on you\n[02:44.01]You’re gonna see me When you hear my music\n[02:47.72]I’ll be there for you No matter where you go\n[02:51.11]How do you see me from your point of view\n[02:54.32]Oh baby tell me Everything’s alright\n[02:57.83]I hope nobody Wastes his time tonight\n[03:01.40]Make you feel so good I’ll never let you go\n[03:04.79]If you leave me I don’t forgive you\n[03:08.03]I steal your heart\n[03:23.43]You’re gonna know when I sing with all my heart\n[03:26.17]You must be crazy for me\n[03:30.29]I give you my word my dream is top the chart\n[03:33.22]You must be crazy for me\n[03:36.71]You will be my wings Take me to the place\n[03:39.86]Get together, ride my beat\n[03:43.31]Let me take this chance to thank you for the dance\n[03:47.36]I will keep your eyes on me\n[03:51.51]Be crazy for me Make me shine on you\n[03:54.95]You’re gonna see me When you hear my music\n[03:58.42]I’ll be there for you No matter where you go\n[04:01.86]How do you see me from your point of view\n[04:05.16]Be crazy for me Make me shine on you\n[04:08.65]You’re gonna see me When you hear my music\n[04:12.18]I’ll be there for you No matter where you go\n[04:15.53]How do you see me from your point of view\n[04:18.86]Oh baby tell me Everything’s alright\n[04:22.40]I hope nobody Wastes his time tonight\n[04:25.96]Make you feel so good I’ll never let you go\n[04:29.25]If you leave me I don’t forgive you\n[04:32.39]I steal your heart\n[04:36.18]I’ll take you higher\n[04:38.57]Are you crazy for me?\n[04:43.00]I’ll take you higher\n[04:45.82]Are you crazy for me?\n[04:47.82]	/audio/Ya Boy Kongming! Insert Song 「Be Crazy for Me」.mp3	Be Crazy for Me	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253648/covers/Ya_Boy_Kongming_Insert_Song_Be_Crazy_for_Me.png	1
1282	1282	1281	304		/audio/Yona of the Dawn ED2 「Akatsuki」.mp3	Akatsuki	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253762/covers/Yona_of_the_Dawn_ED2_Akatsuki.jpg	1
1286	993	1284	249		/audio/Your Lie in April OP 「Hikaru Nara」.mp3	Hikaru Nara	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253761/covers/Your_Lie_in_April_OP_Hikaru_Nara.jpg	1
520	20	516	396	[00:00.00] \n[00:16.94]Ano hi kimi wa boku no te wo hiite itta\n[00:24.51]Kabe no mukou ni aru kurashi wo mezasou to\n[00:32.07]Yowakute oresou na boku no kata wo daite\n[00:39.03]Fukai yami no naka wo dokomademo aruita\n[00:46.76]Futari ga mezashita yume wa tooi\n[00:54.35]Futari ga nakushita yume mo tooi\n[01:17.39]Futarikiri de sugosu natsu ga hajimatta\n[01:24.42]Hadashi de fumishimeta tatami ga itakatta\n[01:32.02]Boku no tame ni katte kureta hanabi wa\n[01:39.44]Fusaida mama de ite sore mo muda ni shita\n[01:46.84]Futari ga mezashita yume wa tooi\n[01:54.35]Futari ga nakushita yume mo tooi\n[02:03.56]Tsumaranai mono bakari itsumo aishita\n[02:10.87]Fuete wa komaru neko bakari hirotteta\n[02:18.48]Boku no tonari de wa itsumo kimi ga waratteta\n[02:40.99]Sanpo no kaerimichi kane no oto wo kiita\n[02:48.83]Totemo natsukashikute namida ga koboreta\n[02:56.39]Boku no te wo furikiri kimi wa hashiri dashita\n[03:03.79]Sora wa ima mo kuraku bokura wo tozashiteta\n[03:11.14]Futari ga mezashita yume wa tooi\n[03:18.46]Futari ga nakushita yume mo tooi\n[03:27.92]Tsumetai ame ga futta kimi wa hitori\n[03:35.11]Ashimoto ni korogaru ishi wo miteta\n[03:42.62]Boku wa kizu darake no neko wo daita\n[03:50.01]Mamorare tsudzuketa bokura ga ita\n[03:57.81]Sonna imi wa wasureta mama de yokatta\n[04:34.95]Yagate mata bokura wa tsuremodosareta\n[04:42.60]Yarinokoshita hanabi mo tetsukazu no mama\n[04:50.20]Sore wo daite kimi no heya wo otozureta\n[04:57.67]Kimi wa itsunomanika warawanaku natteta\n[05:06.94]Tsumaranai mono bakari itsumo aishita\n[05:14.03]Fuete wa komaru neko bakari hirotteta\n[05:21.54]Kondo wa boku ga waratte miseru kara\n[05:28.95]Kondo wa boku ga ano natsu e tsuredasu kara\n[05:43.56]	/audio/Little Busters!_ Refrain ED3 「Hanabi」.mp3	Hanabi	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773254095/covers/Little_Busters_Refrain_ED3_Hanabi.jpg	1
521	516	516	334	[00:00.00] \n[00:04.28]onnaji tokoro guru guru mawatte\n[00:11.28]tsukarekitte shimatte mo\n[00:18.75]donna hikari sae sasanai basho kara\n[00:25.68]te wo nobashi tsuzuketetan da yo\n[00:40.47]arigatou subete no owari ni\n[00:47.86]sayonara boku no takaramono\n[00:55.23]donna hikari sae ataranai basho de\n[01:02.53]jitto machitsuzukete itan da yo\n[01:09.44]boku hitori ni naru made\n[01:16.86]donna kanata demo\n[01:22.68]donna hikari demo\n[01:27.70]sugaru ikusen no hoshi wo koete\n[01:39.49]kimi ga warau kara boku mo waraun darou\n[01:49.42]sonna hi ha yoku harewatatta sora no shita\n[02:22.27]kimi ha itsumo boku no ushiro kara\n[02:30.60]kao wo dashi nozokikonde ita\n[02:38.04]soko kara mita sekai sore ha donna fuu\n[02:45.07]hitasura ni tanoshii kana\n[02:51.98]niji datte mieru kana\n[02:59.47]donna kanata ni mo\n[03:05.51]owari ga matte iru\n[03:10.47]susumu kyou mo niji no mukou made\n[03:22.26]kimi ga warau nara boku mo warau kara\n[03:32.28]ano tooi natsu no hi made mukae ni yuku kara\n[03:48.72]donna kanata demo\n[03:54.67]mienai hikari demo\n[03:59.68]tsukamu ikusen no toki wo koete\n[04:11.33]kimi ga warau kara minna mo waraun darou\n[04:21.42]sonna hi ga kuru nante omotte nakatta no ni\n[04:37.57] 	/audio/Little Busters!_ Refrain ED5 「Haruka Kanata」.mp3	Haruka Kanata	ED5	https://res.cloudinary.com/ddc6silap/image/upload/v1773254090/covers/Little_Busters_Refrain_ED5_Haruka_Kanata.jpg	1
596	596	595	237	[00:00.00] \n[00:02.34]If everyone is not special\n[00:04.99]Maybe you can be what you want to be\n[00:07.53]Sorezore no kotae mitsukaru darou\n[00:12.99]1%,2%,3%,4%,5%,6%,7%,8%,9%,10%…\n[00:17.42]11%,12%,13%,14%,15%,16%,17%,18%,19%,20%…\n[00:22.95]21%,22%,23%,24%,25%…\n[00:25.78]Akogare nayami panpuappu\n[00:27.63]26%,27%,28%,29%,30%…\n[00:30.48]Jibunsagashi terepashii\n[00:32.71]31%,32%,33%,34%,35%…\n[00:35.43]Naimononedari saiko shouda\n[00:37.75]36%,37%,38%,39%,40%…\n[00:41.03]Seishun soruto supurasshu\n[00:43.59]Mob? Mob? What do you want?\n[00:46.18]Mob? Mob? Why do you want?\n[00:48.67]Mob? Mob? Who do you want?\n[00:51.16]Move! Move! Just like Mob!\n[00:53.33]If everyone is not special\n[00:55.37]Maybe you can be what you want to be\n[00:58.04]Yorokobi kanashimi kakaetemo\n[01:03.39]Your life is your own, OK? tokubetsu janakutemo OK\n[01:08.27]Sorezore no kotae mitsukaru darou\n[01:12.86]41%,42%,43%,44%,45%,46%,47%,48%,49%,50%…\n[01:18.11]51%,52%,53%,54%,55%,56%,57%,58%,59%,60%…\n[01:23.18]61%,62%,63%,64%,65%…\n[01:26.50]Aisowarai reizaa biimu\n[01:28.33]66%,67%,68%,69%,70%…\n[01:31.45]Kuuki yomenai oni rasshu\n[01:33.23]71%,72%,73%,74%,75%…\n[01:36.89]Jishin soushitsu saikoweebu\n[01:38.45]76%,77%,78%,79%,80%…\n[01:41.57]Koi no oharai gurafikku\n[01:44.19]Mob? Mob? Where do you go?\n[01:46.65]Mob? Mob? Which do you go?\n[01:49.22]Mob? Mob? How do you go?\n[01:51.75]Love? Love? Just like Mob?\n[01:53.76]If everyone is so special\n[01:55.98]Maybe you can't be what you want to be\n[01:58.67]Itsuwari sagesumi ataetemo\n[02:04.09]Your life is your own, OK? tokubetsu na jibun nara OK?\n[02:08.79]Sorezore no kotae mitsukaru darou\n[02:19.93] \n[02:45.32]Mob! Mob! Whatever you want!\n[02:47.38]Mob! Mob! Whenever you want!\n[02:49.87]Mob! Mob! Wherever you want!\n[02:52.20]Move! Move! Just like Mob!\n[02:54.42]If you can notice not alone\n[02:56.75]Maybe you will find your own answer\n[02:59.28]Arasoi nikushimi kakaetara\n[03:04.78]Your life is your own, OK? nigedashitatte OK\n[03:09.55]Sore ga dekiru nara machigawanai\n[03:14.70]If everyone is not special\n[03:17.02]So you can be what you want to be\n[03:19.62]Yorokobi kanashimi kakaetemo\n[03:24.84]Your life is your own, OK! tokubetsu janakutemo OK\n[03:29.71]Sorezore no kotae mitsukaru darou\n[03:34.86]81%,82%,83%,84%,85%,86%,87%,88%,89%,90%…\n[03:40.23]91%,92%,93%,94%,95%,96%,97%,98%,99%…\n[03:50.91] \n	/audio/Mob Psycho 100 OP「99」.mp3	99	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253668/covers/Mob_Psycho_100_OP_99.jpg	1
951	43	950	326		/audio/Say I Love You ED2 「Sarari」.mp3	Sarari	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253653/covers/Say_I_Love_You_ED2_Sarari.jpg	1
522	522	516	266		/audio/Little Busters!_ Refrain OP 「Boys be Smile」.mp3	Boys be Smile	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252417/covers/Little_Busters_Refrain_OP_Boys_be_Smile.jpg	1
1255	1254	1254	415		/audio/Weathering with you 「Is There Still Anything Th.mp3	Is There Still Anything That Love Can Do?	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253657/covers/Weathering_with_you_Is_There_Still_Anything_That_Love_Can_Do.jpg	1
1263	18	1262	247		/audio/Why the hell are you here, Teacher!_ OP 「Bon Ky.mp3	Bon Kyu Bon wa Kare no Mono	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253659/covers/Why_the_hell_are_you_here_Teacher_OP_Bon_Kyu_Bon_wa_Kare_no_Mono.jpg	1
1268	74	1268	287		/audio/WorldEnd ED 「From」.mp3	From	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253656/covers/WorldEnd_ED_From.jpg	1
51	51	50	275		/audio/Asobi Asobase OP 「Three Piece」.mp3	Three Piece	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253681/covers/Asobi_Asobase_OP_Three_Piece.jpg	1
57	57	57	222		/audio/Astra Lost in Space ED 「Glow at the Velocity of.mp3	Glow at the Velocity of Light	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253705/covers/Astra_Lost_in_Space_ED_Glow_at_the_Velocity_of_Light.jpg	1
60	60	59	211		/audio/Baka and Test ED2 「Hare Tokidoki Egao」.mp3	Hare Tokidoki Egao	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253682/covers/Baka_and_Test_ED2_Hare_Tokidoki_Egao.jpg	1
426	426	426	352	[00:00.00] \n[00:26.56]Semi no uta waraigoe\n[00:33.61]Yuuyake no akaneiro\n[00:39.65]Kaerimichi toomawari\n[00:47.53]Yakusoku wa "mata ashita"\n[00:58.04]Natsu wa tada sakihokori\n[01:10.93]Sono inochi kagayakase\n[01:24.32] \n[01:38.97]Owaranai o-hanashi no\n[01:46.06]Sono saki ni kiga tsuite\n[01:52.45]KARASU-tachi toozakari\n[02:00.42]Dokoka e to tonde yuku\n[02:08.24] \n[02:11.17]Natsu wa tada kakenukeru\n[02:24.78]Takaramono wo shimau youni\n[02:38.38] \n[03:25.98]Itsumade mo natsukashii\n[03:33.61]Ano koro wa koganeiro\n[03:40.61]Nanigenai mainichi no\n[03:48.70]Katasumi wo terashiteru\n[04:00.92]Natsu wa mada yatte kuru\n[04:14.78]Yakusoku wo mamoru youni\n[04:28.17]Natsu wa tada sakihokori\n[04:41.82]Sono inochi kagayakase\n[04:55.16] \n	/audio/Into The Forest of Fireflies ED Theme 「Natsu wo.mp3	Natsu wo Miteita	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253679/covers/Into_The_Forest_of_Fireflies_ED_Theme_Natsu_wo_Miteita.jpg	1
533	137	532	246	[00:00.00] \n[00:03.87](Let's look for Sparkling Daydream...)\n[00:09.95] \n[00:15.54]Shibaraku mitsume atte kara\n[00:19.66]Sorasu made ni nani wo kangaeteta no?\n[00:25.11]...Ki ni naru\n[00:26.48]Kuchibiru togaraseta watashi wo mite\n[00:30.73]"Doushita no?" tte\n[00:32.48]Kiite kuru no matte miru no\n[00:36.39]Gomakashita ato no hitorigoto wa\n[00:42.18]Hazukashii kara\n[00:44.78]Kikanaide kureru?\n[00:48.19]Ato ni hikenai hodo\n[00:51.03]Hikare au koi\n[00:53.38]Mou hajimatteta\n[00:58.72]Yume nara takusan mita\n[01:01.42]Sameta mama demo mada aitai\n[01:05.31]Kimi ga sousaseta\n[01:07.56]Koi wa yokubari dane\n[01:09.81]Tobihanesou na kokoro no\n[01:12.46]Yuku mama ni yukou yo\n[01:15.25]Risou mo mousou mo genjitsu mo\n[01:18.05]Subete kimi wo jiku ni mawaru\n[01:20.68]Atarashii sekai e\n[01:26.24] \n[01:27.08](Love's get me looking so Crazy...)\n[01:31.13] \n[01:37.63]Guuzen kikoeta dareka no koe ga\n[01:41.86]Mou ichido kikoeta toki\n[01:45.25]Hitsuzen wo shinjita\n[01:47.50]Sonna toki kotoba ni imi wanakute\n[01:53.41]Karada ga ugoku kimi wo sagashite\n[01:59.72]Itami nejifuseru you ni genjitsu touhi\n[02:04.43]Demo soko ni kimi ga arawarete\n[02:10.29]Okubyou na watashi sura\n[02:13.12]dakishimete kureta\n[02:15.57]Niji ga kakaru asa\n[02:21.19]Kireina sora miagete\n[02:23.80]Kimi to kakeru yume miru no\n[02:27.53]Ashita mo soudayo koi wa owaranai\n[02:32.19]Onaji hoshi ni umareta\n[02:34.61]Konna chansu hoka ni nai\n[02:37.53]Unmei to shukumei ga meguru\n[02:40.40]Mahou ni kakerareru youna\n[02:42.97]Kagayaku kiseki e\n[02:48.58] \n[03:07.34]Risou to mousou to genjitsu wa\n[03:11.72]Chigau youde onaji nanda\n[03:18.32]Katachi ni wa dekinai keredo\n[03:21.18]Dore mo taisetsu to satoru no\n[03:25.04]Hitomi ga yoru wasurenai\n[03:27.59]Yumenara takusan mita\n[03:30.23]Sameta mama demo mada aitai\n[03:34.10]Kimi ga sou saseta\n[03:36.34]Koi wa yokubari dane\n[03:38.64]Tobihanesouna kokoro no\n[03:41.23]Yuku mama ni yukou yo\n[03:44.11]Risou mo mousou mo genjitsu mo\n[03:46.82]Subete kimi wo jiku ni mawaru\n[03:49.62]Atarashii sekai e\n[03:57.32]	/audio/Love Chunibyou And Other Delusions OP 「Sparklin.mp3	Sparkling Daydream	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254058/covers/Love_Chunibyou_And_Other_Delusions_OP_Sparkling_Daydream.jpg	1
534	532	532	236	[00:00.00] \r\n[00:15.42]Mebuita yamiyo ga haran he to hakou\r\n[00:18.65]Waku waku suru nee\r\n[00:21.48]Nanatsu no oto eigou yori hanatarete\r\n[00:26.09]Doki doki suru nee\r\n[00:26.95]Matsui no rakuin anshou ni hirameku\r\n[00:30.92]Mada tsudzukeru ki na no?\r\n[00:32.99]Ai no setsuri ni kyokkou matataku\r\n[00:36.88]Mou yamenasai....\r\n[00:38.46]Bokura wa hitotsu ni nari ten wo kakete\r\n[00:44.16]Hokori wo sakebi chiru hanabi no you da\r\n[00:49.94]Kagayaki wa setsuna ni...Hazeta!!\r\n[00:55.73]Douke wa seigi no tategami wo hashirasete\r\n[01:01.35]Gusha wa tsukikage ni kyomou wo idaku\r\n[01:07.22]Genjitsu sekai -GEEMU- ga bokura wo\r\n[01:09.78]Oitsumeru tame ni aru naraba\r\n[01:12.91]Semete kuchinu hodo no baka de aritai\r\n[01:17.97]Reiki suru tamashii de hoeta--...\r\n[01:23.18]Van!shment Th!s World!!\r\n[01:25.59] \r\n[01:36.01]Tsurugi wo te ni shite yo wo abaku mono\r\n[01:39.20]Kakkoii yo nee\r\n[01:41.67]Hayari ni sugatte iki nagara eteru mono\r\n[01:46.23]Kakkowarui nee\r\n[01:47.37]Bokura wa sabinai!!\r\n[01:49.02]Sousei suru tame no DAAKU HIIROO de ii\r\n[01:53.21]Shinobi wo hokoru jaoo de aritai...!!\r\n[01:57.62]...Sore wa dou na no?\r\n[01:59.79]Koudou sono mono ga sadame nandaze?\r\n[02:04.73]Kami ni tayoru yori mo jibun wo shinjiro\r\n[02:10.35]Sugata naki kyoufu wo...Tayase!!\r\n[02:16.15]Karera wa haruka na sora ni risou wo hasete\r\n[02:21.86]Bokura wa kabuite hoshi wo kuruwaseru\r\n[02:27.58]Houmuritai no wa zetsubou suru shika nou ga nai oroka na rettoukan\r\n[02:36.08]SHINAPUSU ga hajikeru!!\r\n[02:38.53] \r\n[02:52.16]Ashita ga horibite mo\r\n[02:54.92]Boku wa eien de aritai\r\n[02:57.58]Kuzure yuku shizen no naka\r\n[03:00.76]Sutarenai no wa yume dake datta\r\n[03:08.10]Kokou no jakusha yo takerishi hatou wo koete\r\n[03:13.58]Mu he to kaeru made ijou -Ima- wo buchikowase\r\n[03:19.40]Genjitsu sekai -GEEMU- ga bokura wo oitsumeru tame ni aru naraba\r\n[03:25.12]Semete kuchinu hodo no baka de aritai\r\n[03:30.06]Keshitobase banshou no kotowari\r\n[03:35.85]Reiki suru tamashii de hoero--...\r\n[03:41.20]Van!shment Th!s World!!\r\n[03:45.78]	/audio/Love Chunibyou And Other Delusions S2 ED 「Van!s.mp3	Van!shment Th!s World	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253863/covers/Love_Chunibyou_And_Other_Delusions_S2_ED_Van_shment_Th_s_World.jpg	2
61	61	59	243		/audio/Baka and Test OP 「Perfect-area Complete! 」.mp3	Perfect-area Complete! 	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253684/covers/Baka_and_Test_OP_Perfect-area_Complete.jpg	1
73	73	73	333		/audio/Beautiful Bones -Sakurako_s Investigation- ED 「.mp3	Uchiyoserareta Boukyaku no Zankyou ni	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253702/covers/Beautiful_Bones_-Sakurako_s_Investigation-_ED_Uchiyoserareta_Boukyaku_no_Zankyou_ni.jpg	1
74	74	73	261		/audio/Beautiful Bones -Sakurako_s Investigation- OP 「.mp3	Dear answer	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253792/covers/Beautiful_Bones_-Sakurako_s_Investigation-_OP_Dear_answer.jpg	1
86	14	13	226		/audio/Ah! My Goddess ED 「Negai」.mp3	Negai	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253789/covers/Ah_My_Goddess_ED_Negai.jpg	1
241	241	241	250		/audio/ef ~ A Tale of Memories ED 「I_m here」.mp3	I'm here	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253685/covers/ef_A_Tale_of_Memories_ED_I_m_here.jpg	1
67	67	66	275		/audio/Bakemonogatari OP 「staple stable」.mp3	staple stable	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253713/covers/Bakemonogatari_OP_staple_stable.jpg	1
535	137	532	260	[00:00.00] \r\n[00:03.80]I wanna fallin' LOVE....\r\n[00:07.86] \r\n[00:20.74]Yokan--...Yume ga tsudzuku\r\n[00:24.83]Yakusoku shite mo kokoro ga doko ka de obieteru mitai\r\n[00:30.94]Hitori janai tte shinjitai no ni\r\n[00:36.66]Omoi tsudzuketeru dake de shiawase nante ienai ne\r\n[00:41.88]Utsuro na jishin seotteite mo kimi ga warau\r\n[00:48.98]Soshite watashi no yuuki ni naru\r\n[00:51.95]Hitotsu no kotoba de kimi no sekai wo kaeraretara\r\n[00:56.63]Futatsu no koi ga shinka suru honto da yo\r\n[01:02.40]Meguraseta mayoi ga mitsuketa kotae wa\r\n[01:07.74]Itsudemo kimi ni michibikareta\r\n[01:10.44]Todokeru kakugo ga zama ni naranakute mo\r\n[01:14.92]Sunao ni tsutaetai (kokoro aru ga mama koi ga kirameku)\r\n[01:20.36]Real come on voice hibiki wataru yo\r\n[01:26.10] \r\n[01:36.49]Mata surechigatte\r\n[01:40.43]Massugu sugiru kokoro to urahara tomadoi no meiro\r\n[01:46.45]Kimi no honshin ga mienakunatteku\r\n[01:52.01]Daisuki ijou no kimochi ni namae wo tsuketai kedo\r\n[01:57.43]Tsukai konasenai tada damatte kokoro nozoku\r\n[02:04.73]Kawasu hohoemi futatsu no ito\r\n[02:07.89]Afureru omoi wo nomikomi gyutto dakishimeta\r\n[02:12.19]Kotoba janai koe wo kimi he... Kikoeteru?\r\n[02:18.16]Kietakunaru kurai okubyou na mabuta wa\r\n[02:23.31]Yappari kimi wo mata oikakeru\r\n[02:25.82]Subete no chikara wa koi kara wakiagaru\r\n[02:30.74]Yasashii oikaze (kokoro itsumo itsu made mo irodoru)\r\n[02:35.79]You touch voice tonari de zutto\r\n[02:41.20] \r\n[02:47.05]Tatoe yurameki ga fuantei da to shite mo\r\n[02:52.20]Futari wa onaji hou wo muiteru\r\n[02:57.01]Sore wa dare ni mo saigen dekinai kiseki\r\n[03:06.98] \r\n[03:08.36]Where you can stay forever\r\n[03:13.43] \r\n[03:23.36]Kanatta negai wa futatabi chigau yume ni naru\r\n[03:27.92]Sekai wa kimi de mawatteku honto da yo\r\n[03:33.76]Kirei ni ikiteku no wa muzukashii kara\r\n[03:38.97]Ari no mama no watashi wo mitete\r\n[03:44.19]Kono koe ga todoku kagiri soba ni iru kara\r\n[03:48.87]Haruka na kanata he (tsureteku omoi kimi to futari nara)\r\n[03:54.24]Real my voice doko made mo todoke\r\n[04:02.16]	/audio/Love Chunibyou And Other Delusions S2 OP 「VOICE.mp3	VOICE	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254192/covers/Love_Chunibyou_And_Other_Delusions_S2_OP_VOICE.jpg	2
547	547	546	234	[ti:Maison Ikkoku ED2 「Ci · ne · ma」]\n[ar:PICASSO]\n[al:Maison Ikkoku]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:23.4.20]\n[length:03:53.94]\n[00:00.00]\n[00:18.44]Michiranu machi no toori ame ano hi no kimi ha\n[00:26.60]Nureta hiiru wo ki ni shiteta\n[00:33.77]Osanasa kakushita yokogao itsuka kawashita\n[00:41.30]Kotoba wo ima mo omoidaseru\n[00:47.48]Hajime kara shinema kanjisasete\n[00:55.16]Kimi ga sasayaku shizukana rasuto shiin\n[01:03.55]Kakaeta hadaka no tsumasaki kyou ha chiisaku\n[01:10.82]Yurashite bonyari miteta kedo\n[01:18.27]Sukoshi dake kanashii hito wo enjitai nara\n[01:26.03]Makuai ni ikaga? Boku no LOVE SONG FOR YOU\n[01:32.24]Hajime kara shinema kanjisasete\n[01:39.87]Kimi ga sasayaku shizukana rasuto shiin\n[02:02.01]Tasogare matsu dake no gogo no hamabe de futari\n[02:10.70]Wasurekaketa suteppu de\n[02:17.93]Tadotta mijikai kioku ni kasanaru sutoorii\n[02:25.53]Makugire shirasete nami ga sarau yo\n[02:33.19]Hajime kara shinema kanjisasete\n[02:41.33]Kimi ga sasayaku shizukana rasuto shiin\n[02:48.67]Saigo made shinema mi wo makaseta\n[02:56.05]Tsukuri warai no katto de sayonara\n[03:03.72]Hajime kara shinema kanjisasete\n[03:10.97]Kimi ga sasayaku shizukana rasuto shiin\n[03:18.31]Hajime kara shinema shinema...\n[03:25.07]	/audio/Maison Ikkoku ED2 「Ci · ne · ma」.mp3	Ci · ne · ma	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253722/covers/s6vib6m6ob9f3hjjsefl.jpg	1
414	414	414	200	[00:00.00] \n[00:13.71]Yo, umm\n[00:17.21]Iro o kasanete\n[00:19.26]Uso o kasanete\n[00:21.31]Kireina mama ja irarenai\n[00:25.38]Kagayakitakute hane ga hoshikute\n[00:29.15]Kizukeba oboreteita\n[00:32.37]Butterfly\n[00:34.38]Butterfly\n[00:38.27]Butterfly\n[00:41.38]I wish that I could hide\n[00:43.82]In a purple sky\n[00:45.57]No one see me cry\n[00:48.27]Butterfly\n[00:48.31]Butterfly\n[01:04.31]Butterfly\n[01:05.22]Aishitakute mo\n[01:07.25]Aisenai no wa\n[01:09.26]Kegare o shiranai dakedato\n[01:13.32]Kumo no nagare ga urayamashikute\n[01:17.22]Tadatada nagameteita\n[01:20.28]Butterfly\n[01:22.47]Butterfly\n[01:26.46]Butterfly\n[01:29.18]I wish that I could hide\n[01:31.72]In a purple sky\n[01:33.65]No one see me cry\n[01:36.37]Butterfly\n[01:39.25] \n[01:45.20]Butterfly\n[01:52.63]Butterfly\n[01:53.49]Tell me, tell me , where are my wings?\n[01:57.06]Dare ni mo mienai sekai e\n[02:01.08]Tell me, tell me , where are my wings?\n[02:05.20]Ima sugu tondeikitai ...\n[02:08.94] \n[02:16.36]Butterfly\n[02:18.36]Butterfly\n[02:22.36]Butterfly\n[02:25.15]I wish that I could hide\n[02:27.61]In a purple sky\n[02:29.64]No one see me cry\n[02:32.50]Butterfly\n[02:32.96]Tell me, tell me, where are my wings?\n[02:41.05]Tell me, tell me, where are my wings?\n[02:45.77] \n[02:48.29]Butterfly\n[03:04.47]Butterfly\n[03:06.75] \n	/audio/ID_ Invaded OST Theme「 Butterfly」.mp3	 Butterfly	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253737/covers/ID_Invaded_OST_Theme_Butterfly.jpg	1
466	466	464	272	[00:00.00] \r\n[00:00.55]Sora no aosa sae utagai tsuzuke\r\n[00:06.61]Bokura koko made kita no darou\r\n[00:11.29]Me wo tojiru koto de\r\n[00:14.79]Nanimo miezu ni kowakunakatta\r\n[00:21.86]Sekai no subete o utagaitsuzuke\r\n[00:28.09]Bokura koko made kita no darō\r\n[00:32.77]Hontō wa subete o shinjiru koto ga\r\n[00:38.73]Kowakatta no darō\r\n[00:41.86] \r\n[00:43.52]Yasashisa sura utagatta\r\n[00:48.75]Tsunaida te no atatakasa shiru made\r\n[00:54.02]Wasurete ita namida ga\r\n[00:58.44]Kimi no mune no naka de afuredashita\r\n[01:03.78]Kaze ni fukarete kaze ni fukarete\r\n[01:09.08]Kie sō ni naru kimochi o\r\n[01:13.71]Anata ga tsuyoku anata ga tsuyoku\r\n[01:19.72]Tsunagitomete kureta kara\r\n[01:24.36]Mō mayowazu ni aruite ikeru yo\r\n[01:33.73] \r\n[01:36.69]Kawasu kotoba ni mo sunao ni narezu\r\n[01:42.69]Bokura omoi wo kakushiteta\r\n[01:47.40]Me wo akereba hora\r\n[01:50.77]Zutto tonari ni kimi ga ita no ni\r\n[01:58.14]Kono mune no setsunasa sura\r\n[02:03.40]Hontou ni kimi wo suki datte akashi ni naru\r\n[02:08.77]Yowasa wo misenai koto ga\r\n[02:13.07]Tsuyosa janai koto ni kizuketan da\r\n[02:18.34]Kaze ni fukarete kaze ni fukarete\r\n[02:23.71]Kogoesou ni naru toki mo\r\n[02:28.42]Anata ga ireba anata ga ireba\r\n[02:34.46]Kitto koete ikeru kara\r\n[02:39.15]Mou kowakunai shinjite ikeru yo\r\n[02:48.58] \r\n[02:51.43]Itsumo bokura wa bukiyou na hodo ni\r\n[02:56.66]Taisetsu na mono ni tadori tsukun da\r\n[03:02.12]Ima sugu kimi ni tsutaetain da\r\n[03:07.34]Ookina koe de "anata ga suki da" to\r\n[03:16.38] \r\n[03:17.08]Wasurenai kara nakusanai kara\r\n[03:22.34]Anata ga kureta tsuyosa wo\r\n[03:27.13]Donna toki demo soba ni itai yo\r\n[03:33.05]Kono aoi sora no shita de\r\n[03:37.78]Kaze ni fukarete kaze ni fukarete\r\n[03:43.76]Kiesou ni naru kimochi wo\r\n[03:48.49]Anata ga tsuyoku anata ga tsuyoku\r\n[03:54.40]Tsunagi tomete kureta kara\r\n[03:59.15]Mou mayowazu ni aruite ikeru yo\r\n[04:08.42] \r\n	/audio/Kaguya sama_ Love is War S2 ED 「Kaze ni Fukaret.mp3	Kaze ni Fukarete	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253794/covers/Kaguya_sama_Love_is_War_S2_ED_Kaze_ni_Fukarete.jpg	2
1110	1110	1107	260	[00:00.00] \n[00:15.73]kyuu ni senaka wo mukete kakedashita wa\n[00:21.97]hoka no ko ni yasashiku shiteta kara yo\n[00:29.75]Boy onegai oikakete yo\n[00:36.28]ato ni wa hikenai kara\n[00:39.71]PUN! PUN PUN!\n[00:45.28]I am so sorry\n[00:46.27]GOMEN to ienakute, GOMEN NE\n[00:50.66]shinjite iru no ni kuchibiru ga togaru\n[00:58.85]kawaiku narenakute GOMEN NE\n[01:04.47]kosame no furu machi tsukamaete\n[01:10.13]furimuku kara nakanaori no CHU~ wo shite\n[01:18.79]atsui ryouude no naka de\n[01:31.37]kaze wo hiita mitai to yorisottara\n[01:38.28]kaerou to sekasu no arienai wa\n[01:45.99]Boy HONTO wa koi no netsu yo\n[01:52.47]MUUDO ga dainashi desho\n[01:55.91]CHIKU! CHIKU CHIKU!\n[02:01.06]Come closer to me\n[02:02.55]jouzu ni ienakute, GOMEN NE\n[02:07.28]hitori de kaeru wa fukureteru mama de\n[02:14.97]suki tte ienakute, GOMEN NE\n[02:19.75]yoru made byouyomi hikitomete\n[02:26.29]tsurenai furi dekinai yo na CHU~ wo shite\n[02:34.78]memai kanjichau kurai\n[03:04.45]Boy yasashiku dakishimete yo\n[03:10.49]jikan ga tomaru you ni\n[03:13.97]KYUN! KYUN KYUN!\n[03:18.62]I am so sorry\n[03:20.57]GOMEN to ienakute, GOMEN NE\n[03:25.28]shinjite iru no ni kuchibiru ga togaru\n[03:32.90]kawaiku narenakute GOMEN NE\n[03:38.17]kosame no furu machi tsukamaete\n[03:44.38]furimuku kara nakanaori no CHU~ wo shite\n[03:53.15]atsui ryouude no naka de\n[03:58.31] 	/audio/The Familiar of Zero S3 ED 「Gomen ne」.mp3	Gomen ne	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253738/covers/The_Familiar_of_Zero_S3_ED_Gomen_ne.jpg	3
82	82	82	233		/audio/Bloom into You ED 「hectopascal」.mp3	hectopascal	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253800/covers/Bloom_into_You_ED_hectopascal.jpg	1
370	263	369	305	[00:00.00] \n[00:10.72]Zenzen suki ja nakatta\n[00:14.25]Horā eiga to kyarameru aji no kisu\n[00:19.65]Zenzen suki ni narenakatta\n[00:23.17]Sore na no ni ne\n[00:25.43]Ima wa himei o age nagara\n[00:29.46]Kimi no yokogao o sagashite iru\n[00:36.98]Kūkyo na kokoro no otoshiana\n[00:41.13]Kura sugite nani mo mienai\n[00:45.76]Konkyo nante hitotsu mo nai no ni sa\n[00:50.02]Karada ga hashiridashiteku\n[00:57.36]Akaku somatta sora kara\n[01:01.76]Afuredasu shawā ni utarete\n[01:05.80]Nagaredasuukabiagaru\n[01:10.02]Ichiban yowai jibun no kage\n[01:14.91]Aoku nijinda omoide kakusenai no wa\n[01:23.28]Mō ichi do onaji hibi o\n[01:27.80]Motomete iru kara\n[01:33.15]Zenzen suki ja nakatta\n[01:36.54]Hora, ano yobi kata manga no shujinkō mitai de\n[01:41.96]Zenzen suki ni narenakatta n da\n[01:45.23]Sore na no ni ne\n[01:47.65]Ima mo nita kotoba ni karada ga ugoku yo\n[01:54.11]Hiniku na omoide na no sa\n[01:59.24]Nankai mo uō saō shite mite mo\n[02:03.46]Kura sugite nanimo mienai\n[02:07.99]Sō ka i mada kakurete iru no ka i\n[02:11.97]Tobidashite o ide memorī\n[02:19.28]Takaku kakageta tenohira\n[02:23.92]Todoku ki ga shita n da tashika ni\n[02:28.05]Mawaridasuosoikakaru\n[02:32.29]Akuma no kao o shita yatsu-ra ga\n[02:37.14]Aitai hito ni aenai\n[02:41.68]Sonna akumu o\n[02:45.45]Kumo ni kaete tabete yaru yo\n[02:50.13]Kanashiku naru kara\n[02:57.25]Itsu mo itsu mo itsu mo itsu mo\n[02:59.23]Kimi ga kimi ga kimi ga kimi ga\n[03:01.35]Saisho ni inakunatte shimau\n[03:05.87]Nande nande nande nande nande\n[03:08.04]Boku ni boku ni boku ni boku ni\n[03:10.23]Sayonara mo iwazu ni\n[03:15.61]Sora ni natta no?\n[03:19.21] \n[03:37.10]Akaku somatta sora kara\n[03:41.71]Afuredasu shawā ni utarete\n[03:45.91]Nagaredasuukabiagaru\n[03:50.04]Ichiban yowai jibun no kage\n[03:54.86]Aoku nijinda omoide kakusenai no wa\n[04:03.13]Mō ichi do onaji hibi o\n[04:07.78]Motomete iru kara\n[04:11.63]Kimi ga shitte iru\n[04:14.17]Sora no ao-sa o shiritai kara\n[04:21.21]Oikakete iru\n[04:25.74]Oikakete iru\n[04:31.58]Todoke\n[04:36.90]	/audio/Her Blue Sky OP Theme 「Her Blue Sky」.mp3	Her Blue Sky	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253748/covers/Her_Blue_Sky_OP_Theme_Her_Blue_Sky.jpg	1
741	234	740	283	[00:00.00] \n[00:42.81]Mawari tsuzukeru haguruma ni wa narisagaranai\n[00:49.31]Heikin enjiru tanjou kara hajimatta jigoku\n[00:56.13]Asobi hanbun de kami ga michibiku banjou no sekai\n[01:00.98]No no no game no life\n[01:02.63]Nurui heion o bassari kirisute\n[01:05.90]Eiko e no kaidan ni sonzai kizamunda\n[01:10.23]Me ni utsuru no wa kanzen shouri no unmei\n[01:14.73]Nanimokamo keisan doori\n[01:18.57]Kaeteyaru somaranai kuuhaku de\n[01:23.71]We are maverick kyuusai nante iranai\n[01:29.98]Donna rifujin osooutomo\n[01:33.21]Kateba ii dake no hanashi darou\n[01:36.82]Kakehiki to sainou ga muhai izanau\n[01:43.08]Umarenaoshita inochi de tanoshimu sa\n[01:49.55]Jibun dake wa jibun shinjiteru\n[01:57.12] \n[01:59.66]Kokoro ni hisomu yami yori tsuyoi aite wa inai\n[02:06.25]Kujikenu kagiri soko ni haiboku wa arienai\n[02:12.70]Uwabe no kosei de anshin to hikikae ni puraido korosu na\n[02:17.66]No no no sense of life\n[02:19.49]Yaban na zatsuon o kippari ketobashite\n[02:22.62]Dare yori junsui na koe agerunda\n[02:27.09]Tatakau koto wa kitto machigai janai\n[02:31.45]Tegotae ga oshiete kureta\n[02:35.48]Subete ushinattemo kachinokore\n[02:40.46]We are maverick joushiki nante iranai\n[02:46.89]Mae e narae mukau saki ni\n[02:50.07]Matteru no wa taikutsu darou\n[02:53.68]Iinari ja tsumaranai idondeyaru\n[02:59.85]Umarenaoshita inochi mo koma ni shite\n[03:06.47]Jibun dake no michi o saigo made\n[03:16.31] \n[03:31.97]Mayowanai erabareshi mono\n[03:35.82]Makka na unubore demo\n[03:38.50]Hokorashiku ikinuku tame no houhou o\n[03:43.74]Hitotsu shika shiranai kara\n[03:49.14]We are maverick kyuusai nante iranai\n[03:55.37]Donna rifujin osoutomo\n[03:58.87]Kateba ii dake no hanashi darou\n[04:02.03]Kakehiki to sainou ga muhai izanau\n[04:08.54]Umarenaoshita inochi de tanoshimu sa\n[04:14.97]Kono sekai te ni shite waraunda\n[04:18.69]We are maverick saikyou no maverick gamers\n[04:24.94]Kuuhaku naraba nanimono ni mo nareru\n[04:31.32]Jibun dake wa jibun shinjiteru\n[04:38.73] \n	/audio/No Game No Life OP 「This Game」.mp3	This Game	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253742/covers/No_Game_No_Life_OP_This_Game.jpg	1
485	485	484	285	[ti:Koi to Uso OP 「Kanashii Ureshii」]\n[ar:Frederic]\n[al:Love and Lies]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:44.61]\n[00:00.00]\n[00:20.47]Makka na sen o egaita chippoke na kokoro no ohanashi\n[00:27.28]Bokura no mirai wa doko ni mukatte hikaru no?\n[00:34.08]Tsuzuki no sen o egaita irozuite shimau tabi ni mabushii\n[00:40.76]Sonna kokoro no rizumu o tsunagidasu\n[00:47.53]Kanashii kanashii kanashii kanashii\n[00:54.25]Ureshii ureshii ureshii ureshii\n[01:01.08]Futatsu no kanjou ni yusaburarete wa\n[01:07.74]Mada minu yubisaki o terashidashiteku dake\n[01:14.58]Kono mama uso demo ii kara yume oyogasete\n[01:21.30]Tadashii tadashii ima o sagashiteku\n[01:28.11]Bokura wa mienai mirai o shinjiteru\n[01:34.62]Dakara tadashii tadashii ima o sagashite wa hikatta\n[01:55.66]Makka na reeru tsunaida hottokenai kimi no ohanashi\n[02:02.28]Bokura no yogisha wa doko ni mukatte hashiru no?\n[02:09.10]Kemuri ni maita omoi wa furimuite shimau tabi ni sabishii\n[02:15.83]Sonna kokoro no biito o tsunagidasu\n[02:22.60]Kanashii kanashii kanashii kanashii\n[02:29.37]Ureshii ureshii ureshii ureshii\n[02:36.27]Futatsu no kanjou ni yusaburarete wa\n[02:42.92]Mada minu yubisaki ni susumitsuzukeru dake\n[02:56.28]Sayonara, sayonara\n[03:05.87]Kanashii dake no bokura no hanashi\n[03:11.41]Kono mama uso demo ii kara yume oyogasete\n[03:18.19]Tadashii tadashii ima o sagashiteku\n[03:24.91]Bokura wa mienai mirai o shinjiteru\n[03:31.22]Dakara tadashii tadashii ima o sagashiteku\n[03:38.55]Bokura wa mada minu yukisaki ni ashi o mukete\n[03:45.45]Kanashii kanashii kanashii ya tte mo tomaranai\n[04:05.70]Kanashii kanashii kanashii kanashii\n[04:12.41]Ureshii ureshii ureshii ureshii\n[04:17.94]	/audio/Koi to Uso OP 「Kanashii Ureshii」.mp3	Kanashii Ureshii	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253797/covers/Koi_to_Uso_OP_Kanashii_Ureshii.jpg	1
551	547	546	272	[ti:Maison Ikkoku ED6  「Begin the Night」]\n[ar:PICASSO]\n[al:Maison Ikkoku]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:23.4.20]\n[length:04:32.41]\n[00:00.00]\n[00:18.95]Omotta yori kimi wa kuuru ni\n[00:24.89]Hitori ga suki to kuchi o tsugunda\n[00:32.51]Muri wa shinaide kyandoru no hi mo\n[00:40.10]Yorisou you na yoru ni\n[00:47.42]Mitsumete subete o\n[00:54.50]Ima made tsuita uso fukikeshite goran yo\n[01:02.01]Begin the night, Begin your love\n[01:09.11]Hitoriyogari no misuteriasu\n[01:13.06]Kono boku ni tsuujinai...... Woo\n[01:38.26]Seiza no kisetsu suroo ni\n[01:44.88]Koi no jikan o kazatte kureru\n[01:52.17]Aoi kokoro mo atatame naosu\n[02:00.20]Boku no soba de sairento naito\n[02:07.00]Kanjite subete o\n[02:14.04]Kanashimi fuyasu no wa orokana koto darou\n[02:21.52]Begin the night, Begin your love\n[02:28.67]Toorisugari no koi ja nai\n[02:32.45]Wakaru daro kuchizuke mo...... Woo\n[02:54.98]Yumemite subete o\n[03:01.50]Naname no koigokoro konya kagiri sutete\n[03:09.66]Begin the night, Begin your love\n[03:16.32]Tokai sodachi no egoisuto\n[03:20.57]Samishisa no uragaeshi...... Woo\n[03:31.77]Mitsumete subete o\n[03:38.54]Ima made tsuita uso fukikeshite goran yo\n[03:46.88]Begin the night, Begin your love\n[03:53.26]Hitoriyogari no misuteriasu\n[03:57.80]Kono boku ni tsuujinai...... Woo\n[04:12.86]Begin the night, Begin the night	/audio/Maison Ikkoku ED6  「Begin the Night」.mp3	Begin the Night	ED6	https://res.cloudinary.com/ddc6silap/image/upload/v1773254131/covers/Maison_Ikkoku_ED6_Begin_the_Night.jpg	1
700	700	627	216	[ti:Naruto Shippuden OP3 「Blue Bird」]\n[ar:Ikimonogakari]\n[al:Naruto]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:36.14]\n[00:00.92]Habataitara modorenai to itte\n[00:07.11]Mezashita no wa aoi aoi ano sora\n[00:26.03]Kanashimi wa mada oboerarezu\n[00:29.24]Setsunasa wa ima tsukami hajimeta\n[00:32.37]Anata e to idaku kono kanjou mo\n[00:35.55]Ima kotoba ni kawatteku\n[00:38.83]Michi naru sekai no yume kara mezamete\n[00:44.70]Kono hane wo hiroge tobi tatsu\n[00:51.31]Habataitara modorenai to itte\n[00:57.57]Mezashita no wa shiroi shiroi ano kumo\n[01:03.63]Tsuki nuketara mitsukaru to shitte\n[01:10.16]Furikiru hodo\n[01:13.06]Aoi aoi ano sora\n[01:16.59]Aoi aoi ano sora\n[01:19.87]Aoi aoi ano sora\n[01:29.67]Aisou sukita you na oto de\n[01:32.39]Sabireta furui mado wa kowareta\n[01:35.36]Miakita kago wa hora sotete iku\n[01:38.56]Furikaeru koto wa mou nai\n[01:41.88]Takanaru kodou ni kokyou wo azukete\n[01:48.01]Kono mada wo kette tobi tatsu\n[01:54.53]Kakedashitara te ni dekiru to itte\n[02:00.74]Izanau no wa tooi tooi ano koe\n[02:07.25]Mabushi sugita anata no te mo nigitte\n[02:13.34]Motomeru hodo aoi aoi ano sora\n[02:33.13]Ochite iku to wakatte ita\n[02:39.20]Soredemo hikari wo oi tsudzukete iku yo\n[02:46.75]Habataitara modorenai to itte\n[02:52.80]Sagashita no wa shiroi shiroi ano kumo\n[02:58.93]Tsukinuketara mitsukaru to shitte\n[03:05.65]Furikiru hodo aoi aoi ano sora\n[03:12.06]Aoi aoi ano sora\n[03:15.05]Aoi aoi ano sora\n[03:20.27]	/audio/Naruto Shippuden OP3 「Blue Bird」.mp3	Blue Bird	OP3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253756/covers/Naruto_Shippuden_OP3_Blue_Bird.jpg	1
1053	1053	1052	247	[ti:takt op.Destiny OP 「takt」]\n[ar:ryo (supercell)]\n[al:takt op.Destiny]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:07.29]\n[00:00.00] \n[00:05.72]Ano machi mukatta bokura\n[00:10.08]Detarame na uta wo utai\n[00:14.40]“nan da yo, sore” tte warau\n[00:18.73]Tabi wa tsuzuku to omotta\n[00:33.52]Kanashimi ga tsuzuku michi wo\n[00:37.99]Ato dore dake arukeba ii?\n[00:42.34]Furikaettemo mou mienai\n[00:46.64]Kagayaku no wa sugita hi\n[00:50.01]Onaji toki omoidashite hiku yo\n[00:57.56]Hora kimi to miageteta nagareboshi\n[01:05.27]Tsurete ikou ano uta wo\n[01:09.83]Ano toki wo ano yoru wo\n[01:13.76]Bokura ga iru itsudemo aeru\n[01:17.63]Sabishikunai yo soko ni iru kara\n[01:21.51]Wasure wa shinai hibike\n[01:24.81]Kono natsukashii senritsu ga bokura ni todoku made\n[01:34.22]Kore ijou ushinaitakunai\n[01:38.53]Kore ijou kizutsukitakunai\n[01:42.81]Sonna mon darou, to warai\n[01:46.39]Boku wa boku wo mamotta\n[01:51.02]“Ikiteku riyuu wa aru no?\n[01:54.79]Nanimo nai mama aruketeta bokura wa\n[02:00.72]Tabun kou iu yo\n[02:03.66]“miro yo, kore ga kotae da!”\n[02:08.00]Togireta omoi wo atsume hiku yo\n[02:15.33]Kawaranai koto wo tsunaida hoshizora ni\n[02:23.18]Utsukushii omoide ga ano hibi ga\n[02:28.75]Sayonara ga boku ni oshieta\n[02:32.67]Aisuru koto wo sabishikunai yo\n[02:36.43]Koko ni iru kara\n[02:38.56]Hikari ga sashi itsuka kono michi no\n[02:43.57]Shuuchaku chiten de bokura wa mata aeru\n[02:51.09]Yume to iu ni wa baka mitai de\n[02:54.68]Shinji kiru ni wa tayori nakute\n[02:58.52]Sukoshi zutsu akiramete tebanashitan da\n[03:04.47]Kedo omoidashita\n[03:07.91]Chippoke na puraido\n[03:10.56]Dare ni mo yuzurenai\n[03:11.28]Saa tabi wo tsuzukeyou\n[03:32.87]Tsurete ikou ano uta wo\n[03:36.29]Ano toki wo ano yoru wo\n[03:40.24]Bokura ga iru itsudemo aeru\n[03:44.35]Sabishikunai yo soko ni iru kara\n[03:48.20]Wasure wa shinai hibike\n[03:51.39]Kono natsukashii senritsu ga bokura ni todoku made\n[04:01.71]	/audio/takt op.Destiny OP 「takt」.mp3	takt	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253753/covers/takt_op.Destiny_OP_takt.jpg	1
1281	1281	1281	292		/audio/Yona of the Dawn ED 「Yoru」.mp3	Yoru	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253764/covers/Yona_of_the_Dawn_ED_Yoru.jpg	1
1289	1254	1288	132		/audio/Your Name OST 「Dream lantern」.mp3	Dream lantern	OST	https://res.cloudinary.com/ddc6silap/image/upload/v1773253757/covers/Your_Name_OST_Dream_lantern.jpg	1
1294	387	1293	266		/audio/Yuru Camp ∆ OP 「SHINY DAYS」.mp3	SHINY DAYS	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253759/covers/Yuru_Camp_OP_SHINY_DAYS.jpg	1
80	79	79	271		/audio/Black Bullet ED2 「Wasurenai Tame ni」.mp3	Wasurenai Tame ni	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253774/covers/Black_Bullet_ED2_Wasurenai_Tame_ni.jpg	1
96	96	96	274		/audio/Darker than Black S2 ED 「From Dusk Till Dawn」.mp3	From Dusk Till Dawn	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253772/covers/Darker_than_Black_S2_ED_From_Dusk_Till_Dawn.jpg	2
556	556	556	293		/audio/Maquia ED Theme 「Viator」.mp3	Viator	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253779/covers/Maquia_ED_Theme_Viator.jpg	1
588	465	464	254	[00:00.00] \r\n[00:07.32]DADDY! DADDY! DO! hoshii no sa\r\n[00:10.71]Anata no subete ga\r\n[00:13.90]Ai ni dakare giragira\r\n[00:17.28]Moete shimaitai\r\n[00:20.80] \r\n[00:32.97]Kawaige na kisu de 1. 2. 3\r\n[00:36.44]Mesen sorashite zurui yo ne\r\n[00:40.03]Hoteridasu boku no kimochi\r\n[00:43.37]Moteasobu mitai de\r\n[00:47.01]Oikakecha dame na no wa\r\n[00:50.31]Wakatteru demo murisa\r\n[00:53.88]Ichido fumidaseba modorenakute\r\n[00:58.34]Kamen wa nugisutete\r\n[01:01.44]Ikenai kotoba de\r\n[01:04.89]Asobi ga maji ni naru\r\n[01:08.53] \r\n[01:09.89]DADDY! DADDY! DO! hoshii no sa\r\n[01:13.34]Anata no subete ga\r\n[01:16.41]Damasaretara sore demo ii\r\n[01:20.45]Motto furuwasete\r\n[01:23.75]Misete kure boku dake ni\r\n[01:27.32]Egao no ura made\r\n[01:30.46]Ai ni dakare giragira\r\n[01:34.27]Moete shimaitai\r\n[01:36.74] \r\n[01:42.43]Chuucho nado shinai NO NO NO\r\n[01:45.99]Nido to aenai hito dakara\r\n[01:49.47]Koukai ni kureru no nara koi no hi ni yakaretai\r\n[01:56.45]wazato deshou nagashime ga\r\n[01:59.93]Itoshisa wo shigeki suru\r\n[02:03.38]Sotto furikaeru utsukushisa ni\r\n[02:07.89]Kokoro wa tsukamarete\r\n[02:11.06]Kokyuu ga tomatte asobi ga maji ni naru\r\n[02:18.27] \r\n[02:19.46]DADDY! DADDY! DO! Butsuketai\r\n[02:22.93]Omoi no subete wo\r\n[02:26.02]Kirei na mono dake janakute kiken na negai mo\r\n[02:33.40]Tomenaide sono koe ga boku wo tsurete iku ai ni dakare giragira\r\n[02:43.45]Moete shimaitai\r\n[02:47.81] \r\n[02:49.76]"Anata dake" to iu kuchibiru ga yasashiku hohoemu tabi\r\n[03:02.56]Nomikomarete izanawarete\r\n[03:09.28]Michi no sekai furete\r\n[03:16.38] \r\n[03:20.38]DADDY! DADDY! DO! Saigo made\r\n[03:23.87]Anata ni yudanete\r\n[03:26.94]Kowareru nara sore demo ii\r\n[03:30.53]Motto kuruwasete\r\n[03:34.27]Misete kure boku dake ni\r\n[03:37.71]Kokoro no oku made\r\n[03:40.88]Ai ni dakare giragira\r\n[03:44.21]Moetai inochi hateru yoake made\r\n[03:52.45] \r\n	/audio/Kaguya sama_ Love is War S2 OP 「DADDY! DADDY! D.mp3	DADDY! DADDY! DO!	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253651/covers/Kaguya_sama_Love_is_War_S2_OP_DADDY_DADDY_DO.jpg	2
717	708	708	90		/audio/Nichijou ED6 「Green Green」.mp3	Green Green	ED6	https://res.cloudinary.com/ddc6silap/image/upload/v1773253778/covers/Nichijou_ED6_Green_Green.jpg	1
1210	1102	1210	284	[00:00.00] \r\n[00:00.91]Anata no koe ga michishirube\r\n[00:12.17] \r\n[00:22.90]Ichiwa no tori ga naite iru\r\n[00:34.06]Namae no nai sora ni watashi wo sagashite\r\n[00:44.76]Yasashisa de ami tsuzuketa\r\n[00:50.25]Yurikago de asu e yukou\r\n[00:55.74]Hare no hi mo ame no hi ni mo\r\n[01:02.02]Anata wo mamoru tame ni\r\n[01:07.00]Kakegae no nai takaramono\r\n[01:18.03]Namae no nai hana wa\r\n[01:23.30]Shizuka ni nemuru yo\r\n[01:28.50] \r\n[01:51.61]Iro naki kaze ga yonde iru\r\n[02:02.25]Koinegau furusato natsukashii kaori\r\n[02:13.38]Tooku osanai kioku wa\r\n[02:18.66]Hidamari no you na nukumori\r\n[02:24.12]Utakata no yume kara same\r\n[02:29.62]Kodoku ga “hitori” to shitta\r\n[02:41.68] \r\n[02:45.99]Sazukerareta tsubasa wo habatakasete\r\n[02:57.23]Tobu koto wo yamenai to yakusoku shiyou\r\n[03:04.72]Hitori ja nai\r\n[03:15.12] \r\n[03:19.90]Negai wa hitotsu dake anata no shiawase\r\n[03:30.65] \r\n[03:33.13]Yasashisa de ami tsuzuketa\r\n[03:38.64]Yurikago de asu wo yukou\r\n[03:44.15]Hare no hi mo ame no hi ni mo\r\n[03:50.47]“aishiteru” wo tsutaete…\r\n[03:55.30]Kono machi ni umareta no wa\r\n[04:00.80]Anata to meguriau tame\r\n[04:06.26]Kono machi ni umareta kara\r\n[04:12.47]Anata ni meguriaeta\r\n[04:17.65]Ichiwa no tori ga tonde yuku\r\n[04:28.58]Namae no nai sora ni ashita wo sagashite\r\n[04:40.95] \r\n	/audio/Violet Evergarden ED 「Michishirube」.mp3	Michishirube	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253776/covers/Violet_Evergarden_ED_Michishirube.jpg	1
546	546	546	269	[ti:Maison Ikkoku  ED 「Ashita Hareru ka」]\n[ar:Takao Kisugi]\n[al:Maison Ikkoku]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:23.4.20]\n[length:04:29.07]\n[00:00.00]\n[00:24.00]Doushite anata wa\n[00:31.22]Suzushige de irareru\n[00:38.22]Fureru hodo chikaku kuchibiru munamoto\n[00:45.21]Konna ni mo boku o kiken ni sasetoku\n[00:54.33]Aishite mo ii hazu\n[01:01.26]Soredemo toki ga jukusanai\n[01:08.36]Sekitateru kokoro ni\n[01:15.40]Oitsukanakute genjitsu wa\n[01:20.72]Mama naranai\n[01:36.59]Shizen ni dakiyose\n[01:43.46]Hitonami no machikado\n[01:50.06]Kuruma no BUREEKI ushiro de hibiite\n[01:57.19]Jouken hansha de futari wa yokomuku\n[02:06.18]Tamaranaku koi nara\n[02:12.72]CHANSU wa ima da otozurezu\n[02:20.35]Tamaranaku orokana\n[02:26.30]Otoko ni natte ikisou de\n[02:32.72]Mama naranai\n[02:48.30]Ayaui BEERU o kisetsu ni kasanete\n[02:54.80]anata wa higoto ni onna ni natteku\n[03:04.07]Tamaranaku koi nara\n[03:11.11]Ashita hareru ka harenai ka\n[03:17.94]Sukoshi demo koi nara\n[03:24.85]Yume wa mireru ka mirenai ka\n[03:30.35]Kaze ni kiku yo\n[03:31.85]Aishite mo ii hazu\n[03:38.92]Ashita hareru ka harenai ka\n[03:45.93]Tamaranaku koi nara\n[03:52.94]Tsuki tsutsundeku kokoro nara\n[03:58.77]Kaze ga shitteru\n[04:01.79]	/audio/Maison Ikkoku  ED 「Ashita Hareru ka」.mp3	Ashita Hareru ka	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253786/covers/Maison_Ikkoku_ED_Ashita_Hareru_ka.jpg	1
355	130	349	215		/audio/Hanasaku Iroha OP2 「Omokage Warp」.mp3	Omokage Warp	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253811/covers/Hanasaku_Iroha_OP2_Omokage_Warp.jpg	1
489	488	488	233	[00:00.00] \n[00:35.43]Awatadashiku usu-enjiiro no\n[00:39.64]BIROODO wo hiroge ikusaki wa dochira?\n[00:43.93]"Boku wa asa e, nishi no hou e mukau" to iu\n[00:50.77]de wa gokigenyou\n[00:53.68]TIIKAPPU ni utsuru hitomi wa\n[00:56.91]KEIJI no naka obieta usagi mitai\n[01:00.43]Kitto ire wasureta kakuzatou no sei\n[01:05.52]Sore wa shiranai ai no amami\n[01:10.97]Mada kurai ya akegata no sora\n[01:15.15]Hontou ni taisetsu na mono ga aru no kashira?\n[01:19.53]Kono itami ya mada ibasho ga\n[01:23.86]Atarimae tte omotteita itsuka dattari suru no kana.\n[01:30.82] \n[01:37.86]"Kondo hidoi ame ga furu wa douka o-ki wo tsukete\n[01:46.15]Shirase wo doumo arigatou to kaze ni kuchizukeru\n[01:52.99]de wa gokigenyou\n[01:56.02]Oikakete wa nigeteiku\n[01:59.15]Maru de taiyou to tsuki to watashi to anata\n[02:02.75]Demo kikkake ga hoshii no wa onaji\n[02:07.64]Sore wa yamanai kanjou no ame\n[02:13.25]Mou kurai ya amefuri no sora\n[02:17.41]Ryoute furisosoida kokoro wo tashikameta\n[02:21.73]Toozakatte mo chikazuite mo\n[02:26.21]Ari no mama kizutsukeatte ikite yuku sou deshou?\n[02:32.67] \n[02:43.83]Anata wa kirau demo naku\n[02:45.83]Nikumu demo kobamu demo naku\n[02:48.78]Kitto aishi aisareru tame ikiteiru\n[02:52.42]Sore wa wagamama wa nakute\n[02:54.42]Ogori ya jishin demo naku\n[02:57.18]Umare motta negai na no dakara\n[03:00.45]Nishi no hou e to kaeru yoru kara\n[03:04.82]Azuketa mayoi ya osore wo uketotte\n[03:09.19]Fureatte wa toketa koori ga\n[03:13.19]Kawaki kitta kokoro wo uruoshiteiku\n[03:17.47]Mabushii kurai da akegata no sora\n[03:21.90]Hontou ni taisetsu na sekai ga aru no dakara\n[03:26.15]Kono itami ya mata ibasho ga\n[03:30.78]Atarimae tte omoeru you ni nattari suru no kana.\n[03:37.39] \n[03:39.27]Cry out\n	/audio/Kokoro Connect ED2 「Cry out」.mp3	Cry out	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253801/covers/Kokoro_Connect_ED2_Cry_out.jpg	1
590	501	500	196	[00:00.00] \n[00:13.13]Koronde surimuita toko\n[00:18.46]Chi ga nijinde shimiru keredo\n[00:25.24]Hecchara sa sugu naoru kara\n[00:30.80]Ashita ni wa kasabuta dekiru\n[00:37.46]kyou mo mata BAKA ni sareta yo\n[00:42.76]Hazukashii shi kuyashii keredo\n[00:49.55]Hecchara sa oboete oke yo\n[00:54.93]Ima ni warai kaeshite yaru\n[01:01.21]misaki kara fune wo daseba\n[01:07.00]Kaze wo uke ho ga fukuramu\n[01:13.01]Boku wa ima tsuchi wo hanare\n[01:19.14]Nanatsu no umi wo mata ni kakeru\n[01:25.39] \n[01:50.44]KENKA shite nagurareta toko\n[01:55.82]Murasakiiro AZA nin atta\n[02:02.48]Hecchara sa kyou no tokoro wa\n[02:07.69]Maketa koto ni shitoite yaru.\n[02:13.95]oka ni tachi te wo hirogete\n[02:19.96]Kaze wo machi habataku no sa\n[02:25.99]Boku wa ima tsuchi wo hanare\n[02:32.07]Oozora wataru ichiwa no tori\n[02:38.48]minami kara kaze ga fuite\n[02:44.21]Kyuu ni ame furi hajimeta\n[02:50.31]Haru wa sugu tonari ni iru\n[02:56.33]Sentakumono torikomanakucha\n[03:02.99] \n	/audio/Konosuba ED 「Chiisana Boukensha」.mp3	Chiisana Boukensha	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253807/covers/Konosuba_ED_Chiisana_Boukensha.jpg	1
94	94	94	295	[00:00.00] \n[00:22.20]kono sekai wa naze\n[00:27.52]watashi wo azamuki tsukihanasu ‘n darou\n[00:43.30]kono sekai wa naze\n[00:48.41]mune no naka kakimidashi kurikaesu ‘n darou\n[00:59.08]wakari-kitta koto wo anata ni\n[01:05.20]toitadashite shimau nukumori wo kanjitakute\n[01:17.43]kantan ni kudakeru koori no ue demo susumeru no wa\n[01:25.88]ai no hotsure mo kakushita kizu mo\n[01:37.35]anata ga mitsumete ita\n[01:42.38]demo itami wa ubawanaide\n[02:00.96]kono sekai ni iru\n[02:06.48]shinjitsu wa surudoku furete wa kizutsuite\n[02:17.14]soko ni imi wo motomete iru\n[02:22.48]toozakete shimau hitori ni naritakunai noni\n[02:34.44]yami no naka yurete’ru tatta hitotsu mitsuketa\n[02:40.99]chiisana hi\n[02:43.22]ai no nemuke mo kakushita kanjou mo\n[02:54.60]anata ni mukete utaeba\n[02:59.84]kikoeru kana konna ni tookutemo\n[03:18.24]kono sekai de dakishimete iru\n[03:29.13]koori no ue wo tashika na ashidori de arukeru\n[03:39.47]ai no hotsure mo kakushita kizu mo\n[03:50.65]anata ga iru sore dake de\n[03:55.65]waruku wa nai to ieru ukeirete miru\n[04:03.21]ai no kotoba wa utsumukazu iu yo\n[04:14.74]anata no mae wo aruite iku kara\n[04:19.87]onegai watashi wo mitsumete ite\n[04:27.84] 	/audio/Code Geass M9 OP 「Kono Sekai de」.mp3	Kono Sekai de	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253821/covers/Code_Geass_M9_OP_Kono_Sekai_de.jpg	1
121	20	118	331	[00:00.00] \r\n[00:07.31]Kuzurete owaru sekai\r\n[00:13.44]Mujibi ni tsugeru\r\n[00:23.15]Kimi wa hitori nani wo kiiteta\r\n[00:35.92]Boku wa tooi yume wo miteta\r\n[00:48.53] \r\n[00:48.82]Nani wo erabitoru nani wo akirameru\r\n[00:51.94]Kimeyou to shiteru boku wa nanisama da\r\n[00:55.11]Nani wo erabu ka wa mou kimatte iru\r\n[00:58.20]Machigai wa nai ka kami ni toikakeru\r\n[01:01.32]Hitorikiri ja nakatta zutto soba ni itan da\r\n[01:07.00]Kono te wo nobasu\r\n[01:14.16]Kowai mono nanka nai\r\n[01:17.16]Tatoe bakemono ni narou to mo nashitogeru\r\n[01:30.91] \r\n[01:39.99]Ano hi wo saigo ni shite\r\n[01:46.30]Tsuyoku nareta ka\r\n[01:55.90]Hikyou datta zutto boku wa\r\n[02:08.75]Kimi wa itsumo mukoumizu datta\r\n[02:21.62]Mae ni susumu no ka koko de yameru no ka\r\n[02:24.85]Kimeyou to shiteru boku wa nanisama ka\r\n[02:28.11]Mae ni susumu no wa mou kimatte iru\r\n[02:31.10]Machigai wa nai ka kama ni toikakeru\r\n[02:34.20]Hitorikiri ja nakatta sore wo omoidashita toki\r\n[02:40.41]Imi wo shitta\r\n[02:46.91]Doredake datte ubau yo\r\n[02:49.88]Kono te wo shinjita toki yuuki wo toreta\r\n[03:03.64] \r\n[03:06.30]Itsukara kimi wo miru me ga kawatte shimatta no darou\r\n[03:12.66]Sono hitomi ni utsusu mono naka ni majiritaku natta\r\n[03:19.18]Doredake no konnan ga matsu no ka kowaku mo naru\r\n[03:25.48]Kimi kara takusareta mono sore dake wa hanasanai de iru kara\r\n[03:38.91] \r\n[04:04.06]Boku wa nanimono de nande sono boku ga\r\n[04:07.09]Kami ni mo hitoshii yaku wo ninatteru\r\n[04:10.37]Mae ni susumo no mo iya ni natte iru\r\n[04:13.77]Yasumitai no desu kami ni hakisuteru\r\n[04:16.58]Watashi ga shinjita hito wa sonna hito dakke to\r\n[04:22.34]Koe ga shitan da\r\n[04:29.20]Marude hitogoto no you ni kikoeta kara\r\n[04:34.18]Mushiro yakki ni natte iku\r\n[04:42.46]Hitorikiri ja nakatta kono te ni nigiru mono ga\r\n[04:48.14]Douyara shouko\r\n[04:54.87]Yowasa wo kanagurisute tatoe bakemono ni narou to mo\r\n[05:01.53]Kaette yaru	/audio/Charlotte OP 「Bravely You」.mp3	Bravely You	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253813/covers/Charlotte_OP_Bravely_You.jpg	1
443	443	443	306	[ti:Isshuukan Friends ED 「Kanade」]\n[ar:Fujimiya (Sora Amamiya)]\n[al:Isshuukan Friends]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:05:05.54]\n[00:00.00]\n[00:42.28]Kaisatsu no mae tsunagu te to te itsumono zawameki, atarashii kaze\n[00:54.85]Akaruku miokuru hazu datta no ni umaku waraezu ni kimi wo miteita\n[01:09.46]Kimi ga otona ni natteku sono kisetsu ga\n[01:15.66]Kanashii uta de afurenai you ni\n[01:22.21]Saigo ni nani ka kimi ni tsutaetakute\n[01:28.08]"Sayonara" ni kawaru kotoba wo boku wa sagashiteta\n[01:49.11]Kimi no te wo hiku sono yakume ga boku no shimei da nante sou omotteta\n[02:00.88]Dakedo ima wakattanda bokura nara mou kasaneta hibi ga hora, michibiite kureru\n[02:15.65]Kimi ga otona ni natteku sono jikan ga\n[02:21.95]Furitsumoru ma ni boku mo kawatteku\n[02:28.41]Tatoeba soko ni konna uta ga areba\n[02:34.37]Futari wa itsumo donna toki mo tsunagatte yukeru\n[03:12.42]Totsuzen fui ni narihibiku BERU no oto\n[03:19.45]Aseru boku hodokeru te hanareteku kimi\n[03:25.70]Muchuu de yobitomete dakishimetanda\n[03:32.03]Kimi ga doko ni ittatte boku no koe de mamoru yo\n[03:43.12]Kimi ga boku no mae ni arawareta hi kara\n[03:50.40]Nanimo kamo ga chigaku mietanda\n[03:56.79]Asa mo hikari mo namida mo, utau koe mo\n[04:02.83]Kimi ga kagayaki wo kuretanda\n[04:09.23]Osaekirenai omoi wo kono koe ni nosete\n[04:16.07]Tooku kimi no machi e todokeyou\n[04:22.44]Tatoeba sore ga konna uta dattara\n[04:28.27]Bokura wa doko ni ita toshite mo tsunagatte yukeru\n[04:39.25]	/audio/Isshuukan Friends ED 「Kanade」.mp3	Kanade	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253819/covers/Isshuukan_Friends_ED_Kanade.jpg	1
1129	1129	1128	179	[00:00.00] \n[00:13.79]Pattomi kireina koufuku no gisou\n[00:16.86]Mekki ga hagare ochita\n[00:19.71]Ichi mai no usukawa hedateta saki de\n[00:22.75]Guro imo no ga nanka umeiteita\n[00:25.79]Ningen no aida ni chinden shita\n[00:28.71]Dosuguroi mono ga bouhatsu suru hi\n[00:31.62]Soreni zutto obieru bokutachi wa\n[00:34.74]Kanmanna shi no sanaka ni aru mitaida\n[00:39.85]Muryoku o norou koe to\n[00:42.55]Sukui o inoru koe ga\n[00:45.31]Mazatta youna uta ga kikoeru\n[00:49.02]Subete nomikondeshimau you ni\n[00:52.66]Susundeyuku seija no koushin\n[00:55.73]Yowai bokura sae mo yurushite\n[00:59.48]Tsuresatteshimau\n[01:01.87]Hakai de mo naku kyūsai de monaku\n[01:04.75]Subete o narasu seija no koushin\n[01:07.79]Uchinomesareteshimatta bokura no\n[01:11.56]Urei o harattekure ,nā\n[01:14.19]Doushite bokutachi no koufuku no tane wa\n[01:17.59]Ikkouni mebukanaino?\n[01:20.40]Ittai dore kurai no kurai yami no soko de\n[01:23.59]Naite mogaite sugoshitara ī?\n[01:26.83]Yamazumi no fukou no ue ni tatsu\n[01:29.43]Misekake no risou, usurasamuine\n[01:32.49]Heionna hibi wa kaettekonai\n[01:35.59]Nekkyou o motarasu bokura no māchingubando\n[01:52.85]Ubugoe o ageta hi kara\n[01:55.71]Kanashimi o shitta hi kara\n[01:58.45]Bokura wa surikireteitta\n[02:04.75]Muryoku o norou koe to\n[02:07.57]Sukui o inoru koe ga\n[02:10.41]Mazatta youna uta ga kikoeru\n[02:14.69]Subete nomikondeshimau you ni\n[02:17.69]Susundeyuku seija no koushin\n[02:20.66]Yowai bokura sae mo yurushite\n[02:24.11]Tsuresatteshimau\n[02:26.80]Mukau saki de matteiru no ga\n[02:29.78]Rakuen darouga jigokudarouga\n[02:32.73]Kono parēdo wa susumitsuzukeru dake\n[02:35.90]Ikari ya kanashimi no uta o utainagara\n[02:42.33]Bakko suru akuma o fumi tsubushite\n[02:48.82]Furueru shinzou ga tomatteshimau made\n[02:53.41]	/audio/The Idaten Deities Know Only Peace OP 「Seija no.mp3	Seija no Koushin	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253825/covers/The_Idaten_Deities_Know_Only_Peace_OP_Seija_no_Koushin.jpg	1
487	487	486	181	[ti:Kokkoku OP 「Flashback」]\n[ar:MIYAVI vs. KenKen]\n[al:Kokkoku]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:00.45]\n[00:00.00]Coming In Coming Now Mawari Mite Mina\n[00:03.79]Nozoi Mamire That You Can't see Me But You Hear Me Loud\n[00:07.24]Don't That Make You Crazy Now\n[00:08.77]Don't That Make You Crazy Now\n[00:10.50]Me Wo Korase Kono Sekai Wa It's All Upside Down\n[00:27.66]Coming In Coming Now Mawari Mite Mina\n[00:31.04]Nozoi Mamire That You Can't see Me But You Hear Me Loud\n[00:34.39]Don't That Make You Crazy Now\n[00:36.19]Don't That Make You Crazy Now\n[00:37.91]Me Wo Korase Kono Sekai Wa It's All Upside Down\n[01:01.86]Crazy now Crazy now\n[01:03.71]Crazy now Crazy now Crazy...\n[01:09.05]Don't Stop Modorenai Flash Back,\n[01:12.70]Look Up Kizukeba It's All Past\n[01:16.10]Too Fast Hikisakaresou Sa Ahhh Ahhhhh . . .\n[01:22.64]Don't Stop Modorenai Flash Back,\n[01:26.42]Look Up Kizukeba It's All Past\n[01:29.79]Too Fast Hikisakaresou Sa Ahhh Ahhhhh . . .\n[01:36.73]Don't Stop Modorenai Flash Back,\n[01:40.15]Look Up Kizukeba It's All Past\n[01:43.54]Too Fast Hikisakaresou Sa Ahhh Ahhhhh . . .\n[01:50.42]Don't Stop Modorenai Flash Back,\n[01:53.76]Look Up Kizukeba It's All Past\n[01:57.28]Too Fast Hikisakaresou Sa Ahhh Ahhhhh . . .\n[02:04.13]Don't Stop Modorenai Flash Back,\n[02:07.58]Look Up Kizukeba It's All Past\n[02:10.96]Too Fast Hikisakaresou Sa Ahhh Ahhhhh . . .\n[02:17.81]Don't Stop Modorenai Flash Back,\n[02:21.28]Look Up Kizukeba It's All Past\n[02:24.70]Too Fast Hikisakaresou Sa Ahhh Ahhhhh . . .\n[02:31.56]Don't Stop Modorenai Flash Back,\n[02:34.96]Look Up Kizukeba It's All Past\n[02:38.47]Too Fast Hikisakaresou Sa Ahhh Ahhhhh . . .\n[02:45.48]Don't Stop Modorenai Flash Back,\n[02:49.48]Look Up Kizukeba It's All Past\n[02:52.73]Too Fast Hikisakaresou Sa Ahhh Ahhhhh . . .	/audio/Kokkoku OP 「Flashback」.mp3	Flashback	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253848/covers/Kokkoku_OP_Flashback.jpg	1
637	637	627	285	[00:01.81]dare datte shippai wa suru nda\n[00:06.99]hazukashii koto janai\n[00:12.40]kono kizu wo muda ni shinai de\n[00:17.72]waratte arukereba ii\n[00:45.13]sou shizuka na kuuki suikomi\n[00:47.57]hiroki sora ni kao age tobikomi\n[00:49.15]toki ni ame ga futtara hito yasumi\n[00:52.33]jaa yukusaki wa kaze fuku mama ni\n[00:54.63]takusan no matotteru koukai\n[00:57.53]kono kizu wo muda ni shicha shounai\n[00:59.98]ude ni kunshou kizami ikoukai shougai\n[01:04.48]sou kokkara ga Show Time\n[01:06.30]ah iroasete kono PORA naka de ikiteru kako no jibun toka\n[01:11.37]itsumo TSURU nde hi no nai you ni\n[01:14.33]ibasho mitsukete hiataru you ni\n[01:17.02]konna kanji de hibi kattou ippo fumidasu beki ganbou\n[01:21.53]makkou shoubu jibun ni muke issou koko de kono uta hibikasou\n[01:27.32]dare datte shippai wa suru nda\n[01:32.51]hazukashii koto janai\n[01:37.88]kono kizu wo muda ni shinai de\n[01:43.24]waratte arukereba ii\n[01:59.31]kyou hajimari wo tsugeru asayake yume to genjitsu no hazama de\n[02:03.46]What's Say kono koe kareru sono hi made\n[02:06.59]korogari tsudzukeru Another Day\n[02:08.99]shuppotsu shinkou kamase in wo shindou kaitaku michi ippon yeah\n[02:14.95]yagate toori ni hanasake soshite mirai ni mugete habatake\n[02:19.91]genjitsu omoku nokkaru ga mezase chouten Like a No Culture\n[02:25.38]saru ga saru ni shikanarenai Oh\n[02:28.04]jibun wa jibun ni shikanarenai Yo\n[02:30.50]asu wo ki ni shite shita muku mae ni\n[02:33.40]kyou no jibun no ki no muku mama ni\n[02:36.05]saisei kyou wa chou kaisei nanimo nayami nankanaize\n[02:51.79]omoku no shikakaru genjitsu ga\n[02:57.57]ima no boku wo semetateteru\n[03:02.92]kantan ni wa ikanai na\n[03:07.58]sonna koto kurai chouchi shiteru yo\n[03:19.16]dare datte shippai wa suru nda\n[03:24.28]hazukashii koto janai\n[03:29.61]kono kizu wo muda ni shinai de\n[03:34.92]waratte arukereba ii\n[03:40.31]takusan no koukai wo matotte\n[03:45.65]aji no aru hito ni naru sa\n[03:50.90]kanashimi mo kaze ni kaete\n[03:56.23]tsuyoku susunde ikereba ii\n[04:00.94]sou shizuka na kuuki suikomi\n[04:04.00]hiroki sora ni kao age tobikomi\n[04:06.88]toki ni ame ga futtara hito yasumi\n[04:09.50]jaa yukusaki wa kaze fuku mama ni\n[04:11.91]takusan no matotteru koukai\n[04:14.90]sono kizu wo muda ni shicha shounai\n[04:17.42]ude ni kunshou kizami ikoukai shougai\n[04:20.89]sou kokkara ga Show Time\n[04:23.20]	/audio/Naruto ED4 「ALIVE」.mp3	ALIVE	ED4	https://res.cloudinary.com/ddc6silap/image/upload/v1773253915/covers/Naruto_ED4_ALIVE.jpg	1
1198	28	939	295	[00:00.00] \n[00:17.10]Hitorikiri demo\n[00:21.66]Heiki to koboreochita tsuyogari\n[00:33.95]Futari no mabushi sugita hi ga\n[00:41.58]Konna ni kanashii\n[00:46.46]Hitori de ikirareru nara\n[00:54.75]Dareka wo aishitari shinai kara\n[01:02.47]Anata no kaori anata no hanashi kata\n[01:11.80]Ima mo karadajuu ni ai no kakera ga nokotteru yo\n[01:19.51]Watashi no negai watashi no negai wa tada\n[01:28.60]Dou ka anata mo dokoka de naite imasu you ni\n[01:40.63] \n[01:54.69]Itsumo atarashii ippo wa\n[02:02.07]Omokute sabishii\n[02:06.98]Moshi umarekawattemo\n[02:14.84]Mou ichido anata ni deaitai\n[02:22.86]Manatsu no hizashi mafuyu no shiroi yuki\n[02:32.12]Meguru kisetsujuu ni ai no kakera ga maiochite\n[02:39.76]Shiawase na no ni dokoka de sabishii no wa\n[02:49.09]Anata yori mo ookina watashi no ai no sei\n[03:00.50] \n[03:14.78]Kagi wa anata ga motta mama\n[03:19.20]Utau imi wo nakushita kanaria\n[03:23.18]Kurai torikago no naka de\n[03:30.84]Anata no kaori anata no hanashi kata\n[03:39.95]Ima mo karadajuu ni ai no kakera ga nokotteru yo\n[03:47.63]Watashi no negai watashi no negai wa tada\n[03:56.91]Dou ka anata ga shiawase de arimasu you ni\n[04:12.41] \n[04:15.62]Oh, ooh-woah, oh\n[04:25.09]Unlasting world\n[04:28.88]The course of love\n[04:34.32]Forever thinking of you\n[04:41.83] \n	/audio/Sword Art Online Alicization- War of Underworld.mp3	Unlasting	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253828/covers/Sword_Art_Online_Alicization-_War_of_Underworld_ED_Unlasting.jpg	1
655	655	627	257	[ti:Naruto Shippuden ED15 「U can do it!」]\n[ar:DOMINO]\n[al:Naruto]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:17.01]\n[00:01.84]Shiranai wo riyuu ni nigete bakari de\n[00:05.58]Raku na michi wo susumu no wa kantan da yo ne\n[00:10.16]Demo ima dake no kono isshun wa\n[00:14.91]Dare no mono demo nai yo\n[00:17.13]What's going on, What's going on\n[00:18.52]Chiisaikoro ni egaiteta\n[00:23.05]Naritai jibun ni naru tame ni\n[00:27.62]Nani shite nani wo mirebaii notte\n[00:32.22]Mayocchau toki mo aru yo ne\n[00:35.79]Dakedo\n[00:37.11](Anytime) kitto ima daiji na mono\n[00:41.68](Anytime) sore wa koko ni aru kara\n[00:45.97](Anytime) kowagaranai de sono mama\n[00:50.96]Ikou shinjite!\n[00:55.08]Shiranai wo riyuu ni nigete bakari de\n[00:59.24]Raku na michi wo susumu no wa kantan da yo ne\n[01:03.49]Demo ima dake no kono isshun wa\n[01:07.64]Dare no mono demo nai yo\n[01:10.27]What's going on, What's going on!\n[01:12.76]Hey hey hey, I think U can do it!\n[01:17.04]Yoku mimi wo sumasete kimi wo yobu hou e\n[01:21.12]Biru no aida no aida made sagashite mite yo\n[01:25.80]Mitsukaru yo kitto\n[01:27.71]Jibun wo ugokasu nanika\n[01:32.73]Kotae no nai michi ga tsuzuku\n[01:37.02]Soredemo akiramekirezu ni\n[01:41.59]Nando mo ochikonde naitatte\n[01:46.18]Mada hashiri tsuzuketai no\n[01:49.78]Dakara\n[01:50.88](Anytime) kuyashi namida nagashite mo\n[01:54.99](Anytime) itsumo soba ni iru kara\n[01:59.29](Anytime) tanoshimu koto wasurezu ni\n[02:03.88]Ikou shinjite!\n[02:08.47]Shiranai wo riyuu ni nigete bakari de\n[02:12.55]Raku na michi wo susumu no wa kantan da yo ne\n[02:17.15]Demo ima dake no kono isshun wa\n[02:21.33]Dare no mono demo nai yo\n[02:23.62]What's going on, What's going on!\n[02:26.17]Hey hey hey, I think U can do it!\n[02:30.42]Yoku mimi wo sumasete kimi wo yobu hou e\n[02:34.67]Biru no aida no aida made sagashite mite yo\n[02:39.34]Mitsukaru yo kitto\n[02:41.15]Jibun wo ugokasu nanika\n[02:44.69]Nani mo nai ichibi nante nai\n[02:49.36]Onaji you ni me ga sameta toshite mo\n[02:53.46]Furikaeranai de\n[02:57.60]Jibun wo shinjite!\n[03:02.25]Shiranai wo riyuu ni nigete bakari de\n[03:06.66]Raku na michi wo susumu no wa kantan da yo ne\n[03:11.09]Demo ima dake no kono isshun wa\n[03:15.23]Dare no mono demo nai yo\n[03:17.54]What's going on, What's going on\n[03:19.98]Kawatteku narenai jikan no naka de\n[03:24.29]Mienaku naru mono mo aru, wakatteru kedo\n[03:28.75]Demo ima dake no kono isshun wa\n[03:32.98]Zenryoku de susumanakya\n[03:35.46]What's going on, What's going on!\n[03:37.82]Hey hey hey, I think U can do it!\n[03:42.03]Yoku mimi wo sumasete kimi wo yobu hou e\n[03:46.26]Biru no aida no aida made sagashite mite yo\n[03:50.91]Mitsukaru yo kitto\n[03:52.86]Jibun wo ugokasu nanika\n[03:55.81]You can do it!\n[04:00.40]You can do it!\n[04:04.42]You can do it!\n[04:09.80]You can do it!\n[04:11.70]	/audio/Naruto Shippuden ED15 「U can do it!」.mp3	U can do it!	ED15	https://res.cloudinary.com/ddc6silap/image/upload/v1773253750/covers/Naruto_Shippuden_ED15_U_can_do_it.jpg	1
920	919	919	375	[ti:Rising of The Shield Hero ED2 「Atashi ga Tonari ni Iru Uchi ni」]\n[ar:Chiai Fujikawa]\n[al:Rising of The Shield Hero]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:05:55.03]\n[00:00.00]\n[00:22.33]Kayoi nareta itsumo no michi\n[00:27.74]Misugoshisou na hana ga yurete\n[00:33.04]Atarimae to omoikomi dore dake\n[00:35.70]Taisetsu na mono ni kizukazu ni itan darou\n[00:41.63]Itsuka awa no you ni atashi mo anata mo\n[00:47.68]Kirei ni kiete nakunaru no\n[00:52.86]Semete sono hi made wagamama wo kiite\n[00:58.47]Demo ienai ya iesou ni nai ya\n[01:06.10]Atashi ga tonari ni iru uchi ni\n[01:09.56]Ai wo motto atashi ni kudasai\n[01:16.51]Yokubari de gomen nasai\n[01:22.24]Anata no ai ni oboretai\n[01:27.42]Atashi ga tonari ni iru uchi ni\n[01:30.30]Ai wo motto atashi ni kudasai\n[01:37.24]Afureru you na omoi de\n[01:42.74]Anata wo tsutsumikomitai no\n[02:04.50]Ame ni furare yukiba nakushi\n[02:09.82]Nan no batsu sa? To sora wo niramu\n[02:14.94]Tsuitenai ya tte sou\n[02:17.40]Dare kare nikunde\n[02:19.47]Kimi ni kidzukazu ni nasakenai na\n[02:24.82]Netami urami tsurami\n[02:28.22]Kuso mitaina uso\n[02:31.31]Subete ga kiete nakunarya ii\n[02:36.00]Nani o shinjireba?\n[02:38.55]Nani mo shinjinai\n[02:41.93]Mou shinjirareru\n[02:43.23]Mono nante nai yo\n[02:49.08]Anata ga tonari ni iru uchi ni\n[02:52.28]Ai wo motto oshiete kudasai\n[02:59.40]Yokubari de gomen nasai\n[03:04.71]Anata no ai ni oboretai\n[03:09.92]Anata ga tonari ni iru uchi ni\n[03:13.51]Ai wo motto oshiete kudasai\n[03:20.98]Afureru you na omoi de\n[03:25.86]Anata wo tsutsumiko mitai no\n[04:29.08]Anata ga warau warau\n[04:31.69]Anata ga waratteru\n[04:34.32]Sono riyuu ga Atashi dattara ii no ni na\n[04:39.68]Anata ga nagasu nagasu\n[04:42.02]Sono namida no wake mo zenbu\n[04:46.35]Atashi ga riyuudattara ii no ni na aaa\n[04:57.50]Atashi ga tonari ni iru uchi ni\n[05:01.57]Ai wo motto atashi ni kudasai\n[05:08.40]Yokubari de gomen nasai\n[05:13.57]Anata no ai ni oboretai\n[05:19.05]Atashi ga tonari ni iru uchi ni\n[05:22.26]Ai wo motto atashi ni kudasai\n[05:29.64]Afureru you na omoi de\n[05:34.81]Anata wo tsutsumiko mitai no\n[05:42.56]	/audio/Rising of The Shield Hero ED2 「Atashi ga Tonari.mp3	Atashi ga Tonari ni Iru Uchi ni	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253855/covers/Rising_of_The_Shield_Hero_ED2_Atashi_ga_Tonari_ni_Iru_Uchi_ni.jpg	1
1056	1056	1054	181	[ti:Tamako Love Story OP 「Koi no Uta」]\n[ar:Mamedai (Keiji Fujiwara)]\n[al:Tamako Market]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:00.60]\n[00:00.00] \n[00:14.59]Yuuhi ga shizumu ongakushitsu de\n[00:21.18]Piano wo kanaderu anata no\n[00:26.15]Yawarakai yokogao ni\n[00:33.40]Hikitsukerarete me ga hanasenakute\n[00:39.49]Anata no ie no terefon nanbaa\n[00:46.08]Kurikaeshi kaite oboete\n[00:51.18]Juwaki wo hazushite\n[00:58.26]Daiyaru mawasu sore dake nan da\n[01:04.22]Dakedo sonna yuuki mo dasenai kara\n[01:16.76]Semete kono uta wo anata no tame dake ni utau\n[01:42.12]Sugoku bakageta koto nan da kedo\n[01:47.97]Anata wo isshou shiawase ni suru\n[01:53.19]Anata ga daisuki de\n[02:00.64]Komacchimau kurai daisuki de\n[02:06.49]Dakedo sonna koto iidasenai kara\n[02:18.87]Semete kono uta wo anata no tame dake ni utau\n[02:30.53]Kono uta wa anata dake ni kiite hoshii\n[02:36.20]	/audio/Tamako Love Story OP 「Koi no Uta」.mp3	Koi no Uta	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253851/covers/Tamako_Love_Story_OP_Koi_no_Uta.jpg	1
1261	1261	1261	213	[ti:Whisper of the Heart ED 「Country Road」]\n[ar:Youko Honna]\n[al:Whisper of the Heart]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:33.09]\n[00:00.00]\n[00:07.83]Country road,\n[00:10.70]Kono michi, zutto, yukebaa\n[00:18.64]Ano machi ni, tsuzuiteru,\n[00:23.57]Kiga suru\n[00:26.26]Country road\n[00:52.52]Hitori botchi, osorezuni,\n[00:57.57]Ikiyoto, yume ni tetaa,\n[01:02.62]samishisa oshi komete,\n[01:06.96]Tsuyoichibun wo mamotte iko\n[01:10.82]Country road,\n[01:13.35]Kono michi, zutto, yukebaa\n[01:20.72]Ano machi ni, tsuzuiteru,\n[01:25.44]Kiga suru\n[01:27.58]Country road\n[01:31.00]Aruki tsukare, tatazumu to,\n[01:35.84]Ukande kuru, furusato no machii\n[01:40.74]Oka wo makuu, saka no michii,\n[01:45.28]Sonna boku wo Shikate iru\n[01:49.23]Country road,\n[01:51.90]Kono michi, zutto, yukebaa\n[01:58.90]Ano machi ni, tsuzuiteru,\n[02:03.67]Kiga suru\n[02:06.14]Country road\n[02:09.54]Donna kujike souna toki datte,\n[02:13.89]Keshite namida wa misenaidee\n[02:17.81]Kokoro nashi ka houchou, na hayaku natte iku,\n[02:22.95]Omoide, kesutame\n[02:31.89]Country road\n[02:34.51]Kono michi Furusato e Tsuzuitemo\n[02:41.46]Boku wa Yukanai sa Yukanai\n[02:48.63]Country road\n[02:51.26]Country road\n[02:53.62]Ashita wa, itsumono, boku saa\n[03:00.75]Kaeritai, kaerenai, sayonara\n[03:07.89]Country road\n[03:11.23]	/audio/Whisper of the Heart ED 「Country Road」.mp3	Country Road	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253858/covers/Whisper_of_the_Heart_ED_Country_Road.jpg	1
266	266	266	241	[ti:Fate Grand Order Absolute Demonic Front: Babylonia  ED2 「Prover」]\n[ar:milet]\n[al:Fate]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:23.4.20]\n[length:04:01.06]\n[00:00.00]\n[00:06.11]Fumikonda shadowland rakuen nante nai\n[00:12.49]Sabiru Old Remedies kakushin nante nai\n[00:17.87]Sore demo Go up the river\n[00:20.93]Shigamitsuku dake no ladder\n[00:24.06]Namida ni sae tomoru hi ga\n[00:27.20]Hitotsu no sign hitotsu no light\n[00:31.05]Akenai yoru mo uta ga togirenai you ni\n[00:37.07]Ate naku mayou yume ga motsurenai you ni\n[00:42.85]Surechigatta ashiatotachi furikaeranu you ni\n[00:48.75]Fumihazushita anata de sae tebanasanai you ni\n[00:54.98]I'm the Prover, I am the Prover\n[01:01.08]Owaranai sekai nida tte tachimukau you ni\n[01:07.65]I'm the Prover inochi no koe ga\n[01:13.41]Mata hibikidasu koro ni anata to\n[01:20.13]Shizumazu ni yuku fune wo\n[01:29.68]Furidashita iron rain zero ni suru tame no pray\n[01:35.60]Onaji kodoku o miteta anata nara wakarudeshō\n[01:41.14]Sore de mo go up the river\n[01:43.98]Itsu ka mata deaerunara\n[01:47.09]Kono ai ni tomoru hi ga\n[01:50.26]Hito-tsu no sign hito-tsu no light\n[01:54.04]Akenai yoru mo uta ga togirenai yō ni\n[02:00.13]Atenakumayou yume ga motsurenai yō ni\n[02:05.78]Surechigatta ashiato-tachi furikaeranu yō ni\n[02:11.85]Fumihazushita anata de sae tebanasanai yō ni\n[02:20.37]If you can't find your way\n[02:22.80](I won't give up on you)\n[02:26.21]Everything is not lost\n[02:30.01]('Cause I'm standing with you)\n[02:32.42]Ni do to modore wa shinai sekai da to shite mo\n[02:37.88]I'm here for you\n[02:44.67]I'll live for you\n[03:14.10]I'm the prover\n[03:16.69]I am the prover\n[03:19.75]Owaranai sekai ni da tte tachimukau yō ni\n[03:26.39]I'm the prover inochi no koe ga\n[03:31.85]Mata hibikidasu koto ni anata to (I'll be there)\n[03:38.55]Shizumazu ni yuku fune o\n[03:44.75]Doko made mo yuku fune o\n[03:50.66]	/audio/Fate Grand Order Absolute Demonic Front Babylonia  ED2 「Prover」.mp3	Prover	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253871/covers/Fate_Grand_Order_Absolute_Demonic_Front_Babylonia_ED2_Prover.jpg	1
461	339	458	201	[ti:Kabaneri of the Iron Fortress Movie ED 「Sakase ya Sakase」]\n[ar:EGOIST]\n[al:Kabaneri of the Iron Fortress]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:20.97]\n[00:00.00]\n[00:16.09]Ima to nare ba nagori yuki\n[00:20.71]Mushi wa aruku iyoiyo to\n[00:24.40]Kagiri aru mono ga utau\n[00:28.13]Nemuri fuyu o koete\n[00:31.14]Machidōshi ya ume Sakura hana mizuki\n[00:35.69]Kaore ba chō ni mitsubachi ga mau\n[00:39.45]Shoujou meiketsu hayo kīhin ka na\n[00:43.16]Ima wa tada yōkō ni\n[00:46.96]Dare ga yume o egaku\n[00:50.03]Sā sa motto odore ya odore\n[00:53.63]Ban made naruko narase\n[00:57.33]Hanafubuki sakase ya sakase\n[01:00.98]Atarashiki haru no hiki tare\n[01:05.30]Yuki tokete tsuchi kaore ba\n[01:09.41]Kawazu mo naku geragera to\n[01:13.22]Kusa wa mebuki yama warau\n[01:16.73]Nemuri fuyu o koete\n[01:20.08]Chōshi yokerya ei sa hoisa soko no shū\n[01:24.66]Maketara sore nome me mau made\n[01:28.46]Shō-jō se ze ara yotto\n[01:30.04]Shiranu koto\n[01:32.18]Ima wa tada hanamuke to\n[01:35.97]Mina ga yume o egaku\n[01:38.67]Sā sa motto iwae ya iwae\n[01:42.46]Ban made matsuri akase\n[01:46.24]Mina kakoe sakase ya sakase\n[01:50.07]Atarashiki haru no hi kure ba\n[01:54.24]Kokoro mo mata ibuku\n[01:58.59]Don to sawage omae ga tate yakusha\n[02:02.31]Odoru ahō ni miru ahō\n[02:05.93]Kansha kansha de yōtsu te tataki hyōshi ni nore\n[02:13.14]Unto sawage sora daichi made furuwasero\n[02:20.73]Don to sawage oi mo wakai moso iya to\n[02:27.56]Sā sa motto odore ya odore\n[02:31.99]Ban made naruko narase\n[02:35.49]Hanafubuki sakase ya sakase\n[02:39.18]Atarashiki haru no hiki tare\n[02:42.34]Sā sa motto iwae ya iwae\n[02:46.32]Ban made matsuri akase\n[02:50.11]Mina kakoe sakase ya sakase\n[02:53.89]Atarashiki haru no hi kureba\n[02:58.12]Kokoro mo mata ibuku\n[03:02.36]Sakase ya sakase\n[03:17.09]	/audio/Kabaneri of the Iron Fortress Movie ED 「Sakase .mp3	Sakase ya Sakase	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253870/covers/Kabaneri_of_the_Iron_Fortress_Movie_ED_Sakase_ya_Sakase.jpg	1
1107	1107	1107	262	[00:00.00] \n[00:18.76]RIARU na mahou ni\n[00:23.94]Kakatta mitai ni\n[00:29.54]Kono mune ni yakitsuita\n[00:34.43]Mabushii egao\n[00:40.06]Dakedo au tabi ni\n[00:44.99]TSUN TSUN tsumetaku shichau no\n[00:51.07]Naze dare yori ki ni naru no ni\n[00:56.16]IJIWARU wo shichaun darou?\n[01:04.49]Hontou no KIMOCHI\n[01:09.60]Setsuna sa no KAKERA ga\n[01:14.60]Kono KOKORO no ichiban oku\n[01:20.12]Kimi wo yonde iru yo\n[01:25.61]ZERO kara hajimaru hi wo\n[01:41.77]Sasayaka na kiseki\n[01:47.37]Nemuri ni tsuitara\n[01:52.64]Futari wa yume no naka de\n[01:57.80]Yorisotte ita\n[02:03.19]Hoka ni mo takusan\n[02:08.39]Suteki na hito wa iru no ni ne\n[02:13.78]Naze kimi dake tokubetsu na no?\n[02:18.81]Hoka no dare mo kawarenai\n[02:27.12]Hontou no KIMOCHI\n[02:32.14]Yasashisa wo agetai\n[02:36.88]Shiroi tsuki ni inori nagara\n[02:42.82]JUMON wo tonaeru yo\n[02:48.23]Sunao ni nareru you ni\n[03:25.60]Hontou no KIMOCHI\n[03:30.96]Setsunasa no KAKERA ga\n[03:36.10]Kono KOKORO no ichiban oku\n[03:41.39]Kimi wo yonde iru yo\n[03:47.15]Hontou no KIMOCHI\n[03:52.19]Yasashisa wo agetai\n[03:57.50]Yoake no hoshi UINKU shite\n[04:02.89]Watashi ni unazuita\n[04:08.25]Ashita ga hajimaru yo to\n[04:14.41]	/audio/The Familiar of Zero ED 「Honto no Kimochi」.mp3	Honto no Kimochi	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253868/covers/The_Familiar_of_Zero_ED_Honto_no_Kimochi.jpg	1
1226	1226	1226	296	[00:00.00] \n[00:27.02]nichiyou no hareta hirusagari\n[00:32.63]kyou wa doko e yukou\n[00:37.73]yasashiku soyogu kaze wa\n[00:41.72]kawa no minamo wo odoraseru\n[00:47.61] \n[00:58.71]okiniiri no rajio wo narasu\n[01:03.79]boryuumu wa ookime de\n[01:09.30]kayoinareta itsumo no michi ga\n[01:13.61]mabushiku kagayaite mieru\n[01:19.27]terasu atatakai taiyou to\n[01:24.59]tonari ni kimi ga ireba\n[01:28.56]mou high high high\n[01:33.38]hashagidasu kimochi ni\n[01:38.90]utae rai rai rai\n[01:43.85]koe mo tobihaneru\n[01:52.71] \n[02:14.28]shiosai kikoeru michi wo\n[02:19.34]hashireba suiheisen mietekuru\n[02:24.68]rajio kara no suteki na kyoku ni\n[02:29.18]tobikau tori mo utaidasu\n[02:34.95]yosete wa kaesu nami no oto\n[02:40.14]tonari ni kimi ga ireba\n[02:44.26]mou high high high\n[02:49.16]maiagaru kaze ni nori\n[02:54.51]utae rai rai rai\n[02:59.63]koe wa doko made mo\n[03:13.91]taisetsu na no wa ima,\n[03:16.75]kimi no nukumori kanjiru koto\n[03:23.96]high high high\n[03:28.29]hashagidasu kimochi ni\n[03:33.77]utae rai rai rai\n[03:38.50]koe wa doko made mo\n[03:44.63]mou high high high\n[03:49.15]maiagaru kaze ni nori\n[03:54.69]utae rai rai rai\n[03:59.45]koe mo tobihaneru\n[04:08.36] \n	/audio/Usagi Drop ED 「High High High」.mp3	High High High	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253932/covers/Usagi_Drop_ED_High_High_High.jpg	1
435	435	435	289	[00:00.00] \n[00:16.43]sakamichi wo nobotta saki ni matsu\n[00:23.73]tokubetsu na keshiki wo yubi de kiritotta kimi\n[00:31.51]mimimoto wo mahou ga kasumete irozuku sekai\n[00:44.20]watashi wo nokoshite\n[00:48.89] \n[00:50.34]mirai wa kobore koborete ashimoto de nijimu\n[00:59.84]monotoon tamari shizundemo\n[01:06.34]kawaranu asu wo dakishimete shimaetara\n[01:18.01]kimi ni sukoshi chikazuku\n[01:24.66] \n[01:38.52]sakamichi wo nobotta saki no ano\n[01:45.72]keshiki wa kawarihate betsu no dareka no mono\n[01:53.50]kuchibiru ni mahou wo yadoshite\n[02:01.62]iwazu ni ita taisetsu na himitsu\n[02:10.29]oto ni nosereba kuuki wo furuwasete\n[02:17.08]ryuusei no you tsuyoku hikatte mieta\n[02:26.04]tomoshita iro wa azayaka ni tooi keredo\n[02:37.96]toumei de wa nai kara\n[02:44.65] \n[03:13.95]kimi no egaita ari no mama no keshiki ni\n[03:22.10]jibun no katachi mo kage sae mo utsuranai\n[03:30.18]soredemo ii\n[03:34.09] \n[03:34.33]kawaranu asu no tame ni\n[03:39.24]kimi ni nando mo deau\n[03:44.02]tada, watashi, shiritakute,\n[03:50.20]sekai wa somaru somatte ashita e to kawaru\n[04:00.00]ima tashika na mahou de\n[04:06.18]hitomi no naka wo asayake ga mitashiteru\n[04:17.96]mirai wa mada koko kara\n[04:24.68] \n	/audio/Irozuku Sekai no Ashita Kara ED 「Mimei no Kimi .mp3	Mimei no Kimi to Hakumei no Mahou	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253885/covers/Irozuku_Sekai_no_Ashita_Kara_ED_Mimei_no_Kimi_to_Hakumei_no_Mahou.jpg	1
694	694	627	237	[ti:Naruto Shippuden OP16 「Silhouette」]\n[ar:KANA-BOOM]\n[al:Naruto]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:57.26]\n[00:00.00]\n[00:24.22]Issee noo se de\n[00:26.44]Fumikomu goorurain\n[00:28.62]Bokura wa nanimo nanimo mada shiranu\n[00:35.02]Issen koete\n[00:37.22]Furikaeru to mou nai\n[00:39.23]Bokura wa nanimo nanimo mada shiranu\n[00:45.77]Udatte udatte udatteku\n[00:50.22]Kirameku ase ga koboreru no sa\n[00:55.95]Oboetenai koto mo\n[00:58.48]Takusan atta darou\n[01:02.09]Daremo kare mo shiruetto\n[01:06.26]Daiji ni shiteta mono\n[01:08.94]Wasureta furi wo shitanda yo\n[01:12.31]Nanimo nai yo waraeru sa\n[01:19.80]Issee noo de\n[01:21.78]Omoidasu shounen\n[01:23.68]Bokura wa nanimokamo hoshigatta\n[01:29.92]Wakatatteiru tte\n[01:32.31]Aa kidzuiteiru tte\n[01:34.40]Tokei no hari wa hibi wa tomaranai\n[01:40.54]Ubatte ubatte ubatteku\n[01:45.19]Nagareru toki to kioku\n[01:48.37]Tooku tooku tooku ni natte\n[01:51.13]Oboetenai koto mo\n[01:53.39]Takusan atta darou\n[01:56.94]Daremo kare mo shiruetto\n[02:01.42]Osorete marugoto\n[02:04.02]Shiranai furi wo shitanda yo\n[02:07.38]Nanimo nai yo waraeru sa\n[02:23.26]Hirari to hirari to matteru\n[02:27.33]Konoha no you ni yureru koto naku\n[02:31.60]Shousou nakusu sugoshiteitai yo\n[02:35.10]Oboetenai koto mo\n[02:37.28]Takusan atta kedo\n[02:39.78]Kitto zutto\n[02:43.38]Kawaranai mono ga aru koto wo\n[02:47.81]Oshietekureta anata wa\n[02:50.95]Kieru kieru shiruetto\n[02:55.84]Daiji ni shitai mono\n[02:58.30]Motte otona ni narunda\n[03:01.99]Donna toki mo hanasazu ni\n[03:06.27]Mamoritsudzukeyou\n[03:08.58]Soshitara itsu no hi ni ka\n[03:12.23]Nanimokamo waraeru sa\n[03:16.86]Hirari to hirari to matteru\n[03:21.29]Konoha ga tondeyuku\n[03:31.38]WO...\n[03:34.01]	/audio/Naruto Shippuden OP16 「Silhouette」.mp3	Silhouette	OP16	https://res.cloudinary.com/ddc6silap/image/upload/v1773253849/covers/Naruto_Shippuden_OP16_Silhouette.jpg	1
1283	1283	1281	221	[00:00.00] \n[00:20.09]Modoranai hibi ni namida koboshite\n[00:29.74]Miageta sora wa akaku akaku moeru\n[00:39.55]Jibun no tsuyosa yowasa\n[00:44.28]Kizuketa no nara ima\n[00:52.02]Kimi yo osoreru na\n[00:55.76]Kokoro omomuku mama\n[01:00.07]Kaze wo kirisusumu\n[01:03.09]Sono tabiji wo akatsuki ga terasu\n[01:07.60]Tsudoe\n[01:08.58]Takeki kaina\n[01:09.77]Senri no hitomi\n[01:10.72]Sora wo kakeyuku ashi\n[01:13.66]Kuon no tate\n[01:14.71]Inishie no chikai ima hatashite\n[01:20.02]Yoru yo akete yuke\n[01:30.20]Minamo ochiru hana hitotsu\n[01:34.21]Doko e doko e nagare\n[01:38.54]Dare ga shiru ka kunnou no\n[01:42.74]Kokoro wa mada kumo no naka\n[01:46.59]Wúxiàn tāo dòng\n[01:50.72]Zài nà cǎoyuán\n[01:54.88]Yìdì fēng xiāoxiāo\n[01:58.80]Zài rénjiān\n[02:04.91]Yogiru mayoi wo tsuranuku you ni\n[02:12.74]Yumi ni ya tsugae tooku tooku hanatsu\n[02:21.01]Aka no kami wo nabikasete\n[02:25.23]Ikiru koto wo kimeta nara\n[02:29.26]Wareta tsume mo kizuato mo\n[02:33.49]Ashita e no kate ni shite\n[02:40.49]Kimi yo wasureru na\n[02:44.42]Moyuru sora no hate ni\n[02:48.64]Itsuka mita yume no\n[02:51.63]Sono kakera ga mezame matsu darou\n[03:11.57]Kimi yo osoreru na\n[03:15.07]Kokoro omomuku mama\n[03:19.12]Manazashi no honoo\n[03:22.12]Tayasanu you\n[03:24.08]Kimi rashiku susume\n[03:26.10]Shiroki kizuna wo kawashi\n[03:29.91]Ao no yoru ni inori sasage\n[03:34.39]Midori no tane wo makite\n[03:38.05]Ougon no minori wo idake\n[03:42.46]	/audio/Yona of the Dawn OP2 「Akatsuki no Hana」.mp3	Akatsuki no Hana	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253876/covers/Yona_of_the_Dawn_OP2_Akatsuki_no_Hana.jpg	1
157	157	95	235		/audio/Couple of Cuckoos OP 「Dekoboko」.mp3	Dekoboko	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254052/covers/Couple_of_Cuckoos_OP_Dekoboko.jpg	1
221	136	219	255	[ti:Domestic Girlfriend OP 「Kawaki wo Ameku」]\n[ar:Minami]\n[al:Domestic Girlfriend]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:13.36]\n[00:02.45]Mijuku Mujou Saredo\n[00:07.33]Utsukushiku are\n[00:23.53]No Destiny fusawashiku nai\n[00:27.18]Konnan ja kitto mono tarinai\n[00:29.04]Kurai katattokeba umaku iku\n[00:30.89]Mono, kane, ai, koto, mou jiko kenji akita\n[00:37.20]Déjà vu nani ga sonna fuman nan da?\n[00:41.58]Sanzan wagamama katattoite kore ijou hoka ni nani ga iru?\n[00:45.40]Sonna tokoro mo wari to kirai ja nai\n[00:52.73]Mou 'kikiakitan da yo, sono serifu.'\n[00:55.85]Chuuto hanpa dake wa iya\n[00:59.92]Mou ii\n[01:00.67]Aa shite kou shite ittetatte\n[01:02.37]Aishite dou shite? iwaretatte\n[01:04.21]Asobi dake nara kantan de shinken koushou muchakucha de\n[01:08.09]Omoi mo shinai omoi kotoba\n[01:11.29]Nan do tsukaifurusu no ka?\n[01:14.51]Douse\n[01:15.29]Kitai shitetanda deki reisu demo\n[01:17.18]Inyoudarake no fureizu mo\n[01:19.18]Kakato mochiagaru kotoba tabuu ni shite\n[01:23.78]Kuuki wo yonda ame furanaide yo\n[01:41.31]Madorokkoshii hanashi wa iya\n[01:48.68]Hitsuyou saiteigen de ii ni moji inaide douzo\n[01:55.92]Kurenai no chou wa nan no meiru mo okuranai\n[02:03.31]Moroi sensu hirogeru sono hou ga miryokuteki deshou\n[02:10.33]Mei de\n[02:11.13]Kotaerarenai nara hottoite kure\n[02:12.93]Mayoeru kurai nara sattoite kure\n[02:14.84]Kanjin na toko wa tsutsunuke de anshin dake wa saserareru you na\n[02:19.40]Amai ame ga fureba\n[02:21.94]Kasa mo sashitaku naru darou?\n[02:25.46]Kono mama\n[02:26.12]Kitai shita mama de yokatta\n[02:27.77]Me wo tsubutta kaetakatta otonabutta\n[02:30.64]Nakushita makimodosenakatta\n[02:33.91]Ima ame, yamanaide\n[02:37.95]Kopii, peisuto, deriito sono kurikaeshi\n[02:49.26]Sutte haita\n[02:51.30]Dakara\n[02:55.67]Sore demo ii kara sa koko itai yo\n[02:58.92]Mou ii\n[02:59.88]Aa shite kou shite ittetatte\n[03:01.55]Aishite dou shite? iwaretatte\n[03:03.34]Asobi dake nara kantan de shinken koushou shiri metsuretsu de\n[03:07.06]Omoi mo shinai omoi uso wa\n[03:10.57]Tabuu ni shinakucha na?\n[03:13.70]Kitto\n[03:14.71]Kitai shitetan da deki reisu demo\n[03:16.65]Koushiki touri no fureizu mo\n[03:18.52]Kakato agaru kuse mou owari ni shite\n[03:23.13]Kuuki wo yonda sora harenai de yo\n[03:59.17]Kyou mo Ame\n[04:02.68]Kasa wo tojite\n[04:05.01]Nurete Kaerou yo	/audio/Domestic Girlfriend OP 「Kawaki wo Ameku」.mp3	Kawaki wo Ameku	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254054/covers/Domestic_Girlfriend_OP_Kawaki_wo_Ameku.jpg	1
309	300	300	256	[00:00.00] \n[00:21.53]Rokugatsu no uso me no mae no hontou\n[00:28.72]Sepia ni shimaikomu\n[00:32.91]Yorisou to ka nukumori to ka\n[00:38.96]Wakaranaku natteta\n[00:41.68]"kimi wa hitori de heiki da kara... ne" to\n[00:48.86]Oshitsukete sayonara\n[00:53.07]Sono tagui no kiyasume nara\n[00:58.07]Kikiakita hazu na no ni\n[01:01.92] \n[01:03.50]Nariyamanai youshanai omoidetachi wa\n[01:08.31]Yurushitekuresou ni mo nai\n[01:13.56]Me wo tojireba ikioi wa masu bakari de\n[01:18.38]Toomaki de kimi ga warau\n[01:23.55] \n[01:25.73]Ame wa itsuka yamu no deshou ka\n[01:30.71]Zuibun nagai aida tsumetai\n[01:35.73]Ame wa dou shite boku wo erabu no\n[01:41.16]Nigeba no nai boku wo erabu no\n[01:49.84] \n[01:49.90]Yatto mitsuketa atarashii asa wa\n[01:57.16]Tsukihi ga jama wo suru\n[02:01.38]Mukau saki wa "tsugi" ja nakute\n[02:06.41]"sugi" bakari oikaketa\n[02:10.36] \n[02:11.63]Nagusame kara kikkake wo kureta kimi to\n[02:16.59]Urameshiku kowagari na boku\n[02:21.77]Sorosoro ka na tesaguri tsukareta hoho wo\n[02:26.67]Kattou ga koboreochiru\n[02:31.37]Kako wo shiritagaranai hitomi\n[02:36.32]Arainagashitekureru yubi\n[02:41.51]Yasashii hohaba de iyasu kizuato\n[02:46.84]Todokisou de todokanai kyori\n[02:54.55] \n[03:11.85]Ame wa itsuka yamu no deshou ka\n[03:16.76]Zuibun nagai aida tsumetai\n[03:21.96]Ame wa dou shite boku wo erabu no\n[03:27.20]Tsutsumarete ii ka na\n[03:32.06]Ame wa yamu koto wo shirazu ni\n[03:37.03]Kyou mo furitsuzuku keredo\n[03:41.98]Sotto sashidashita kasa no naka de\n[03:47.43]Nukumori ni yorisoinagara\n[03:58.79] 	/audio/Fullmetal Alchemist Brotherhood OP5 「Rain」.mp3	Rain	OP5	https://res.cloudinary.com/ddc6silap/image/upload/v1773253897/covers/Fullmetal_Alchemist_Brotherhood_OP5_Rain.jpg	1
702	145	627	248	[ti:Naruto Shippuden OP6 「Sign」]\n[ar:FLOW]\n[al:Naruto]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:08.35]\n[00:00.00]\n[00:10.36]I realize the screaming pain\n[00:14.48]Hearing loud in my brain\n[00:17.71]But I’m going straight ahead with the scar\n[00:36.09]“Wasurete shimaeba ii yo kanjinaku nacchaeba ii”\n[00:41.50]Surimuita kokoro ni futa wo shitan da\n[00:47.08]“Kizutsuita tte heiki da yo mou itami wa nai kara ne”\n[00:52.36]Sono ashi wo hikizuri nagara mo\n[00:58.41]Miushinatta jibun jishin ga\n[01:00.75]Oto wo tatete kuzurete itta\n[01:03.47]Kizukeba kaze no oto dake ga…\n[01:08.37]Tsutae ni kita yo kizuato wo tadotte\n[01:13.41]Sekai ni oshitsubusarete shimau mae ni\n[01:18.99]Oboeteru ka na namida no sora wo\n[01:24.56]Ano itami ga kimi no koto wo mamotte kureta\n[01:30.35]Sono itami ga itsumo kimi wo mamotterun da\n[01:38.50]“Kizutsukanai tsuyosa yori mo kizutsukenai yasashisa wo”\n[01:43.74]Sono koe wa dokoka kanashisou de\n[01:49.59]Kakechigaeta botan mitai ni\n[01:51.99]Kokoro karada hanarete itta\n[01:54.56]Mou ichido kokoro wo tsukande\n[01:59.52]Tsutae ni kita yo kizuato wo tadotte\n[02:05.33]Sekai ni oshitsubusarete shimau mae ni\n[02:10.22]Oboeteru ka na namida no sora wo\n[02:16.09]Ano itami ga kimi no koto wo mamotte kureta\n[02:21.68]Sono itami ga itsumo kimi wo mamotterun da\n[02:46.37]Itsuka kiita ano nakigoe wa\n[02:48.65]Machigai naku sou jibun no datta\n[02:51.29]Subete wa kono toki no tame ni…\n[02:58.55]Kitto hajime kara wakattetan da\n[03:04.53]Mou nido to jibun dake wa hanasanaide\n[03:09.65]Kizuite kureta kimi e no aizu\n[03:15.34]Ano itami ga kimi no koto wo mamotte kureta\n[03:20.53]Tsutae ni kita yo kizuato wo tadotte\n[03:26.17]Sore nara mou osoreru mono wa nain da to\n[03:31.26]Wasurenaide ne egao no wake wo\n[03:37.12]Ano itami ga kimi no koto wo mamotte kureta\n[03:42.24]Ano itami ga kimi no koto wo mamotte kureta\n[03:47.68]Sono itami ga itsumo kimi wo mamotterun da\n[03:52.00]	/audio/Naruto Shippuden OP6 「Sign」.mp3	Sign	OP6	https://res.cloudinary.com/ddc6silap/image/upload/v1773253822/covers/Naruto_Shippuden_OP6_Sign.jpg	1
754	754	753	264	[00:00.00] \r\n[00:06.34](Tonight, we honor the hero)\r\n[00:21.20]Fusagu no men yei kowasu kyouran kids\r\n[00:24.65]Uso kirai? houkai? Hibi wo touka shite\r\n[00:27.99]Amai taion no mitsu nioi tatte\r\n[00:31.39]Sosoru flavor flavor flavor\r\n[00:33.88]Just wanna hold your hands\r\n[00:37.35]Just wanna hold your hands\r\n[00:40.77]Just wanna hold your hands\r\n[00:42.44](Hey people. Let's go back to zero)\r\n[00:47.87]Kurutte hey kids, tozashita kinou o terashte\r\n[00:52.49]Ikiba Nai shoudou\r\n[00:54.62]Kurutte hey kids, modorenai basho o sagashite\r\n[00:58.82]Woah oh oh oh\r\n[01:01.47]Kurutte hey kids, kudaranai ego o tobashite\r\n[01:06.05]Imi No nai kousou\r\n[01:08.13]Kurutte heiki? Watashi no namae o hakanai ka?\r\n[01:12.98](Are you ready? I respect the hero)\r\n[01:28.90]Narasanai no? Kokkei na disutooshon\r\n[01:32.29]Ima ya kyouhan sa ama no sonzai mo hora\r\n[01:36.58](Who is the master, who calls my favorite name?)\r\n[01:39.17]Iza forever, ever, ever\r\n[01:42.02]Kurutte hey kids, tozashita kinou o terashite\r\n[01:46.57]Ikiba Nai shoudou\r\n[01:48.76]Kurutte hey kids, modorenai basho o sagashite\r\n[01:52.93]Woah oh oh oh\r\n[01:55.47]Kurutte hey kids, kudaranai ego o tobashite\r\n[02:00.16]Imi No nai kousou\r\n[02:02.36]Kurutte heiki? Watashi no namae o hakanai ka?\r\n[02:09.12] \r\n[02:33.87]Oh~\r\n[02:45.59]Just wanna hold your hands\r\n[02:51.07] \r\n[03:00.99]Just wanna hold your ha-ha-hands\r\n[03:04.43]Just wanna hold your ha-ha-hands\r\n[03:07.64]Just wanna hold your ha-ha-hands\r\n[03:11.21]Just wanna hold your ha-ha-hands\r\n[03:13.18]Kurutte hey kids, shidai ni jidai wa kawatte\r\n[03:17.92]Owaranai shousou\r\n[03:20.11]Kurutte hey kids, deau hazu datta anata to\r\n[03:26.79]Kurutte naita wasurenai ai o Sagashite\r\n[03:31.36]Tsunagitai zutto\r\n[03:33.70]Kurutte hey kids, soredemo\r\n[03:36.03]Mirai wa hakanai ka?\r\n[03:43.26]Just wanna hold your hands\r\n[03:48.59](I swear I respect the hero)\r\n[03:52.49] \r\n	/audio/Noragami Aragoto OP 「Kyouran Hey Kids!!」.mp3	Kyouran Hey Kids!!	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254088/covers/Noragami_Aragoto_OP_Kyouran_Hey_Kids.jpg	1
76	76	75	212		/audio/Ben-To OP2 「Treasure」.mp3	Treasure	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253911/covers/Ben-To_OP2_Treasure.jpg	1
78	78	77	318		/audio/Big Fish _ Begonia OP 「Da Yu」.mp3	Da Yu	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253912/covers/Big_Fish_Begonia_OP_Da_Yu.jpg	1
103	103	102	256		/audio/Bofuri OP 「Kyuukyoku Unbalance!」.mp3	Kyuukyoku Unbalance!	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253909/covers/Bofuri_OP_Kyuukyoku_Unbalance.jpg	1
115	115	112	231		/audio/Cells at Work S2 OP 「GO!GO! Saibou Festa」.mp3	GO!GO! Saibou Festa	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253921/covers/Cells_at_Work_S2_OP_GO_GO_Saibou_Festa.jpg	2
129	129	129	273		/audio/Citrus ED 「Dear Teardrop」.mp3	Dear Teardrop	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253928/covers/Citrus_ED_Dear_Teardrop.jpg	1
134	108	131	300		/audio/Clannad OP 「Megu Meru」.mp3	Megu Meru	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253923/covers/Clannad_OP_Megu_Meru.jpg	1
139	139	94	264		/audio/Code Geass ED 「Yuukyou Seisyunka」.mp3	Yuukyou Seisyunka	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253925/covers/Code_Geass_ED_Yuukyou_Seisyunka.jpg	1
307	307	300	90	[00:00.00] \n[00:09.04]Shuuchuu dekite nai na mada karada ga mayotte iru 'n da\n[00:13.30]furuete ita 'n ja KONTOROORU shitatte bure 'n da\n[00:16.97]taiyou mo tsuki mo nan mo kanzen ni kocchi muite inai ga\n[00:20.85]yaru shika nai 'n da iikikaseru you ni sou tsubuyaita\n[00:24.72] \n[00:26.41]Joukyou wa warui ga tada nigedasu 'n ja konjou nai na\n[00:30.42]tenbou wa nai ga dokyou de KURIA suru shika nai ya\n[00:34.18]shoudou wa osaeta mama TAAGETTO to no kankaku sagure\n[00:38.07]hitsuyou na mono wa katsu PURAIDO wo\n[00:40.93]ajiwau no wa shouri no bishu ka sore tomo haiboku no kujuu ka\n[00:48.23]sono subete wa futatsu ni hitotsu ayatsuritai unmei no ito\n[00:57.07]Zekkou no GOORUDEN TAIMU kono te de tsukame\n[01:00.95]konshin no POOKAA FEISU kimete shikakeru yo\n[01:05.05]IRYUUJON no sekai e hikizuri konde\n[01:10.26] \n[01:12.43]Saigen nai PURESSHAA GEEMU sururito nukete\n[01:16.36]eikou no BOODAA RAIN tobikoeru tame ni\n[01:20.52]HAU MENII? dore kurai no daishou ga iru?\n[01:25.20]tebanashitaku nai no wa dore?\n[01:29.33] 	/audio/Fullmetal Alchemist Brotherhood OP3 「Golden Tim.mp3	Golden Time Lover	OP3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253914/covers/Fullmetal_Alchemist_Brotherhood_OP3_Golden_Time_Lover.jpg	1
9	9	6	267		/audio/Accel World OP2 「Burst the Gravity」.mp3	Burst the Gravity	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773254201/covers/Accel_World_OP2_Burst_the_Gravity.jpg	1
136	136	136	250		/audio/Classroom of the Elite ED 「Beautiful Soldier」.mp3	Beautiful Soldier	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253944/covers/Classroom_of_the_Elite_ED_Beautiful_Soldier.jpg	1
573	573	573	269	[00:00.00] \n[00:25.99]Kokoro ga shinu yo jibun no tamerai ga\n[00:30.41]hikigane ni naru yo\n[00:33.82]"Tasukete" kimi he to\n[00:35.94]"Shinjite" kimi kara moreta koe ni yureru\n[00:42.00]Kiseki wo inorou ka\n[00:45.05]Dakedo higeki ha owaranai kodou\n[00:49.90]Yami no oku de kurikaesu\n[00:53.77]Sakebi, itami, ikari, akui.\n[00:58.35]Erabareshi Blood teller\n[01:01.63]Nakitaku nai kore ijou aitaku nai\n[01:05.94]Moeru itoshisa ga kousa-shita\n[01:09.92]Ai ni kite nakitakute oikakete\n[01:14.13]Dare ni mo tomerarenai\n[01:18.51]Kore ha mirai? Soretomo yume? Kotae ha\n[01:23.92]doko darou\n[01:26.39]Kore ga ima wo tamesu tobira kowasu\n[01:31.75]no? Akeru no? Doushiyou?\n[01:37.90] \n[01:45.17]Kotoba ni sasare yokei na awaremi de\n[01:49.65]teokure ni naru sa\n[01:53.09]"Oshiete" boku he to\n[01:55.41]"Tsuresatte" boku ni ha kakugo sae tarinai\n[02:01.03]Risei de shibarou ka\n[02:04.44]Nanoni kyoufu ni kimi ga nigeta yo\n[02:09.22]Yurushinagara dakishimeru\n[02:13.16]Nageki, urami, aseri, satsui.\n[02:17.73]Kasanereba Blood teller\n[02:20.78]Furetaku nai samui kedo aitaku nai\n[02:25.17]Furue motomeau sonzai ha\n[02:29.19]Ai ni kite furetakute toikakete\n[02:33.35]Dare ni mo jama sasenai\n[02:37.49]Negau mirai? Kanawanu yume? Kotae ha\n[02:43.26]doko darou\n[02:45.66]Negai sae mo tamesu tobira kowashite?\n[02:51.37]Aketara? Lost heaven...\n[02:56.11] \n[03:13.92]I wanna stay erabareshi Blood\n[03:17.05]foreigner\n[03:18.25]Kiero uragiri no kizashi yo\n[03:21.96]But I wanna live kasanereba Blood\n[03:25.27]alien\n[03:26.39]Modorenu mama ni nemure\n[03:30.16]Nakitaku nai kore ijou aitaku nai\n[03:34.32]Moeru itoshisa ga kousa-shita\n[03:38.20]Ai ni kite nakitakute oikakete\n[03:42.70]Dare ni mo tomerarenai\n[03:46.93]Kore ha mirai? Soretomo yume? Kotae ha\n[03:52.36]doko darou\n[03:54.90]Kore ga ima wo tamesu tobira kowasu\n[04:00.19]no? Akeru no? Blood teller...\n[04:09.33] \n	/audio/Mirai Nikki ED 「Blood Teller」.mp3	Blood Teller	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253934/covers/Mirai_Nikki_ED_Blood_Teller.jpg	1
761	761	759	204	[ti:Odd Taxi OP 「ODDTAXI」]\n[ar:PUNPEE]\n[al:Odd Taxi]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:23.52]\n[00:00.00]Teiryuu ni yorisotte\n[00:06.42]Kaabu wo magareba mata\n[00:13.25]Ankyo ni ochiteiku you da\n[00:18.50]Nani ga mieru?\n[00:21.17]Nani ga hibiiteru?\n[00:25.95]Kotaete yo\n[00:38.64]Machi wa rekoodo de\n[00:40.42]Hibi wo noseta hari ga sarashiteru noizu\n[00:44.14]Boku wa haikei ni natte kimi ni toccha\n[00:47.65]Shosen gomi shori\n[00:50.00]Rizume shita rejume ja tokenai nazo no rizumu gennari sa nareru\n[00:55.36]Machi ni fuchidorareta jibun wo shitte (Iya ni naru kedo)\n[00:59.71]Kake chigaeta kioku\n[01:02.80](Guddo mōningu kumori akita sukai)\n[01:04.70]Mazariawanai mesen no saki e\n[01:14.30]Tadoritsukeru ka\n[01:21.55]Oketemo yoshi moke moke suru no mo yoshi kedo\n[01:27.11]Acchuu ma ni deru rouhaibutsu haiki gasu toka Co2\n[01:31.65]Hontou jinsei mo ootoma douse komyunikeeshon nante engiryoku (Hold On)\n[01:37.68]Gakkou ja shirenai minohodo kono anime sanshou no hodo\n[01:41.98]Obake gaado nukete sa mou kyou wa kono gurai de\n[01:52.33]Mawari mireba hora kaonajimi no ko najimi no hinekuremono kane kaese yo\n[02:04.79]Yurete koboreochite\n[02:11.34]Hokorobi wa tsuranatte\n[02:15.34]Marude fukurokouji janai ka!\n[02:24.06]Bokura wa zutto\n[02:29.01]Tobira tatakenai mama\n[02:38.55]Kake chigaeta kioku\n[02:44.45]Minareta hazu no keshiki ni\n[02:49.20]Tarinai mono ga arun da\n[02:55.27]Mazariawanai mesen no wake wo\n[03:03.86]Omoidaseru ka\n[03:08.20]	/audio/Odd Taxi OP 「ODDTAXI」.mp3	ODDTAXI	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253846/covers/Odd_Taxi_OP_ODDTAXI.jpg	1
149	149	94	239		/audio/Code Geass S2 ED Theme Song 「Mushoku Toumei」.mp3	Mushoku Toumei	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253961/covers/Code_Geass_S2_ED_Theme_Song_Mushoku_Toumei.jpg	2
154	154	154	236		/audio/Combatants will be Dispatched ED 「Home Sweet Ho.mp3	Home Sweet Home	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253963/covers/Combatants_will_be_Dispatched_ED_Home_Sweet_Home.jpg	1
174	174	96	235		/audio/Darker than Black S2 OP 「Tsukiakari no Michishi.mp3	Tsukiakari no Michishirube	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253975/covers/Darker_than_Black_S2_OP_Tsukiakari_no_Michishirube.jpg	2
184	184	184	234		/audio/Date A Live ED 「Hatsukoi Winding Road」.mp3	Hatsukoi Winding Road	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253964/covers/Date_A_Live_ED_Hatsukoi_Winding_Road.jpg	1
226	226	223	159		/audio/Dororo OP2 「Dororo」.mp3	Dororo	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773254203/covers/Dororo_OP2_Dororo.jpg	1
308	308	300	218	[00:00.00] \n[00:19.54]Owari naki tabi no tochuu tachidomarisou na toki\n[00:27.08]Fukai tameiki kobosu bokura wa\n[00:34.21] \n[00:35.39]Tsukamikakete wa mata hanareteiita\n[00:41.71]Demo ima wa mou nanimo osoreru koto wa nai\n[00:49.47]Kokoro o tsunagu tsuyoi kizuna wa\n[00:56.70]Keshite hodoke wa shinai sa\n[01:04.43]Sagashitsuzukete tadoritsuita\n[01:12.05]Kono basho de piriodo ni\n[01:19.05] \n[01:35.18]Ai ni michita nukumori karadajuu kakemeguru\n[01:42.68]Nido to kieru koto nai kioku ga...\n[01:49.44] \n[01:49.65]Kanarazu yakusoku hatashite kimi o tsureteku yo\n[01:57.38]Afureru (yume o) negai (daite) subete uta ni nosete\n[02:04.81]Genjitsu kara me wo sorasazu ni\n[02:12.37]Tachimukau yuuki wo\n[02:19.89]Kanashimi ikari chikara ni kaete\n[02:27.93]Unmei wa sugu soba ni\n[02:34.38] \n[02:37.09]Mukau saki wa sora\n[02:43.10]Kirameku sekai\n[02:47.42] \n[02:50.30]Boku wo furuwasu kono kansei wo\n[02:57.82]Uragiru koto wa shinai sa\n[03:05.34]Tomo ni ikiteku mirai no tame ni\n[03:13.05]Kono basho de piriodo ni\n[03:20.00] \n[03:20.56]Shinjitsu wa yubisaki ni\n[03:28.93] \n	/audio/Fullmetal Alchemist Brotherhood OP4 「Period」.mp3	Period	OP4	https://res.cloudinary.com/ddc6silap/image/upload/v1773253967/covers/Fullmetal_Alchemist_Brotherhood_OP4_Period.jpg	1
770	768	766	219	[00:00.00] \n[00:14.16]Heion datta machi ni\n[00:16.62]Gouon hibikasekuru zo\n[00:18.79]Yabai! kebai! Monsters!\n[00:23.46]Senjin kin no dare da?\n[00:25.91]Kaijin haijo no sai wa\n[00:28.26]Hakai & gokai… bureikou!\n[00:33.06]We know “We are HEROES!”\n[00:38.10](Ah) naze aku ni\n[00:39.51](omae) umareta no ka?\n[00:42.11](kotae) shiritai nara\n[00:44.43](tokubetsu) oshieyou\n[00:46.78]Konya seigi no panchi de dohade ni\n[00:52.41]Chiru no ga sadame\n[00:57.29](HERO) sono na wa yatsu no tame ni aru\n[01:01.70](Go! Go!) seijaku no ken wo tsukiagero!\n[01:06.47](HERO) kodoku wo seou aposutoru\n[01:11.08](Go! Go!) nikushimi janai\n[01:14.92]Heiwa wo mamoru dake sa\n[01:23.11]Manten datta suriru\n[01:25.42]Itten kyoufu ni kaete\n[01:27.82]Hidoi! kudoi! Monsters!\n[01:32.37]Saikyou chiimu kumu zo\n[01:34.63]Aikyou nai yatsua iranee\n[01:36.54]A kyuu B kyuu… Thank you!\n[01:41.83]You know “We are HEROES!”\n[01:46.58](Ah) biru yori mo\n[01:48.21](maji de) dekai teki ni\n[01:50.68](furari) idomu aitsu\n[01:52.73](doko no) dare darou?\n[01:55.55]Arekuru ujuujin ippatsu de taoshita\n[02:01.18]Ase mo kakazu ni\n[02:06.05](HERO) kagayake! jigoku e no sora ni\n[02:10.53](Go! Go!) chinmoku no jojishi kakiagero!\n[02:15.35](HERO) kaosu ni ochita aposutoru\n[02:19.60](Go! Go!) hamon hirogeru\n[02:24.12]Tsuyosa ga unmei da\n[02:32.85] \n[02:47.93](HERO) kagayake! jigoku e no sora ni\n[02:52.46](Go! Go!) chinmoku no uta yo\n[02:57.21](HERO) sono na wa yatsu no tame ni aru\n[03:01.67](Go! Go!) seijaku no ken wo tsukiagero!\n[03:06.59](HERO) kodoku wo seou aposutoru\n[03:11.17](Go! Go!) nikushimi janai\n[03:15.22]Heiwa wo mamoru dake sa… ONE PUNCH!\n[03:33.47] \n	/audio/One Punch Man S2 OP 「Seijaku no Apostle」.mp3	Seijaku no Apostle	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253833/covers/One_Punch_Man_S2_OP_Seijaku_no_Apostle.jpg	2
10	10	6	319		/audio/Accel World_ Infinite Burst ED 「PLASMIC FIRE」.mp3	PLASMIC FIRE	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254207/covers/Accel_World_Infinite_Burst_ED_PLASMIC_FIRE.jpg	1
14	14	13	280		/audio/Ah! My Goddess OP  「Shiawase no Iro」.mp3	Shiawase no Iro	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254209/covers/Ah_My_Goddess_S2_OP_Shiawase_no_Iro.jpg	2
15	14	13	260		/audio/Ah! My Goddess OP 「Open Your Mind」.mp3	Open Your Mind	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254205/covers/Ah_My_Goddess_OP_Open_Your_Mind.jpg	1
232	232	227	227	[00:00.00] \r\n[00:22.04]Migi e iku ka hidari iku ka dou dai dou dai\r\n[00:26.87]Boku to chigau naraba koko de sayonara\r\n[00:31.66]Acchi no mitsu kocchi no mitsu unzari\r\n[00:36.69]Ajimi shiteru you na sonna hima wa nai\r\n[00:41.72]Saki e isoge mikai no rakuen\r\n[00:47.12] \r\n[00:48.89]Shakunetsu no shoudou koko ni aru\r\n[00:53.76]Tsukamitakerya te wo nobase\r\n[00:58.76]Karehateta koko ni todomaru nara\r\n[01:03.61]Kimi da to shitemo boku wa kiba wo muku\r\n[01:08.54]Karamatte himotoite\r\n[01:11.06]Tobikoete yuganda sekai\r\n[01:13.44]Owatte hajimatte\r\n[01:15.77]Haiagatte negatta jidai\r\n[01:18.30]Karamatte himotoite\r\n[01:20.72]Tobikoete yuganda sekai\r\n[01:23.15]Owatte hajimatte\r\n[01:25.66]Haiagatte negatta jidai\r\n[01:28.44] \r\n[01:30.49]Kinou yori mo ame wa tsukyoku naru darou\r\n[01:35.42]Matou wa itsuku shimetta kaze touza kare\r\n[01:40.43]Konna toko de matteitara fuuka shunzen\r\n[01:45.36]Boku no ishi wa hitotsu\r\n[01:47.68]Mayoi yochi wa nai\r\n[01:50.37]Hontou no tsuyosa torikaeshitainda\r\n[01:57.50]Sabitsuita honnou tokihanate\r\n[02:02.38]Ubaitakerya ubaeba ii\r\n[02:07.36]Nani mo kamo kawaru kono sеkai wo\r\n[02:12.11]Kokoro no me ni yakitsukete okеyo\r\n[02:19.65] \r\n[02:46.54]Kare mo minna asu e iku shikanai\r\n[02:51.45]Ato zusari wa yameshimae yo\r\n[02:59.16]Shakunetsu no shoudou koko ni aru\r\n[03:04.30]Tsukamitakerya te wo nobase\r\n[03:09.09]Karehateta koko ni todomaru nara\r\n[03:13.97]Kimi da to shitemo boku wa kiba wo muku\r\n[03:18.96]Karamatte himotoite\r\n[03:21.32]Tobikoete yuganda sekai\r\n[03:23.80]Owatte hajimatte\r\n[03:26.20]Haiagatte negatta jidai\r\n[03:28.69]Karamatte himotoite\r\n[03:31.18]Tobikoete yuganda sekai\r\n[03:33.63]Owatte hajimatte\r\n[03:36.10]Haiagatte negatta jidai\r\n[03:39.20] \r\n	/audio/Dr. Stone S2 OP 「Rakuen」.mp3	Rakuen	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253985/covers/Dr._Stone_S2_OP_Rakuen.jpg	2
774	774	773	252	[00:00.00] \n[00:24.57]Katachi mo iro mo chigau biizu ga\n[00:28.53]Teeburu no ue de hikatteta\n[00:32.74]Tagai ga tagai wo terashiatte\n[00:36.86]Irotoridori kagayaiteta\n[00:41.13]Hibi ga waretemo sukoshi kaketemo\n[00:45.19]Sono hahen sae kagayaiteta\n[00:52.00]Yorisoiai nagara\n[00:53.90]Toki ni toozake nagara\n[00:55.97]Fuzoroi na kakera to kakera tsunagu\n[01:00.35]Itsuka no kanashimi mo\n[01:02.37]Namida shita omoide mo\n[01:04.46]Kimi no hohoemi wo irodoru hikari\n[01:11.51] \n[01:17.40]Sabishisa ni makesou ni nattemo\n[01:21.30]Heiki na furi shite waratteta\n[01:25.52]Jibun no nimotsu, hoka no dareka ni\n[01:29.51]Seowasete shimawanai you ni\n[01:33.89]Kizuiteita yo kimi no tsuyosa wo\n[01:37.87]Sono yokogao wo zutto miteta\n[01:44.82]Orenji iro no sora\n[01:46.81]Nishibi ni terasarete\n[01:48.86]Fuzoroi na kageboushi ga yureteta\n[01:52.96]Nanika tsutaetai noni\n[01:55.18]Nanimo ienakatta\n[01:57.30]Nagareru toki to kurete yuku hikari\n[02:04.09]Ibitsu na kakera tachi\n[02:08.14]Toki ni wa kosureai\n[02:12.21]Hikari ni kazashita mangekyou no you ni\n[02:20.55]Wakariaenakutemo\n[02:24.63]Namida ga nagaretemo\n[02:28.78]Hitorikiri dewa kanaerarenai keshiki\n[02:42.70] \n[02:51.06]Waraiaeta koto mo\n[02:52.95]Butsukariatta koto mo\n[02:55.20]Boku no taisetsu na takaramono\n[02:59.36]Kakiatsumeta biizu de\n[03:01.44]Nani ga tsukureru darou?\n[03:03.32]Iroasenai hikari no kakera tachi\n[03:11.78]Orenji iro no sora\n[03:13.73]Nishibi ni terasarete\n[03:15.94]Fuzoroi na kageboushi ga yureteta\n[03:19.84]Nanika tsutaetai noni\n[03:21.90]Nanimo ienakatta\n[03:24.02]Nagareru toki to kurete yuku hikari\n[03:28.37]Yorisoiai nagara\n[03:30.23]Toki ni toozake nagara\n[03:32.32]Fuzoroi na kakera to kakera tsunagu\n[03:36.57]Itsuka no kanashimi mo\n[03:38.47]Namida shita omoide mo\n[03:40.65]Kimi no hohoemi wo irodoru hikari\n[03:47.57] \n	/audio/Orange OP 「Hikari No Hahen」.mp3	Hikari No Hahen	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253715/covers/Orange_OP_Hikari_No_Hahen.jpg	1
161	161	159	268		/audio/Daily Lives of High School Boys OP 「Shiny tale」.mp3	Shiny tale	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253999/covers/Daily_Lives_of_High_School_Boys_OP_Shiny_tale.jpg	1
162	162	162	288		/audio/Danmachi ED 「Right Light Rise」.mp3	Right Light Rise	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254011/covers/Danmachi_ED_Right_Light_Rise.jpg	1
404	404	403	266	[00:00.00] \n[00:00.30]Kitto kienai, kyo wa ienai\n[00:03.77]Moto doori niwa mo dekinai\n[00:07.15]Ano koro ni\n[00:08.54]Kimi o nokoshita mama\n[00:11.87] \n[00:24.25]Kioku no naka dewa hare ma no heya\n[00:30.71]Hikareaeba saraba shiritakunai\n[00:37.15]Omoidase ba ima mo fuwatto kaoru\n[00:43.56]Kimi to boku wa onaji iro kousui\n[00:49.19]Honno sukoshi senobi wo shite aruita michi\n[00:55.72]Biidoro no kutsu utsuri kawaru kisetsu moyou\n[01:01.91]Kitto kienai, kyo wa ienai\n[01:05.50]Motodoori niwa mo dekinai\n[01:08.65]Ano koro ni kakushita honmono wa doko\n[01:14.99]Okotte kurenai, wakatte kurenai\n[01:17.93]Omottemo tada tsunotte shimau dake\n[01:22.48]Natsukashii nioi to kono utaga nokoru\n[01:29.44] \n[01:41.90]Kioku no naka de wa futari no heya\n[01:48.53]Hikareaeba bokura kono mama\n[01:55.12]Omoidaseba ima mo fuwatto kaoru\n[02:01.81]Kimi to boku wa onaji iro kousui\n[02:07.14]Ushinau hodo\n[02:10.33]Yasashisa sura iya ni natte\n[02:13.55]Biidama no naka\n[02:16.72]Koboreochiru namida no you\n[02:19.86]Kitto kienai kyou wa ienai\n[02:23.43]Moto doori ni wa mou dekinai\n[02:26.47]Ano natsu ni kakushita hontou wa mou\n[02:32.58]Okotte kurenai wakatte kurenai\n[02:35.88]Omottemo tada tsunotte shimau dake\n[02:40.83]Atarashii nioi to kono machi ni nokoru\n[02:47.84]Itsuka itsuka\n[02:50.45]Kuchi wo tsuita kono uso ga\n[02:53.89]Hitotsu nokorazu hontou ni natte\n[03:00.52]Dou ka dou ka\n[03:03.23]Kurikaeshi tonaete ita\n[03:06.87]Kimi ga toumei ni natta mama\n[03:11.77]Kitto kienai kyou wa ienai\n[03:15.24]Moto doori ni wa mou dekinai\n[03:18.45]Ano koro ni kakushita honmono wa doko\n[03:24.57]Okotte kurenai wakatte kurenai\n[03:27.76]Omottemo tada tsunotte shimau dake\n[03:32.27]Natsukashii nioi to kono uta ga nokoru\n[03:39.22] \n	/audio/Horimiya OP 「Iro Kousui」.mp3	Iro Kousui	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254007/covers/Horimiya_OP_Iro_Kousui.jpg	1
974	359	974	251	[ti:Shadows House ED 「Nai Nai」]\n[ar:ReoNa]\n[al:Shadows House]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:11.30]\n[00:01.00]Tu-tu-tu-tu\n[00:03.46]Tu-tu-tu-tu\n[00:05.26]Tu-tu-tu-tu\n[00:07.00]Tu-tu-tu-tu\n[00:08.57]Haa (Sigh)\n[00:09.59]Hai no nai fukai kage bakari\n[00:13.27]Ai no nai kotae dōru mitai\n[00:17.18]Jibun fuzai doko nimo inai\n[00:20.79]Nai jyanai?\n[00:23.77]Aimai na ai iro no nai ai\n[00:28.21]Gitai igai! hitogoto mitai\n[00:31.96]Okagesama? dochirasama?\n[00:34.56]Kotae samazama\n[00:38.20]Nanimono demo nai mama\n[00:41.78]Nannimo deki nai mama\n[00:45.50]Ikiru nowa muda desuka\n[00:49.32]Warui koto desuka\n[00:52.85]Koko ni inai inai inai no wa\n[00:57.51]Jibun jibun\n[01:00.37]Dare mo minai minai minai mama\n[01:04.37]Hakisutete sayounara\n[01:07.65]Ureshikunai kanashiku mo nai\n[01:12.30]Toumei na kibun\n[01:15.24]Tarinai jibun\n[01:17.01]Awasu kao mo nai \n[01:19.79](nai) nai (nai)\n[01:22.66]Warae nai janai?\n[01:27.88]Hai janai ai tojita mama kai\n[01:32.15]Henji "hai" kitai dake dai\n[01:35.85]Iyaiya nagerareta sai\n[01:38.48]Deme wa shiranai\n[01:56.25]Koko ni itai itai itai no mo\n[02:01.06]Jibun jibun\n[02:03.93]Aji wa nigai nigai nigai mama\n[02:08.45]Atedo naku sayonara\n[02:11.40]Kaeranai ikusaki mo nai\n[02:15.70]Maigo no kibun\n[02:18.61]Machigaete nai?\n[02:20.53]Mada wakaranai \n[02:23.10](nai) nai (nai)\n[02:26.22]Doudatte ii janai\n[02:51.13]Kage no katachi mo\n[02:54.48]Isso nakushite shimaeba ii\n[02:58.53]Mata hai hitotsu\n[03:00.37]Hitotsu kara hajimereba ii\n[03:07.61]Koko ni inai inai inai no wa\n[03:12.16]Jibun jibun\n[03:15.04]Dare mo minai minai minai mama\n[03:19.41]Haki sutete sayonara\n[03:24.26]Ureshikunai kanashiku mo nai\n[03:28.50]Toumeina kibun\n[03:31.37]Tarinai jibun\n[03:33.38]Awasu kao mo nai \n[03:36.10](nai) nai (nai) nai nai mama de\n[03:42.22]Koko ni itai (itai) itai (itai)\n[03:46.26]Waraitai janai?\n[03:49.87]	/audio/Shadows House ED 「Nai Nai」.mp3	Nai Nai	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254042/covers/Shadows_House_ED_Nai_Nai.jpg	1
163	163	162	351		/audio/Danmachi ED2 「Realize」.mp3	Realize	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253998/covers/Danmachi_ED2_Realize.jpg	1
181	181	175	250		/audio/Darling In The FranXX OP 「KISS OF DEATH」.mp3	KISS OF DEATH	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254001/covers/Darling_In_The_FranXX_OP_KISS_OF_DEATH.jpg	1
300	300	300	208	[00:00.00] \n[00:01.01]Ano hi mita sora akaneiro no sora wo\n[00:06.84]Nee kimi wa oboeteimasuka\n[00:11.97]Yakusoku chigiri shoka no kaze ga tsutsumu\n[00:17.92]Futari yorisotta\n[00:22.67] \n[00:26.23]Muri na egao no ura nobita kage wo kakumau\n[00:36.71]Dakara kizukanu furi saisei wo erabu\n[00:46.36] \n[00:47.89]Teeburu no ue no furuenai shirase machi tsuzukete\n[00:58.66]Kuuhaku no yoru mo kuru hazu no nai asa mo zenbu wakattetanda\n[01:08.45]Ano hi mita sora akaneiro no sora wo\n[01:14.06]Nee kimi wa wasureta no deshou\n[01:18.92]Yakusoku chigiri shoka no kaze ni kieta\n[01:24.62]Futari modorenai\n[01:28.73]Oto mo iro mo ondo mo hanbun ni natta kono heya\n[01:39.30]Kyou mo chirakashite wa yure tsukare nemuru\n[01:49.00] \n[02:11.90]Jouzu ni damashite ne uso wa kirai de suki kimi no kotoba\n[02:22.66]Ima goro ni natte kimochi wa itai hodo dakara bokura sayonara\n[02:32.43]Itsuka mata ne to te o furiatta kedo mou au koto wa nai no deshou\n[02:43.03]Saigo no uso wa yasashii uso deshita wasurenai\n[02:50.88]Ano hi mita sora akaneiro no sora wo\n[02:56.77]Nee itsuka omoidasu deshou\n[03:01.63]Hatase nakatta yakusoku wo idaite\n[03:07.34]Futari arukidasu\n[03:15.56] \n	/audio/Fullmetal Alchemist Brotherhood ED 「USO」.mp3	USO	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254004/covers/Fullmetal_Alchemist_Brotherhood_ED_USO.jpg	1
89	89	52	215	[00:00.00] \r\n[00:03.98]Seishun... Satsubatsuron!\r\n[00:07.48] \r\n[00:13.21]Kuchi ni dasu no wa jikkou suru toki\r\n[00:16.34]Sore ga kakkoii koto shitteru sa\r\n[00:19.06](TARGET, sagashite bokura wa satsubatsu)\r\n[00:21.58]Omoi wa mayou mayoedo susumu\r\n[00:25.04]Migite to migiashi issho ni de sou da\r\n[00:30.42] \r\n[00:31.50]Nan nanda ira ira no hadou wa\r\n[00:34.50]Bokura no sonzai no shoumei?\r\n[00:37.49]Tsuki wo miage takamaru\r\n[00:40.93]Saa saa! SASSASSA tto START!!\r\n[00:45.46]Yarikittenai kara YARIKIRENAI\r\n[00:48.55]Yarikittenai kara YARIKIRENAI\r\n[00:51.64]Genjou daha wo chiisana koe de yagate zekkyou shitaku naru\r\n[00:58.05]Yarikittenai kara YARIKIRENAI (Yareba dekiru sa)\r\n[01:01.28]Yarikittenai kara YARIKIRENAI (Kitto dekiru sa)\r\n[01:04.34]Douse, to iu no wa kantan dakedo\r\n[01:07.57]Ima wa agaite mitain'da kimi to hajikete mitain'da\r\n[01:14.13] \r\n[01:32.16]KETSU wo tatakare nigetaku natte\r\n[01:35.40]Sore wa kakkowarui n'da, jaa dou suru?\r\n[01:38.16](ASSAULT, mattara bokura no unmei tenkan)\r\n[01:40.57]Susumeba manabi manabeba kawaru\r\n[01:44.18]Gikochinai ugoki ga yagate koyuu no STYLE\r\n[01:49.04] \r\n[01:50.56]Nande da gira gira to neraitai\r\n[01:53.63]Bokura ga umareta kono shunkan\r\n[01:56.72]Tsuyoku nare to ishiki ga\r\n[02:00.04]Saa saa! SASSASSA tto BURST!!\r\n[02:04.52]Furikitte mitakerya FURIKIRERO\r\n[02:07.55]Furikitte mitakerya FURIKIRERO\r\n[02:10.60]Rinkaiten toppa de nagameru keshiki chigau ondo no kaze ga fuku\r\n[02:17.14]Furikitte mitakerya FURIKIRERO (Sore ga dekiru sa)\r\n[02:20.29]Furikitte mitakerya FURIKIRERO (Minna dekiru sa)\r\n[02:23.51]Ashita, ni sureba rakuchin dakedo\r\n[02:26.67]Jibun BEST nurikaete miseru kimi mo chousen shite miro yo\r\n[02:32.76]Shizumaru kodou (Batsubatsu, satsubatsu)\r\n[02:35.86]Ayaui shidou (Marumaru, satsubatsu)\r\n[02:38.98]Haigo ni chikadzuku seppakukan\r\n[02:45.34]Yarikittenai kara YARIKIRENAI\r\n[02:48.55]Furikitte mitakerya FURIKIRERO\r\n[02:52.13] \r\n[02:52.31]Yarikittenai kara YARIKIRENAI\r\n[02:55.34]Yarikittenai kara YARIKIRENAI\r\n[02:58.51]Genjou daha wo chiisana koe de yagate zekkyou shitaku naru\r\n[03:04.86]Yarikittenai kara YARIKIRENAI (Yareba dekiru sa)\r\n[03:07.90]Yarikittenai kara YARIKIRENAI (Kitto dekiru sa)\r\n[03:11.16]Douse, to iu no wa kantan dakedo\r\n[03:14.30]Ima wa agaite mitain'da kimi to hajikete mitain'da\r\n[03:20.26]Saredo seishun wa mirai e GO!!\r\n[03:24.30] \r\n[03:25.95]Saa saa saa! Seishun SATSUBATSURON!\r\n[03:30.80]	/audio/Assassination Classroom OP 「Sheishun Satsubatsu.mp3	Sheishun Satsubatsuron	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254059/covers/Assassination_Classroom_OP_Sheishun_Satsubatsuron.jpg	1
150	150	94	257	[00:00.00] \n[00:24.68]Mune no naka itsuka hirotta shiawase\n[00:31.81]no kakera atsumete miyou\n[00:36.62]Wasurekakete ita merodii iroasezu\n[00:43.90]boku no mannaka ni\n[00:57.24]Karita mama no manga sousakuchuu\n[00:59.78]tamatama mitsuketa iroaseta bunshuu\n[01:02.40]"Tenka wo tsukamu" nante warenagara aho\n[01:05.70]rashikute warai ga deta\n[01:07.74]Tenka ja nakute densha no tsurikawa wo tsukamu hibi\n[01:12.98]Ano koro no boku ni gomen nasai ne to\n[01:15.65]hohoeminagara atama wo sageta\n[01:18.16]Arigatou kokoro kara\n[01:23.15]Boku ni ima ga aru no ha minna no okage sa\n[01:27.70]Arigatou kokoro kara\n[01:32.75]Tsugi ha boku ga minna ni HAPPY okuru yo Wow\n[01:39.15]Nanimo ka mo wasurenai yo ano hi no\n[01:45.33]boku mo boku dakara\n[01:50.36]Daisuki da yo tte itsumo itte agenakya dame da ne\n[01:59.84]Tsurakereba nigetemo ii yo mata koko\n[02:05.53]ni kaette kuru no nara\n[02:10.52]Iroiro yorimichi mo shite yukou\n[02:15.82]orijinaru na hibi wo\n[02:40.68]Tomaranai machi no mannaka de itsu\n[02:43.28]kara ka kimi ha utsumuki kagen\n[02:45.72]Kakaeru "kimochi" ga oosugite hitori\n[02:48.15]kiri de panku-shichatteru\n[02:50.62]Dakara boku no kotoba wo kiite\n[02:53.03]shiawase wo kureta kimi no tame\n[02:55.73]Chikara wo okuru yo day by day\n[03:00.57]Mune no naka afuresou na shiawase no\n[03:07.13]kakera tsunagete miyou\n[03:12.29]Chikaradzuyoku naru merodii\n[03:17.24]kurikaesareteku messeeji\n[03:21.98]Namida ga koboresou na nagai yoru ha\n[03:28.02]futto furikaette\n[03:32.56]Ashiato wo tadorunda ano hi wo\n[03:39.17]wasurenai you ni\n[03:44.68]	/audio/Code Geass S2 ED 「Shiawase Neiro」.mp3	Shiawase Neiro	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254057/covers/Code_Geass_S2_ED_Shiawase_Neiro.jpg	2
736	726	723	220		/audio/Nisekoi S2 ED6 「Tooriame drop」.mp3	Tooriame drop	ED6	https://res.cloudinary.com/ddc6silap/image/upload/v1773254061/covers/Nisekoi_S2_ED6_Tooriame_drop.jpg	2
1292	1254	1288	286	[00:00.00] \r\n[00:19.62]Yatto me wo samashita kai sore na no ni naze me mo awase ya shinaindai ?\r\n[00:29.97]Osoi yo to okoru kimi koredemo yareru dake tobashite kitanda yo\r\n[00:39.66]Kokoro ga karada wo oikoshite kitanda yo\r\n[00:45.24]Kimi no kami ya hitomi dake de mune ga itai yo\r\n[00:50.22]Onaji toki wo suikonde hanashitakunai yo\r\n[00:55.13]Haruka mukashi kara shiru sono koe ni\r\n[01:00.21]Umarete hajimete nani wo ieba ii ?\r\n[01:07.65]Kimi no zen zen zense kara boku wa kimi wo sagashi hajimeta yo\r\n[01:12.26]Sono bukiccho na waraikata wo megakete yatte kitanda yo\r\n[01:17.84]Kimi ga zenzen zenbu naku natte chirijiri ni nattatte\r\n[01:22.41]Mou mayowanai mata ichi kara sagashi hajimeru sa\r\n[01:27.34]Mushiro zero kara mata uchuu wo hajimete miyou ka\r\n[01:32.65] \r\n[01:43.45]Dokkara hanasu kana kimi ga nemutteita aida no SUTOORII\r\n[01:53.62]Nanoku nankounenbun no monogatari wo katari ni kitanda yo kedo iza sono sugata kono me ni utsusu to\r\n[02:08.65]Kimi mo shiranu kimi to jarete tawamuretai yo\r\n[02:13.76]Kimi no kienu itami made aishite mitai yo\r\n[02:18.77]Ginga nankobun ka no hate ni deaeta\r\n[02:23.73]Sono te wo kowasazu ni dou nigitta nara ii ?\r\n[02:31.11]Kimi no zen zen zense kara boku wa kimi wo sagashi hajimeta yo\r\n[02:35.75]Sono sawagashii koe to namida wo megake yatte kitanda yo\r\n[02:41.06]Sonna kakumei zenya no bokura wo dare ga tomeru to iundarou\r\n[02:45.84]Mou mayowanai kimi no HAATO ni hata wo tateru yo\r\n[02:50.57]Kimi wa boku kara akiramekata wo ubaitotta no\r\n[02:56.60] \r\n[03:53.00]Zen zen zense kara boku wa kimi wo sagashi hajimeta yo\r\n[03:57.14]Sono bukiccho na waraikata wo megakete yatte kitanda yo\r\n[04:02.54]Kimi ga zen zen zenbu naku natte chirijiri ni nattatte\r\n[04:07.32]Mou mayowanai mata ichi kara sagashi hajimeru sa\r\n[04:12.21]Nankounen demo kono uta wo kuchizusami nagara\r\n[04:18.12] \r\n	/audio/Your Name 「Zenzenzense」.mp3	Zenzenzense	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773254070/covers/Your_Name_Zenzenzense.jpg	1
756	756	753	196	[00:00.00] \r\n[00:18.21]Dangan kometa shouchuu wo boku wa kata te ni motteiru\r\n[00:23.12]Furueta kimi no iru basho e hashi wo hayame mukatteiru\r\n[00:28.29]Chikutaku hari wa chikutaku to\r\n[00:30.48]Aseru kokoro wo sekashita dake\r\n[00:33.45]Chikutaku hari wa chikutaku to\r\n[00:35.46]Tomaru kehai mo naku susunde iku\r\n[00:38.57] \r\n[00:43.57]Dare no honou mo nai heya de\r\n[00:46.01]Kiekitta te wo nobashiteru\r\n[00:48.44]Usaida boku no iru basho wa\r\n[00:51.09]Dare ni mo wakaranai\r\n[00:53.78]Chikutaku hari wa chikutaku to\r\n[00:55.89]Owari to hajimari no sakaime\r\n[00:58.84]Chikutaku hari wa chikutaku to\r\n[01:00.90]Subete kasanatta\r\n[01:03.63]Hekoushite boku wa matteita\r\n[01:05.96]Waraeru hodo no kanashimi wo\r\n[01:08.82]Hekoushite boku wa matteita\r\n[01:11.22]Wariesuru hodo no koufuku mo\r\n[01:14.15]Dare no honou mo nai heya de\r\n[01:16.42]Kiekitta te wo nobashiteru\r\n[01:18.95]Usaida boku no iru basho wa\r\n[01:21.64]Dare ni mo wakaranai\r\n[01:25.20] \r\n[01:34.56]Chikutaku chikutaku to\r\n[01:36.94]Tamashi tamashi no shibu wo\r\n[01:39.79]Chikutaku chikutaku to\r\n[01:41.86]Susumanai boku wo\r\n[01:44.71]Chikutaku hari wa chikutaku to\r\n[01:46.98]Same tateru you ni\r\n[01:49.69]Chikutaku hari wa chikutaku to\r\n[01:51.65]Subete kasanatta\r\n[01:53.80]Hekoushite boku wa matteita\r\n[01:56.07]Usugurai heya hitori kiri\r\n[01:58.94]Hekoushite boku wa matteita\r\n[02:01.25]Doa wo keyaburu sono oto wo\r\n[02:03.94]Hekoushite boku wa matteita\r\n[02:06.36]Usugurai heya hitori kiri\r\n[02:09.10]Hekoushite boku wa matteita\r\n[02:11.29]Mou osoreru koto wa nai yo\r\n[02:14.38]Dangan kometa shouchuu wo motte\r\n[02:16.77]Kataku tozasareta doa wo keyabutta\r\n[02:19.82]Tsui tsuita juukou ga hanete kinou no boku wo tsuranuita\r\n[02:24.46]Oyasumi sono zetsubou wo uketotte\r\n[02:27.06]Ashita e no boku wa aruki hajimeta\r\n[02:29.91]Mata konya machiawase yo\r\n[02:33.73] \r\n	/audio/Noragami OP「Goya no Machiawase」.mp3	Goya no Machiawase	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254069/covers/Noragami_OP_Goya_no_Machiawase.jpg	1
48	48	46	276	[00:00.00] \n[00:05.39]Zenbu kitai shite mita maboroshi datta\n[00:08.78]Shinjitakatta\n[00:11.45]Sugaritakatta\n[00:15.64]Karada no okusoko ni aita rasenjou no ana\n[00:19.95]Boku dake janaku kimi ni mo nan da ne\n[00:29.56]Yurusareru koto nado mou nozonja inai\n[00:34.67]Dakiyosetemo mada wakaranai shiruetto\n[00:38.99]Tamerai mo naku kizutsuketa daishou ka\n[00:43.78]Kimi no soubou wa yurete boku wo hanareta\n[00:48.70]Dochira ga hoshii ka nante zankoku na toi\n[00:52.54]Kamisama wa nando bokura ni nagekakeru?\n[00:58.26]Michi wo tagaeru tabi ni boku no ushiro ni wa\n[01:02.28]Nagaku nobita ippon no kage\n[01:06.23]Daremo ga te ni shieru chiisana kakera de\n[01:12.90]Nani ga dekiru?\n[01:17.15]Dochira ga hoshii ka nante zankoku na toi\n[01:20.14]Kamisama wa nando bokura ni nagekakeru?\n[01:31.22]Nanimo rikai sezu nomikondeta\n[01:34.38]Mitakunakatta\n[01:37.17]Furetakunakatta\n[01:40.69]Karada no okusoko ni mebuita ano hana no tane\n[01:45.65]Kimi dake janaku boku ni mo nan da yo\n[01:53.25]Furerarenai ondo ni negau kurai nara\n[01:58.34]Tsukurimono no sugata demo jishin wo nozomu\n[02:03.09]Kimi ga boku ni tsugete kurenai to shitemo\n[02:07.69]Tatta hitori de mitsukedasu dake dakara\n[02:12.58]Dochira mo te ni ireyou to ushinatta mono\n[02:16.05]Kamisama ni aragau to shitemo torimodosu to\n[02:21.88]Itami ni chikau tabi ni boku no senaka ni wa\n[02:24.69]Fukaku kizamareta musuu no kizu\n[02:30.04]Daremo erabanai sentakushi wo kono te ni\n[02:36.59]Nani ga dekiru?\n[02:40.90]Dochira mo te ni ireyou to ushinatta mono\n[02:44.52]Kamisama ni aragau to shitemo torimodosu\n[02:59.95]Kimi ga ikiteiru nara boku wa shindeiru darou\n[03:10.09]Boku ga ikiteiru nara kimi wa shindeiru darou\n[03:16.97]Se wo mukete bokura\n[03:24.48]Zenbu kitai shite mita maboroshi datta\n[03:27.91]Shinjitakatta\n[03:30.65]Sugaritakatta\n[03:34.28]Karada no okusoko ni aita rasenjou no ana\n[03:39.22]Boku dake janaku kimi ni mo nan da ne\n[03:46.50]Dochira ga hoshii ka nante zankoku na toi\n[03:49.94]Kamisama wa nando bokura ni nagekakeru?\n[03:55.82]Michi wo tagaeru tabi ni boku no ushiro ni wa\n[03:59.14]Nagaku nobita ippon no kage\n[04:03.77]Daremo ga te ni shieru chiisana kakera de\n[04:09.68]Nani ga dekiru?\n[04:14.46]Dochira ga hoshii ka nante zankoku na toi\n[04:18.34]Kamisama wa nando bokura ni nagekakeru?\n[04:24.68] 	/audio/Arifureta S2 ED 「Gedou Sanka」.mp3	Gedou Sanka	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254082/covers/Arifureta_S2_ED_Gedou_Sanka.jpg	2
130	130	129	233		/audio/Citrus OP 「Azalea」.mp3	Azalea	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254211/covers/Citrus_OP_Azalea.jpg	1
156	156	95	220		/audio/Couple of Cuckoos ED 「Shikaku Unmei」.mp3	Shikaku Unmei	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254086/covers/Couple_of_Cuckoos_ED_Shikaku_Unmei.jpg	1
158	158	95	193		/audio/Couple of Cuckoos OP2 「Glitter」.mp3	Glitter	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773254085/covers/Couple_of_Cuckoos_OP2_Glitter.jpg	1
170	170	96	270		/audio/Darker than Black ED 「Tsuki Akari」.mp3	Tsuki Akari	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254096/covers/Darker_than_Black_ED_Tsuki_Akari.jpg	1
173	173	96	259		/audio/Darker than Black OP2 「Kakusei Heroism ~The Her.mp3	Kakusei Heroism ~The Hero without a Name~	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773254083/covers/Darker_than_Black_OP2_Kakusei_Heroism_The_Hero_without_a_Name.jpg	1
464	464	464	244	[00:00.00] \n[00:00.62]Kimi to watashi kitto ima onaji kimochi dayo\n[00:25.27]Kimi kara waraikakete kuretanara\n[00:31.08]Tenshi de irareru no ni\n[00:36.14]Kizuita no tamesareteru\n[00:38.91]Iji waru na kakehiki de\n[00:42.07]Ato ni wa mō hikenai kara\n[00:44.84]Shikakete ageru\n[00:47.65]Sā, kakatte misete tomadotte misete\n[00:54.79]Soshite saigo ni tsutaete misete ‘suki da’ tte\n[01:05.08]Kimi to watashi donna fū ni koi suru no?\n[01:12.49]Saguru RELATION\n[01:16.52]Yoyū nante nai yo mitsumerareru tabi\n[01:24.16]Itsu mo furueteru\n[01:28.03]Sunao ja nai watashi wo tsuredashite\n[01:40.06]Risāchi wa shitsukoi hodo shite kita shi\n[01:45.73]Shumi. shisō zenbu wakaru\n[01:50.96]Mondai wa taimingu to nachuraru na nagare dake\n[01:56.59]Misete mite nijinda toko kirinuite ageru\n[02:02.46]Hora, kakushin shite onaji tte tsugete\n[02:09.48]Unmei-teki na ito o kanjite ima sugu ni\n[02:19.74]Mabushi sugite nani mo mienakunari sō\n[02:27.24]Shiroku HALATION\n[02:31.26]Tekitō de mo mawarikudoku te mo ī yo\n[02:38.81]Kimi no tokubetsu o\n[02:42.77]Katachi ni shite namida ga deru mae ni\n[02:52.77]Ītai kotoba dake ga\n[02:55.29]Dō shite mo ienakute\n[02:58.40]Zurī no wa shōchi de matteru\n[03:01.96]Kasureta koe ni ki ga tsuite\n[03:08.75]Kimi to watashi donna fū ni koi suru no?\n[03:16.13]Saguru RELATION\n[03:20.18]Yoyū nante nai yo mitsumerareru tabi\n[03:27.82]Itsu mo furueteru\n[03:31.65]Sunao ja nai watashi wo tsuredashite\n[03:38.33] \n	/audio/Kaguya sama_ Love is War ED 「Sentimental Crisis.mp3	Sentimental Crisis	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254109/covers/Kaguya_sama_Love_is_War_ED_Sentimental_Crisis.jpg	1
503	501	500	201	[00:00.00] \r\n[00:12.40]nanimo iwazu ni ie o dete\r\n[00:17.66]konna toko made kita keredo\r\n[00:22.94]higure to tomo ni nakimushi ga\r\n[00:28.20]kokorobosoi to beso o kaku\r\n[00:33.54]akaku somaru machi no sora o\r\n[00:38.73]karasu ga naite ikisugiru\r\n[00:43.99]michi ni nobiru nagai kage ga\r\n[00:49.30]hayaku kaero to sode o hiku\r\n[00:54.64]osakana o yaku nioi\r\n[00:59.88]bangohan no ii nioi\r\n[01:05.14]oharanomushi mo nakidashita\r\n[01:10.28]iji o haru no mo akitekita\r\n[01:15.62]imasugu gomen to ayamatte\r\n[01:20.26]hayaku ouchi ni kaeritai\r\n[01:26.25] \r\n[01:36.84]iku ate no nai boku no mae o\r\n[01:41.92]kodomo ga hitori ikisugiru\r\n[01:47.33]hana o susuri shakuriagete\r\n[01:52.47]wakime mo furazu hashitteku\r\n[01:57.94]yami ni kieteku senaka\r\n[02:03.20]ano hi no boku ni niteiru\r\n[02:08.42]hashire hashire namida fuite\r\n[02:13.70]kaketa otsukisan oikakete\r\n[02:19.01]imasugu gomen to ayamareba\r\n[02:23.58]bangohan ni wa maniau sa\r\n[02:29.51] \r\n[02:34.76]osakana o yaku nioi\r\n[02:40.06]bangohan no ii nioi\r\n[02:45.22]oharanomushi mo nakidashita\r\n[02:50.46]iji o haru no mo akitekita\r\n[02:55.91]imasugu gomen to ayamatte\r\n[03:00.39]hayaku ouchi ni kaeritai\r\n[03:06.46] \r\n	/audio/Konosuba S2 ED 「Wanna Go Home」.mp3	Wanna Go Home	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254099/covers/Konosuba_S2_ED_Wanna_Go_Home.jpg	2
837	837	837	220	[ti:Parasyte ED 「IT'S THE RIGHT TIME」]\n[ar:Daichi Miura]\n[al:Parasyte]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:40.08]\n[00:00.00]\n[00:11.75]Itsuka kimi ga oshiete kureta ano kotoba ga\n[00:23.38]Mune no oku no DOA wo fui ni NOOKU suru\n[00:33.47]Furikaeru hima mo naku nanika ni oware\n[00:40.19]Wasureteita keshiki wo\n[00:45.88]Ima kimi no koe ga omoidasaseru yo\n[00:52.41]Daijoubu saa hajimeyou\n[00:57.02]IT'S THE RIGHT TIME\n[01:00.40]Arukidasou\n[01:02.91]IT'S THE RIGHT TIME\n[01:06.11]Osorenaide\n[01:08.45]Hora\n[01:09.30]Ano oka wo koeta basho de\n[01:14.95]Boku wo matteiru yo\n[01:20.45]Tatoe donna tsurai toki mo sono kotoba ga\n[01:31.68]Hiroi umi wo mayowazu susumu kibou ni naru\n[01:42.54]Me no mae no kurayami ni tachisukumu tabi\n[01:49.31]Hikari wo kureru no sa\n[01:54.55]Moshi kimi ga hitori wo kanjiru toki wa\n[02:00.79]Daijoubu soba ni iru yo\n[02:05.16]IT'S THE RIGHT TIME\n[02:08.60]Arukidasou\n[02:11.08]IT'S THE RIGHT TIME\n[02:14.29]Osorenaide\n[02:16.64]Hora\n[02:17.56]Ano oka wo koeta basho wo\n[02:23.28]Tomo ni mi ni yukou\n[02:28.62]Katachi no nai kotae ni tomadou hi mo chiisana koe de\n[02:40.50]Sotto tsubuyaku no sa\n[02:44.73]Kimi to boku ni kikoeru koe de\n[02:51.14]IT'S THE RIGHT TIME\n[02:54.43]Arukidasou\n[02:56.73]IT'S THE RIGHT TIME\n[02:59.98]Osorenaide\n[03:02.40]Hora\n[03:03.61]Ano oka wo koeta basho de\n[03:08.66]Bokura wo matteiru yo\n[03:13.99]Hora\n[03:15.26]Ano oka wo koeta basho e\n[03:21.03]Tomo ni dokomademo\n[03:27.29]	/audio/Parasyte ED 「IT_S THE RIGHT TIME」.mp3	IT'S THE RIGHT TIME	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254115/covers/Parasyte_ED_IT_S_THE_RIGHT_TIME.jpg	1
910	234	904	258	૾嬀　　㨀　　⸀　　崀 ਀嬀　　㨀㄀㄀⸀㠀㄀崀樀椀戀甀渀 渀漀 欀愀欀漀 渀椀 琀漀爀愀眀愀爀攀 洀愀礀漀琀琀攀਀嬀　　㨀㄀㜀⸀㄀㘀崀猀漀甀 樀愀渀愀椀 礀漀 琀漀 椀椀欀椀欀愀猀攀琀攀 猀甀戀攀琀攀 漀਀嬀　　㨀㈀㈀⸀　㤀崀樀椀礀甀甀 渀椀 愀礀愀琀猀甀爀攀爀甀 欀愀 渀愀渀琀攀਀嬀　　㨀㈀㜀⸀㐀㌀崀眀愀欀愀爀愀渀愀椀 礀漀 琀漀 猀漀爀愀 眀愀 欀愀猀甀渀搀攀਀嬀　　㨀㈀㤀⸀㔀㄀崀猀攀椀欀愀椀 眀愀 搀漀欀漀㼀਀嬀　　㨀㌀㈀⸀㄀㐀崀戀漀欀甀 渀漀 琀攀渀漀栀椀爀愀 渀椀 渀漀欀漀爀甀 搀愀椀樀椀 渀愀 洀漀渀漀਀嬀　　㨀㌀㜀⸀㐀㐀崀眀愀猀甀爀攀渀愀椀 欀椀漀欀甀 渀愀渀搀漀搀攀洀漀਀嬀　　㨀㐀㈀⸀㈀㄀崀欀椀洀椀 漀 洀愀洀漀爀椀渀甀欀甀 琀漀 猀愀欀攀渀搀攀਀嬀　　㨀㐀㜀⸀㔀㔀崀洀愀欀椀洀漀搀漀猀栀椀 渀漀 渀愀欀愀 琀猀甀欀愀渀搀愀 愀椀 眀愀 猀漀甀਀嬀　　㨀㔀㈀⸀㌀㠀崀栀愀渀愀猀栀椀 眀愀 猀栀椀渀愀椀 欀愀爀愀਀嬀　　㨀㔀㐀⸀㜀㘀崀挀栀椀爀椀戀愀洀攀琀愀 漀洀漀椀 椀洀愀 椀挀栀椀搀漀欀椀爀椀 渀漀 渀攀最愀椀 攀਀嬀　㄀㨀　　⸀　㤀崀琀猀甀最椀 攀渀漀 戀漀欀甀 渀椀 琀愀欀甀猀栀椀琀愀 礀漀਀嬀　㄀㨀　㔀⸀㄀㜀崀椀琀猀甀欀愀 渀漀 礀愀欀甀猀漀欀甀 栀椀欀愀爀椀 渀漀 洀椀挀栀椀猀栀椀爀甀戀攀 渀椀 渀愀爀甀਀嬀　㄀㨀㄀　⸀　㐀崀挀栀椀欀愀椀 漀 猀愀愀 欀椀洀椀 渀漀 琀愀洀攀 猀愀椀最漀 洀愀搀攀਀嬀　㄀㨀㈀㄀⸀㐀㜀崀渀愀洀椀搀愀 猀愀攀 挀栀椀欀愀爀愀 渀椀 欀愀攀琀攀 欀椀琀琀漀 攀最愀椀琀攀椀琀愀 渀漀稀漀洀甀 洀椀爀愀椀 攀਀嬀　㄀㨀㈀㘀⸀㐀㌀崀琀猀甀渀愀最甀 礀漀਀嬀　㄀㨀㈀㤀⸀㜀㈀崀 ਀嬀　㄀㨀㌀㌀⸀㠀㈀崀猀漀甀稀漀甀 漀 欀漀攀爀甀 樀椀琀愀椀 渀椀 欀甀爀甀琀琀攀਀嬀　㄀㨀㌀㤀⸀㈀㈀崀琀猀甀洀攀 漀 琀愀琀攀琀攀 眀愀 洀漀最愀欀椀愀最愀椀琀攀 欀漀欀漀爀漀 眀愀਀嬀　㄀㨀㐀㐀⸀　㐀崀樀椀渀猀攀椀 渀漀 愀礀愀洀愀挀栀椀 漀 洀漀甀 渀愀渀欀愀椀਀嬀　㄀㨀㐀㤀⸀㌀㌀崀欀甀爀椀欀愀攀猀栀椀琀攀 眀愀 欀椀爀愀椀 渀椀 渀愀琀琀攀਀嬀　㄀㨀㔀㄀⸀㠀㌀崀渀愀椀琀攀琀攀洀漀਀嬀　㄀㨀㔀㐀⸀㈀㌀崀欀椀洀椀 渀漀 愀欀漀最愀爀攀 眀愀 椀琀猀甀洀漀 欀愀最愀礀愀椀琀攀琀愀਀嬀　㄀㨀㔀㤀⸀㔀㐀崀䤀✀氀氀 挀漀洀攀 戀愀挀欀⠀夀攀愀栀⤀	/audio/Re_Zero OP 「Redo」.mp3	Redo	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254100/covers/ReZero_OP_Redo.jpg	1
594	314	571	257		/audio/Midori Days ED 「Mou Sukoshi... Mou Sukoshi...」.mp3	Mou Sukoshi... Mou Sukoshi...	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254216/covers/Midori_Days_ED_Mou_Sukoshi..._Mou_Sukoshi....jpg	1
619	619	619	262	[ti:My Roommate is a Cat ED 「Kimi no Tonari Watashi no Basho」 ]\n[ar:Yoshino Nanjo]\n[al:My Roommate is a Cat]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:21.45]\n[00:00.00]\n[00:09.81]（ rarara, rarara, rarara）\n[00:14.09]Kimi no tonari watashi no basho\n[00:19.46]Tayorinai kimi da kedo soba ni ite ageru\n[00:31.44]Mata sonna kao shite dō shita no？ hanashi o kiku yo\n[00:40.37]Genki de nai nara onaka ichi bai gohan o tabeyō\n[00:50.18]Atatakai basho yawaraka na tokoro\n[00:59.64]Kyō wa tokubetsu ni o ki ni iri o oshiete ageru ne\n[01:10.38]Kimi no hiza no ue wa pokapoka shite ohi-sama mitai\n[01:19.74]Kanashī toki wa yonde sugu ni iku wa egao misete\n[01:29.18]Tayorinai kimi da kara soba ni ite ageru\n[01:59.32]Kazoku tte shitte iru subarashī mono na nda to\n[02:08.85]Nei mata sonna kao kocchi ni kite o hirune shiyō\n[02:18.29]Sotto oita te ni tsutawaru nani ka \n[02:27.85]hotto suru nioi\n[02:32.45]Utouto suru fushigi na kibun yo\n[02:38.62]Kimi no koe o kiku to ureshiku naru mahō mitai\n[02:47.89]Sabishī toki mo itsu mo chikaku ni iru daijōbu yo\n[02:57.40]Tayorinai kimi da kara mamotte ageru wa\n[03:25.78]Kimi no hiza no ue wa pokapoka shite ohi-sama mitai\n[03:35.14]Kanashī toki wa yonde sugu ni iku wa egao misete\n[03:44.60]Tayorinai kimi da kara soba ni ite ageru\n[03:54.10]Yasashī kimi no tonari zutto soba ni iru\n[04:04.03]	/audio/My Roommate is a Cat ED 「Kimi no Tonari Watashi.mp3	Kimi no Tonari Watashi no Basho	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773256657/covers/My_Roommate_is_a_Cat_ED_Kimi_no_Tonari_Watashi_no_Basho.jpg	1
724	724	723	201		/audio/Nisekoi ED2 「Recover Decoration」.mp3	Recover Decoration	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773254213/covers/Nisekoi_ED2_Recover_Decoration.jpg	1
875	875	871	221	[00:00.00] \n[00:16.80]YO! SAY, natsu ga mune wo shigeki suru\n[00:20.24]Nama ashi miwaku no MAAMEIDO\n[00:23.80]Dasu toko dashite tawa wa ni nattara\n[00:27.17]Honmono no koi wa yare soukai\n[00:31.76] \n[00:37.67]Gomakashi kika nai usugi no kyokusen wa\n[00:41.06]Kakushinhan no shinaya ka na STYLE!\n[00:44.60]Taisuisei no kimochi ni kiri kawaru\n[00:47.82]Shunkan no mabushi sa wa ika ga na mono\n[00:51.59]Kokoro made nugasareru atsui kaze no\n[00:56.59]yuuwaku ni\n[00:58.45]Make chatte kamawa nai kara manatsu wa\n[01:03.50]Fushouji mo kimi shidai de\n[01:07.40]Yousei tachi ga natsu wo shigeki suru\n[01:10.74]Nama ashi miwaku no MAAMEIDO\n[01:14.07]Dasu toko dashite tawa wa ni nattara\n[01:17.57]Honmono no koi ga deki soukai?\n[01:22.04] \n[01:28.27]Kimi ja nakutemo bate gimi ni mo naru yo\n[01:31.64]Atsui bakka no machi wa yuutsu de\n[01:35.13]Suki wo misetara fui ni mimi ni hairu\n[01:38.45]Sabui gyagu nankade suzumi taku nai\n[01:41.88]Muse kaeru nettai ya wo irodoru hanabi no you ni\n[01:48.59]Uchiagete chiru omoi nara\n[01:52.37]Kono mama daki atte\n[01:55.86]Kogareru made\n[01:57.67]Yousei tachi to natsu wo shitaku naru\n[02:01.11]Atsui yokubou wa TORUNEIDO\n[02:04.64]Dasu mono dashite sunao ni naritai\n[02:07.94]Kimi to boku nara It's All Right\n[02:12.07] \n[02:39.73]Tokai no BIRU no umi ja kanji nakunatteru Kimi wa\n[02:46.19]Hieta WAIN no kuthi zuke de yowasete tolokashite\n[02:52.98]Sashi age mashou\n[02:55.24]Yousei tachi ga natsu wo shigeki suru\n[02:58.60]Nama ashi heso dashi MAAMEIDO\n[03:02.07]Koi ni kamakete orusu ni naru nomo\n[03:05.54]Daisuke teki ni mo OORUKKEE!\n[03:09.08]YO! SAY, natsu wo dare toshitaku naru?\n[03:12.51]Hitori ne no yoru ni You Can Say Good Bye\n[03:16.10]Oku no hou made kawaku manai hodo\n[03:19.19]Honmono no koi wo shimasenka?\n[03:23.37] \n	/audio/Relife ED2 「HOT LIMIT」.mp3	HOT LIMIT	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253660/covers/Relife_ED2_HOT_LIMIT.jpg	1
1072	1061	1061	372		/audio/Teasing Master Takagi San S2 ED4 「Arigatou」.mp3	Arigatou	ED4	https://res.cloudinary.com/ddc6silap/image/upload/v1773254218/covers/Teasing_Master_Takagi_San_S2_ED4_Arigatou.jpg	2
1174	1174	1173	231	[00:00.00] \r\n[00:06.56]Sore de wa\r\n[00:07.35]Saa, katarimashou ka nanbaa sebun?\r\n[00:10.17] \r\n[00:32.64]Eh? Haa? Ikki ichiyuu kako mo mirai mo\r\n[00:35.43](Nee nee) kaidan jou ni uri futatsu tsutawaru kage\r\n[00:38.14](Naisho kitai-nashi tada no ohanashi)\r\n[00:39.44]Hi genjitsu ni mazaru amai kajitsu\r\n[00:42.82]Hai, hai, saisan itte kika setatte\r\n[00:45.43](Hora hora) shikuhakku mattaku motte kiicha inai na\r\n[00:48.28](Naisho kitai nashi owaranai ohanashi)\r\n[00:49.54]Shosen wa uwasabanashi moushuu no genjitsu sa\r\n[00:52.69]Juufu-gou mitai na esoragoto wo asa hiru ban\r\n[00:55.19]Rokkon shoujou wa oroka sodatanai kama ni kusa\r\n[00:57.63]I want some magic\r\n[00:58.14]Nanakuse nante fukanzende\r\n[00:59.80]Mikansei dakara agaiterunda\r\n[01:03.45]Amaneku kotoba yaiba furikazashite\r\n[01:06.72]Warau uso no kamen wo kabutte\r\n[01:10.09](Kimi wa hitori)\r\n[01:11.66]Dareka no tame ni kizutsuite\r\n[01:14.31]Tsumi to batsu no sono hazama\r\n[01:16.75]Daremo inai ano basho ni wa\r\n[01:20.15]Kitto irunda\r\n[01:21.75]Saa, katarimashou ka nanbaa sebun?\r\n[01:24.57] \r\n[01:44.83](Ano ne ano ne ano ne... Naishobanashi...\r\n[01:48.78]Dokoka de kiita, kimi to dake no himitsu dakara)\r\n[01:54.81]Ki mai boku ni akireta kioku moroi shinjitsu de sae mo\r\n[01:59.92]Tabun itsuka no uwasabanashi sono mi wo sonjite\r\n[02:04.93]Icchou isseki bakari de minogashite iku ni no mai\r\n[02:07.64]Chousan boshi kata sukashi\r\n[02:08.91]Ichi ni san shi\r\n[02:10.02]Mirai Misaki minai kagami shijima miseru ka\r\n[02:12.52]Ichi ki bachi ka sono atari de\r\n[02:13.92]Hachiban me wa nai daro?\r\n[02:15.30]Yottsu ha sura kuireba\r\n[02:16.39]Shiku de hakku sa hikute amata\r\n[02:17.62]Nana koronde bachi ga ataru\r\n[02:18.95]Oide oide kikikaikai\r\n[02:20.44]Wagami hachi kuse imadani fukanzen de\r\n[02:22.14]Mikansei dakara mokaiterunda\r\n[02:25.66]Amaneku kotoba yaiba furikazashite\r\n[02:28.81]Toboke warai uso wo kasanete\r\n[02:31.97](Zutto inashi)\r\n[02:34.15]Heikina furi shite gomakashita\r\n[02:36.45]Tsumi to batsu no sono hazama\r\n[02:38.88]Potsuri hitori ano basho ni wa\r\n[02:42.16]Kitto irunda\r\n[02:46.03](Ahhh wooooooohh...!)\r\n[02:52.56] \r\n[02:55.99]Kako mo kakushi nao fusete tsukasaru unmei no saki\r\n[03:01.74]Ichido kaetan dakara mata kaete yarou ze\r\n[03:06.95]Too ka too ka toki no hate\r\n[03:09.10]Sugaru saki de tsukitsukerareta\r\n[03:12.32](Nanimokawaranai yo)\r\n[03:14.13]Sono kotae nara joutou da!\r\n[03:17.03] \r\n[03:17.44]Amaneku kotoba yaiba furikazashite\r\n[03:20.59]Warau uso no kamen wo kabutte\r\n[03:23.94](Kimi wa hitori)\r\n[03:25.58]Dareka no tame ni kizutsui te\r\n[03:28.23]Tsumi to batsu no sono hazama\r\n[03:30.68]Daremo inai ano basho ni wa\r\n[03:34.08]Kyou mo irunda\r\n[03:35.70]Saa, katarimashou ka nanbaa sebun?\r\n[03:38.13]Nee, oshiete yo tsuzuki wo~\r\n[03:41.95] \r\n	/audio/Toilet Bound Hanako Kun OP 「No.7」.mp3	No.7	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254125/covers/Toilet_Bound_Hanako_Kun_OP_No.7.jpg	1
358	358	357	209	[ti:Handyman Saitou in Another World ED 「Hidamari no Saido」]\n[ar:konoco]\n[al:Handyman Saitou]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:23.4.20]\n[length:03:29.01]\n[00:00.00]\n[00:20.64]Fuwari nagareru you na\n[00:23.06]Yoru ni madoromu you na\n[00:25.41]Nannimo nai you na\n[00:27.91]Kokoro ga hitotsu\n[00:30.09]Mata ne terashite yuku\n[00:32.74]Mirai no oku\n[00:34.90]Yasashisa dake tashika ni kanjita\n[00:39.91]Nee kitto sa bokura wa shiranu mama\n[00:44.62]Demo ne ima wa sore de ii\n[00:49.27](Aa)\n[00:50.19]Matteru yo matteru yo koko de mata utaou\n[00:54.67]Itsuka hikari tomosu namida sae ima nara dakishimete\n[00:59.86]Kaite yuku egaite yuku nukumori dake hitotsu\n[01:04.42]Sore ja waraeru you ni hora te wo tsunagu\n[01:11.03](Aa) sore de ii yo sora ni saku\n[01:16.80]Ikiru michishirube wo\n[01:38.50]Itsuka yume samayotte\n[01:41.26]Ikiru imi sagashiteta\n[01:43.78]Nomareteku yoru ni nakisou na\n[01:48.20](Nn)\n[01:48.85]Kimi wa nukumori wo kuretan da\n[01:53.09]Dakara ima wa sore de ii\n[01:58.34](aa)\n[02:28.14]Itsu kara ka itsu kara ka yuugure no mukougawa\n[02:32.75]Na mo nai oto kasanatte modoranai hibi dake dakishimete\n[02:37.89]Sugu soko ni sugu soko ni saita hidamari ga\n[02:42.38]Hora ne mata michibiite yuku\n[02:46.86](Aa)\n[02:47.64]Matteru yo matteru yo koko de mata utaou\n[02:51.75]Itsuka hikari tomosu namida sae ima nara dakishimete\n[02:57.04]Kaite yuku egaite yuku nukumori dake hitotsu\n[03:01.61]Sore ja waraeru you ni hora te wo tsunagu\n[03:08.22](Aa) sore de ii yo sora ni saku\n[03:14.00]Ikiru michishirube wo\n[03:19.99]	/audio/Handyman Saitou in Another World ED 「Hidamari no Saido」.mp3	Hidamari no Saido	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254130/covers/Handyman_Saitou_in_Another_World_ED_Hidamari_no_Saido.jpg	1
407	407	406	268	[00:00.00] \r\n[00:14.01]Joukyou wa hikagakuteki ni kanjou no MONTAAJU\r\n[00:22.65]Dare ga dare wo yonderu?\r\n[00:25.25]Furimukeba nigeteku shisen kanjiru\r\n[00:31.31]Ki no sei ja tsurenai yo\r\n[00:33.71]ANTENA wa sainou tte iu desho\r\n[00:39.08]Datte datte shiritai kimi wa chigau no?\r\n[00:44.19]Seishun no ondosa ima no uchi tadashite ageru yo\r\n[00:50.96]Ashita kaiketsu suru nara ima demo yokunai!?\r\n[00:55.71]Kimi no MISUTERII toite mitai\r\n[01:01.22]Shounen no himitsu meita senaka sagase!\r\n[01:06.06]Kyou mo kimi wa FANTAJII hikarete yuku yo, zurui\r\n[01:13.45]Fukuranda koukishin TORIKKU wa nai no ni\r\n[01:19.13]Ki ni naru yo kyoumibukai doushite?\r\n[01:26.18] \r\n[01:30.19]Mieteiru koto ja hanbun?\r\n[01:35.91]Nandatte hanashite yappa dokoka SHAI nanda\r\n[01:41.55]Me ga aeba hen na iwakan chiku chiku\r\n[01:47.59]Koi nante seikai ja kimi wa mada fu ni ochinai ne\r\n[01:55.40]Dakedo dakedo kikitai honto no koto\r\n[02:00.50]Muzukashii kao shite tanjun na kakehiki oshiete\r\n[02:07.33]Warai tobaseba shingai? Kitto matteru!\r\n[02:12.13]Kimi to SHINPASHII tsukamaetai\r\n[02:17.50]Todokisou de sugu ni kiete shimau fushigi\r\n[02:22.37]Dakara kimi ni TEREPOOTO ichiban soba ni iku yo\r\n[02:29.78]Oteage no koukishin baka mitaku hashaide\r\n[02:35.44]Gomakashita suki na kimochi mitome you\r\n[02:43.20] \r\n[03:03.76]Muki ni natteta no wa watashi? Ishiki saretai kuse ni\r\n[03:13.94]Yureteru mirai jibun shidai dake ja yada yo\r\n[03:25.39]Kimi no MISUTERII toite mitai\r\n[03:30.97]Shounen no himitsu meita senaka sagase!\r\n[03:35.69]Kyou mo kimi wa FANTAJII hikarete yuku yo, zurui\r\n[03:43.10]Fukuranda koukishin TORIKKU wa nai no ni\r\n[03:48.89]Ki ni naru yo kyoumibukai doushite?\r\n[03:56.90] \r\n	/audio/Hyouka ED2 「Kimi ni Matsuwaru Mystery」.mp3	Kimi ni Matsuwaru Mystery	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773254128/covers/Hyouka_ED2_Kimi_ni_Matsuwaru_Mystery.jpg	1
1001	1001	1000	306		/audio/Somali and the Forest Spirit OP 「Arigatou wa Ko.mp3	Arigatou wa Kocchi no Kotoba	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254219/covers/Somali_and_the_Forest_Spirit_OP_Arigatou_wa_Kocchi_no_Kotoba.jpg	1
882	882	871	243		/audio/Relife ED9 「There will be love」.mp3	There will be love	ED9	https://res.cloudinary.com/ddc6silap/image/upload/v1773253239/covers/Relife_ED9_There_will_be_love.jpg	1
1231	1229	1228	311	[00:00.00] \n[00:23.64]katari tsugareru ai no komori uta\n[00:29.83]sotto anata ni utau\n[00:36.23]yosete wa kaesu nami no oto no youni\n[00:42.45]towa ni hibiki kanaderu\n[00:50.55]futae ni karamiai eien ni tsuzuku\n[01:00.22]rasen no youni\n[01:03.01]tsunagaru futari no sadame itsuka aeru to\n[01:12.49]kono yo ni umareta\n[01:17.39]anata wa yumebito itsumo kanata dokoka ni\n[01:23.78]natsukashi omokage sagashiteru\n[01:30.01]fushigi na sekai wa mangekyou no youni\n[01:36.18]katachi kaete wa kurikaesareru yume ka utsutsu ka\n[02:10.87]katari tsugu no wa kanashi koi no uta\n[02:17.34]ukabu oto ni nosete\n[02:23.55]itsumo yozora ni mieru hoshi no youni\n[02:29.97]towa ni hikari kagayaku\n[02:37.86]ikue ni karamiai eien ni tsuzuku\n[02:47.29]futari no kizuna\n[02:50.49]itsuka wa aeru to negai sotto me wo toji\n[02:59.77]kono yume inoru no\n[03:04.75]anata wa tabibito kitto haruka tooku de\n[03:11.34]nakushita maboroshi sagashiteru\n[03:17.19]fushigi na sekai ni shinkirou no youni\n[03:23.37]kasuka mieru wa hikari ka kage ka yume ka utsutsu ka\n[03:48.96]itsuwari yadoshi umareru makoto\n[04:01.57]yurameita kokoro wa itsushika kie yuku\n[04:17.30]anata wa yumebito itsumo kanata dokoka ni\n[04:23.56]natsukashi omokage sagashiteru\n[04:29.81]fushigi na sekai wa mangekyou no youni\n[04:35.92]katachi kaete wa kurikaesareru yume ka utsutsu nano ka\n[04:47.52] 	/audio/Utawarerumono S2 ED 「Yume ka Utsutsu ka」.mp3	Yume ka Utsutsu ka	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254134/covers/Utawarerumono_S2_ED_Yume_ka_Utsutsu_ka.jpg	2
18	18	18	247		/audio/Aho-Girl ED 「Odore! Kyu-Kyoku Tetsugaku」.mp3	Odore! Kyu-Kyoku Tetsugaku	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254142/covers/Aho-Girl_ED_Odore_Kyu-Kyoku_Tetsugaku.jpg	1
42	42	41	90		/audio/Arakawa Under the Bridge OP2 「Title nante Jibun.mp3	Title nante Jibun de Kangaenasaina	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773254144/covers/Arakawa_Under_the_Bridge_OP2_Title_nante_Jibun_de_Kangaenasaina.jpg	1
735	735	723	90		/audio/Nisekoi S2 ED5 「marchen ticktack」.mp3	marchen ticktack	ED5	https://res.cloudinary.com/ddc6silap/image/upload/v1773254147/covers/Nisekoi_S2_ED5_marchen_ticktack.jpg	2
874	874	871	223	[00:00.00] \n[00:01.01]Kimi ga ita natsu wa tooi yume no naka\n[00:14.40]Sora ni kieteita uchiage hanabi\n[00:28.51] \n[00:31.33]Kimi no kami no kaori hajiketa\n[00:34.63]Yukata sugata ga mabushi sugite\n[00:38.04]Omatsuri no yoru wa mune ga sawaida yo\n[00:44.93]Hagure sou na hitogomi no naka\n[00:48.26]Hanarenaide dashikaketa\n[00:51.10]te wo POKETTO ni irete nigiri shimeteita\n[00:58.97]Kimi ga ita natsu wa tooi yume no naka\n[01:05.64]Sora ni kieteita uchiage hanabi\n[01:13.50] \n[01:17.29]Kodomo mitai kingyo sukuini muchuu ni natte\n[01:22.28]sode ga nureteru\n[01:23.99]Mujaki na yokogao ga totemo kawaikute\n[01:30.90]kimi wa suki na watagashi katte gokigen dakedo\n[01:35.93]sukoshi mukou ni\n[01:37.59]Tomodachi mitsukete hanarete aruita\n[01:44.96]Kimi ga ita natsu wa tooi yume no naka\n[01:51.58]Sora ni kieteita uchiage hanabi\n[01:59.67] \n[02:28.92]Jinja no naka ishidan ni suwari moya' to\n[02:33.11]shita yami no naka de\n[02:35.36]zawameki ga sukoshi tooku kikoeta\n[02:42.30]Senkou hanabi MACCHI wo tsukete\n[02:45.59]ironna koto hanashita keredo\n[02:49.06]"suki da" tte koto ga ienakatta\n[02:56.46]Kimi ga ita natsu wa tooi yume no naka\n[03:03.03]Sora ni kieteita uchiage hanabi\n[03:09.89]Kimi ga ita natsu wa tooi yume no naka\n[03:16.68]Sora ni kieteita uchiage hanabi\n[03:24.68] \n[03:25.31]Sora ni kieteita uchiage hanabi.\n[03:38.35] \n	/audio/Relife ED12 「Natsumatsuri 」.mp3	Natsumatsuri 	ED12	https://res.cloudinary.com/ddc6silap/image/upload/v1773254136/covers/Relife_ED12_Natsumatsuri.jpg	1
66	66	66	341		/audio/Bakemonogatari ED 「Kimi no Shiranai Monogatari」.mp3	Kimi no Shiranai Monogatari	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254151/covers/Bakemonogatari_ED_Kimi_no_Shiranai_Monogatari.jpg	1
223	223	223	273	[00:00.00] \n[00:18.05]Yuuutsu ga kaze ni chirabari fukidamatte kage ni naru\n[00:24.02]Bokura no ashioto wa mujou wo jouzetsu ni satosu\n[00:30.90]Kimi no hitomi no fukasa wo nozokimite urotaeru\n[00:37.07]Nozomi nado atta deshou ka kono yukusaki ni wa\n[00:43.90]Odokete warau no wa kono michi ga kurai kara\n[00:50.27]Akari wo tomosu no ni boku ga iru deshou\n[00:57.17]Sayonara gokko wa nareta mon sa demo te wo futtara naichatta\n[01:03.66]Bokura no makka na kanashimi ga kureru kureru soshite yoru ga kuru\n[01:10.06]Atarimae ni yatte kuru ashita nara “ikitai” nante iwanakatta\n[01:16.59]Yoseba ii no ni yume mite shimau mirai mirai kimi no sei nan da\n[01:23.58] \n[01:36.42]Nashitogeneba naranai koto mikazuki ni burasagete\n[01:42.50]Samayou yomichi ni sura ando wa kimi no se ni akarui\n[01:49.40]Shinjiru ni wa jikan ga iru mashite ya tanin dakara\n[01:55.46]Soredemo michi ga onaji nara hanareru riyuu mo nai\n[02:02.09]Subete ga owattara wakachiau tame ni\n[02:08.65]Dareka ga iru deshou boku ga iru deshou\n[02:15.55]Sayonara gokko wa nareta mon sa demo te wo futtara naichatta\n[02:22.22]Bokura no makka na kanashimi ga kureru kureru soshite yoru ga kuru\n[02:28.48]Hajime kara soko ni aru aijou nara tashikameau koto wa nakatta\n[02:34.98]Kiguu ni mo tsureau en dakara fureru fureru kokoro no erimoto\n[02:42.81] \n[03:07.83]Tsurasa nara seoeru kara itami nara wakeaeru kara\n[03:14.36]Demo kimi no sadame made wa katagawari dekinakatta\n[03:20.95]Wakare wa nandome demo ai kawarazu kanashii kara\n[03:27.46]Wakareru furi wo surun da yo sayonara no asobi da yo\n[03:33.87]Itsuka kanarazu aeru tte jibun wo damasu asobi da yo\n[03:45.36] \n[03:46.90]Sayonara gokko wa nareta mon sa demo te wo futtara naichatta\n[03:53.53]Bokura no makka na uso dake ga nureru nureru soshite asa ga kuru\n[04:00.10]Hanarebanare ni naru tte koto wa ichido wa hitotsu ni nareta ka naa\n[04:06.43]Akirame to yobeba ushirometai sadame sadame sou kimi wa yonda\n[04:13.45] \n	/audio/Dororo ED 「Sayonara Gokko」.mp3	Sayonara Gokko	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254137/covers/Dororo_ED_Sayonara_Gokko.jpg	1
257	226	256	120	[00:00.00] \n[00:12.89]kimi o matta\n[00:14.32]boku wa matta\n[00:15.90]togirenai ashita mo sugiteitte\n[00:18.97]tachitomatte furikaette\n[00:22.43]tomedonai kyou o nagekiatta\n[00:25.30]kioku datte  towa ni nante\n[00:28.29]nokoranai mono to omoishitte\n[00:31.38]boku wa zutto kakimushitte\n[00:34.54]kokoro no sumikko de naita\n[00:37.35]soshite douka nakusanaide yo tte\n[00:40.72]kouka shita, sugiru hibi o\n[00:43.68]koukai shitenda yo tte  sou iinogashita ano hi\n[00:51.27]tsunagiatta toki mo atta\n[00:56.74]hodokenai kanjou mochiyotte	/audio/Erased OP 「Re_Re_」.mp3	Re:Re:	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254220/covers/Erased_OP_ReRe.jpg	1
431	431	427	236	[ti:Inu x Boku SS ED5 「sweets parade」]\r\n[ar:Roromiya (Kana Hanazawa)]\r\n[al:Inu x Boku Secret Service]\r\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\r\n[ve:22.5.26]\r\n[length:03:56.19]\r\n[00:00.10]Ai, ue, okashi, shita Kaki kuu kke? Konna ni mo\r\n[00:05.27]Sashi su se SOFUTO KURIIMU Gozou roppu de ikou\r\n[00:10.02]TACCHI tsuite TORUTE kita Nani? NUNE nori shio\r\n[00:14.52]Ha-! HIFUHEHO tto PAI to Minna de nukunuku\r\n[00:19.43]SHOOTO KEEKI Fuwari KYANDII Pero pero\r\n[00:24.01]CHOKOREETO no kawa de Watagashi kumo mita\r\n[00:28.56]AISU KURIIMU to PURIN no oshiro de\r\n[00:33.21]KASUTAADO Watanuki Futari no RANDEBUU\r\n[00:37.91]PAFE iro SANDEE Anko mo HAPPII\r\n[00:42.52]TAIYAKI ni KURIIMU Koakuma DOROPPU\r\n[00:47.12]KAPPUKEEKI kara Ichigo anmitsu made\r\n[00:51.82]Koukyou naki sweets Nakayoku nareru yo\r\n[00:56.54]Bonyari yume mite goran\r\n[01:01.09]KYARAMERU mitai ni Kuttsukou\r\n[01:05.84]Ma mi mu me mo MON BURAN Yai! Yue YOOGURUTO\r\n[01:10.42]RARIRUURE ROORU KEEKI Watanuki to Kiss wo\r\n[01:15.09]Ai, ue, okashi, shita Kaki kuu kke? Konna ni mo\r\n[01:19.85]Sashi su se SOFUTO KURIIMU Gozou roppu de ikou\r\n[01:24.57]Nonbiri hayaben Yaki nori abutte\r\n[01:29.08]Onigiri KORO KORO Tomodachi hoka hoka\r\n[01:33.82]Momiji manjuu to Anpan otsuki sama\r\n[01:38.45]Watanuki ni hajimari Watanuki ni owaru hibi\r\n[01:43.22]Honnori mitsumete goran\r\n[01:47.56]Amakute nigai yuuyake wo\r\n[01:52.42]TACCHI tsuite TORUTE kita Nani? NUNE nori shio\r\n[01:57.07]Ha-! HIWAHEHO tto PAI to Minna de nukunuku\r\n[02:01.73]Ma mi mu me mo MON BURAN Yai! Yue YOOGURUTO\r\n[02:06.17]RARIRUURE ROORU KEEKI Watanuki to Kiss wo\r\n[02:29.75]MIRUFIIYU WAFFURU BON BON\r\n[02:32.26]MUUSU Watanuki PAI\r\n[02:34.33]SHUU KURIIMU BANANA ZERII\r\n[02:36.78]BABAROA Watanuki\r\n[02:38.94]HOTTO KEEKI BAUMUKUUHEN\r\n[02:41.38]Wataunuki WATANUKI\r\n[02:43.55]BATAA Watanuki KUREEPU\r\n[02:45.96]WATANUKI Watanuki\r\n[02:48.41]WATANUKI to gohan WATANUKI to oyatsu\r\n[02:52.88]WATANUKI to niku man WATANUKI to Pekkin DAKKU\r\n[02:57.49]Mitsumame Watanuki Watanuki SHIROPPU\r\n[03:02.22]Kintoki WATANUKI Oomori Watanuki don\r\n[03:06.97]Kongari omoide iro\r\n[03:11.41]HACHIMITSU mitai ni Torokeru\r\n[03:16.25]Ai, ue, okashi, shita Kaki kuu kke? Konna ni mo\r\n[03:21.03]Sashi su se SOFUTO KURIIMU Gozou roppu de ikou\r\n[03:25.43]TACCHI tsuite TORUTE kita Nani? NUNE nori shio\r\n[03:30.08]Ha-! HIFUHEHO tto PAI to Futari de nukunuku\r\n[03:35.02]Ma mi mu me mo MON BURAN Yai! Yue YOOGURUTO\r\n[03:39.44]RARIRUURE ROORU KEEKI\r\n[03:42.21]Watanuki to Kiss wo\r\n[03:44.58]WATANUKI no amami to WATANUKI no nigami\r\n[03:49.04]WATANUKI no sanmi de\r\n[03:51.57]Suki suki RABU KONBO\r\n[03:53.82]	/audio/Inu x Boku SS ED5 「sweets parade」.mp3	sweets parade	ED5	https://res.cloudinary.com/ddc6silap/image/upload/v1773254160/covers/Inu_x_Boku_SS_ED5_sweets_parade.jpg	1
549	547	546	241	[ti:Maison Ikkoku ED4 「Fantasy」]\n[ar:PICASSO]\n[al:Maison Ikkoku]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:23.4.20]\n[length:04:01.46]\n[00:00.00]\n[00:06.86]mitsumeaeba HAATO ni nagareru\n[00:12.74]fushigi na Melody\n[00:19.93]futari ni shika mienai tobira wo\n[00:25.94]mirakeba Fantasy\n[00:37.21]ai ga umaku shabere nakute\n[00:44.40]PIANO wo hiita no sa\n[00:50.93]kimi no kami ga aoi tsuki no\n[00:57.43]shizuku ni hikarumade\n[01:04.24]yume wo nage ire (please smile for me)\n[01:07.84]hakatte okure (love more than you)\n[01:11.11]ai no fukasa wo\n[01:16.46]sotto fureta kuchibiru kanaderu\n[01:22.44]shizuka na Harmony\n[01:30.07]dakishimete mo setsunasa afurete\n[01:35.67]yume miru Fantasy\n[01:44.43]kimi ga warau tabi\n[01:51.28]boku wa yasashiku naru\n[01:57.29]kaze ga machi ga kooete iru\n[02:03.99]mafuyu no tasogare mo\n[02:10.59]POKETTO no naka tsuberi konda\n[02:17.14]kimi no te wa atatakai\n[02:49.73]mitsume aeba HAATO ni nagareru\n[02:55.54]fushigi na Melody\n[03:02.74]futari ni shika mienai tobira wo\n[03:08.48]mirakeba Fantasy\n[03:16.97]ai ga meiro nara\n[03:23.56]kimi to mayou dake sa\n[03:29.42]sotto fureta kuchibiru kanaderu\n[03:35.02]shizuka na Harmony\n[03:42.60]dakishimete mo setsunasa afurete\n[03:48.54]yume miru Fantasy\n[03:53.81]	/audio/Maison Ikkoku ED4 「Fantasy」.mp3	Fantasy	ED4	https://res.cloudinary.com/ddc6silap/image/upload/v1773254154/covers/Maison_Ikkoku_ED4_Fantasy.jpg	1
1	1	1	327	[00:00.00] \r\n[00:16.72]Kore ijou nani wo ushinaeba kokoro wa yurusareru no\r\n[00:23.98]Dore hodo no itami naraba mou ichido kimi ni aeru\r\n[00:31.13]One more time kisetsu yo utsurowanaide\r\n[00:38.83]One more time fuzake atta jikan yo\r\n[00:46.45]Kuichigau toki wa itsumo boku ga saki ni oreta ne\r\n[00:53.88]Wagamama na seikaku ga naosara itoshiku saseta\r\n[01:00.86]One more chance kioku ni ashi wo torarete\r\n[01:08.56]One more chance tsugi no basho wo erabenai\r\n[01:16.17]Itsu demo sagashite iru yo dokka ni kimi no sugata wo\r\n[01:23.51]Mukai no hoomu rojiura no mado\r\n[01:27.22]Konna toko ni iru hazu mo nai no ni\r\n[01:31.20]Negai ga moshimo kanau nara ima sugu kimi no moto e\r\n[01:38.47]Dekinai koto wa mou nanimo nai\r\n[01:42.13]Subete kakete dakishimete miseru yo\r\n[01:57.43]Sabishisa magirasu dake nara\r\n[02:01.08]Dare demo ii hazu na no ni\r\n[02:05.09]Hoshi ga ochisou na yoru dakara\r\n[02:09.06]Jibun wo itsuwarenai\r\n[02:12.10]One more time kisetsu yo utsurowanaide\r\n[02:19.77]One more time fuzake atta jikan yo\r\n[02:27.19]Itsu demo sagashite iru yo dokka ni kimi no sugata wo\r\n[02:34.45]Kousaten demo yume no naka demo\r\n[02:38.28]Konna toko ni iru hazu mo nai no ni\r\n[02:42.24]Kiseki ga moshimo okoru nara im sugu kimi ni misetai\r\n[02:49.39]Atarashii asa kore kara no boku\r\n[02:53.03]Ienakatta suki to iu kotoba mo\r\n[02:59.47] \r\n[03:08.28]Natsu no omoide ga mawaru fui ni kieta kodou\r\n[03:23.45]Itsu demo sagashite iru yo dokka ni kimi no sugata wo\r\n[03:31.15]Akegata no machi sakuragichou de\r\n[03:34.85]Konna toko ni kuru hazu mo nai no ni\r\n[03:38.68]Negai ga moshimo kanau nara ima sugu kimi no moto e\r\n[03:45.96]Dekinai koto wa mou nanimo nai\r\n[03:49.69]Subete kakete dakishimete miseru yo\r\n[03:53.68]Itsu demo sagashite iru yo dokka ni kimi no kakera wo\r\n[04:00.75]Tabisaki no mise shinbun no sumi\r\n[04:04.26]Konna toko ni aru hazu mo nai no ni\r\n[04:08.01]Kiseki ga moshimo okoru nara ima sugu kimi ni misetai\r\n[04:15.32]Atarashii asa kore kara no boku\r\n[04:19.02]Ienakatta suki to iu kotoba mo\r\n[04:23.06]Itsu demo sagashite shimau dokka ni kimi no egao wo\r\n[04:30.24]Kyuukou machi no fumikiri atari\r\n[04:33.75]Konna toko ni iru hazu mo nai no ni\r\n[04:37.44]Inochi ga kurikaesu naraba nandomo kimi no moto e\r\n[04:45.11]Hoshii mono nado mou nanimo nai\r\n[04:48.91]Kimi no hoka ni taisetsu na mono nado	/audio/5 Centimeters Per Second 「One More Time, One Mo.mp3	One More Time, One More Chance	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773254064/covers/5_Centimeters_Per_Second_One_More_Time_One_More_Chance.jpg	1
46	46	46	279		/audio/Arifureta ED 「Hajime no Uta」.mp3	Hajime no Uta	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254179/covers/Arifureta_ED_Hajime_no_Uta.jpg	1
47	47	46	289		/audio/Arifureta OP 「FLARE」.mp3	FLARE	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254178/covers/Arifureta_OP_FLARE.jpg	1
165	165	162	241		/audio/Danmachi S2 ED 「Sasayakana Shukusai」.mp3	Sasayakana Shukusai	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254182/covers/Danmachi_S2_ED_Sasayakana_Shukusai.jpg	2
243	243	241	290		/audio/ef ~ A Tale of Memories S2 ED3 「ever forever」.mp3	ever forever	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773254185/covers/ef_A_Tale_of_Memories_S2_ED3_ever_forever.jpg	2
504	500	500	273	[00:00.00] \n[00:16.18]Hajimari no shunkan sa\n[00:19.77]Oikaze wa sunabokori ageta\n[00:23.78]Tachidomatterarenai\n[00:26.83] \n[00:30.44]Umaku yarisugoshite mo\n[00:34.06]Hontou ni hoshii mono dakishimenakya\n[00:38.03]Itsumo mitasarenai\n[00:40.98] \n[00:43.75]Sagashi ni yukou hateshinai oozora he\n[00:50.96]Kizamu ashiato azayaka ni\n[00:54.93]Kitto kimi to egakidasou\n[01:01.20]Hashiridase\n[01:04.73]Dare mo shiranai mirai\n[01:09.29]Tobikonda sono toki ni\n[01:15.68]Kagayaita kimi no hitomi kanjita\n[01:22.98]Subarashii ashita ga mou bokura wo matte iru kara\n[01:32.67] \n[01:40.41]Donna ni gomakashite mo\n[01:44.07]Kore koso ga genjitsu sa\n[01:46.92]Demo ne mou me wa sorasenai\n[01:50.69] \n[01:54.76]Dareka no shiawase toka\n[01:58.22]Yokodori shitaku nacchau kedo ne\n[02:02.29]Sore ja mitasarenai\n[02:04.99] \n[02:07.83]Souzou yori mo mune kogasu shinjitsu wo\n[02:15.08]Mitsumeru yuuki nigirishime\n[02:19.24]Motto kimi to hajimeyou\n[02:25.13]Asayake ga\n[02:28.93]Itsuka yumemita mirai\n[02:33.18]Terashite kureteru kara\n[02:39.74]Te wo tsunagi ima sugu ni tobidasou\n[02:47.16]Subarashii ashita wa hora bokura no tame ni aru kara\n[02:57.42] \n[03:26.80]Mayotte mo ushinatte mo\n[03:33.76]Ano sora no mukou de\n[03:41.01]Owaranai monogatari wa\n[03:44.63]Kyou mo mata iro wo kaete matataku yo\n[03:49.76]Saa tobira akete\n[03:54.67] \n[03:54.81]Hashiridase\n[03:58.42]Dare mo shiranai mirai\n[04:02.85]Tobikonda sono toki ni\n[04:09.53]Kagayaita kimi no hitomi kanjita\n[04:16.61]Subarashii ashita ga mou bokura wo matte iru kara\n[04:27.71] \n	/audio/Konosuba S2 OP 「TOMORROW」.mp3	TOMORROW	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254176/covers/Konosuba_S2_OP_TOMORROW.jpg	2
62	61	59	233		/audio/Baka and Test S2 ED 「Eureka Baby」.mp3	Eureka Baby	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254171/covers/Baka_and_Test_S2_ED_Eureka_Baby.jpg	2
63	59	59	261		/audio/Baka and Test S2 ED2 「Baka to Koshitsu to Kodok.mp3	Baka to Koshitsu to Kodoku Meshi	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773254170/covers/Baka_and_Test_S2_ED2_Baka_to_Koshitsu_to_Kodoku_Meshi.jpg	2
64	59	59	236		/audio/Baka and Test S2 ED3 「Hi-Ho!!」.mp3	Hi-Ho!!	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773254180/covers/Baka_and_Test_S2_ED3_Hi-Ho.jpg	2
65	65	59	223		/audio/Baka and Test S2 OP 「Kimi+Nazo+Watashi de JUMP!.mp3	Kimi+Nazo+Watashi de JUMP!!	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254167/covers/Baka_and_Test_S2_OP_Kimi_Nazo_Watashi_de_JUMP.jpg	2
68	68	66	248		/audio/Bakemonogatari OP2 「Kaerimichi」.mp3	Kaerimichi	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773254168/covers/Bakemonogatari_OP2_Kaerimichi.jpg	1
159	159	159	197		/audio/Daily Lives of High School Boys ED 「Bungaku Sho.mp3	Bungaku Shoujo	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254183/covers/Daily_Lives_of_High_School_Boys_ED_Bungaku_Shoujo.jpg	1
116	116	112	176	[ti:Cells at Work! Code Black ED 「Ue wo Muite Hakobu with Sekkekkyuu & Hakkekkyuu」]\n[ar:POLYSICS]\n[al:Cells at Work]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:02:55.80]\n[00:00.00]\n[00:01.05]Hakobe hakobe\n[00:02.62]Hakobe hakobe\n[00:04.44]Hakobe hakobe\n[00:06.23]Hakobe hakobe\n[00:15.61]Hitasura mainichi kurikaeshi\n[00:19.26]Michi mo kewashiku naru\n[00:22.92]Tsumazuite mo egaonara\n[00:26.55]Michitariteru sain\n[00:29.66]Todokeyo hakobeyo sekkekkyū\n[00:33.65]Tayori ni shiteruyo hakkekkyū\n[00:37.35]Minna ga hitotsu ni nari sasaeau\n[00:40.95]Donna shigoto mo raku janaiyona\n[00:00.00][source: https://animesonglyrics.com]\n[00:48.25]Hi wa mata nobotte kurikaesu\n[00:51.75]Asu e mukatte asu e mukatte\n[00:55.45]Madamada hatarakō\n[00:59.07]Itsu made tsuzuku kono hibi ni\n[01:02.74]Tama ni nakitaku naru\n[01:06.38]Owari no mie nai yamazumi ni\n[01:10.01]Tameiki tsuku bakari\n[01:13.65]Iwanakute mo wakaruyo sekkekkyū\n[01:17.28]Jibun o daiji ni hakkekkyū\n[01:21.02]Nantoka girigiri mochikotaeteru\n[01:24.73]Taimu kādo no imi wa naiyona\n[01:31.81]Saenai yume nai kibō nai\n[01:35.47]Asu wa konaide asu wa konaide\n[01:39.16]Tadatada neteiyō\n[01:43.30]Furēfurē saibō\n[02:01.45]Todokeyo hakobeyo sekkekkyū\n[02:05.14]Tayori ni shiteruyo hakkekkyū\n[02:08.77]Minna ga hitotsu ni nari sasaeau\n[02:12.85]Donna shigoto mo raku janaiyona\n[02:19.76]Hi wa mata nobotte kurikaesu\n[02:23.29]Asu e mukatte asu e mukatte\n[02:27.09]Madamada hatarakō\n[02:30.59]Furēfurē saibō\n[02:34.15]Furēfurē saibō\n[02:37.88]Asu e mukatte asu e mukatte\n[02:41.43]Matamata kyō mo todokeyō\n[02:45.08]Hakobe hakobe\n[02:46.73]Hakobe hakobe\n[02:48.59]Hakobe hakobe\n[02:50.32]Hakobe hakobe\n[02:52.11]Hakobe hakobe...\n[02:53.76]	/audio/Cells at Work! Code Black ED 「Ue wo Muite Hakob.mp3	Ue wo Muite Hakobu with Sekkekkyuu & Hakkekkyuu	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254196/covers/Cells_at_Work_Code_Black_ED_Ue_wo_Muite_Hakobu_with_Sekkekkyuu_Hakkekkyuu.jpg	1
177	175	175	260	[00:00.00] \n[00:19.27]Doushite kimi bakari mitsumete shimau'n darou\n[00:26.57]Taikutsu na kyoushitsu ni kimi ga irodori wo kureteru\n[00:33.87]Neguse nokoru kami mo kawaiku omotte shimau\n[00:41.00]Terete hanasenakute\n[00:44.09]Mado wo ake kaze wo uke mune ippai ni iki wo suikonda\n[00:54.10] \n[00:58.80]Aozora ga saware sou na hodo azayaka ni miete\n[01:06.07]Ureshikute setsunakute kore ga koi nanda\n[01:13.10]Kimi ga tada boku no namae wo ne koe ni suru dake de\n[01:20.57]Jiyuu ni nareru ki ga shita'n da\n[01:28.42]Itsumo hitori soto wo nagamete ita boku ni\n[01:35.54]"Nani wo mite iru no?" to hanashi kakete kureta houkago\n[01:42.90]Omoeba ano hi kara kimi ga ki ni natte ita\n[01:50.24]Wakarou to shite kurete\n[01:53.05]Kyuukutsu na TORIKAGO ni iru basho wo tsukutte kureta\n[02:07.71]Koishisa ga mune ni furu tabi ni omoi shirasareru\n[02:15.16]Souzou yori sekai wa warukunai'n da\n[02:22.19]Hohoende hanashikiku kimi ga hikatte mieru kara\n[02:29.81]Me ga au tabi ni sorashite shimau yo\n[02:36.63] \n[02:47.71]Boku wa jibun jishin sae mo marude wakattenakatta\n[02:54.86]Chigireta kumo wa nagare KAATEN ga yureteru boku no kokoro to issho ni\n[03:10.18] \n[03:15.03]Aozora ga saware sou na hodo azayaka ni miete\n[03:22.52]Ureshikute setsunakute kore ga koi nanda\n[03:29.45]Kimi ga tada boku no namae wo ne koe ni suru dake de\n[03:36.92]Jiyuu ni nareru ki ga shita'n da\n[03:44.39]Hajimete no suki daiji ni shitai\n[03:51.98] \n	/audio/Darling In The FranXX ED3 「Beautiful World」.mp3	Beautiful World	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773254186/covers/Darling_In_The_FranXX_ED3_Beautiful_World.jpg	1
207	207	207	215	[ti:Death Parade OP 「Flyers」]\n[ar:BRADIO]\n[al:Death Parade]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:34.87]\n[00:00.00]\n[00:15.97]"Kou nattara ii na" no mousou to genjitsu ni\n[00:19.72]isseki wo toujite kosei wo migake\n[00:23.62]kakaenayamu nandai wo mata hitotsu shoukyo\n[00:27.15]atama kara ketsu made sore ga wa ga entame\n[00:30.66]Boom, boom, boom, dancing through the skies\n[00:33.74]mada shijainai sa himotoita shourai wa\n[00:37.42]Boom, boom, boom, dancing through the skies\n[00:40.41]daichi kettobashite motto maiagatte\n[00:44.73]Everybody put your hands up\n[00:48.17]saa flyin' tsubasa ni nare\n[00:51.59]mitemitai na muchuu ni nareru kimi\n[00:54.84]ima da seichouki shinsekai e\n[01:05.09]modokashikute mou douka shiteru\n[01:08.82]mugamchuu ni nareru mono ga hoshii\n[01:12.57]fugainai hiidetenai nante kawaikunai ne\n[01:15.85]konpurekkusu wa sakate ni totte orijinaritii\n[01:19.34]Boom, boom, boom, dancing through the skies\n[01:22.10]"yaranakyayamai" de yamadzumi no mondai mo\n[01:26.26]Boom, boom, boom, dancing through the skies\n[01:29.01]motto waruagaite shoutai wo abaite\n[01:35.63]Everybody put your hands up\n[01:38.82]saa flyin' sono imeeji de\n[01:42.29]kitto nareru sa naritai jibun ni\n[01:45.65]sagase you're the one oobutai e\n[01:49.19]Flyin' wasureteta Flyin' kioku no naka de\n[01:52.99]mou ichido mune no takanari wo kike\n[01:58.09]yeah... wow... chu... na...\n[02:37.19]Everybody put your hands up\n[02:40.80]saa flyin' tsubasa ni nare\n[02:44.40]mitemitai na muchuu ni nareru kimi\n[02:47.69]ima da seichouki shinsekai e\n[02:51.10]Everybody put your hands up\n[02:54.58]saa flyin' sono imeeji de\n[02:58.17]kitto nareru sa naritai jibun ni\n[03:01.55]sagase you're the one oobutai e\n[03:05.01]Flyin' wasureteta Flyin' kioku no naka de\n[03:08.61]mou ichido mune no takanari wo kike\n[03:20.50]yeah... wow... chu... na...\n[03:25.66]	/audio/Death Parade OP 「Flyers」.mp3	Flyers	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254189/covers/Death_Parade_OP_Flyers.jpg	1
369	263	369	253	[00:00.00] \n[00:18.91]Kitto bokutachi ga sōzō shita mirai wa\n[00:22.88]Osanai koro mitsuketa ishikoro mitai ni marukkoku te\n[00:27.75]Hen na kizuato nanka mo naku te sa\n[00:31.94]Heiwa tte yū kanji no tōri na n da tte omotte ita\n[00:37.60] \n[00:40.48]Kanjin na bonjin wa yume o otte shima o deta\n[00:44.33]Mune ni yume tte kaite tobidashita ano ō unabara e\n[00:49.62]Hen ni nai tatte kūki ga nigoru kara sa\n[00:53.60]Jāne tte yū matanette yū\n[00:55.63]Ishikoro o sora ni nageta\n[00:57.80] \n[00:58.52]Kyodai na chikara de tsubusare sō na\n[01:03.99]Kodoku ni wa sono doku ni wa\n[01:07.99]Dokutoku no sekai o yobiokosu\n[01:12.81]Mahō ga aru yo\n[01:16.17]Sayonara itsu ka no shōnen no kage yo\n[01:25.95]Mata aō na mada tadaima\n[01:30.56]Ieru basho wa totte oku ze\n[01:35.02]Kono ōzora no aosa o hitomi no paretto ni\n[01:43.99]Mogurasete tsutsumikonde\n[01:48.33]Namida sae mo mikata ni\n[01:53.99] \n[01:56.30]Kitto bokutachi ga sōzō shita mirai wa\n[02:00.28]Garasu no kutsu ya majo ga tobikau ehon no yō na monogatari\n[02:05.30]Hen na riyū mo naku sō shinjite ita n da\n[02:09.43]Hei beibī! nante odokete warai\n[02:11.59]Ase kaite otona ni natta\n[02:14.36]Shiranai aida ni tsubusare sō na\n[02:19.80]Shiawase ya no ni mebuku hana ga\n[02:23.83]Dō ka saigo made sakimasu yō ni\n[02:28.59]Subete o hikarase\n[02:34.16]Sayonara ano hi no shōnen no yume yo\n[02:43.96]Mata aō ka mada tadaima\n[02:48.56]Ieru kurai no yoyū wa arudaro?\n[02:53.13]Kono ōzora no aosa o kokoro no oashisu ni shite\n[03:02.58]Oyoide mogurikonde\n[03:06.60]Mata kaitte oida\n[03:09.93]Dakara ima wa\n[03:12.70]Sayonara shōnen no kage yo\n[03:20.21]Mata aō na mata tadaima\n[03:24.66]Ieru basho wa totte oku ze\n[03:29.40]Kono ōzora no ao-sa o hitomi no paretto ni\n[03:38.29]Mogurasete tsutsumikonde\n[03:42.77]Namida sae mo mikata ni\n[03:47.43] \n	/audio/Her Blue Sky ED Theme 「Aoi」.mp3	Aoi	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773254194/covers/Her_Blue_Sky_ED_Theme_Aoi.jpg	1
193	188	184	268	[00:00.56] It was something nice and sweet, 'til I see the real\n[00:09.05] It's been always something cruel, dark and sore\n[00:17.75] 近付くたび 煌めくたび この胸 押し寄せる\n[00:26.40] 嬉しいでも苦しい ここから先は 無理に近付かないで\n[00:34.86] （やさしい声で）ただこのままでいたいだけ\n[00:43.40] （揺さぶらないで）なのに\n[00:51.59] 誰も崩せない 築き上げたバリケード\n[01:00.26] 固く閉ざしてたはずだったのにどうして？\n[01:12.98] Do you hear weary heart's S.O.S?\n[01:26.17] 目にするたび 感じるたび この胸 締め付ける\n[01:35.02] 恥ずかしくて虚しい そこから先は 口に出さないでいて\n[01:43.42] （やさしい声で）嘘吐いたって痛いだけ\n[01:52.37] （裏切らないで）なのに\n[02:00.26] 誰も通せない 施錠されたゲートウェイ\n[02:08.54] 開き方も思い出せなくて\n[02:17.46] 見えない線引いて ひとりきりを選んだ\n[02:25.62] 私 まだ胸がはれないのはどうして？\n[02:39.16] 見えた気がした境界線の向こうで笑うあなた\n[02:56.48] ここから先に進まずいれば 傷つくこともないの\n[03:10.76] なにも...\n[03:13.35] It was something nice and sweet, 'til I see the real\n[03:21.93] It's been cruel and dark and sore, has that so?\n[03:30.04] 拒むことでしか 守ること出来なくて\n[03:38.60] すべて手放したつもりでいた\n[03:47.28] 重たいココロごと 強く掴むその手を\n[03:55.84] 離したくないと思ったのはどうして？\n[04:08.29] Do you hear weary heart's S.O.S?\n[04:22.33] 	/audio/Date A Live S4 ED 「S.O.S」.mp3	S.O.S	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251659/covers/Date_A_Live_S4_ED_S.O.S.jpg	4
904	111	904	291	[00:00.00] \r\n[00:19.75]Oh, please don’t let me die\r\n[00:22.07]Waiting for your touch\r\n[00:27.58]No, don’t give up on life\r\n[00:29.84]This endless dead end\r\n[00:37.50]Kurutta tokei kizamu inochi\r\n[00:41.59]Koboreteku kioku no suna\r\n[00:45.69]Mebaeta omoi made\r\n[00:49.50]Nee… konna ni akkenaku\r\n[00:56.09]Kieteshimau no?\r\n[01:01.76]I wish I was there\r\n[01:03.00]Oh, please don’t let me die\r\n[01:04.97]Waiting for your touch\r\n[01:07.10]Nido to nanimo nakusanu you ni\r\n[01:11.54]Watashi o wasurete, hajimete “Restart”\r\n[01:18.38]No, don’t give up on life\r\n[01:20.53]This endless dead end\r\n[01:22.61]Kimi o kudaku kono kanashimi ga\r\n[01:27.23]Itsuka owarimasu you ni\r\n[01:32.80]For now I’ll see you off\r\n[01:37.02]My time is spinning around\r\n[01:40.80]Your deep black eyes\r\n[01:44.84]I forgot what time it is\r\n[01:48.45]And all our memories are gone…?\r\n[01:53.89]Amai kaori hanatsu\r\n[01:57.78]Tsuioku to iu na no wana\r\n[02:01.57]Sasoware toraware\r\n[02:05.40]Naze… aragae mo sezu mata\r\n[02:12.36]Oboreteshimau no\r\n[02:17.93]I wish you were here\r\n[02:19.08]Oh, never close your eyes\r\n[02:21.06]Searching for a true fate\r\n[02:23.04]Dokoka kieta ano nukumori mo\r\n[02:27.76]Oikaketsudzukete miushinau “Restart”\r\n[02:34.61]So, let us try again\r\n[02:36.87]From the very first time\r\n[02:38.72]“kitto kitto” sou yatte, ima mo\r\n[02:43.57]Munashii wa o egaiteru\r\n[02:48.69]For now, see you again\r\n[02:52.66]…fading in, fading out…\r\n[03:20.23]I wish we were there\r\n[03:21.48]Ano hibi niwa modorenai\r\n[03:25.67]Toki wa tsuyoku kanashiku tsuyoku\r\n[03:30.18]Tada tada susundeyuku dake “Restart”\r\n[03:36.98]No, don’t give up on life\r\n[03:39.24]This endless dead end\r\n[03:41.08]Furikaeranai sonna tsuyosa o\r\n[03:45.63]Daremo mina enjiteru\r\n[03:51.01]For now I’ll see you off\r\n[03:56.62]And we’ll die\r\n[03:58.32]Waiting for a new day\r\n[04:00.30]Nido to…\r\n[04:04.36]And we’ll start\r\n[04:06.25]Waiting for a new day\r\n[04:08.21]Kimi to…\r\n[04:09.94]Oh, please don’t let me die\r\n[04:16.90]Kienaide ah…\r\n	/audio/Re_Zero ED 「STYX HELIX」.mp3	STYX HELIX	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253805/covers/ReZero_ED_STYX_HELIX.jpg	1
911	111	904	233	[00:00.00] \n[00:10.05]Now let me open the scar\n[00:12.47]Tokeatta Virus niji ni kuro o sashi tobitatsu\n[00:24.19] \n[00:30.32]Akai hana no mitsu nurete kakureta noizu\n[00:39.43]Mune ni haiyoru no “umarekawaritai no deshou?”\n[00:48.20]Eien nemutteita paradaimu\n[00:52.99]Shin o kutte shinshoku shiteita\n[01:00.22]Now let me open the scar\n[01:02.56]Tokeatta Virus furete arawa ni naru honnou\n[01:09.78]Grew up in the loneliness\n[01:12.25]Kowareta Reality niji ni kuro o sashi tobitatsu\n[01:24.14]Ima sugu nukedashite shouki no meiro\n[01:27.01]Hanten shita kontorasuto e\n[01:31.21]Aoi garasu ni utsutta watashi wa\n[01:40.22]Zankoku na bishou de nodo o furuwaseru no\n[01:50.67]I’m changing to a monster\n[01:52.67]Uragiriai mo fukaku ochiteyuku purosesu\n[01:59.97]Is this my insanity?\n[02:02.30]Sono toi sae ga moumoku to yokubou no akashi\n[02:14.27]Sonomama tobidashite shitta sekai wa\n[02:17.14]Paradokusu no rakuen no you\n[02:20.43] \n[02:29.40]“Live it up! Live it up! Live it up!”\n[02:37.22]Me o samashita\n[02:38.76]“Live it up! Live it up! Live it up!”\n[02:44.09]Kanjou no fureru mama ni\n[02:48.33]Now let me open the scar\n[02:51.30]Tokeatta Virus umarekawatta honnou de\n[02:58.47]Grew up in the loneliness\n[03:00.83]Mitsuketa Reality kegare o shittemo motto…\n[03:10.77]Modore wa shinai hyouhaku sareteita Paradise\n[03:17.53]Yes, this is my sanity jiyuu o daite\n[03:22.85]Niji ni kuro o sashi tobitatsu\n[03:31.95]Ima sugu nukedashite shouki no meiro\n[03:34.67]Hanten shita kontorasuto e\n[03:37.23]Tobidashite shitta sekai wa\n[03:39.48]Paradokusu no rakuen no you\n[03:41.95]Te o nobasu kinki no uzu\n[03:44.30]Kuro o sashite niji o abake\n[03:47.45] \n	/audio/Re_ZERO OP2 「Paradisus Paradoxum」.mp3	Paradisus Paradoxum	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253709/covers/ReZERO_OP2_Paradisus_Paradoxum.jpg	1
3	3	2	199	[00:00.00] \n[00:04.92]People try to put us d-down \n[00:08.00](Talkin' 'bout my generation)\n[00:10.13]Just because we get around \n[00:12.58](Talkin' 'bout my generation)\n[00:15.07]Things they do look awful c-c-cold\n[00:17.91] (Talkin' 'bout my generation)\n[00:19.67]I hope I die before I get old\n[00:22.59] (Talkin' 'bout my generation)\n[00:23.89]This is my generation\n[00:26.17]This is my generation, baby\n[00:29.88]Why don't you all f-fade away \n[00:33.15](Talkin' 'bout my generation)\n[00:34.43]And don't try dig what we all s-s-say\n[00:37.62] (Talkin' 'bout my generation)\n[00:39.39]I'm not trying to cause a big s-s-sensation\n[00:42.93] (Talkin' 'bout my generation)\n[00:44.44]I'm just talkin' 'bout my g-g-generation\n[00:47.76] (Talkin' 'bout my generation)\n[00:49.06]My generation\n[00:50.98]This is my generation, baby\n[00:54.58] \n[01:19.43]Why don't you all f-fade away\n[01:22.71] (Talkin' 'bout my generation)\n[01:23.87]And don't try d-dig what we all s-s-say\n[01:26.84] (Talkin' 'bout my generation)\n[01:29.11]I'm not trying to cause a big sensation\n[01:31.94] (Talkin' 'bout my generation)\n[01:33.59]I'm just talkin' 'bout my g-generation\n[01:36.60] (Talkin' 'bout my generation)\n[01:37.79]This is my generation\n[01:40.22]This is my generation, baby\n[01:43.95]My, my g-generation\n[01:47.28]My, my, my, my, my generation\n[01:53.40]People try to put us d-down\n[01:56.47] (Talkin' 'bout my generation)\n[01:58.66]Just because we g-g-get around\n[02:01.37] (Talkin' 'bout my generation)\n[02:03.49]Things they do look awful c-c-cold\n[02:06.43] (Talkin' 'bout my generation)\n[02:07.98]Yeah, I hope I die before I get old \n[02:10.89](Talkin' 'bout my generation)\n[02:12.38]This is my generation\n[02:14.71]This is my generation, baby\n[02:17.69]My, my, my, my, my generation \n[02:22.58] \n[02:39.69]Talkin' 'bout my generation \n[02:41.15]Talkin' 'bout my generation\n[02:43.55]Talkin' 'bout my generation \n[02:46.10]Talkin' 'bout my generation\n[02:48.85]Talkin' 'bout my generation\n[02:51.19]Talkin' 'bout my generation \n[02:53.98]Talkin' 'bout my generation\n[02:56.56]This is my Generation baby\n[02:57.15]Talkin' 'bout my generation\n[03:00.92]This is my Generation...\n(Talking about my Generation...)\n[03:08.73] This is my generation\n	/audio/A Silent Voice OP Theme 「My Generation」.mp3	My Generation	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253751/covers/A_Silent_Voice_OP_Theme_My_Generation.jpg	1
4	4	4	293	[00:00.00] \n[00:01.05]Ame ga futta hana ga chitta\n[00:03.99]Tada somatta hoho wo omotta\n[00:06.93]Boku wa zutto baketsu ippai no gekkou wo nonderu\n[00:13.01]Hontou nan da yoru mitai de\n[00:15.93]Usuku toumei na kuchizawari de\n[00:18.71]Sou nan datte\n[00:20.74]Warattemo ii kedo\n[00:24.39]Boku wa kimi wo matteiru\n[00:28.65] \n[00:51.94]Natsu ga satta machi wa shizuka\n[00:55.00]Boku wa yatto heya ni modotte\n[00:57.92]Yoru ni natta konna yoi tsuki wo hitori de miteiru\n[01:03.90]Hontou nan da mukashi no boku wa\n[01:06.85]Namida ga houseki de dekitetan da\n[01:09.84]Sou nan datte warattemo ii kedo\n[01:15.99]Koe wa mou tokuni wasureta\n[01:19.03]Omoide mo ai mo shinda\n[01:21.92]Kaze no nai umibe wo aruita ano natsu e\n[01:31.00] \n[01:32.15]Boku wa sayonara ga hoshiin da\n[01:38.54]Tada madoromu you na\n[01:44.05]Mono hitotsu sae iwanai mama\n[01:50.28]Boku wa kimi wo matteiru\n[01:55.23] \n[02:05.64]Toshi wo totta hitotsu totta\n[02:08.47]Nani mo nai heya de haru ni natta\n[02:11.39]Boku wa ai wo soko ga nuketa hishaku de nonderu\n[02:17.35]Hontou nan da aji mo shinakute\n[02:20.46]Nomeba nomu hodo nodo ga kawaite\n[02:23.37]Sou nan datte warattemo ii kedo\n[02:28.15] \n[02:29.09]Boku wa yoru wo matteiru\n[02:33.27] \n[03:02.14]Kimi no hanauta ga hoshiin da\n[03:08.40]Tada madoromu you na\n[03:14.12]Mono hitotsu sae iwanai mama\n[03:20.27]Boku wa kimi wo matteiru\n[03:24.62] \n[03:26.12]Kimi no me wo oboete inai\n[03:32.15]Kimi no kuchi wo egaite inai\n[03:38.04]Mono hitotsu sae iwanai mama\n[03:44.25]Boku wa kimi wo matte inai\n[03:49.71] \n[03:50.16]Kimi no hana wo shitte inai\n[03:55.98]Kimi no hoho wo omotte inai\n[04:02.19]Sayonara sura iwanai mama\n[04:08.21]Kimi wa yoru ni natte yuku\n[04:13.93] \n[04:23.51](Hontou nan da yoru mitai de\n[04:26.31]Natsu ga toumei na kuchizawari de)\n	/audio/A Whisker Away ED 「Usotsuki」.mp3	Usotsuki	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253945/covers/A_Whisker_Away_ED_Usotsuki.jpg	1
5	4	4	240	[00:00.00] \n[00:01.18]Mou wasurete shimatta ka na\n[00:03.64]Natsu no kokage ni suwatta mama\n[00:06.25]Aisu wo kuchi ni hourikonde kaze wo matteita\n[00:11.89]Mou wasurete shimatta ka na yononaka no zenbu usodarake\n[00:16.99]Hontou no kachi wo futari de sagashi ni ikou to waratta koto\n[00:22.02] \n[00:26.50]Wasurenai you ni\n[00:29.09]Iroasenai you ni\n[00:31.66]Katachi ni nokoru mono ga subete ja nai you ni\n[00:39.09]Kotoba o motto oshiete natsu ga kurutte oshiete\n[00:44.58]Boku wa egaiteru me ni utsutta no wa natsu no bourei da\n[00:49.92]Kaze ni sukaato ga yurete omoide nante wasurete\n[00:55.25]Asai kokyuu wo suru\n[00:59.23]Ase wo nugutte natsumeku\n[01:02.62] \n[01:22.55]Mou wasurete shimatta ka na\n[01:24.98]Natsu no kokage ni suwatta koro\n[01:27.62]Touku no oka kara kaodashi ta kumo ga atta janai ka\n[01:33.25]Kimi wa sore wo tsukamou to shite\n[01:35.71]Baka mitai ni kuu o kitta te de\n[01:38.31]Boku wa kami ni kumo hitotsu wo kaite\n[01:41.14]Waratte nigitte misete\n[01:43.57] \n[01:45.22]Wasurenai you ni\n[01:47.75]Iroasenai you ni\n[01:50.28]Rekishi ni nokoru mono ga subete janai kara\n[01:57.99]Ima dake kao mo nakushite\n[02:00.61]Kotoba mo zenbu wasurete\n[02:03.08]Kimi wa waratteru\n[02:04.80]Natsu wo matteiru bokura bourei da\n[02:08.70]Kokoro wo motto oshiete\n[02:11.29]Natsu no nioi wo oshiete\n[02:13.90]Asai kokyuu wo suru\n[02:16.60] \n[02:46.50]Wasurenai you ni\n[02:49.03]Iroasenai you ni\n[02:51.61]Kokoro ni hibiku mono ga subete janai kara\n[02:57.54] \n[03:01.80]Kotoba wo motto oshiete\n[03:04.29]Sayonara datte oshiete\n[03:07.29]Ima mo mirun da yo\n[03:08.77]Natsu ni saiteru hana ni bourei wo\n[03:12.65]Kotoba janakute jikan wo\n[03:15.28]Jikan janakute kokoro wo\n[03:17.89]Asai kokyuu wo suru\n[03:21.94]Ase wo nugutte natsumeku\n[03:25.04] \n[03:28.61]Natsu no nioi ga suru\n[03:39.24]Natsu no nioi ga suru\n[03:45.05] \n[03:47.92]Mou wasurete shimatta ka na\n[03:50.37]Natsu no kokage ni suwatta mama\n[03:52.96]Aisu wo kuchi ni hourikonde kaze wo matteita\n[03:58.93] \n	/audio/A Whisker Away OP Theme 「Ghost In A Flower」.mp3	Ghost In A Flower	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773251584/covers/A_Whisker_Away_OP_Theme_Ghost_In_A_Flower.jpg	1
6	6	6	282		/audio/Accel World ED 「→unfinished→」.mp3	→unfinished→	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254208/covers/s3d2adaoecxgefhqvuhw.jpg	1
7	7	6	227		/audio/Accel World ED2 「Unite」.mp3	Unite	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251546/covers/Accel_World_ED2_Unite.jpg	1
12	12	11	238		/audio/After the Rain OP 「Nostalgic Rainfall」.mp3	Nostalgic Rainfall	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251511/covers/After_the_Rain_OP_Nostalgic_Rainfall.jpg	1
16	16	13	301		/audio/Ah! My Goddess S2 ED2 「Koibito Doshi」.mp3	Koibito Doshi	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251545/covers/Ah_My_Goddess_S2_ED2_Koibito_Doshi.jpg	2
17	14	13	250		/audio/Ah! My Goddess! S2 ED 「Bokura no Kiseki 」.mp3	Bokura no Kiseki 	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254198/covers/Ah_My_Goddess_S2_ED_Bokura_no_Kiseki.jpg	2
23	23	22	262	[ti:Akame ga Kill ED2 「Tsuki Akari」]\n[ar:Sora Amamiya]\n[al:Akame ga Kill]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:21.60]\n[00:00.00] \n[00:11.87]Furikaeru kako wa nai kono te hanashita hi kara\n[00:22.06]Ushinau mono wa nai to kurikaeshi iikikaseteta\n[00:32.20]Seijaku ni tadayou tsuki donna yami mo terashiteyukeru\n[00:42.62]Tsuyoi hikari mirai e kazasu maketaku wa nai kara\n[00:53.36]Owaranai yume ga mune no zawameki ga karada wo megutte\n[01:03.80]Itami sae ima tsuyosa ni naru yo shinjita michi wo yuku\n[01:14.58]Watashi wo tsukiugokasu netsu egaki tsudzukete kita sekai e michibiku\n[00:00.00][source: https://animesonglyrics.com]\n[00:00.00][Full Version Continues:]\n[01:36.30]Yuku te wo habamu no wa tojikometa hazu no yowasa\n[01:46.59]Kokoro ni yadoshita hi ga nando mo kiesou ni natte\n[01:56.96]Iji no you na mono na no kamo\n[02:01.74]Kizuguchi wo kakusu tabi mata\n[02:06.92]Ieru koto nai mune no sukima tsumetai kaze ga fuku\n[02:17.59]Koe ni mo naranai musuu no kotoba wo chiribameta yozora\n[02:28.17]Hikaru hoshikuzu mitai ni hakanaku sakebi tsudzuketeiru\n[02:38.85]Gisei ni shite kita mono kurai wakatteru\n[02:45.80]Mou atomodori wa dekinai\n[02:51.29]Te ga todokisou na no ni watashi, nani wo kowagatteiru no?\n[03:04.40]Owaranai yume ga mune no zawameki ga karada wo megutte\n[03:14.43]Itami sae ima tsuyosa ni naru yo shinjita michi wo yuku\n[03:24.91]Watashi wo tsukiugokasu netsu egaki tsudzukete kita sekai e michibiku\n[03:48.51]Itsumo tsuyoku arou to sou kimeteita no ni\n[03:58.74]Naze da ka hoho wo tsutatte\n[04:02.90]...Kyou dake naite mo ii kana?\n[04:14.79]	/audio/Akame ga Kill ED2 「Tsuki Akari」.mp3	Tsuki Akari	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773254175/covers/Akame_ga_Kill_ED2_Tsuki_Akari.jpg	1
25	25	22	294		/audio/Akame ga Kill OP2 「LIAR MASK」.mp3	LIAR MASK	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773254200/covers/Akame_ga_Kill_OP2_LIAR_MASK.jpg	1
27	27	27	114	[00:00.00] \r\n[00:04.17]Itsumo hitori de aruiteta\r\n[00:11.08]Furikaeru to minna wa tooku\r\n[00:19.02]Sore demo atashi wa aruita\r\n[00:26.20]Sore ga tsuyosa datta\r\n[00:32.68]Mou nani mo kowakunai\r\n[00:40.35]Sou tsubuyaite miseru\r\n[00:48.52] \r\n[00:51.90]Itsuka hito wa hitori ni natte\r\n[00:59.77]Omoide no naka ni ikiteku dake\r\n[01:07.19]Kodoku sae aishi waratterareru yori\r\n[01:14.88]Atashi wa tatakaun'da\r\n[01:22.25]Namida nante misenain'da\r\n	/audio/Angel Beats ED 「Brave」.mp3	Brave	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254140/covers/Angel_Beats_ED_Brave.jpg	1
29	20	27	279	[00:00.00] \r\n[00:20.34]Mezamete wa kurikaesu nemui asa wa\r\n[00:26.72]Eri no tai wo kitsuku shime\r\n[00:33.55]Kyoushitsu no doa kuguru to\r\n[00:36.81]Hon no sukoshi mune wo hatte arukidaseru\r\n[00:46.34]Sonna nichijou ni fukinukeru kaze\r\n[00:53.39]Kikoeta ki ga shita\r\n[00:56.68]Kanjita ki ga shitan da\r\n[01:02.72]Furuedasu ima kono mune de\r\n[01:06.66]Mou kuru ki ga shita\r\n[01:09.86]Ikuoku no hoshi ga kiesatteku no o\r\n[01:18.08]Miokutta te o futta "Yokatta ne" to\r\n[01:29.83]Rouka no sumi miorosu souji no tochuu\r\n[01:36.07]Okashina mono da to omou\r\n[01:43.21]Atashi no naka no toki ha tomatteru noni\r\n[01:49.32]Chigau hibi wo ikiteru you ni\r\n[01:56.03]Hokiri ha yuki no you ni furitsumu\r\n[02:02.74]Matteru ki ga shita\r\n[02:06.18]Younderu ki ga shitan da\r\n[02:12.19]Furudeasu ima kono toki ga\r\n[02:16.32]Mitsuketa ki ga shita\r\n[02:19.49]Ushinawareta kioku ga yobisamashita\r\n[02:27.48]Monogatari eien no sono owari\r\n[02:39.42]Itsumomanika kakedashiteta\r\n[02:45.84]Anata ni te wo hikareteta\r\n[02:52.53]Kinou ha tooku ashita ha sugu\r\n[02:58.39]Sonna atarimae ni kokoro ga odotta\r\n[03:10.75]Kikoega ki ga shita\r\n[03:14.10]Kanjita ki ga shitan da\r\n[03:20.09]Furuedasu ima kono mune de\r\n[03:24.02]Mou kuru ki ga shita\r\n[03:27.26]Ikusen noasa wo koe atarashii hi ga\r\n[03:37.17]Matteru ki ga shita\r\n[03:40.51]Yonderu ki ga shitan da\r\n[03:46.60]Furueteru kono tamashii ga\r\n[03:50.52]Mitsuketa ki ga shita\r\n[03:53.67]Ikuoku no yume no you ni kiesareru hi wo\r\n[04:01.85]Miokutta te wo futta arigatou\r\n[04:12.55] \r\n	/audio/Angel Beats OP 「My Soul, Your Beats!」.mp3	My Soul, Your Beats!	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253865/covers/Angel_Beats_OP_My_Soul_Your_Beats.jpg	1
31	31	30	290	[00:00.00] \n[00:07.97]Wasurenagusa ga saku koro ni\n[00:11.44]Hanabira no iro omoidasu\n[00:15.55]Shizuka na me wo shita ano koto\n[00:19.33]Takaku sora ni nobotte iku yume\n[00:24.83] \n[00:39.22]Hikouki gumo wo hinata ni egaku rokettoboizu to\n[00:45.74]Nagamete warau toppyoshi no nai jiai wo mune ni daku garuzu\n[00:55.24]Toki wa guruguru sonna bokura mo minna inaku natte\n[01:01.36]Ozanari ni naru kurai memagurushii hibi ni setsunaku naru\n[01:10.11]Itsuka mata koko de ne\n[01:14.08]Sayonara no koe ga itsu made mo hibiite\n[01:20.04]Senaka wo osu koto mo naku bokura wo tsunaida\n[01:26.29]Aimai na koto mo tanjun na koto mo\n[01:30.64]Minna irodzuite iku\n[01:33.59]Kotoba ni naranai\n[01:35.72]Kono kusubutta kimochi dakishimete itai yo\n[01:41.91]Aimai na koto mo tanjun na koto mo\n[01:46.17]Minna onaji datte\n[01:49.22]Bokura no uta\n[01:51.28]Kono mune no mannaka de hana wo sakasete iru\n[01:59.34] \n[02:13.17]Kakedashita hitori no gogo\n[02:16.47]Da are mo inai machi wo kuguri\n[02:20.29]Mawaru asobi kara ichi nukete\n[02:24.20]Kimi no koto wo omoide ni shite shimau\n[02:29.93] \n[02:44.07]Circle game wo tsuzukete\n[02:47.66]Boku wa inotte kimi wa utau\n[02:51.47]Kienai maboroshi wo kanaeyou\n[02:55.43]Dakara inotte boku wa utau\n[02:59.51]Circle game wo tsuzuke you\n[03:03.55]Bokura wa hanete omomi wo shiru\n[03:07.20]Kawaru yorokobi ya kanashimi wo\n[03:11.28]Koko de inotte uta ni shite mi tari suru\n[03:15.26]Yatto mata aeta ne\n[03:19.07]Natsukashii kimi no koe ga suru\n[03:22.90]Kizukeba bokura wa chuu ni ukabi agatte\n[03:28.87]Toki ni oiyarare\n[03:31.08]Aimai na koto mo tanjun na koto mo\n[03:35.59]Minna hanabira no you\n[03:38.50]Tada yoi nagara\n[03:40.62]Sora wo mawatte iru dake furikaeranai de\n[03:46.91]Kaze ni hakobareta wasurenagusa ga\n[03:51.08]Minna oikoshite iku\n[03:54.02]Bokura no uta\n[03:56.02]Zutto saki ni ano iro no hana wo sakasete iru\n	/audio/Anohana movie ED Theme 「Circle Game」.mp3	Circle Game	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253650/covers/Anohana_movie_ED_Theme_Circle_Game.jpg	1
33	31	30	366	[00:00.00] \n[00:22.15]Nanpeeji mo tsuiyashite tsuzurareta bokura no kibun\n[00:29.37]Doushite ka ichigyou no kuuhaku wo umerarenai\n[00:36.37]Oshibana no shiori hasande kimi to korogasu tsukaisute no jitensha\n[00:44.71]Wasurekake no renga wo tsumiagete wa kuzushita\n[00:52.62]Ikooru e to hikizurarete iku kowai kurai ni aoi sora wo\n[01:01.80]Asobitsukareta bokura wa kitto omoidasu koto mo nai\n[01:09.42]Sou yatte ima wa boku no hou e oshitsukeru hizashi no taba\n[01:16.37]Mada futari wa sugu soko ni iru no ni "douka mata aemasu you ni" nante\n[01:31.15]Douka shiteru mitai\n[01:39.51] \n[01:45.79]Ichipeeji mekuru tenohira kuchibiru de musunda misanga\n[02:00.21]Nee kyou mo kawaranai kyou de ame fureba denwa mo dekiru yo\n[02:14.79]Sou yatte ima wa kimi no hou e (itsu no ma ni ka kireta misanga)\n[02:22.02]Oshitsukeru boku no yasashisa wo (demo nazeka ienai mama da yo)\n[02:28.28]Hontou douka shiteru mitai\n[02:37.77] \n[02:43.97]Doreka hitotsu wo erabeba oto wo tatete kowareru\n[02:51.07]Sore ga ai da nante odokete kimi wa waratteta\n[02:59.10]Ma ni atte yokatta machi wa shiranai furi wo kimete nemutta\n[03:06.60]Wasurekake no renga wo tsumiageta basho ni yukou\n[03:14.53]Umi wo miwatasu saka wo kakenobotte kowai kurai ni aoi sora to\n[03:23.61]Migite ni saidaa hidarite wa zutto kimi wo sagashiteru\n[03:31.52] \n[03:32.10]Sou yatte fusaida ryou no te de dakishimete iru haru no kaze\n[03:39.01]Mada jikan wa bokura no mono de "itsuka, wasurete shimau kyou da ne" nante\n[03:53.64]Iwanai de hoshii yo\n[04:01.05]Sou yatte "ima" wa boku no hou e toitsumeru koto mo nakute\n[04:08.16]Mada futari wa sugu soko ni iru darou "sou da, kuuhaku wo umeru kotoba wa"\n[04:22.84]Iya, mada iwanai de okou\n[04:31.20] \n[04:44.73]Ichipeeji makuru tenohira kuchibiru de hodoita misanga\n[04:59.02]Shihatsu densha mabara na shiawase nee, kyou mo kawaranai kyou da\n[05:10.80] \n[05:19.84]Hontou douka shiteru mitai\n[05:29.53]	/audio/Anohana OP 「Aoi Shiori」.mp3	Aoi Shiori	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253645/covers/Anohana_OP_Aoi_Shiori.jpg	1
34	34	34	331	[00:00.00] \r\n[00:37.17]Iroaseteiku FIRUMU no you ni\r\n[00:54.87]Tashika na ima mo izure kasunde\r\n[01:09.93]Nande mo naku waraiatta\r\n[01:18.59]Setsuna no jikan to hikari\r\n[01:28.03] \r\n[01:28.95]Tsunagatte yuku kioku no soko ni\r\n[01:37.46]Dareka ga mitsukeru tame aru to\r\n[01:47.42]Shinjiteiru imademo\r\n[01:55.41] \r\n[02:32.52]"Naze kokoro wa naze itamu no"\r\n[02:50.34]Mune no katasumi fuan kakaete\r\n[03:05.33]Ikiru koto wo osore nagara\r\n[03:13.93]Muimi ni toikake tsuzuketa\r\n[03:24.39]Ushinatte yuku kioku no naka de\r\n[03:33.20]Dareka ni sukui wo motometeiru\r\n[03:42.97]Kimi no koe\r\n[03:46.41]Boku wa tsukamu\r\n[03:52.12]Chiisakute mo kikoenakute mo\r\n[04:00.92]Kimi no tame sukui ageru kara\r\n[04:13.15] \r\n[04:23.67]Meguriai mata toozakaru hibi\r\n[04:32.66]Ima mo azayaka na hikari tomosu\r\n[04:42.11]Nani mo kamo nakushita yoru mo\r\n[04:50.16]Bokura dake ga shiru ano basho e\r\n[05:00.21]Itsudatte kaerou\r\n[05:09.53] \r\n	/audio/Another ED 「Anamnesis」.mp3	Anamnesis	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253953/covers/Another_ED_Anamnesis.jpg	1
37	12	36	312	[00:00.00] \n[00:00.54]Sekai wa koi ni ochiteiru\n[00:04.37]Hikari no ya mune wo sasu\n[00:07.94]Kimi wo wakaritainda yo\n[00:11.19]"Nee, oshiete"\n[00:15.56] \n[00:30.13]Surechigau kotoba ni\n[00:32.10]Chotto dake no koukai namida koborete\n[00:37.52]Isogashii kanjou kodou ni RINKU suru\n[00:42.96]CHUUNINGU tashikametainda\n[00:50.11] \n[00:52.30]Mokuteki bakka ni torawarete\n[00:55.90]Daiji na mono ga kasunde nigete\n[00:59.65]Kyou mo RISUTAATO\n[01:05.81] \n[01:07.10]Sekai wa koi ni ochiteiru\n[01:10.81]Hikari no ya mune wo sasu\n[01:14.36]Zenbu wakaritainda yo\n[01:17.58]"Nee, kikasete"\n[01:21.84]Tatta ichi-miri ga tookute\n[01:25.42]Kakenuketa hibi ni\n[01:29.30]Wasurenai wasurerarenai kagayaku ichi PEEJI\n[01:35.90] \n[01:51.31]O-niai no futari ni\n[01:53.39]Nandaka fukuzatsu na kimochi ga iru yo\n[01:58.77]Hajimete no kanjou\n[02:00.72]Kodou ni RINKU suru\n[02:04.38]Taionkei kowarechatta kana?\n[02:11.51] \n[02:13.46]Jibun no koto wakaranai mama\n[02:17.17]Ano ko ni ADOBAISU made shichatte\n[02:20.90]Mune ga itai ya\n[02:26.10] \n[02:26.33]Sekai wa koi ni ochiteiru\n[02:30.15]Hikari no ya mune wo sasu\n[02:33.82]Kizuita kono omoi wa\n[02:37.12]"Mou, osoi no"\n[02:41.23]Ano ko no hou ga kawaii no shitteru yo dakedo\n[02:48.45]"Umaku ikanai de" nante ne\n[02:52.27]Nigedashita kuse ni\n[02:54.95] \n[02:55.68]Baka\n[02:56.87] \n[03:08.92]Haru ni saita hana ga koi wo shita\n[03:16.03]Hana wa hisshi ni ue wo muite waratta\n[03:23.48]Aoi natsu no tsubomi mo koi wo shita\n[03:30.72]Sakanai hana to kayaku no nioi\n[03:37.28] \n[03:53.20]Honto no kimochi kotoba ni shite\n[03:56.90]Daiji na koto hanasetara\n[04:00.57]Kyou mo RISUTAATO\n[04:06.43] \n[04:07.99]Donkan na kimi dakara\n[04:11.52]Kuchi ni dashite iwanakya\n[04:15.28]Ima kimi ni tsutaeru yo\n[04:18.62]"Nee, suki desu"\n[04:22.63]Sekai wa koi ni ochiteiru\n[04:26.61]Hikari no ya mune wo sasu\n[04:30.09]Zenbu wakaritainda yo\n[04:33.35]"Nee, kikasete"\n[04:37.38]Taguri yosete mou zero-senchi\n[04:41.00]Kakenuketa hibi ni\n[04:44.86]Wasurenai wasurerarenai\n[04:48.71]Kagayaku ichi PEEJI\n[04:51.53] \n	/audio/Ao Haru Ride OP 「Sekai wa Koi ni Ochiteiru」.mp3	Sekai wa Koi ni Ochiteiru	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251540/covers/Ao_Haru_Ride_OP_Sekai_wa_Koi_ni_Ochiteiru.jpg	1
39	39	39	268		/audio/Ao-chan Can_t Study ED 「Koi wa Miracle」.mp3	Koi wa Miracle	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251520/covers/Ao-chan_Can_t_Study_ED_Koi_wa_Miracle.jpg	1
41	41	41	190	[ti:Arakawa Under the Bridge OP 「Venus to Jesus」]\n[ar:Etsuko Yakushimaru]\n[al:Arakawa Under the Bridge]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:10.05]\n[00:00.00] \n[00:04.30]mezame no kissu wa madoromu anata ni\n[00:07.24]ayakashi rippu na ohimesama\n[00:10.27]deai no kippu wa yume miru anata ni\n[00:13.44]mayakashi VIP na ea foosu\n[00:16.37]jikan ga nai no ima nanji?\n[00:19.53]jugyou kaishi no gofunmae\n[00:22.61]isoidenai no ima daiji\n[00:25.67]anata ni deau gofunmae\n[00:30.35]Viinasu otonarisan na no\n[00:33.70]dou shite? shiranai aida ni\n[00:36.52]Jiizasu omukaisan na no\n[00:39.58]kiite yabai no\n[00:42.63]daitan aitsu no kougeki\n[00:44.27]baibai kizuitenai furi\n[00:45.71]daitan aitsu no shougeki\n[00:47.20]masa ni ikijigoku\n[01:01.29]neoki no kikku wa aisatsugawari ni\n[01:04.15]namaashi ittsumo kizudarake\n[01:07.16]temochi no chippu wo anoko ni kaketara\n[01:10.26]mabataki mittsu de nokku daun\n[01:13.34]kirai ja nai no iya na dake\n[01:16.36]yosoku dekinai kono kimochi\n[01:19.52]kitai shinaide hima na dake\n[01:22.53]anata to kieru gofunkan\n[01:27.26]Viinasu anoko wa itsu demo ronrinesu\n[01:31.69]me wo hanasanaide\n[01:33.42]Jiizasu omukaisan nara\n[01:36.48]kiite onegai\n[02:04.20]jikan ga nai no ima nanji?\n[02:07.14]gekou jikoku no gofunmae\n[02:10.12]isoidenai no ima daiji\n[02:13.23]tokimeki ni kizuku gofunmae\n[02:19.55]Viinasu otonarisan na no\n[02:22.70]dou shite? shiranai aida ni\n[02:25.72]Jiizasu omukaisan na no\n[02:28.81]kiite yabai no\n[02:31.82]Viinasu anoko wa itsu demo sou na no?\n[02:36.68]ima nara maniau\n[02:38.38]Jiizasu hikikaesenai no\n[02:41.47]hayaku kizuite\n[02:44.46]daitan aitsu no kougeki\n[02:45.92]baibai kizuitenai furi\n[02:47.43]daitan aitsu no shougeki\n[02:49.01]masa ni ikijigoku\n[02:50.55]mezame no kissu wa madoromu anata ni\n[02:53.96]ayakashi rippu na ohimesama\n[02:57.11]deai no kippu wa yume miru anata ni\n[03:00.27]yoakashi kon'ya wa furaidee naito\n[03:04.54]	/audio/Arakawa Under the Bridge OP 「Venus to Jesus」.mp3	Venus to Jesus	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253747/covers/Arakawa_Under_the_Bridge_OP_Venus_to_Jesus.jpg	1
43	43	41	220		/audio/Arakawa under the Bridge x Bridge ED 「Akai Coat.mp3	Akai Coat	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253703/covers/Arakawa_under_the_Bridge_x_Bridge_ED_Akai_Coat.jpg	1
44	44	41	222		/audio/Arakawa Under the Bridge x Bridge OP 「COSMOS vs.mp3	COSMOS vs ALIEN	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254165/covers/Arakawa_Under_the_Bridge_x_Bridge_OP_COSMOS_vs_ALIEN.jpg	1
50	50	50	265		/audio/Asobi Asobase ED 「Inkya Impulse」.mp3	Inkya Impulse	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252133/covers/Asobi_Asobase_ED_Inkya_Impulse.jpg	1
53	53	52	90	[00:00.00] \r\n[00:12.13]Taiyou ga sasu tozashita mabuta no\r\n[00:19.38]Uragawa ni akai zanzou\r\n[00:25.29]Kawa no kaban ni Note to Pen wo\r\n[00:31.25]Saa arukidasou\r\n[00:34.15] \r\n[00:36.12]Kaite mo kaite mo kirei ni naranai\r\n[00:42.07]Eranda enogu ni tsumi wa nai\r\n[00:48.16]Kinou no yonaka ni mita nagareboshi\r\n[00:54.65]Mada oboeteiru\r\n[00:58.41]I was waiting for...\r\n[01:01.84] \r\n[01:02.84]Hello, shooting-star\r\n[01:04.52]Hello, shooting-star again\r\n[01:07.43]Matteita yo\r\n[01:09.00]Yume wo miru ano ko wa zutto\r\n[01:13.44]Koko ni iru no, ah ah\r\n[01:19.61]Ano hi no mama, ah ah\r\n[01:25.37]Mata hikatte	/audio/Assassination Classroom ED「Hello, Shooting Star.mp3	Hello, Shooting Star	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253675/covers/Assassination_Classroom_ED_Hello_Shooting_Star.jpg	1
55	55	52	264	[00:00.00] \n[00:22.58]Kimi no koto bakari omotteru\n[00:25.22]Hoka no koto mienakunatteru\n[00:27.82]Kanarazu sono haato itomeru (chikau)\n[00:33.37]Iketenai nowa furui hanashi\n[00:36.02]Oshimanu doryoku mo shitanda shi\n[00:38.64]Muchaburi mo kuria shitekita\n[00:41.16]Hazu (ikeru) jishin (michiru)\n[00:46.31]Choushidzuita sono toki\n[00:49.37]Itsudatte kou yatte tsukiotosareteshimau nosa\n[00:54.50]Shinratsu de shiriasu na kimi no koe ga sasattekuru\n[00:59.84]Nanzenkai nanmankai boku no kimochi katachi ni shite\n[01:05.28]Uchikonde nagekonde dakedo kimi wa nigeteku dake\n[01:10.84]QUESTION QUESTION boku wa\n[01:13.51]QUESTION QUESTION ittai\n[01:16.30]QUESTION QUESTION kimi no\n[01:18.75]Nani o shitteita no?\n[01:21.56]QUESTION QUESTION doushite\n[01:24.29]QUESTION QUESTION kimi wa\n[01:26.92]QUESTION QUESTION konna ni\n[01:29.57]Chikakute tooi no darou?\n[01:35.59] \n[01:43.20]Kimi dake ni mitomeraretetai\n[01:45.84]Kimi dake no tokubetsu de itai\n[01:48.33]Kakkoii toko migaite zenryoku (apiiru)\n[01:53.78]Saikin fuetekita raibaru\n[01:56.54]Fuiuchi neratteru sunaipaa\n[01:59.27]Dareka ni yarareteshimaisou\n[02:01.82]Mata (mousou) fuan (bousou)\n[02:06.92]Ochikondeta sono toki\n[02:09.80]Naze nanda!? sou nanda kimi wa boku no te o nigiri\n[02:15.14]Yasashii fuu “daijoubu?” nante hohoendekuretari sa\n[02:20.71]Nanzenkai nanmankai kokoro oresou ni nattemo\n[02:25.93]Sono shunkan sono jikkan dake ga boku ni mirai miseru\n[02:31.45]QUESTION QUESTION moshika\n[02:34.08]QUESTION QUESTION kimi mo\n[02:36.79]QUESTION QUESTION boku o\n[02:39.56]Mitsumetekureteru no?\n[02:42.19]QUESTION QUESTION nanimo\n[02:44.84]QUESTION QUESTION iwazu\n[02:47.51]QUESTION QUESTION kimi wa\n[02:50.24]Unazuita you ni mieta\n[02:56.07] \n[03:14.35]Oshiete\n[03:16.36]Itsudatte kou yatte tsukiotosareteshimau nosa\n[03:21.61]Shinratsu de shiriasu na kimi no koe ga sasattekuru\n[03:27.04]Nanzenkai nanmankai boku no kimochi katachi ni shite\n[03:32.31]Uchikonde nagekonde dakedo kimi wa nigeteku dake\n[03:37.91]QUESTION QUESTION boku wa\n[03:40.60]QUESTION QUESTION ittai\n[03:43.88]QUESTION QUESTION kimi no\n[03:45.90]Nani o shitteita no?\n[03:48.54]QUESTION QUESTION doushite\n[03:51.32]QUESTION QUESTION kimi wa\n[03:54.01]QUESTION QUESTION konna ni\n[03:56.64]Chikakute tooi no darou?\n[04:02.78] \n	/audio/Assassination Classroom OP3 「QUESTION」.mp3	QUESTION	OP3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253803/covers/Assassination_Classroom_OP3_QUESTION.jpg	1
56	52	52	270	[00:00.00] \r\n[00:16.67]Komorebi ga yasashiku sashikomu ooki na mado no naka\r\n[00:28.69]Kimi to deatta ano hi wo tooku ni kanjita\r\n[00:39.06] \r\n[00:40.69]Sukoshizutsu narabeta omoide wa boku wo atatameru\r\n[00:51.67]Chiisana heya tsunagu kokoro sotto oshiete kureta\r\n[01:03.34]Kono kisetsu ga mukae ni kitara kimi no sugata mou sagasu koto mo\r\n[01:15.84]Dekinaku nacchaunda ne\r\n[01:21.30]Zutto wasurezu ni iru yo\r\n[01:26.82]Mata kimi ni aeru hi made...\r\n[01:32.74] \r\n[01:37.70]Sakura-iro hirogaru minareta keshiki kawasu kotoba\r\n[01:49.76]Ashita kara "Nichijou" to wa kawatte yuku\r\n[01:59.66] \r\n[02:01.87]Itsudatte jibun yori dareka wo taisetsu ni shiteta\r\n[02:12.59]Sonna kimi no senaka wo mite bokura wa aruite kita\r\n[02:24.21]Kono kisetsu ga mukae ni kitara kimi wo omoidashite kureru kana\r\n[02:36.86]Sugoshita jikan ga iroasete mo\r\n[02:44.19]Wasurezu ni iru yo\r\n[02:48.13]Mata kimi ni aeru you ni...\r\n[02:55.13] \r\n[02:56.43]Donna koto ni mo (Kimi wa) Imi ga aru kara (Sou itte)\r\n[03:08.37]Hitotsuzutsu hiroiatsume katachi ni shite kureta ne\r\n[03:22.60]Kono kisetsu ga mukae ni kitara kimi no sugata mou sagasu koto mo\r\n[03:35.34]Dekinaku nacchaunda ne\r\n[03:40.78]Zutto kono mama...\r\n[03:46.80] \r\n[03:46.80]Kono kisetsu ga mukae ni kitara kimi no sugata mou sagasu koto mo\r\n[03:59.24]Dekinaku nacchaunda ne\r\n[04:04.81]Dakedo bokura wa warau yo\r\n[04:10.36]Mata kimi ni aitai kara...\r\n[04:16.59]	/audio/Assassination Classroom 「Mata Kimi Ni Aeru Hi」.mp3	Mata Kimi Ni Aeru Hi	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773254050/covers/Assassination_Classroom_Mata_Kimi_Ni_Aeru_Hi.jpg	1
58	58	57	260		/audio/Astra Lost in Space OP 「Star_frost」.mp3	Star*frost	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252136/covers/Astra_Lost_in_Space_OP_Starfrost.jpg	1
71	71	71	322		/audio/Barakamon ED 「Innocence」.mp3	Innocence	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252141/covers/Barakamon_ED_Innocence.jpg	1
72	72	71	279		/audio/Barakamon OP 「Rashisa」.mp3	Rashisa	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253782/covers/Barakamon_OP_Rashisa.jpg	1
75	75	75	269		/audio/Ben-To OP 「LIVE for LIFE」.mp3	LIVE for LIFE	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251602/covers/Ben-To_OP_LIVE_for_LIFE.jpg	1
77	77	77	287		/audio/Big Fish _ Begonia ED 「Jiao Xi Ru Feng」.mp3	Jiao Xi Ru Feng	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251591/covers/Big_Fish_Begonia_ED_Jiao_Xi_Ru_Feng.jpg	1
84	57	83	248		/audio/Bloom Into You OP 「Kimi ni Furete」.mp3	Kimi ni Furete	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252189/covers/Bloom_Into_You_OP_Kimi_ni_Furete.jpg	1
87	87	26	256		/audio/Amagi Brilliant Park OP 「Extra Magic Hour」.mp3	Extra Magic Hour	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252202/covers/Amagi_Brilliant_Park_OP_Extra_Magic_Hour.jpg	1
88	43	41	221	[ti:Arakawa under the Bridge ED 「Sakasama Bridge」]\n[ar:Suneohair]\n[al:Arakawa Under the Bridge]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:41.18]\n[00:00.00] \n[00:01.19]sakasama ni natte\n[00:03.82]kimi no koto sagashite\n[00:06.72]itsu made mo bokura wa\n[00:09.76]tadoritsukenai mama\n[00:24.84]ano hi yuugure\n[00:30.60]fui ni waraigoe\n[00:36.81]kumo no sukima nagareboshi ni\n[00:42.67]kasanegasane aitaku naru\n[01:00.97]itsuka yuugure\n[01:06.75]kimi to mitsumeta yoru\n[01:12.77]ai no kakera sagasu tabi ni\n[01:18.75]itsumo nazeka sabishiku naru\n[01:26.97]mou ikanakucha\n[01:31.21]kono sora nakidasu mae ni\n[01:37.09]sakasama ni natte\n[01:39.90]kimi no koto sagashite\n[01:42.93]itsu made mo bokura wa\n[01:45.64]tadoritsukenai mama\n[01:49.00]hashi no shita ni tatte\n[01:51.76]nagareru uzu ni atte\n[01:54.64]itsu made mo bokura wa\n[01:57.56]sono kotae sagashite\n[02:01.16]barabara ni natte\n[02:03.70]sono koe wo sagashite\n[02:06.66]itsu no hi ka bokura wa\n[02:09.63]otagai wo motometeku\n[02:12.60]sarasara ni natte\n[02:15.89]nagareteku mainichi ni\n[02:18.91]itsu no hi ka bokura ga\n[02:21.79]tadoritadoritsuku basho\n[02:24.58]tayorinaku natte tsukamenakute\n[02:30.66]fuan ni natte nemurenakute\n[02:36.55]oogoe wo dashita hanarenaide\n[02:42.53]hanarenai tte zutto soba ni ite ne\n[02:51.92]hanarenaide\n[02:54.59]hanarenaide\n[02:57.52]hanarenaide\n[03:04.51]	/audio/Arakawa under the Bridge ED 「Sakasama Bridge」.mp3	Sakasama Bridge	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253982/covers/Arakawa_under_the_Bridge_ED_Sakasama_Bridge.jpg	1
95	95	95	247	[ti:Couple of Cuckoos ED2 「HELLO HELLO HELLO」]\n[ar:Eir Aoi]\n[al:Couple of Cuckoos]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:23.4.20]\n[length:04:06.87]\n[00:00.00]\n[00:05.54]Nanige naku futo mieru sono yasashisa wa\n[00:09.93]Uso ka honto ka kangaeru hima mo nai na\n[00:14.73]Douse nara isso itsumo no ano basho de\n[00:18.64]Kimi wo mi tsuzukeru yo\n[00:23.13]Sunao ni narenai\n[00:25.20]Honne mo ienai\n[00:27.40]Fukiyou na doukeshi da\n[00:31.78]Sonna nichijou kara\n[00:35.99]Zutto me wo hanasenai\n[00:40.61]Itsumo kenka shiteru keredo\n[00:44.78]Tsutaetai kotoba\n[00:49.16]Ichiban ni todokeru yo\n[00:53.42]Hello Hello Hello\n[00:57.78]Shikamettsura niau kimi ni\n[01:02.13]Kawaranu kotoba de\n[01:05.86]Kono kimochi tada tsutaetai\n[01:10.54]Hello Hello Hello\n[01:32.37]Niteru tokoro nante zenzen nai futari dakedo\n[01:36.50]Futoshita toki ni onaji ugoki shite ita\n[01:40.95]Massugu ni mitsumeru koto nante dekinai\n[01:45.04]Kimi wo mite itai no ni naa\n[01:49.18]Nani wo omotte\n[01:51.47]Nani wo kanjite\n[01:53.64]Sonna fuu ni itteru no?\n[01:57.83]Chikaku ni iru no ni\n[02:02.42]Wakaranai kotodarake\n[02:06.63]Kyou mo kenka shichatta keredo\n[02:10.89]Nakanaori no mahou\n[02:15.62]Kimi made todokeru yo\n[02:19.74]Hello Hello Hello\n[02:24.02]Douka misuka sanaide ne\n[02:28.53]Hontou no kokoro wo\n[02:32.39]Sono kawari mata tsutaeru yo\n[02:37.21]Hello Hello Hello\n[02:49.72]Me wo mite hanaseta toki mo\n[02:52.47]Nakanaka aenai toki mo\n[02:54.56]Subete kagayaite mieru yo\n[02:59.03]Mata wakariaenakute mo\n[03:06.59]Kimi no tonari ga ii\n[03:13.07]Waraeru hodo kantan de\n[03:17.16]Muzukashii kotoba\n[03:21.51]Ichiban ni todokeru yo\n[03:25.63]Hello Hello Hello\n[03:29.95]Amanojaku datte iu kimi ni\n[03:34.51]Kawaranu egao de\n[03:38.33]Itsumademo tada tsutaetai\n[03:43.12]Hello Hello Hello\n[03:47.57]Nanige naku futo mieru sono yasashisa wa\n[03:51.27]Uso ka honto ka kangaeru hima mo nai na\n[03:56.34]Douse nara isso itsumo no ano basho de\n[04:00.51]Hello Hello Hello\n[04:05.34]	/audio/Couple of Cuckoos ED2 「HELLO HELLO HELLO」.mp3	HELLO HELLO HELLO	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251588/covers/Couple_of_Cuckoos_ED2_HELLO_HELLO_HELLO.jpg	1
211	28	208	239	[00:00.00] \n[00:00.80]Tsuyoku nareru riyuu wo shitta\n[00:07.16]Boku wo tsurete susume\n[00:16.17] \n[00:18.72]Dorodarake no soumatou ni you\n[00:23.67]Kowabaru kokoro furueru te wa\n[00:28.32]Tsukamitai mono ga aru\n[00:30.72]Sore dake sa\n[00:32.72]Yoru no nioi ni (I'll spend days and nights)\n[00:36.29]Sora nirandemo (Staring into the sky)\n[00:39.78]Kawatte ikeru no wa jibun jishin dake\n[00:45.12]Sore dake sa\n[00:47.12]Tsuyoku nareru riyuu wo shitta\n[00:53.26]Boku wo tsurete susume\n[01:00.10]Dou shitatte kesenai yume mo tomarenai ima mo\n[01:04.72]Dareka no tame ni tsuyoku nareru nara\n[01:09.14]Arigatou kanashimi yo\n[01:14.17]Sekai ni uchinomesarete makeru imi wo shitta\n[01:18.97]Guren no hana yo sakihokore\n[01:23.29]Unmei wo terashite\n[01:33.35]Inabikari no zatsuon ga mimi wo sasu\n[01:38.28]Tomadou kokoro yasashii dake ja\n[01:43.08]Mamorenai mono ga aru\n[01:45.52]Wakatteru kedo\n[01:47.88]Suimenka de karamaru zenaku\n[01:49.58]Sukete mieru gizen ni tenbatsu\n[01:51.29]Tell me why, tell me why, tell me why, tell me, I don't need you\n[01:54.83]Itsuzai no hana yori\n[01:56.53]Idomi tsudzuke saita ichirin ga utsukushii\n[02:00.47]Ranbou ni shikitsumerareta togedarake no michi mo\n[02:05.22]Honki no boku dake ni arawareru kara\n[02:09.58]Norikoete miseru yo\n[02:14.48]Kantan ni katazukerareta mamorenakatta yume mo\n[02:19.43]Guren no shinzou ni ne wo hayashi\n[02:23.79]Kono chi ni yadotte\n[02:31.02] \n[02:41.62]Hito shirezu hakanai chiriyuku ketsumatsu\n[02:48.76]Mujou ni yabureta himei no kaze fuku\n[02:55.85]Dareka no warau kage dareka no nakigoe\n[03:02.44]Daremo ga shiawase wo negatteru\n[03:08.00]Dou shitatte kesenai yume mo tomarenai ima mo\n[03:12.65]Dareka no tame ni tsuyoku nareru nara\n[03:17.13]Arigatou kanashimi yo\n[03:22.30]Sekai ni uchinomesarete makeru imi wo shitta\n[03:26.96]Guren no hana yo sakihokore\n[03:31.54]Unmei wo terashite unmei wo terashite\n[03:36.25] \n	/audio/Demon Slayer OP 「Gurenge」.mp3	Gurenge	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253970/covers/Demon_Slayer_OP_Gurenge.jpg	1
108	108	108	361		/audio/Bungaku Shoujo ED 「Haruka na Hibi」.mp3	Haruka na Hibi	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251536/covers/Bungaku_Shoujo_ED_Haruka_na_Hibi.jpg	1
109	109	109	237	[00:00.00] \r\n[00:00.17]Katarenai nemurenai toroimerai\r\n[00:05.14]Anata no miteru shoutai\r\n[00:10.33]Daremo yomenai karute\r\n[00:15.19]Fukashigi shiritai dake\r\n[00:20.47] \r\n[00:21.26]Uso mo genjitsu mo\r\n[00:28.37]Docchi mo shinjitsu datta no hontou yo\r\n[00:40.87]Kyou mo hitorigoto\r\n[00:48.40]Nannimo muri wo shinaide watashi aisaretai\r\n[01:01.42] \r\n[01:02.80]Uyamuya sayonara karui memai\r\n[01:07.79]Anata no inai genshoukai\r\n[01:12.58]Daremo yomenai karute\r\n[01:17.58]Jiishiki afuredashite\r\n[01:22.50] \r\n[01:33.29]Kodou wo sekaizou wo\r\n[01:40.69]Itsumo kami awanai no itakute\r\n[01:53.14]Maiyo negaigoto\r\n[02:00.81]Nannimo utagawanaide mazari toke aitai\r\n[02:14.09] \r\n[02:15.21]Tawainai wakaranai riyuu sonzai\r\n[02:20.16]Anata to nokosu koukai\r\n[02:25.07]Daremo yomenai karute\r\n[02:29.96]Fuyukai kurikaeshite\r\n[02:35.10] \r\n[02:45.76]Tadashii yume wa kanashii koe wa\r\n[02:55.69]Utsukushii? utagawashii? urayamashii?\r\n[03:02.93]Nee, dore?\r\n[03:07.37] \r\n[03:07.64]Katarenai nemurenai toroimerai\r\n[03:12.66]Anata no miteru shoutai\r\n[03:17.67]Daremo yomenai karute\r\n[03:22.69]Fukashigi shiritai dake\r\n[03:27.69]Owaranai koto wa nai toroimerai\r\n[03:32.75]Anata to matagu kyoukai\r\n[03:37.72]Daremo yomenai karute\r\n[03:42.62]Shishunki kizuguchi mune no uchi\r\n[03:47.67]Fukashigi shiritai dake\r\n[03:52.77]	/audio/Bunny girl Senpai ED 「Fukashigi no Carte」.mp3	Fukashigi no Carte	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254002/covers/Bunny_girl_Senpai_ED_Fukashigi_no_Carte.jpg	1
110	110	109	268	[00:00.00] \n[00:03.05]Kimi no sei kimi no sei kimi no sei de watashi oh\n[00:08.08]Okubyou de kakkou tsukanai kimi no sei da yo\n[00:13.24] \n[00:25.48]Sukoshi nobita maegami ni\n[00:29.63]Kakureteru kimi no nee, chotto\n[00:33.15]Doko miten no? Kocchi ni kite\n[00:36.54]Kimi ga watashi wo muchuu ni\n[00:40.57]Saseru no ni muzukashii koto wa\n[00:44.40]Hitotsu mo nai\n[00:47.21]Yuugata no eki no hoomu nami no oto\n[00:52.83]Damaru watashi wo misukashita you ni\n[00:57.56]Sonna fuu ni warawanaide\n[01:03.56]Kimi no sei kimi no sei kimi no sei de watashi oh\n[01:08.71]Okubyou de kakkou tsukanai konna hazu ja nai no ni\n[01:14.58]Kimi no sei kimi no sei kimi no sei de watashi oh\n[01:19.72]Dareka wo kirai ni naru no\n[01:23.91] \n[01:25.85]Konna yoru wa munasawagi shika shinai yo\n[01:30.75]Haato no mashin gan kamaete\n[01:33.60]Yoyuu bukkoiteru kimi ni\n[01:36.46]Neraiuchi suru no sa\n[01:40.41] \n[01:51.00]Ima mo sukoshi itamu kizu\n[01:55.28]Kakushiteru seifuku nuida tte\n[01:58.77]Mie mo shinai hontou no kokoro\n[02:01.82]Futari narande aruite mo\n[02:06.29]Bimyou sugiru kyori kan motto\n[02:09.73]Chikazuite yo\n[02:12.52]Saitei na kotoba hiite mitari shita\n[02:18.20]Kawaisou na onna no ko tte yatsu ni\n[02:23.24]Naranai tame no yobousen\n[02:27.40] \n[02:27.69]Kimi no sei kimi no sei kimi no sei de watashi oh\n[02:32.68]Wasurerarenai koto bakka fuete itte komaru na\n[02:38.76]Kimi no sei kimi no sei kimi no sei de ima ne oh\n[02:43.96]Watashi wa kirei ni naru no\n[02:48.55] \n[03:12.59]Kimi ja nakya iya da tte iitai\n[03:15.44]Ima sugu oh\n[03:17.62]Hitorikiri no yoru to zutto\n[03:20.46]Koko de matte ita nda yo\n[03:23.53]Kimi no sei kimi no sei kimi no sei de watashi oh\n[03:28.53]Okubyou de kakkou tsukanai konna hazu ja nai no ni\n[03:34.56]Kimi no sei kimi no sei kimi no sei de watashi oh\n[03:39.47]Dareka wo kirai ni naru no\n[03:43.62] \n[03:45.85]Konna yoru wa munasawagi shika shinai yo\n[03:50.84]Haato no mashin gan kamaete\n[03:53.62]Yoyuu bukkoiteru kimi ni\n[03:56.68]Neraiuchi suru no sa\n[04:00.65] 	/audio/Bunny Girl Senpai OP 「Kimi no Sei」.mp3	Kimi no Sei	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253673/covers/Bunny_Girl_Senpai_OP_Kimi_no_Sei.jpg	1
111	111	92	242		/audio/Cautious Hero OP 「TIT FOR TAT」.mp3	TIT FOR TAT	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251814/covers/Cautious_Hero_OP_TIT_FOR_TAT.jpg	1
113	113	112	91		/audio/Cells at Work OP 「Mission! Ken Kou Dai Ichi」.mp3	Mission! Ken Kou Dai Ichi	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251613/covers/Cells_at_Work_OP_Mission_Ken_Kou_Dai_Ichi.jpg	1
118	27	118	316	[00:31.875]miwataseru basho ni kesa wa tadoritsuku\r\n[00:39.681]tooku senro ga nobiru\r\n[00:46.645]kobiritsuita tsuchi kakato kara otoshi\r\n[00:53.801]aruita kyori wo hakatte mitari\r\n\r\n[01:01.891]maegami wo yurasu youni kaze ga tsuyoku fuitara\r\n[01:08.951]mou nanimo mayowanai\r\n\r\n[01:15.015]sekai no hate sae bokura wa shiranai\r\n[01:22.375]kanashi mazu ikiru sube mo mottenai\r\n[01:29.671]mezasu kono saki ni matteru yuuki\r\n[01:37.135]sore wo te ni shitara owaru yume wo mita\r\n\r\n[02:00.401]iron'na aisatsu kurikaeshite kita\r\n[02:08.165]narabu shiroi ha wa onaji\r\n[02:15.641]oogesa na baggu mada karappo dakedo\r\n[02:22.465]taishite iru mono nanka nakatta\r\n\r\n[02:30.261]ryouhiza wo chi ni tsuku to mata kaze ga zawameite\r\n[02:37.635]boku no senaka wo osu\r\n\r\n[02:43.701]sora ga kawarihate bokura wa nemuru\r\n[02:50.924]asu e no kakehashi nantoka watatte\r\n[02:58.358]hontou no tsuyosa wo daremo mottenai\r\n[03:05.634]mezametara sugu ni kyou mo arukidasou\r\n\r\n[03:16.640]sorosoro gohan no shitaku wo shinakya\r\n[03:23.720]taoerete shimau mae ni\r\n[03:29.170]mitsu wo kutsu de sukutte nonda\r\n[03:35.940]darashi naku naru\r\n[03:39.670]hitori da to\r\n\r\n[03:46.264]maegami wo yurasu hodo kaze ga tsuyoku fuitara\r\n[03:53.328]koko wo hanareru aizu\r\n\r\n[03:59.214]sekai no hate sae bokura wa shiranai\r\n[04:06.570]kanashi mazu ikiru sube mo mottenai\r\n[04:13.974]mezasu kono saki ni matteru yuuki\r\n[04:21.380]sore wo te ni shitara owaru yume wo mita\r\n[04:28.874]sora ga kawarihate hoshi wa megutte yuku\r\n[04:36.298]mezametara sugu ni kyou mo arukidasou\r\n\r\n	/audio/Charlotte ED 「Yakeochinai Tsubasa」.mp3	Yakeochinai Tsubasa	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253689/covers/Charlotte_ED_Yakeochinai_Tsubasa.jpg	1
343	339	339	328		/audio/Guilty Crown OP3 「The Everlasting Guilty Crown」.mp3	The Everlasting Guilty Crown	OP3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252356/covers/Guilty_Crown_OP3_The_Everlasting_Guilty_Crown.jpg	1
120	120	118	239	[00:00.00] \n[00:01.48]odayaka ni kurashitai\n[00:07.28]kimi to nara dekiru hazu\n[00:13.43]iya dekinai kana\n[00:16.42]demo kimi to sugosetara\n[00:22.41]sore dake de ii to omou\n[00:28.87] \n[00:34.67]PINTO ga ZURE ta youna futari datta\n[00:49.97]ima mo onnaji ka\n[00:57.94]warui yatsu o damarase ni ikou\n[01:08.28]sonna koto o kurikaeshite ita\n[01:17.12] \n[01:18.23]mucha na koto bakari datta kedo\n[01:24.04]sonna ni warui omoide janai\n[01:30.49] \n[01:31.96]odayaka ni kurashitai\n[01:37.88]kimi to nara dekiru hazu\n[01:43.94]iya dekinai kana\n[01:46.78]tada boku no kokuhaku ga minoru koto inotteru yo\n[02:00.62] \n[02:02.16]odayaka na kaze ga fuku ano haru ni kaeretara\n[02:14.06]sou omou kedo\n[02:17.10]mou dare ga matteta ka   matteru ka\n[02:26.10]wasurete shimau\n[02:29.20]nakaseteru   gomen mo iu\n[02:35.12]kedo kimi o omoidasenai\n[02:41.10]tada hitotsu wakaru koto\n[02:47.18]kono moji wa kimi no mono da\n[03:44.50] \n	/audio/Charlotte Ending song 「Kimi no Moji」.mp3	Kimi no Moji	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773251622/covers/Charlotte_Ending_song_Kimi_no_Moji.jpg	1
124	123	123	244		/audio/Chobits ED2 「Ningyohime」.mp3	Ningyohime	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251806/covers/Chobits_ED2_Ningyohime.jpg	1
131	20	131	109	[00:00.00] \n[00:08.67]mitsumete ita nagareru kumo wo\n[00:16.63]kanjite ita kawaru sora no iro wo\n[00:24.25]tachidomatta bokura wa kizuku\n[00:31.70]utsuroiyuku sekai ga tsumugu uta ni\n[00:39.25]nobashita yubi de taguru you ni\n[00:46.37]tada hitotsu kawaranai mono sagasu\n[00:55.16]kazasu te ni tomoshibi wo\n[01:02.33]asu he to tsuzuku chiisana shirube\n[01:10.06]ima mo mada kodama suru\n[01:17.68]ano hi no kotoba chikai ni kae boku wa yuku\n[01:28.85] 	/audio/Clannad After Story ED 「Torch」.mp3	Torch	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254048/covers/Clannad_After_Story_ED_Torch.jpg	1
132	20	131	294	[00:00.00] \n[00:16.68]Ochite iku sunadokei bakari miteru yo\n[00:22.21]Sakasama ni sureba hora mata hajimaru yo\n[00:27.91]Kizanda dake susumu jikan ni\n[00:33.10]Itsuka boku mo haireru kana\n[00:39.48]Kimi dake ga sugisatta saka no tochuu wa\n[00:45.18]Atataka na hidamari ga ikutsu mo dekiteta\n[00:50.79]Boku hitori ga koko de yasashii\n[00:55.82]Atatakasa wo omoikaeshiteru\n[01:03.25] \n[01:03.69]Kimi dake wo kimi dake wo\n[01:11.43]Suki de ita yo\n[01:17.42]Kaze de me ga nijinde\n[01:25.23]Tooku naru yo\n[01:32.22]Itsu made mo oboeteru\n[01:34.44]Nani mo ka mo kawatte mo\n[01:36.51]Hitotsu dake hitotsu dake\n[01:38.77]Arifureta mono da kedo\n[01:41.04]Misete yaru kagayaki ni michita sono hitotsu dake\n[01:45.30]Itsu made mo itsu made mo mamotte iku\n[01:49.49] \n[02:01.24]Hadazamui hi ga tsuzuku mou haru na no ni\n[02:06.86]Mezamashidokei yori hayaku okita asa\n[02:12.34]Sanninbun no asa-gohan wo tsukuru kimi ga\n[02:20.13]Soko ni tatte iru\n[02:25.41]Kimi dake ga kimi dake ga\n[02:33.01]Soba ni inai yo\n[02:39.22]Kinou made sugu soba de boku wo miteta yo\n[02:54.27] \n[03:08.51]Kimi dake wo kimi dake wo\n[03:17.13]Suki de ita yo\n[03:23.22]Kimi dake to kimi dake to\n[03:31.28]Utau uta da yo\n[03:37.09]Boku-tachi no boku-tachi no\n[03:44.77]Kizanda toki da yo\n[03:50.86]Katahou dake tsuzuku nante\n[03:58.72]Boku wa iya da yo\n[04:06.07] \n[04:14.31]Itsu made mo oboeteru\n[04:16.26]Kono machi ga kawatte mo\n[04:18.71]Dore dake no kanashimi to deau koto ni natte mo\n[04:23.40]Misete yaru hontou wa tsuyokatta toki no koto\n[04:27.60]Saa iku yo arukidasu saka no michi wo\n[04:32.15]	/audio/Clannad After Story OP 「Toki Wo Kizamu Uta_」.mp3	Toki Wo Kizamu Uta"	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253974/covers/Clannad_After_Story_OP_Toki_Wo_Kizamu_Uta.jpg	1
146	145	94	225	[00:00.00] \n[00:09.43]Jibun wo sekai sae mo kaete\n[00:14.79]shimaesou na\n[00:17.00]Shunkan ha itsumo sugu soba ni...\n[00:24.62]Kakusenu iradachi to tachitsukusu\n[00:33.30]jibun wo mitsume\n[00:38.23]Mayoinagara nayaminagara\n[00:41.31]kuyaminagara kimereba ii sa\n[00:45.17]Kimi ga kureta kotoba hitotsu\n[00:48.42]tomadoi ha kiesari\n[00:52.21]Karappo datta boku no heya ni\n[00:55.95]hikari ga sashita\n[00:58.74]Miageta oozora ga aoku sumikitte yuku\n[01:06.30]Tozashita mado wo hiraku koto wo\n[01:11.19]kimeta\n[01:12.71]Jibun wo sekai sae mo kaete\n[01:18.23]shimaesou na\n[01:20.44]Shunkan ha itsumo sugu soba ni...\n[01:27.88]Mitasenu nichijou ni aru hazu no\n[01:36.97]kotae wo sagashite\n[02:10.39]Asahi ni hitori yawaraka na koe ni\n[02:14.18]furimukeba\n[02:16.53]Mabayui hizashi no naka futo kimi ga\n[02:21.82]homoemu\n[02:24.02]Tozashita mado ga hirakisou ni naru\n[02:30.71]Jibun wo sekai sae mo kaete\n[02:36.18]shimaesou na\n[02:38.39]Sonzai ha boku no me no mae ni...\n[02:45.18]Miageta oozora ga aoku sumikitte yuku\n[02:52.36]Tozashita mado wo hiraku koto wo\n[02:57.32]kimeta\n[02:58.91]Jibun wo sekai sae mo kaete\n[03:04.20]shimaesou na\n[03:07.18]Shunkan wo kanjiru ima koko ni...\n[03:13.85]Hikari he to ryoute wo nobashite...\n[03:20.25]Kokoro wo fukinukeru sora no iro\n[03:25.43]kaoru kaze\n[03:27.98] 	/audio/Code Geass OP 「COLORS」.mp3	COLORS	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253661/covers/Code_Geass_OP_COLORS.jpg	1
151	139	94	263		/audio/Code Geass S2 ED2 「Wage Routashi Aku no Hana」.mp3	Wage Routashi Aku no Hana	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773254038/covers/Code_Geass_S2_ED2_Wage_Routashi_Aku_no_Hana.jpg	2
152	150	94	237		/audio/Code Geass S2 OP 「O2」.mp3	O2	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773251946/covers/Code_Geass_S2_OP_O2.jpg	2
169	169	169	121		/audio/Dareka no Manazashi ED 「Sore de Ii yo」.mp3	Sore de Ii yo	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254108/covers/Dareka_no_Manazashi_ED_Sore_de_Ii_yo.jpg	1
176	175	175	225	[00:00.00] \n[00:22.58]Aozora to sunahama ga hazukashi garanakutemo ii yo to sasotteru\n[00:34.50]T-SHATSU wo nugou to suru kimi kara shisen awatete sorasu\n[00:46.36]PARASORU no shita de hiyakedome nutteru\n[00:52.20]Kimi ga itsumo yori otona ni miete nodo ga kawaita\n[01:01.18]Manatsu no setsuna no tokimeki kanjitetai\n[01:07.11]Namiuchigiwa hashiru kimi wo bishonure de oikakete\n[01:12.91]Isshun furikaetta kimi no hajikeru egao ga\n[01:18.90]Boku wo kogashite atama karappo ni natte yuku yo\n[01:27.99] \n[01:30.64]Konya moshi nagareboshi mitsukeraretara kimi wa nani wo negau no?\n[01:42.51]Iikakete yameta boku wo kimi wa "hen na no" tte kubi kashigeta\n[01:54.40]Kamome no nakigoe tanoshige ni hibiku\n[02:00.17]Rikutsu janain da donkan na kimi mo kirai janai yo\n[02:09.18]Manatsu no setsuna no tokimeki kanjitetai\n[02:15.31]Shio no kaze ga karadajuu wo nade nagara fukinukeru\n[02:21.01]Zettai kakaranai to hana de waratta natsu no mahou\n[02:27.04]Boku mo masaka ne kimi ni kakerarete shimatta no?\n[02:36.67] \n[02:44.78]Suna ni kaita moji mitai ni\n[02:47.80]Zawameku kono kimochi mo kiechau no?\n[02:51.89]Ah kimi tte matsuge nagain da ne kagayaite iru yo\n[03:05.64]Manatsu no setsuna no tokimeki kanjitetai\n[03:11.70]Namiuchigiwa hashiru kimi wo bishonure de oikakete\n[03:17.46]Isshun furikaetta kimi no hajikeru egao ga\n[03:23.40]Boku wo kogashite atama karappo ni natte yuku yo\n	/audio/Darling In The FranXX ED2 「Manatsu no Setsuna」.mp3	Manatsu no Setsuna	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253958/covers/Darling_In_The_FranXX_ED2_Manatsu_no_Setsuna.jpg	1
183	183	182	243	[00:00.00] \n[00:14.08]Kaeru basho wo miushinatte\n[00:18.39]Ugomeita sora de karasutachi ga naiteiru\n[00:24.26]Deguchi no nai meiro no naka\n[00:28.37]Susundeku goto ni koboreochiru\n[00:31.36]Kibou no kakera\n[00:33.90]Tokesou ni nai na kijou no kuuron ja\n[00:38.68]Fukouhei na shisutemu wo zenshin zenrei de kowashite\n[00:44.06]Kimerareta ruuru wo\n[00:46.10]Azamuite susunde yuke\n[00:50.78]Kono makkura na yoru wo kiritotte\n[00:53.53]Warui yume kara sametai kara\n[00:57.21]Hateshi nai tabiji wo yuku\n[01:01.28]Seigyo sarenai mirai wo ima kono te ni\n[01:05.79]Wazuka na hikari shika nakutatte\n[01:08.53]Girigiri demo ikite itai kara\n[01:12.21]Shinjitsu wo tsukami ni yuke\n[01:16.17]Itetsuita toki wo tokasu kara\n[01:21.27]Mou nido to mayowanai\n[01:24.76] \n[01:34.15]Kansan to shita kousaten\n[01:38.34]Azakewaratte kuru oorora bijon niramitsuke\n[01:44.16]Chitsujo no nai meimu no naka\n[01:48.32]Ubawareta kizuna itami kakae hashiri tsuzukeru\n[01:53.99]Egaita endingu e kokou no hata kakagete yuke\n[02:00.72]Kono kanashii kyori wo oikoshite\n[02:03.71]Tadoritsukeru basho ga aru nara\n[02:07.20]Ibara no michi wo tsuranuku\n[02:11.26]Donna michi tsuzuitemo furikaeranai\n[02:15.62]Kanawanai negai ga atta to shitemo\n[02:18.76]Ano hi no koe ga kikoeru kara\n[02:22.25]Hatashitai chikai to yuke\n[02:26.35]Tashika ni tsukanda kono kizuna wo\n[02:31.28]Mou nido to hanasanai\n[02:35.44] \n[02:39.60]Ima wa aenakutemo mamoritai tada egao dake\n[02:48.75]Kimi to tsunaida omoi yakusoku wo mune ni daite\n[03:01.28]Chigirareta kizuna no ito wa kanarazu torimodoseru kara\n[03:08.20]Kono makkura na yoru wo kiritotte\n[03:11.17]Warui yume kara sametai kara\n[03:14.70]Hateshi nai tabiji wo yuku\n[03:18.74]Seigyo sarenai mirai wo ima kono te ni\n[03:23.30]Wazuka na hikari shika nakutatte\n[03:26.09]Girigiri demo ikite itai kara\n[03:29.72]Shinjitsu wo tsukami ni yuke\n[03:33.69]Tashika ni tsukanda kono kizuna wo\n[03:38.59]Mou nido to hanasanai\n[03:43.85]Mou nido to mayowanai\n[03:47.04] \n	/audio/Darwin_s Game OP「Chain」.mp3	Chain	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253952/covers/Darwin_s_Game_OP_Chain.jpg	1
189	189	184	381		/audio/Date A Live S2 ED2 「My Treasure」.mp3	My Treasure	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253613/covers/Date_A_Live_S2_ED2_My_Treasure.jpg	2
202	202	202	256	[00:00.00] \n[00:20.40]Go! Go!! Go! Go!! Go! Go! Go!!\n[00:30.18]Let's go! ashita mo HAPPY\n[00:35.84]Go! Go!! fushigi na HAPPY\n[00:41.28]minna minna irasshai\n[00:44.05]HAPPY COSMOS\n[00:47.13]kitto watashi no buwawawa~n\n[00:49.84]kanjitan da ne\n[00:50.97]sore wa tennen datte guuzen datte\n[00:58.27]tonde tonde sawagou\n[01:00.84]HAPPY COSMOS\n[01:03.78]zettai muteki de poyoyoyo~n\n[01:06.43]machigaete mo\n[01:08.65]ki ni shinai-\n[01:10.93]dattara nanto kanari sou\n[01:14.78]mawari no koto wa Hi-Hi kamawanai\n[01:22.35]warui?\n[01:23.41]sora no kanata e tokimeki sagashite\n[01:28.78]takaku takaku ne 3,2,1 de yukun da yo\n[01:34.35]mirai no chizu wa doko ni mo arimase-n\n[01:39.91]dakara genki na egao de susumimashou\n[01:47.27]Go! Go!!\n[01:51.11]Let's Go! hima nara POPPIN'\n[01:56.72]Go! Go!! abunai POPPIN'\n[02:02.38]oide oide odorou\n[02:04.93]POPPIN' CHANNEL\n[02:07.88]jitto shiteru toburururu~n\n[02:10.58]makesou da yo\n[02:12.23]yatara shinken motto hageshiku motto\n[02:19.08]kiite kiite HAMAtte\n[02:21.57]POPPIN' CHANNEL\n[02:24.66]shunkan kousoku porarara~n\n[02:27.34]komarasechae\n[02:29.69]yume de atta?\n[02:31.79]kokoro ga naze ka natsukashii\n[02:35.76]hajimaritai no Yeah-Yeah watashi-tachi\n[02:43.10]ikaga?\n[02:44.27]anata no sora ni tokimeki mitsuketa\n[02:49.81]tsuyoku tsuyoku ne sunao ni dakishimete\n[02:55.27]koi ni RUURU mo hoken mo arimase-n\n[03:00.99]naraba nonki ni Get you! Get you!!\n[03:05.10]yatte miyou\n[03:07.97]Go! Go!!\n[03:12.03]BANG!! ai wa kitto soko ni a~ru\n[03:14.30]BANG! BANG! SUKI no PUZZLE no kansei\n[03:17.50]tanoshii? ureshii?\n[03:18.80]yume machidooshii sora no hate made FLY HIGH\n[03:22.24]EVERYBODY SAY YEAH~~~~~ YEAH~~~~~\n[03:26.02]datte nanka HAPPY COSMOS\n[03:28.76]fuwafuwa PARABOLA chuu ni ukite CHU\n[03:31.57]futari FARWAY FLY!!\n[03:36.10]maigo mitai ne hoshi no umi oyogou\n[03:41.42]te wo hanashitara POINT to YOU no mujyuuryoku\n[03:47.00]koi wa SURIRU to fushigi no KORABOREITO\n[03:52.71]masaka masaka no kiseki wo tsukurimashou\n[03:59.60]Go! Go!! Go! Go!! Go! Go! Go!!\n[04:06.83] 	/audio/DearS ED 「Happy Cosmos」.m4a	Happy Cosmos	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253862/covers/DearS_ED_Happy_Cosmos.jpg	1
1195	1195	1195	148	[00:00.00] \n[00:19.39]Where you go, don't let 'em flow\n[00:22.52]Kono boku dake nokoshite\n[00:25.42]Konna ni mo I want it more\n[00:28.58]Ima sukoshi demo ii kara\n[00:30.94]Tomaranai tokei no hari, don't leave me all alone\n[00:33.80]Hitori de omoide banashi ni shinaide mou\n[00:37.00]Boku dake de iru kimochi ni naru kara\n[00:39.84]Okizari ni naritakunai yo, take me to you now\n[00:43.44]Too fast kimi ni awase matta kara\n[00:46.29]Boku wa imada ni koko ni iru yo\n[00:49.43]Mae ni bokura ga aruita kono michi de\n[00:53.67]Hitori walking on the way hie sugiru yo so cold\n[00:57.24]Sukoshizutsu ashi omoku nari slow mode\n[01:00.24]Saki ni itta boku no sugata wa black or white?\n[01:03.45]Shashin no you naru kako no mono to\n[01:05.94]Hitorikiri ni naru no ga kowakute\n[01:09.12]Yume noseta kisha mo ugokanakunatte\n[01:12.15]Boku dake ga me no mae no island\n[01:15.09]Mada todokanasou de kowain da mou, ayy\n[01:19.32]Hiru mo yoru mo nayami cry\n[01:20.91]Onaji basho de kawarinai\n[01:22.36]Ari ki tari no kyoku ya kashi ga mae to nani mo kawaranai\n[01:25.43]Mi wo tadashite itsumo hazukashikunai you ni shite, yeah\n[01:28.33]Kagami miru tokini wa warai jibun wo tsuyoku motte\n[01:31.32]Sarakedashite taisei no hito no mae de shoumei\n[01:34.31]Tama ni jishin nakute, kono sugata subete ga, ayy\n[01:37.23]Boku igai no mina ga saki ni susunde\n[01:39.30]Itsumo tonari ni ita yatsu mo touku nari mou mienai\n[01:41.92]Anymore, oh, yeah, yeah\n[01:43.46]Too fast kimi ni awase matta kara\n[01:46.38]Boku wa imada ni koko ni iru yo\n[01:49.40]Mae ni bokura ga aruita kono michi de\n[01:53.60]Hitori walking on the way hie sugiru yo so cold\n[01:57.20]Sukoshizutsu ashi omoku nari slow mode\n[02:00.18]Saki ni itta boku no sugata wa black or white?\n[02:03.54]Shashin no you naru kako no mono to\n[02:05.94]Hitorikiri ni naru no ga kowakute\n[02:08.99]Yume noseta kisha mo ugokanakunatte\n[02:12.26]Boku dake ga me no mae no island\n[02:15.15]Mada todokanasou de kowain da mou, ayy\n[02:19.27] \n	/audio/Tower of God ED 「SLUMP」.mp3	SLUMP	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253920/covers/Tower_of_God_ED_SLUMP.jpg	1
222	222	222	318	[ti:Doraemon Stand by Me ED 「Himawari no Yakusoku」]\n[ar:Motohiro Hata]\n[al:Doraemon]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:05:18.28]\n[00:00.00]\n[00:20.03]Doushite kimi ga naku no mada boku mo naite inai no ni\n[00:32.43]Jibun yori kanashimu kara tsurai no ga docchi ka wakaranaku naru yo\n[00:46.28]Garakuta datta hazu no kyou ga futari nara takara mono ni naru\n[01:00.97]Soba ni itai yo kimi no tame ni dekiru koto ga boku ni aru ka na\n[01:13.29]Itsumo kimi ni zutto kimi ni waratteite hoshikute\n[01:25.17]Himawari no you na massugu na sono yasashisa wo nukumori wo zenbu\n[01:38.35]Kore kara wa boku mo todokete ikitai koko ni aru shiawase ni kidzuita kara\n[02:02.79]Tooku de tomoru mirai moshi mo bokura ga hanarete mo\n[02:14.97]Sore zore aruite iku sono saki de mata deaeru to shinjite\n[02:28.66]Chigu-hagu datta hazu no hohaba hitotsu no you ni ima kasanaru\n[02:43.75]Soba ni iru koto nanigenai kono shunkan mo wasure wa shinai yo\n[02:55.87]Tabidachi no hi te wo furu toki egao de irareru you ni\n[03:07.48]Himawari no you na massugu na sono yasashisa wo nukumori wo zenbu\n[03:20.10]Kaeshitai keredo kimi no koto dakara mou jyubun da yotte kitto iu ka na\n[03:58.98]Soba ni itai yo kimi no tame ni dekiru koto ga boku ni aru ka na\n[04:11.40]Itsumo kimi ni zutto kimi ni waratte ite hoshikute\n[04:22.97]Himawari no you na massugu na sono yasashisa wo nukumori wo zenbu\n[04:35.97]Kore kara wa boku mo todokete ikitai hontou no shiawase no imi wo mitsuketa kara\n[04:50.10]	/audio/Doraemon Stand by Me ED 「Himawari no Yakusoku」.mp3	Himawari no Yakusoku	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254150/covers/Doraemon_Stand_by_Me_ED_Himawari_no_Yakusoku.jpg	1
227	227	227	181	[00:00.00] \n[00:13.53]Maybe I don’t know what to do\n[00:16.06]Hurry up, my mind is on the moon\n[00:18.70]Flying up to where the wind blew\n[00:22.67]Tenohira ni afurete kuru\n[00:24.59]Jounetsu ga me wo samasu\n[00:25.81]Samayotteru dake no This World\n[00:28.45]Hitotsu dake hikaru kimi no Pure\n[00:30.60]Sabita naifu nanka ja sasenai\n[00:32.46]I am burning like a fire gone wild\n[00:34.20]Kokoro ni ya wo hanatareta shunkan\n[00:36.75]Matowaritsuku zatsuon ga hajiketa\n[00:39.35]Everything was different from that moment on\n[00:41.60]If I don’t try, I’ll never know\n[00:44.17]Naze, hana wa saku no darou?\n[00:49.39]Kimi no koe ga hibiku yo\n[00:53.67]Tell me why?\n[00:54.78]I just shouted to the sky\n[00:56.84]But you are no no longer here, that’s right?\n[00:59.51]Ano hi bokura tashikameteta LIFE\n[01:04.11]Hakanai yume to iwaretatte ii kara\n[01:10.06]Kizudarake no kyou kara sukuidasu yo\n[01:14.77]Monokuro no sekai de kimi ga nagashiteru\n[01:17.61]Namida wo ima mo tesaguri de sagashiteru\n[01:20.55]Ashita ni mukau tame ni ato nani wo\n[01:23.30]Ushinaeba hikari wa mieru ka na?\n[01:25.66]When I looked up to the moon and the stars\n[01:27.93]Sono yokogao wo omoiukabeta\n[01:30.77]Kodoku no naka ni noboru asahi\n[01:33.38]Mune no kodou mada kesanai you ni\n[01:35.83]Naze, yoru wa kuru no darou?\n[01:40.91]Boku wa koe wo karasu yo\n[01:45.33]Show me why?\n[01:46.33]I am standing in the night\n[01:48.41]But you are no no longer here that’s right?\n[01:51.24]Ano hi bokura dakishimeteta LIFE\n[01:55.73]Kimi no koe ga tashika ni kikoeru kara\n[02:01.59]Kizudarake ni nattemo sukuidasu yo\n[02:07.28] \n[02:17.46]Don’t matter if you’re ready\n[02:18.83]I’m gonna find you\n[02:19.97]Though it might sound funny\n[02:21.30]I will do what I’ll do\n[02:23.03]Kitto mitsukedasu yo\n[02:26.64]Tell me why?\n[02:27.66]I just shouted to the sky\n[02:29.76]But you are no no longer here, that’s right?\n[02:32.64]Ano hi bokura tashikameteta LIFE\n[02:37.06]Hakanai yume to iwaretatte ii kara\n[02:43.01]Kizudarake no kyou kara sukuidasu yo\n[02:47.85] \n	/audio/Dr. Stone ED 「LIFE」.mp3	LIFE	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253852/covers/Dr._Stone_ED_LIFE.jpg	1
228	228	227	269		/audio/Dr. Stone ED2「Yume no You na」.mp3	Yume no You na	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773254212/covers/Dr._Stone_ED2_Yume_no_You_na.jpg	1
230	230	227	205		/audio/Dr. Stone OP2 「Sangenshoku」.mp3	Sangenshoku	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773251564/covers/Dr._Stone_OP2_Sangenshoku.jpg	1
252	252	252	265	[ti:Elfen Lied ED「Be Your Girl」]\n[ar:Chieko Kawabe]\n[al:Elfen Lied]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:25.24]\n[00:00.00]\n[00:13.80]Maybe I wanna be your girl\n[00:19.86]Maybe all I need is you\n[00:25.83]annani mou soba ni ite mo\n[00:32.03]konnani mou aisarete mo\n[00:37.93]jikan ha mikata shite kurezu ni\n[00:43.63]anata no kanojo ni narenai atashi\n[00:50.04]sore demo iitte nandomo omotta\n[00:55.59]anata wo dareka to SHEA shiteiru keredo\n[01:01.66]soreja iya datte nandomo naiteru\n[01:07.65]uso demo kiyasume demo atashi dakette itte\n[01:25.74]KISU no masui kirete itaku naru\n[01:31.66]anata ha mou kaecchau no?\n[01:37.76]koko de namida ha hikyou datte\n[01:43.68]ha wo kuishibatte gaman shiteru yo\n[01:49.76]sore demo iitte nandomo omotta\n[01:55.71]anata wo dareka to SHEA shiteiru keredo\n[02:01.64]soreja iya datte nandomo naiteru\n[02:07.75]uso demo kiyasume demo\n[02:10.23]ne onegai\n[02:13.65]atashi no naka ha anata dake\n[02:20.18]aishiteiru no ha atashi dakette itte\n[02:50.28]hoshii mono ha hitotsu dake\n[02:53.88]tada anata no zenbu ga hoshii na\n[03:02.09]kono michi no saki ni matte iru sekai\n[03:08.28]nigezu ni tsuduki wo kono me de mite mitai\n[03:14.35]tatoe koreijou kizutsuku toshite mo\n[03:20.34]zettai tomerarenai kono kimochi dakara ne\n[03:26.03]sore demo iitte nandomo omotta\n[03:32.25]anata wo dareka to SHEA shiteiru keredo\n[03:38.30]soreja iya datte nandomo naiteru\n[03:44.10]uso demo kiyasume demo atashi dakette itte\n[03:53.47]Maybe baby\n[03:59.55]I wanna be your girl\n[04:03.74](Maybe I wanna be your girl)\n[04:06.51]Maybe baby\n[04:09.61](Maybe all I need is you)\n[04:12.61]All I need is you\n[04:16.89]	/audio/Elfen Lied ED「Be Your Girl」.mp3	Be Your Girl	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253931/covers/Elfen_Lied_ED_Be_Your_Girl.jpg	1
256	256	256	184	[00:00.00] \n[00:09.21]Boku dake ga miteta\n[00:12.62]Kimi no koto\n[00:15.91]Kako mo mirai mo\n[00:19.68]Kanashimi mo yorokobi mo\n[00:25.05]Subete\n[00:29.20]Otona ni naru tte kitto\n[00:32.27]Yasashikunaru koto dato shinjiteita\n[00:39.62]Kodomo no koro no boku no mama ni\n[00:45.41]Kimi no koto mamoritai to omou\n[00:49.96]Kurayami kara mezametemo\n[00:52.64]Boku o machiuketeru kanata de\n[00:57.22]Futari o kakushita kono machi ni\n[01:01.18]Daremo shiranai yuki ga futteita\n[01:07.69]Kimi wa boku no mune ni kizamareta\n[01:11.50]Ichiban fukai kizuato no you de\n[01:16.69]Kimi ga warau kono sekai no uta\n[01:24.77]Torimodosu yo\n[01:31.12] \n[01:36.73]Dono heya no tokei mo\n[01:39.93]Sukoshi zureteite sa\n[01:43.16]Bokura wa itsumo\n[01:47.12]Kotoba o kakechigau haguruma\n[01:56.67]Hitoribocchi de naita\n[01:59.72]Hiiroo gokko\n[02:02.39]Nobasu mae ni kujiketa\n[02:07.09]Ryoute de kimi no hoo ni fureta\n[02:13.01]Kimi no koto kowashitai to omou sekai wa yume no hazama de\n[02:20.02]Kuroi inori o harande\n[02:24.75]Daiji na mono dato nadeteita\n[02:28.80]Yasashii yubi ga nejireteyuku\n[02:34.12]Boku wa tada boku no tame ni chikara naki kono te o\n[02:39.78]Kasuka na kagayaki no hou e\n[02:44.18]Mogaitemiru\n[02:46.87]Kimi no utau mirai e\n[02:52.97]Michibiite yo\n[03:01.82] \n	/audio/Erased ED 「Sore wa Chiisa na Hikari no You na」.mp3	Sore wa Chiisa na Hikari no You na	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254062/covers/Erased_ED_Sore_wa_Chiisa_na_Hikari_no_You_na.jpg	1
265	265	265	355		/audio/Expelled from Paradise ED 「EONIAN」.mp3	EONIAN	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251576/covers/Expelled_from_Paradise_ED_EONIAN.jpg	1
268	95	266	250		/audio/Fate Grand Order Absolute Demonic Front Babylonia  「Hoshi ga Furu Yume」.mp3	Hoshi ga Furu Yume	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773251935/covers/Fate_Grand_Order_Absolute_Demonic_Front_Babylonia_ED_Hoshi_ga_Furu_Yume.jpg	1
293	293	293	293	[ti:Fireworks ED Theme 「Uchiage Hanabi」]\n[ar:DAOKO x Kenshi Yonezu]\n[al:Fireworks]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:52.67]\n[00:00.00]\n[00:22.62]Ano hi miwatashita nagisa wo ima mo omoidasun da\n[00:33.41]Suna no ue ni kizanda kotoba kimi no ushiro sugata\n[00:43.38]Yorikaesu nami ga ashimoto wo yogiri nanika wo sarau\n[00:53.09]Yuunagi no naka higure dake ga toorisugite yuku\n[01:03.41]Patto hikatte saita hanabi wo mite ita\n[01:08.38]Kitto mada owaranai natsu ga\n[01:13.48]Aimai na kokoro wo tokashite tsunaida\n[01:18.35]Kono yoru ga tsudzuite hoshikatta\n[01:33.57]“Ato nando kimi to onaji hanabi wo mirareru ka na” tte\n[01:38.74]Warau kao ni nani ga dekiru darou ka\n[01:43.77]Kizutsuku koto yorokobu koto kurikaesu nami to joudou\n[01:48.79]Shousou saishuu ressha no oto\n[01:54.12]Nando demo kotoba ni shite kimi wo yobu yo\n[01:59.06]Namima wo erabi, mou ichido\n[02:04.06]Mou nido to kanashimazu ni sumu you ni\n[02:20.58]Hatto iki wo nomeba kiechaisou na hikari ga\n[02:25.80]Kitto mada mune ni sundeita\n[02:30.91]Te wo nobaseba fureta attakai mirai wa\n[02:35.83]Hisoka ni futari wo miteita\n[02:41.62]Patto hanabi ga\n[02:44.26]Yoru ni saita\n[02:46.56]Yoru ni saite\n[02:49.15]Shizuka ni kieta\n[02:51.55]Hanasanaide (hanarenaide)\n[02:54.27]Mou sukoshi dake\n[02:56.64]Mou sukoshi dake\n[02:57.88]Kono mama de\n[03:10.84]Ano hi miwatashita nagisa wo ima mo omoidasun da\n[03:21.24]Suna no ue ni kizanda kotoba kimi no ushiro sugata\n[03:31.47]Patto hikatte saita hanabi wo mite ita\n[03:36.14]Kitto mada owaranai natsu ga\n[03:41.28]Aimai na kokoro wo tokashite tsunaida\n[03:46.20]Kono yoru ga tsudzuite hoshikatta\n[03:51.35]	/audio/Fireworks ED Theme 「Uchiage Hanabi」.mp3	Uchiage Hanabi	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773254133/covers/Fireworks_ED_Theme_Uchiage_Hanabi.jpg	1
302	302	300	276	[00:00.00] \n[00:06.21]meguri megutte mo mata koko de aitai\n[00:11.34]hagurenai youni kono te wo tsunagunda\n[00:16.81] \n[00:18.03]asahi ga noboru made katari atta ne\n[00:20.86]yuuhi ga shizumu made tsunaida te\n[00:23.69]kou yatte asu mo asatte mo tomo ni\n[00:26.68]ayumou hikari to kage\n[00:29.12]kimi wa sono mune ni nani wo kakae\n[00:33.79]donna sekai ni itandarou ima omou yo\n[00:39.41]samishige ni mitsumeru machi no naka de\n[00:44.41]nukumori wa hitori ja mitsukara nakute\n[00:49.81]ai ga konna ni tsuyosa ni naru koto\n[00:55.12]shittanda kimi ni deaete hajimete\n[01:00.83]meguri meguttemo mata koko de aitai\n[01:06.07]hagurenai youni kono te wo tsunagunda\n[01:11.51]hitori ja nemurenai yume wa mirenai kara\n[01:16.83]donna fuan mo todokanai tokoroe\n[01:22.15]hoshi mo nai yoru mo terashi tsuzukeyou\n[01:27.74]doko made mo yukeru kimi to nara\n[01:30.16]hitori ja arukenai michi mo futari nara\n[01:33.03]hana uta utai nagara arukerunda\n[01:36.23]kimi ga ireba shiawase\n[01:38.23]moshimo futari ga deatte nakatta nara\n[01:43.23]takusan no shiawase wo minogashiteta\n[01:48.87]fuan na toki wa gyutto shite kureta ne\n[01:53.87]asu wo miushinai sou na hitogomi no naka\n[01:59.34]ai ga kurushii hitori no jikan wa\n[02:04.61]samishisa wo gomakasu sube wo wasureteta\n[02:10.08]nando mo kono te wo tsunagi naoshi nagara\n[02:15.48]donna michi datte isshoni arukunda\n[02:20.74]hitori ja kanawanai yume wo egaita nara\n[02:26.14]kimi to futari de kanae ni yukunda\n[02:31.46]kimi to hanbun hitotsu no shiawase\n[02:36.80]butsukarisou na kurai hito ooi doyoubi\n[02:39.24]miushitakunai kimi no sonzai\n[02:41.87]kono toki nibai ni chikara haitteru te ni\n[02:44.89]kanjita nukumori to ai NO MORE CRY\n[02:47.56]asera JEANS no POCKET de hikatteru\n[02:50.27]kimi no keitai kizukasetakunai\n[02:52.87]damari komu watashi no naka no ko akuma\n[02:55.59]tada kimi ga inaito iya dakara...\n[02:58.28]nanika ga ubai sarisoude kowai\n[03:00.92]"taisetsu na hito"to tsunagattetai\n[03:03.71]omoi wa dare ni mo makenai\n[03:05.77]sou kono machi ni kirawareru kurai\n[03:07.85]te wo tsunagou\n[03:08.87]yowamu shi na hodo tsuyogatte shimau\n[03:13.63]demo muri da yo... naitemo ii ka na?\n[03:19.09]aki no kaze mou sugu deatta kisetsu\n[03:24.56]ano koro no watashi wa ai wo sagashiteta\n[03:32.62] \n[03:34.22]meguri megutte mo mata kimi ni aitai\n[03:39.49]hagurenai youni kono te wo tsunagunda\n[03:44.84]hitori ja nemurenai yume wa mirenai kara\n[03:50.12]donna fuan mo todokanai tokoro e\n[03:55.52]hitori ja kanawanai yume wo egaita nara\n[04:00.72]kimi to futari de kanae ni yukunda\n[04:06.23]kimi to hanbun hitotsu no shiawase\n[04:12.58] \n	/audio/Fullmetal Alchemist Brotherhood ED3 「Tsunaide t.mp3	Tsunaide te	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253887/covers/Fullmetal_Alchemist_Brotherhood_ED3_Tsunaide_te.jpg	1
465	465	464	263	[00:00.00] \n[00:06.31]Oh Love Me\n[00:07.84]Mister Oh Mister\n[00:10.91]Yume ja nai nara kikasete\n[00:14.58]Nee Mister mō Mister\n[00:18.22]Jirasareru hodo setsunai\n[00:21.98]Omoi dake ga abaredasu\n[00:25.71]Sono shisen ni make sō ni naru\n[00:29.44]Futari dake no abunai gēmu\n[00:33.09]Love is War\n[00:34.07]Love is War\n[00:34.99]Love is War\n[00:37.61] \n[00:39.88]Odorasete doramatikku wa kore kara\n[00:47.09]Iji waru na koi no yokan shibireru\n[00:53.56]Fureta yubi no saki ga unmei o machiwabite iru\n[01:01.31]Anata ni iwasetai\n[01:05.19]Kokoro no kabe o\n[01:08.36]Yaburu ai no kokuhaku\n[01:13.53]Oh Love Me\n[01:14.80]Mister Oh Mister\n[01:17.79]Yume ja nai nara kikasete\n[01:21.47]Nee Mister mō Mister\n[01:25.18]Jirasareru hodo setsunai\n[01:28.94]Omoi dake ga abaredasu\n[01:32.67]Sono shisen ni make sō ni naru\n[01:36.30]Futari dake no abunai gēmu\n[01:39.97]Love is War\n[01:40.98]Love is War\n[01:41.84]Love is War\n[01:44.99] \n[01:46.96]Madowasete sono ki ga nai soburi de\n[01:54.17]O tagai ni kakehiki o enjiteru\n[02:00.66]Furui eiga no yō na\n[02:04.52]Yasashī ketsumatsu wa iranai\n[02:08.69]Uso sae kobamanai\n[02:12.39]Ai ni idakarete\n[02:15.35]Motto kowarete mitai\n[02:20.77]Oh Love Me\n[02:21.78]Mister Oh Mister\n[02:24.86]Kirei na yokogao misete\n[02:28.50]Nee Mister mō Mister\n[02:32.26]Kuchizuke made ga tōku te\n[02:35.98]Utsukushi-sa ni kakusareta\n[02:39.58]Pyua na dake ja nai hitomi ni\n[02:43.37]Nomikomareru abunai gēmu\n[02:47.09]Love is War\n[02:48.04]Love is War\n[02:49.01]Love is War\n[02:51.97] \n[02:53.77]Anata wa itsu made\n[02:57.40]Kotae iwanai no\n[03:01.32]Ai no himitsu ima sugu akashite\n[03:12.37] \n[03:16.24]Oh Love Me\n[03:18.37]Oh Love Me\n[03:19.48]Mister Oh Mister\n[03:22.38]Yume ja nai nara kikasete\n[03:26.09]Nee Mister mō Mister\n[03:29.95]Anata no itoshī koe de\n[03:33.63]Omoi wa mō tomaranai\n[03:37.28]Isso subete ubaisatte\n[03:40.88]Futari dake no abunai gēmu\n[03:44.69]Love is War\n[03:45.58]Love is War\n[03:46.53]Love is War\n[03:48.39]Love is War\n[03:49.40]Love is War\n[03:50.39]Love is War\n[03:52.23]Love is War\n[03:53.13]Love is War\n[03:54.09]Love is War\n[03:57.77] \n	/audio/Kaguya sama_ Love is war OP 「Love Dramatic」.mp3	Love Dramatic	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254163/covers/Kaguya_sama_Love_is_war_OP_Love_Dramatic.jpg	1
306	306	300	245	[00:00.00] \r\n[00:00.90]Masshiro na keshiki ni ima sasowarete\r\n[00:06.41]Boku wa yuku yo\r\n[00:08.44]Mada minu sekai e\r\n[00:13.39] \r\n[00:24.67]Maigo no mama tabi shiteita\r\n[00:27.96]Nezumiiro no sora no shita\r\n[00:30.57]Higawari no chizu\r\n[00:32.96]Ikutsumo no yume ga nijiindeita\r\n[00:36.98]Itsuka wa sa\r\n[00:39.00]Chippoke na boku no kono hohaba demo\r\n[00:43.28]Ano kumo no mukou made ikeru ka na\r\n[00:49.11]Tsuyogatte\r\n[00:50.89]Kizutsuita kokoro sukashita you ni\r\n[00:55.62]Furidashita amatsubutachi ga\r\n[00:59.29]Ranhansha kurikaesu\r\n[01:02.54]Massugu na hikari ga kousa shite\r\n[01:08.06]Ikusaki mo tsugenu mama\r\n[01:11.63]Dokomademo tsukinukeru\r\n[01:14.52]Awai zanzou\r\n[01:16.18]Ryoume ni yakitsukete\r\n[01:20.43]Todoku hazu nanda\r\n[01:22.39]Mada minu sekai e\r\n[01:26.33] \r\n[01:35.00]Shirazu shirazu ni watteita no wa\r\n[01:38.61]Shirokuro no sutekkaa de\r\n[01:41.58]Daiji na mono\r\n[01:43.74]Bokura wa kakushiteshimatteita\r\n[01:47.70]Takara no ishi yori hana yori\r\n[01:51.41]Hoshi no akari yori kirei na\r\n[01:54.84]"Yume" to iu na no horoguramu o\r\n[01:58.31]Zawameki o\r\n[01:59.96]Hamidashite sakaratte\r\n[02:03.22]Itsuka egaita fuukei\r\n[02:06.31]Kuyashisa mo sabishisa mo ima\r\n[02:09.89]Awa mitai ni hajiketobu\r\n[02:13.19]Massugu na michi de\r\n[02:15.20]Tsumazuitatte\r\n[02:18.60]Kasabuta hagaretara\r\n[02:22.25]Ima yori kitto tsuyoku nareru\r\n[02:25.44]Masshiro na keshiki ni ima sasowarete\r\n[02:30.91]Boku wa yuku yo\r\n[02:32.95]Mada minu sekai e\r\n[02:38.05] \r\n[02:46.87]Kasumu sora no saki ni\r\n[02:53.03]Nijiiro no hikari\r\n[02:58.61]Ashita no kage ni furueru tabi ni\r\n[03:05.46]Tooku de boku o yobu koe ga shite\r\n[03:12.52] \r\n[03:17.51]Massugu na hikari ga\r\n[03:20.57]Chirabatte\r\n[03:23.20]Ameagari no gogo ni\r\n[03:26.94]Taba ni natte furisosogu\r\n[03:29.79]Mugen no guradeeshon ga ima mazariatte\r\n[03:35.61]Kono sora no shita donna toko ni ite mo\r\n[03:41.25]Kanarazu todoku hazu sa\r\n[03:43.68]Mada minu sekai e\r\n[03:49.09] \r\n	/audio/Fullmetal Alchemist Brotherhood OP2 「Hologram」.mp3	Hologram	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773254072/covers/Fullmetal_Alchemist_Brotherhood_OP2_Hologram.jpg	1
329	329	327	223	[00:00.00] \n[00:00.83]hand in hand let's go party night!\n[00:04.18]Kokoro odoru tomerarenai no\n[00:07.24]Naite waratte kimi to no kioku zutto wasurenai\n[00:14.32] \n[00:26.95]Hontou no jibun wa doko ni iru to ka\n[00:31.43]Otona ni naru tte taihen de\n[00:34.59]Ima wo wasuretemo ii ka na\n[00:37.68]Yoru ga matte iru kara\n[00:40.63]Kokoro wo hazumase aeru toki wo\n[00:44.86]Hashagimawareba\n[00:47.61]Tsutaetai omoi ni ima\n[00:51.71]Kidzuite shimaisou de\n[00:55.14]Kako to mirai osorete itemo\n[00:58.46]Karappo no mama ja ugokenai\n[01:02.16]Tanoshimeba it's all right!\n[01:07.41]Hajimeyou\n[01:08.96]Ya na koto zenbu wasurete kimi to issho ni odoriakaseba\n[01:15.45]Motto suteki na jibun ni nareru sonna ki ga suru no\n[01:21.25](Let's get together)\n[01:22.77]Owaranai goruden taimu gyutto chikadzuku kimi to no kyori wa\n[01:29.08]Tsukazuhanarezu mawari michi demo taisetsu ni shitai\n[01:35.86] \n[01:41.84]Yume miru jibun wa doko ni iru to ka\n[01:46.31]Mirai nante wakaranai\n[01:49.59]Aru ga mama de ikitai no!\n[01:52.71]Yoru wa matte kurenain dakara\n[01:56.35]Suki to kirai osorete itemo\n[01:59.67]Kokoro wa ima uso wa tsukenai\n[02:03.36]Tsutaenakya Never give up\n[02:08.80]Hajimeyou\n[02:10.10]Ya na koto zenbu wasurete hazukashisa wo kanagurisutetara\n[02:16.70]Motto suteki na jibun ni nareru sonna ki ga suru no\n[02:22.53](Let's get together)\n[02:23.87]Hajimari wa goruden taimu ano toki tsumugiatta kotoba\n[02:30.36]Sore wa tashika ni eien ni mieta yume no tsudzuki ne\n[02:37.31] \n[02:44.70]Mune hatte arukou\n[02:50.33] \n[02:52.92]Hajimeyou\n[02:54.49]Me to me ga au shunkan tanoshii hodo setsunaku natte\n[03:01.00]Bootto shitetara yoake wa sugu ni oikakete kuru yo\n[03:06.70](Let's get together)\n[03:08.09]hand in hand let's go party night!\n[03:11.46]Kokoro odoru tomerarenai no\n[03:14.60]Naite waratte kimi to no kioku zutto wasurenai\n[03:21.84]Korekara no koto mo koremade no koto mo\n[03:26.82]Sukoshizutsu chanyo subete wo ukeirerareru\n[03:31.68]Shinjirareru\n[03:33.68]Kimi ga iru nara\n[03:37.36] \n	/audio/Golden Time OP 「Golden Time」.mp3	Golden Time	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253677/covers/Golden_Time_OP_Golden_Time.jpg	1
332	332	330	264	[00:00.00] \n[00:20.92]zutto mae kara kimatteita youna\n[00:26.62]tooi mukashi kara wakatteta youna\n[00:32.49]mienai sen no ue wo tadoru youni\n[00:38.18]michibikare deai kousasuru Saison\n[00:44.14]senakaawase no hikari to kage no youni\n[00:49.80]tsuyoku hikareru Mystification\n[00:55.43]mimimoto de sasayaki yobu koe ni furimukeba\n[01:01.34]kizukanu uchi hirakareteita tobira\n[01:07.10]sukoshi no guuzen to hitsuzen wo tsunagu youni\n[01:12.77]ugokihajimeta futatsu no Histoire Ah\n[01:22.30] \n[01:24.60]kioku no ito wo taguriyoseru youni\n[01:30.14]pazuru no sukima wo umeteku youni\n[01:36.12]kataritsugareru unmei nimo nita\n[01:41.84]nagai michinori no saki ni aru Maintenant\n[01:47.74]hitotsu hitotsu no setsuna ni kizamareta\n[01:53.49]yuragu koto nai La clef a verite\n[01:59.15]temanekisareru youni chikazukeba mieru nazo\n[02:04.82]shirazu shirazu ni makikomareteyuku\n[02:10.75]mada shiranai sekai atarashiku mekuru tabi ni\n[02:16.42]tokiakasareru tashika na Histoire Ah\n[02:25.97] \n[03:13.24]itsuka mita yume no oku de\n[03:18.99]itsumo kanjiteita Reposer\n[03:24.57]dokoka hakanaku natsukashii koe\n[03:35.92]mimimoto de sasayaki yobu koe ni furimukeba\n[03:41.80]kizukanu uchi hirakareteita tobira\n[03:47.60]sukoshi no guuzen to hitsuzen wo tsunagu youni\n[03:53.38]ugokihajimeta futatsu no Histoire Ah\n[04:02.79] \n[04:05.00]zutto hatenaku tsuzuiteyuku\n[04:11.68] \n	/audio/Gosick OP 「Destin Histoire」.mp3	Destin Histoire	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252322/covers/Gosick_OP_Destin_Histoire.jpg	1
338	41	338	206	[00:00.00] \n[00:05.41]kaze hiku no kaze hiku no\n[00:09.84]o-futon nakute samui o-futon hagasarete samui\n[00:18.92]yoake ni anata ga kuru anata ga waratte iru\n[00:27.61]kitto boku ni wa mienai to omotte iru\n[00:36.34]sotto te wo nobashite ittai nani wo suru tsumori!?\n[00:45.97]kaze hiku no kaze hiku no\n[00:52.73]neta furi wo shite sugosu sukoshi dake atatakaku naru\n[01:01.34]tonari de anata ga nemuru urusai negoto wa mushi shite\n[01:21.65]aaa kinou no yoru gohan nani tabeta ka omoidasenai\n[01:32.77]aaa itsumo-doori no asa douka sekai ga horobanu you ni\n[01:46.27]kaze hiita tte shiranai no\n[01:50.67]o-futon nai to samui o-futon kakusarete samui\n[01:59.71]furueru yubisaki TACCHI toiki wa SUTOOBU mitai\n[02:08.60]kitto sugu ni wa okinai to omotte iru\n[02:17.58]zutto soba de mite'ru ittai nani wo suru tsumori?\n[02:31.24]ze ga hi de mo boku wa TANUKI tsutawaru\n[02:36.72]nukumori wa kounetsu?\n[02:40.34]marumaru karada futatsu kono sai akumu wa mushi shite\n[02:51.66]neta furi wo shite sugosu sukoshi dake atatakaku naru\n[03:00.59]tonari de anata ga nemuru urusai negoto wa mushi shite\n[03:14.01]kasanaru odeko ni KISU shite\n[03:19.11] 	/audio/Ground Control to Psychoelectric Girl ED 「Ruru」.mp3	Ruru	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253719/covers/Ground_Control_to_Psychoelectric_Girl_ED_Ruru.jpg	1
367	129	367	289	[00:00.00] \n[00:10.91]Garasu no kutsu tte kitto kyūkutsu ja warete shimau\n[00:21.01]Sore na no ni motomete shimau sutōrī\n[00:28.44] \n[00:31.09]Hen na shikō da tte bungaku-teki ja nai Rorīta\n[00:41.16]Sā dō kōshaku kinjirareta ai\n[00:46.67]Tokimeku romansu\n[00:50.80]Kokoro kara hoshī to negai\n[00:55.40]Kono junpaku no omoi o tayotte\n[01:01.61]Onaji hana nante ichirin mo sakanai wa\n[01:11.07]Suki ni natte kuremasu ka?\n[01:15.33]Kakushite nante okenai\n[01:21.07]Arinomama no watakushi anata dake ni\n[01:29.95]Hiraiteku sama o mitete\n[01:38.66] \n[01:46.92]Tsubomi o mi tatte hana no iro wa mada wakaranai\n[01:57.07]Manazashi de shibatte ite mo ī kedo\n[02:04.53] \n[02:07.15]Tsuzutte kita koto sarakedashitai kara, o negai\n[02:17.12]Hon no peiji makutte mite yo\n[02:22.85]Tokimeku romansu\n[02:26.81]Kokoro to yū garasu no kutsu ni suashi o tōshite mitanara\n[02:35.19]Hamatte Shimau ka mo... ... sono tsumasaki o sashikonde\n[02:47.20]Suki ni natte kuremasu ka?\n[02:51.35]Amai mitsu to kaori to\n[02:57.09]Azayaka na hanabira, anata dake o\n[03:06.15]Tsutsumikomu sama o mitete\n[03:14.49]Shūchishin to yū doresu o kite\n[03:19.65]Hontō no iro o kakushiteru no wa\n[03:24.65]Tatta hitori no tame dake nano\n[03:29.58]Hadakete iku kanjō\n[03:35.80] \n[03:37.55]Sukitōtte iru kara, kakushite nante okenai\n[03:47.67]Garasu no kutsu no yō na arinomama o\n[03:55.85] \n[03:57.08]Kitto suki ni natte kuremasu ne?\n[04:02.11]Hen na shikō ga kokoro o tsutsumikonda shunkan\n[04:12.39]Koi ni natte hiraiteku sama o,\n[04:21.72]Kawatteku omoi o mitete\n[04:31.21] \n	/audio/Hensuki ED 「Mubyuu no Hana」.mp3	Mubyuu no Hana	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253809/covers/Hensuki_ED_Mubyuu_no_Hana.jpg	1
368	368	367	249	[00:00.00] \n[00:00.52]Karadajuu ga "daisuki" tte sakebu no...\n[00:04.55]Tomaranai MY LOVE!\n[00:12.27] \n[00:13.94]Matataita shunkan ni koi shite dorama mitai da ne?!\n[00:21.30]Kakehiki shichatte ki ni narisugichatte yabai!\n[00:29.02]Fushigi na sekai ga ne mawaridasu\n[00:35.46]Kimi ni ne koi shite hirari fuwari\n[00:42.16]Tokubetsu da to wakatteru. hayaku tsutaenai to!\n[00:49.71]Zokuzoku shichau karamawari shiteru Beating Heart\n[00:56.18]Karadajuu ga "daisuki" tte sakebu no\n[01:00.18]Mou dou ni mo tomaranai!\n[01:04.13]Ippozutsu to wakaru kedo matenai no\n[01:10.06]Karadajuu ga "daisuki" tte sakebu no\n[01:14.27]Kontorooru dekinai!\n[01:17.96]Kossori to ne winku okuru kara\n[01:22.80]Kizuite kuremasu ka?\n[01:28.58] \n[01:30.67]Aikotoba mitai ni kisu shite\n[01:34.78]Mahou kakete mita\n[01:37.91]Kiiteru no ka na?\n[01:41.46]Gozen reiji wa chikai!\n[01:45.53]Watashi dake no kimi de ite hoshii\n[01:52.11]Migatte to shittetemo\n[01:55.84]Iki dekinai\n[01:58.70]Mada issho ni itai kara\n[02:02.77]Wazato ne toomawari\n[02:06.27]Zukizuki shichau\n[02:07.95]Kaeritakunai yo... tomete!\n[02:12.74]Karadajuu ga "daisuki" tte sakebu no\n[02:16.78]Bureeki tomaranai!\n[02:20.47]Manyuaru to ka shitteru kedo dame nan da mon\n[02:26.70]Karadajuu ga "daisuki" tte sakebu no\n[02:30.78]Kontorooru dekinai!\n[02:34.42]Kossori to ne haato wo nagetara\n[02:39.35]Furimuite kureru no?\n[02:43.31] \n[03:11.93]Karadajuu ga "daisuki" tte sakebu no\n[03:15.96]Mou dou ni mo tomaranai!\n[03:19.96]Ippozutsu to wakaru kedo matenai no\n[03:25.86]Karadajuu ga "daisuki" tte sakebu no\n[03:29.83]Kontorooru dekinai!\n[03:33.58]Kossori to ne winku okuru kara\n[03:38.42]Kizuite kuremasu ka?\n[03:42.66]Daisuki.\n[03:44.40]Suki ni natte kuremasu ka?\n[03:51.27] \n	/audio/Hensuki OP 「Daisuki」.mp3	Daisuki	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253899/covers/Hensuki_OP_Daisuki.jpg	1
375	375	222	258	[ti:Doraemon Stand by Me 2 ED 「Niji」]\n[ar:Masaki Suda]\n[al:Doraemon]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:18.40]\n[00:00.00]\n[00:17.55]Naite iin da yo\n[00:21.16]Sonna hitokoto ni boku wa sukuwaretan da yo\n[00:27.74]Honto ni arigatou\n[00:31.13]Nasakenai keredo darashinai keredo\n[00:37.86]Kimi wo omou koto dake de ashita ga kagayaku\n[00:44.37]Ari no mama no futari de ii yo\n[00:47.76]Hidamari mitsukete asobou yo\n[00:51.03]Beranda de mizu wo yaru kimi no\n[00:54.57]Ashimoto ni chiisana niji nee\n[01:01.49]Isshou soba ni iru kara isshou soba ni ite\n[01:08.54]Isshou hanarenai you ni isshou kenmei ni\n[01:14.44]Kitsuku musunda me ga hodokenai you ni\n[01:21.14]Kataku tsunaida te wo hanasanai kara\n[01:32.89]Mama no yasashisa to papa no nakimushi wa\n[01:39.92]Marude bokura no you de sa mirai ga itoshii\n[01:46.45]Ookina yume janakute ii yo\n[01:49.77]Jibunrashiku iretara ii yo\n[01:52.99]Hitoribocchi mayotta toki wa\n[01:56.36]Ano koro wo omoidashite aa\n[02:03.53]Samishii yoru wo hanbun boku ni azukete hoshii\n[02:10.18]Ureshii hibi wa juubun ni waraiatte itai\n[02:15.93]Donna kotoba demo tarinai yo na\n[02:22.69]Kimi no nukumori ni fureta sei ka na\n[02:48.57]Kazoku ya tomodachi no koto konna boku no koto\n[02:55.07]Itsumo daiji ni warau kara nakete kurun da yo\n[03:01.82]Nannimo nakatta sora ni potsun to kagayaite ita\n[03:08.42]“arigatou” ni kawaru kotoba zutto sagashite itan da\n[03:15.14]Isshou soba ni iru kara isshou soba ni ite\n[03:21.85]Isshou hanarenai you ni isshou kenmei ni\n[03:27.62]Kitsuku musunda me ga hodokenai you ni\n[03:34.21]Kataku tsunaida te wo hanasanai kara\n[03:41.49]Hanasanai kara\n[03:44.95]	/audio/Doraemon Stand by Me 2 ED 「Niji」.mp3	Niji	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253745/covers/Doraemon_Stand_by_Me_2_ED_Niji.jpg	1
376	235	235	260		/audio/Eden of the East Movie 2 ED 「after laughter」.mp3	after laughter	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252413/covers/Eden_of_the_East_Movie_2_ED_after_laughter.jpg	1
384	130	349	257	[ti:Hanasaku Iroha OP 「Hana no Iro」]\n[ar:nano.RIPE]\n[al:Hanasaku Iroha]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:16.51]\n[00:00.00]\n[00:08.19]Namida no ame ga hoo wo tataku tabi ni utsukushiku\n[00:38.05]Kudaranai ruuru kara hamidasezu ni naite ita boyakesugita mirai chizu\n[00:49.15]Surihetta kokoro wo umetakute atsumeta iranai mono bakari\n[00:58.94]Baibai ano itoshiki hibi wa modori wa shinai kara\n[01:09.14]Hiraite yuku chiisaku tojita kokoro ga yoru no sumi de shizuka ni\n[01:19.53]Irodzuiteku motto fukaku yasashiku asa no hikari wo ukete\n[01:30.46]Namida no ame ga hoo wo tataku tabi ni utsukushiku\n[01:45.75]Dareka no ashita wo tada ureetari nageitari suru koto ga yasashisa nara\n[01:56.15]Surihetta kokoro wa omou yori mo kantan ni umerare ya shinai ka na\n[02:06.16]Nanikai datte machigaeru kedo owari wa shinai nara\n[02:16.20]Warattetai na\n[02:36.14]Tojite yuku zutto kakushiteta kizu ga yoru no sumi de shizuka ni\n[02:47.88]Tsunagatteku itsuka hagureta subete ga asa no hikari wo ukete\n[02:58.62]Hiraite uku chiisaku tojita kokoro ga yoru no sumi de shizuka ni\n[03:09.18]Irodzuiteku motto fukaku yasashiku asa no hikari wo ukete\n[03:19.91]Chikadzuiteku nando to naku yoru wo koe kinou yori sora no hou e\n[03:29.99]Tama ni karenagara sou shite mata hikari ni me wo hosome fukaku kokyuu wo shite\n[03:41.32]Namida no ame ga hoo wo tataku tabi ni utsukushiku\n[03:54.07]	/audio/Hanasaku Iroha OP 「Hana no Iro」.mp3	Hana no Iro	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253707/covers/Hanasaku_Iroha_OP_Hana_no_Iro.jpg	1
392	389	385	276		/audio/Higurashi Rei OP 「Super Scription of Data」.mp3	Super Scription of Data	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773252148/covers/Higurashi_Rei_OP_Super_Scription_of_Data.jpg	1
403	403	403	296	[00:00.00] \n[00:31.35]Hisashiburi ni sa yume wo mitanda\n[00:37.63]Tsuki ga kirei na yoru ni\n[00:43.79]"Mata ashita ne" to te wo furu kimi no\n[00:49.71]Sugata ga nagori oshikute\n[00:55.91]Nagasode no shatsu ni mioboe aru michi\n[01:01.75]Sukoshi sabishisou ni mieta\n[01:07.18]Mune ga kurushiku naru kedo atatakai\n[01:14.16]Kizuita fuyu no asa da\n[01:20.74]Yakusoku suru yo\n[01:25.95]Chikaku ni iru kara mienai mono hodo\n[01:32.83]Daiji ni suru yo\n[01:38.13]Kotoba ni dekinaindakedo ne\n[01:43.47] \n[01:45.36]Itsumo to onaji keshiki ga sukoshi\n[01:50.99]Chigatte mieta ki ga shite\n[01:56.90]Bonyari ni ukabu kimi no egao ga\n[02:03.21]Ashidori wo karuku saseru\n[02:09.44]Nagai kami no ke wo Nabikaseru kaze wa\n[02:15.31]Kokoro no oku wo yurasu\n[02:20.76]Mada mita koto nai kao ga arundana\n[02:27.72]Kizuita samuzora no shita\n[02:34.02]Kanjiteiru yo\n[02:39.34]Atarimae no koto hodo taisetsu dayo\n[02:46.27]Omoidasu yo\n[02:51.69]Kakegae no nai hibi no koto\n[02:56.07] \n[03:23.18]Yakusoku suru yo\n[03:28.55]Chikaku ni iru kara mienai mono hodo\n[03:35.24]Daiji ni suru yo\n[03:40.70]Kotoba ni dekinaindakedo ne\n[03:45.88]Ohh, Zutto taisetsu da yo\n[03:53.05]Kono kimochi wo sodatete itai\n[03:59.93]Soba ni iru yo\n[04:05.31]Warau kao mo okoru kao mo\n[04:11.44]Zenbu chikaku de mitetai na\n[04:16.54] \n	/audio/Horimiya ED 「Yakusoku」.mp3	Yakusoku	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252143/covers/Horimiya_ED_Yakusoku.jpg	1
412	158	412	275	[00:00.00] \n[00:01.73]Sakura no yohou mo munashiku\n[00:06.97]Ooame ga hana wo chiraseta\n[00:16.46]Shigatsu no kaze\n[00:18.82]Sukoshi samukute\n[00:21.56]Yoru wa mada nagakute\n[00:24.23] \n[00:25.94]Shiketta hanabi no nukegara\n[00:31.24]Oshiire de deban wo matta\n[00:40.36]Kemutagatteru\n[00:43.02]Demo ureshisou na\n[00:45.07]Kimi wo ukabeta\n[00:48.82] \n[00:49.03]Hon wo yomikonde\n[00:51.99]Kimi wa mane shidashite\n[00:55.05]Itsu no ma ni ka hiza no\n[00:57.24]Ue de nemutteita aki\n[01:01.03]Samui no wa iya tte\n[01:04.03]Taion wakeatte\n[01:06.38]Boku wa kogoeru kisetsu mo\n[01:10.98]Anagachi iya janakunatte\n[01:17.62] \n[01:19.54]Arigatou mo\n[01:20.98]Sayonara mo\n[01:22.35]Koko ni irun da yo\n[01:25.29]Gomen ne mo\n[01:27.05]Aitai yo mo\n[01:28.53]Nokotta mama da yo\n[01:31.75]Ureshii yo mo\n[01:33.02]Sabishii yo mo\n[01:34.57]Okizari nan da yo\n[01:37.39]Koishii yo mo\n[01:39.14]Kurushii yo mo\n[01:40.69]Iete inain da yo\n[01:43.85]Mata kaze ga fuite\n[01:47.46]Omoidashitara\n[01:50.43]Haru natsu\n[01:53.40]Aki fuyu\n[01:55.85]Meguru yo\n[01:57.39] \n[02:20.57]Gohan no aji\n[02:21.77]Hana no iro\n[02:23.15]Kakou no nai amai kaori\n[02:26.09]Hitohada wo suuji janaku\n[02:29.09]Shokkaku ni kizande kureta\n[02:32.42]Komaku ni wa Ah\n[02:35.35]Tokubetsu na Ah\n[02:38.56]Gokan no subete wo\n[02:40.45]Betsumono ni kaete kureta\n[02:46.26] \n[02:52.14]Ima sara ne\n[02:53.68]Arekore ne\n[02:55.19]Arigatou mo\n[02:56.46]Sayonara mo\n[02:58.25]Koko ni irun da yo\n[03:01.10]Gomen ne mo\n[03:02.72]Aitai yo mo\n[03:04.07]Sodatte irun da yo\n[03:07.41]Ureshii yo mo\n[03:08.68]Sabishii yomo\n[03:10.24]Kotoba ni natta yo\n[03:13.20]Koishii yo mo\n[03:14.89]Kurushii yo mo\n[03:16.37]Itoshikunatta yo\n[03:19.51]Mata kaze ga fuite\n[03:23.15]Kimi ga sekashitara\n[03:26.08]Sorosoro\n[03:29.07]Ikanakya\n[03:31.55]Boku no ban\n[03:36.77] \n[03:37.73]Nanzenkai\n[03:39.22]Nanmankai demo\n[03:41.06]Omoikaeshitemo ii\n[03:43.76]Nanzenkai\n[03:45.17]Nanmankai\n[03:46.78]Tsugi no kisetsu no tame ni\n[03:49.82]Haru ga kite\n[03:51.31]Natsu ga kite\n[03:52.82]Aki ga kite\n[03:54.26]Fuyu ga kuru\n[03:55.97]Soshite mata haru ni\n[03:58.86]Tsugi no mata haru ni\n[04:01.88]Atarashii kimi to\n[04:05.04]Yagate kuru haru ni\n[04:08.12] \n	/audio/I Want To Eat Your Pancreas ED Theme 「Shunkashu.mp3	Shunkashuutou	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773254065/covers/I_Want_To_Eat_Your_Pancreas_ED_Theme_Shunkashuutou.jpg	1
413	158	412	183	[00:00.00] \n[00:01.95]Yoru wo koete\n[00:04.14]Yami wo nukete\n[00:06.33]Mukae ni yukou\n[00:08.67]Hikaru asa mo\n[00:10.82]Ame mo niji mo\n[00:12.88]Ima kara subete mukae ni yuku yo\n[00:21.04] \n[00:36.32]Kurai kurai kurai heya wo tsukutte\n[00:38.51]Me wo fusageba kizukanai\n[00:40.85]CHIKU CHIKU CHIKU CHIKU\n[00:41.83]Kokoro wa itamanai\n[00:44.88]Mabushii mabushii hikari saegiru\n[00:47.02]KAATEN hiraku no wa\n[00:48.93]Hoka naranu boku da\n[00:50.42]Furueta boku no te da\n[00:53.83]Shiranakerya yoi koto da to\n[00:56.11]Nigeru no wa mou yame\n[00:58.15]Miniku sa mo fugaina sa mo\n[01:00.38]Terashite\n[01:01.40]Nomihoshitara\n[01:02.57]Atarashii jibun darou\n[01:05.84]Yoru wo koete\n[01:07.94]Yami wo nukete\n[01:10.14]Mukae ni yukou\n[01:12.36]Kizu no umi mo nayamu mori mo\n[01:16.54]Itowanai\n[01:20.03]Doku wo nonde sa\n[01:23.42]Yoru wo koete\n[01:25.66]Yami wo nukete\n[01:27.87]Mukae ni yukou\n[01:30.10]Hikaru asa ni me somukezu ni\n[01:34.29]Ima matataki wo kurikaesu no sa\n[01:42.92] \n[01:57.61]Ame furasu kumo wo nozokeba\n[02:00.19]Me wo utsu wa itami\n[02:02.00]Nukarumu ashimoto\n[02:03.79]Ojike tsuitara\n[02:05.16]Nigedashitara\n[02:06.50]Hirundara\n[02:07.56]Utsumuitara\n[02:08.65]Shikou no isshun no\n[02:10.94]Niji wo nogasu'n da\n[02:13.13]Ah\n[02:14.25]Yoru wo koete\n[02:16.28]Yami wo nukete\n[02:18.30]Mukae ni yukou\n[02:20.55]Kizu no umi mo nayamu mori mo\n[02:24.83]Itowanai\n[02:28.38]Doku wo nonde\n[02:30.75]Saa\n[02:31.84]Yoru wo koete\n[02:33.89]Yami wo nukete\n[02:36.07]Mukae ni yukou\n[02:38.27]Hikaru asa ni me somukezu ni\n[02:42.45]Ima mabataki wo kurikaeshite\n[02:48.39]Nando demo mukae ni yuku yo\n[02:54.65] \n	/audio/I Want To Eat Your Pancreas OP Theme 「Fanfare」.mp3	Fanfare	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253755/covers/I_Want_To_Eat_Your_Pancreas_OP_Theme_Fanfare.jpg	1
415	414	414	92	[00:00.00] \r\n[00:16.22]Don't think much if you wanna get us\r\n[00:18.30]Don't think much where the head is\r\n[00:20.02]F*ck you hard if you get us\r\n[00:21.88]Change don't stop, never let it\r\n[00:23.64]Knock, knock, knock yeah they better let us\r\n[00:25.97]Where we go, never get us\r\n[00:27.60]F*ck you hard if you get us (get us)\r\n[00:30.07]There's nowhere to go\r\n[00:32.86]But up\r\n[00:34.74]And there's no stopping, there's no stopping our souls\r\n[00:40.44]Of love\r\n[00:42.79]Heading straight for, heading straight for the clouds\r\n	/audio/ID_Invaded ED2 「UP」.mp3	UP	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252219/covers/IDInvaded_ED2_UP.jpg	1
416	414	414	228	[00:00.00] \r\n[00:09.00]See you on the other side\r\n[00:11.00]Once, it's decided\r\n[00:12.62]Moment of life\r\n[00:15.63]Tokai no zattō o\r\n[00:17.29]Kakikesu noizu\r\n[00:18.66]Mimi fusagu fūdo o fukaku kaburu choice\r\n[00:22.28]Mō mayowanai\r\n[00:23.91]Mō mayowanai\r\n[00:25.68]Uh oh eh yo\r\n[00:29.35]People talk too much\r\n[00:30.72]But I just shut it up\r\n[00:32.14]Ore ni wa kankei nai\r\n[00:33.46]I can see you lie\r\n[00:34.58]It's all black and white\r\n[00:36.02]So I close my eyes\r\n[00:38.42]Going off the edge\r\n[00:39.72]To the other side\r\n[00:43.12]Where's a way out, way out\r\n[00:45.87]To the other side\r\n[00:47.49]Diving deep into the night\r\n[00:49.30]Hane hiroge way out way out\r\n[00:52.90]Leave it all behind\r\n[00:55.42]I'll see you on the other side (side)\r\n[00:58.84]I'll see you on the other side (side)\r\n[01:02.50]Hoka ni michi wa nai\r\n[01:05.84]Ore ni wa kore shika nai\r\n[01:08.20]Mō modoranai\r\n[01:09.98]On the other side\r\n[01:13.06]Doitsu mo koitsu mo\r\n[01:14.59]Jibun no koto\r\n[01:16.11]Are mo kore mo sore mo hoshi-garu yo\r\n[01:19.58]Yokubō tsukinai yokubō tsukinai\r\n[01:22.87]Mō ī yo\r\n[01:26.76]Wanting way too much\r\n[01:28.17]Haven't you had enough\r\n[01:29.38]Ki wa sunda kai\r\n[01:30.79]Haki sō na kurai afureru sekai\r\n[01:33.49]So I close my eyes\r\n[01:35.54]Going off the edge\r\n[01:36.90]To the other side\r\n[01:40.38]Where's a way out, way out\r\n[01:43.41]To the other side\r\n[01:44.75]Diving deep into the night\r\n[01:46.63]Hane hiroge way out way out\r\n[01:50.14]Leave it all behind\r\n[01:52.84]I'll see you on the other side (side)\r\n[01:56.27]I'll see you on the other side (side)\r\n[01:59.91]Hoka ni michi wa nai\r\n[02:03.10]Ore ni wa kore shika nai\r\n[02:05.62]Mō modoranai\r\n[02:07.19]On the other side\r\n[02:10.17]I'll see you on the other side (side)\r\n[02:13.80]Hoka ni michi wa nai\r\n[02:16.96]Ore ni wa kore shika nai\r\n[02:19.50]Mō modoranai\r\n[02:21.22]On the other side\r\n[02:22.81] \r\n[02:49.80]Where's a way out, way out\r\n[02:52.99]To the other side\r\n[02:54.30]Diving deep into the night\r\n[02:56.26]Hane hiroge way out way out\r\n[02:59.73]Leave it all behind\r\n[03:02.31]I'll see you on the other side (side)\r\n[03:05.77]I'll see you on the other side (side)\r\n[03:09.50]Hoka ni michi wa nai\r\n[03:12.74]Ore ni wa kore shika nai\r\n[03:15.25]Mō modoranai\r\n[03:16.75]On the other side\r\n[03:19.71]I'll see you on the other side (side)\r\n[03:23.41]Hoka ni michi wa nai\r\n[03:26.35]Ore ni wa kore shika nai\r\n[03:29.03]Mō modoranai\r\n[03:30.87]On the other side\r\n[03:32.62] \r\n	/audio/ID_Invaded ED「Other Side」.mp3	Other Side	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252207/covers/IDInvaded_ED_Other_Side.jpg	1
419	419	418	220	[00:00.00] \n[00:14.33]Ichi byō-goto ni kimi no suki na toko ga fuete shimau n da\n[00:19.04]Hōzuri suru tabi dō de mo yoku naru yo\n[00:23.94]Sekai-chū no izakoza mo kono shunkan ni wa kanawanai\n[00:28.44]Dekire ba asu mo myōgonichi mo zutto\n[00:33.12]Dekiai chūdoku de shigoto saboritai\n[00:38.48]Ka hogo o koeta shinpai-sei ga\n[00:43.47]Muda ni boku o tsuyoku saseteku\n[00:48.25]Kimi o mamoru to kimeta n da\n[00:51.53]Sono egao no tame nara\n[00:53.86]Masayoshi da tte teki ni naru\n[00:59.73]This is yūsha but zannen!?\n[01:02.44]Kimi ni mero mero\n[01:05.15]Deredere mo ichaicha mo\n[01:07.56]Oya baka makki shōjō\n[01:10.31]Kimi sae ire ba zannen yūsha de kamawanai\n[01:15.16]Da kara zutto soba ni ite\n[01:17.30]Bōken mo dekinai kurai\n[01:34.99]Hiza no ue no tei ichi wa\n[01:37.07]Itsu mo kimi no tame ni akete aru\n[01:39.47]Nanni mo shinpai shinakute ī n da yo\n[01:44.47]Tamani wa ehon o issho ni yomō\n[01:49.29]Kimi no negao o mimamoru tabi ni\n[01:54.48]Yume no naka ni mo o jama shitakunaru\n[01:59.31]O deko-awase tashikamete mita\n[02:01.64]Masaka okosu nante!?\n[02:04.28]Neoki mo yappari kawaī nā\n[02:11.80]This is yūsha but sai Osore!?\n[02:13.72]Mukau Tokoro teki nashi desu!!\n[02:16.78]Uchi no musume no tame nara ba\n[02:19.20]Rasubosu mo ichikoro na n desu\n[02:22.12]Kimi sae ire ba\n[02:23.35]Densetsu yūsha ni nareru n da\n[02:25.90]Kore kara mo soba ni ite\n[02:28.12]Bōken mo dekinai kurai\n[02:53.13]I am yūsha yappa zannen?\n[02:55.01]Da tte shō ga nai jan\n[02:57.58]Me ni irete mo itaku nai yo\n[03:00.70]Kawaii＝ seigi na n desu!!\n[03:27.18](This is yūsha but zannen!? )\n[03:29.44](This is yūsha but zannen!? )\n[03:31.90](This is yūsha but zannen!? )\n[03:34.40](chucchucchucchuru churucchu)\n[03:37.61] 	/audio/If it_s for My Daughter, I_d Even Defeat a Demo.mp3	This is Yuusha, but Zannen!?	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254097/covers/If_it_s_for_My_Daughter_I_d_Even_Defeat_a_Demon_Lord_ED_This_is_Yuusha_but_Zannen.jpg	1
423	423	422	301	[00:00.00] \n[00:00.86]Shōsū ten no kanata ni\n[00:04.50]Kanarazu aru kibō mirai e tsunage\n[00:11.13] \n[00:22.32]Kakuritsu ron ga michibiku answer\n[00:27.49]Nozomanai genjitsu ni kuchibiru o kanda\n[00:32.71]Tsunawatari sae itowanu honnō ga\n[00:36.84]Mune no oku de uzuiteru\n[00:41.78] \n[00:43.26]Iku-e ni mo (You can choose)\n[00:45.83]Bunki suru (either one)\n[00:48.40]Edawakare shita mirai de\n[00:52.79]'ri fujin' ni shibarareta\n[00:55.37]Jiyū tokihanatsu kotae o erabitoru\n[01:02.22]Kono te no saki ni fureta mono\n[01:05.71]Tsukamenakatta mono\n[01:08.07]Sore de mo mada akirametaku nai\n[01:12.60]ichika de mo tsukamitai to negatta\n[01:18.34]Kanōsei wa itsu mo koko ni aru\n[01:25.16] \n[01:38.81]Shikō kairo ni puroguramu sareta\n[01:44.06]Zeijaku na kokoro o appudeito shite\n[01:49.22]Baka ni sareru yo na\n[01:51.22]fikushon  o zenbu\n[01:53.58]Riaru ni kaete shimaō\n[01:58.39] \n[02:00.20]Erabu koto (You can choose)\n[02:02.19]Sore wa kitto (either one)\n[02:04.92]Seikai mo fu seikai mo nai\n[02:09.28]Shinjitai to nozonda\n[02:11.85]Mirai e tsumugu omoi no tsūka ten\n[02:18.75]Kono tenohira o tsutsumikomu nukumori wa zettai\n[02:24.64]Sūshiki de wa shōmei dekinai\n[02:29.10]Fu kanō da tte nurikaeru\n[02:32.56]Chikara ni kawatte yuku\n[02:34.98]Hitori ja nai to kizuketa n da\n[02:41.82] \n[02:50.69](My heart is unbreakable!)\n[02:52.80]Pinchi wa pinchi no mama de\n[02:55.81](My heart is unbreakable!)\n[02:57.76]Chansu no kao sura ogamenai\n[03:00.49]Shirahata nante mottenai\n[03:03.07]Shimen soka nara mayowanai\n[03:06.40]Katenakute mo make wa shinai\n[03:12.76] \n[03:25.23]Tayorinai kono ryōte ja\n[03:28.67]Tsukamikirenai kurai\n[03:31.16]Kizuke ba hora egao ga atta n da\n[03:35.46]Sasayaka na kono shiawase ga\n[03:38.98]Atarimae ni kawaru mirai o tsukame\n[03:45.60]Kono te no saki ni fureta mono\n[03:48.94]Tsukamenakatta mono\n[03:51.46]Sore de mo mada akirametaku nai\n[03:55.93]Shōsū ten no kanata ni kanarazu aru kibō\n[04:01.73]Zero ja nainda\n[04:05.06](Hope is never dead)\n[04:06.77]Kanō-sei wa itsu mo koko ni aru\n[04:13.52]Impossible is possible\n[04:13.77] \n[04:20.23] \n	/audio/Infinite Dendrogram OP 「Unbreakable」.mp3	Unbreakable	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253919/covers/Infinite_Dendrogram_OP_Unbreakable.jpg	1
424	424	424	229		/audio/Inou Battle wa Nichijou-kei no Naka de ED 「You Gotta Love Me!」.mp3	You Gotta Love Me!	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252463/covers/Inou_Battle_wa_Nichijou-kei_no_Naka_de_ED_You_Gotta_Love_Me.jpg	1
451	447	448	269		/audio/Jobless Reincarnation OP4 「Inori no Uta」.mp3	Inori no Uta	OP4	https://res.cloudinary.com/ddc6silap/image/upload/v1773252535/covers/Jobless_Reincarnation_OP4_Inori_no_Uta.jpg	1
473	473	472	198	[ti:Kanojo mo Kanojo OP 「Fuzaketenaize」]\n[ar:Necry Talkie]\n[al:Kanojo mo Kanojo]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:14.11]\n[00:00.00]\n[00:09.60]Fuzaketenaide majime ni kīte\n[00:14.40]Ima wa sonna chotto no zure nante\n[00:19.24]Ato ni shitoite hanashiaetara taratara\n[00:27.68]Atarimae to atarimae janai koto o\n[00:34.40]Narabete misete dochira no hou ga tsurai ka nantesa\n[00:40.69]Wakarya shinaize mieya shinaize\n[00:43.71]Itsuka totemo sutekina kotoba oshietekure\n[00:48.69]Dokidoki suru youna\n[00:50.66]Hora youchi de furachina wagamamana odori no naka de\n[00:59.70]Rurattata\n[01:00.97]ā iya iya iya\n[01:03.46]Iyana koto bakari me ni tsuku ndesu\n[01:06.55]Dare ga dō nattatte yoi yōna\n[01:09.19]Kimochi ni nacchau kara\n[01:12.34]Fuzaketenaide chanto kīte\n[01:15.74]Dare mo naguran de sumeba īna\n[01:18.94]Mada mienai risou desu\n[01:25.57]Fuzaketenaize\n[01:33.68]Fuzaketenaide tonari de kīte\n[01:39.10]Ima wa sonna hayarisutari no koto nante\n[01:44.17]Yoko ni nokete suki ni naretara\n[01:47.55]Akechi no hei no ura no ura de miteta\n[01:51.37]Chizu o zutto sutezu ni koko made kiteiru\n[01:55.23]"usonara īnoni "\n[01:57.12]Kedo ao o buchi maketa sora ga kimi o nirandeiruze\n[02:06.37]Mou toumei ni nacchimatta youna\n[02:09.51]Sore ga itai itai itai\n[02:12.16]Hontou ni itai\n[02:34.28]A ～ iyaiyaiya!\n[02:37.06]Iyana koto bakari chi ni narundesu\n[02:40.08]Nani ga dō nattatte ī yōna kimochi ni\n[02:44.02]Narenaikara\n[02:46.42]Yametaku natte hara kukutte\n[02:49.81]Nani mo uraman de sumeba īna\n[02:53.20]Mada mienai risōdesu\n[02:57.49]	/audio/Kanojo mo Kanojo OP 「Fuzaketenaize」.mp3	Fuzaketenaize	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253556/covers/Kanojo_mo_Kanojo_OP_Fuzaketenaize.jpg	1
488	488	488	240	[00:00.00] \n[00:40.09]Tadayotte kieta nichijou wa\n[00:45.69]Marude genjitsukan no nai yume no you de\n[00:50.66] \n[00:51.41]Wakaranai koto ga wakaranai kodomo no you na boku wo\n[00:58.69]Oboresou na koe de yonde iru\n[01:02.75](Why did you call me Crying Crying Crying ?)\n[01:06.62]Okubyou na no wa onaji hazu na no ni (he can't understand, has no need it)\n[01:12.26]Uketometai to konna ni mo negau no wa\n[01:17.65]Kokoro no kara wo sukitooru sakebi wo\n[01:23.22]Tsukisasu hahen wo nijimu honne wo\n[01:28.74]Terashidashita hitotsuhitotsu Taisetsu na anata da to\n[01:33.88]Shitte hoshii kara shitte itai kara (what a beautiful colors.)\n[01:43.81] \n[01:46.22]Gikochinai hyoujou ni kidzuku\n[01:51.81]Warai kata mo dokoka oite kita mitai\n[01:57.35]Kiri no naka fukaku maigo no kotae wo kitto zutto gushagusha na kao de sagashite iru\n[02:08.98](Why did you call me Crying Crying Crying ?)\n[02:12.70]Chikadzuite mitemo mieru hazu nai no ni (he can't understand, has no need it)\n[02:18.52]Nigedashitai to omou kono kimochi ni\n[02:23.91]Mitsumerareru to iki mo dekinai\n[02:29.46]Keredo anata ni\n[02:32.48]"Sore ga futsuu da yo. dakara mukiai nigenai koto soko ni imi ga aru" tte\n[02:40.11]Shitte hoshii kara\n[02:44.14] \n[02:57.07]Onaji mesen de onaji keshiki wo mite\n[03:02.57]Onaji oto wo kiite donna ni yorisottemo\n[03:08.02]Hito no kokoro wa tsutawaranakute.....\n[03:13.28]Dakara bokura wa kono omoi wo kotoba ni takusu\n[03:18.97]Uketometai to dokomademo negau no wa\n[03:24.55]Kokoro no kara wo tada nokku shi tsudzukete\n[03:30.06]Tsukisasu hahen ga tsukuru sukima ni\n[03:35.64]Sasu hikari no atatakasa taisetsu na anata ni mo\n[03:40.76]Shitte hoshii kara shitte itai kara (what a beautiful colors.)\n[03:50.88] \n	/audio/Kokoro Connect ED 「Kokoro no Kara」.mp3	Kokoro no Kara	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252331/covers/Kokoro_Connect_ED_Kokoro_no_Kara.jpg	1
492	492	488	258	[00:00.00] \n[00:15.79]Kaze ni hazumu so no koe meguru nichijou\n[00:21.45]rizumu\n[00:22.78]Futoshita hyojou no kimi ga mabushikute\n[00:30.00]Zawameki wo oboeta no wa itsukara dattan\n[00:35.62]darou\n[00:37.08]Mitsumeru saki ni wa nani ga matte iru\n[00:43.78] \n[00:44.68]Kirameki e to konekuto boku wo oikoshite\n[00:51.03]Nanairo ni tsunagatteku yo\n[00:57.94]Zenryoku de susumu michi hikari no ko wo\n[01:03.90]egaku you ni\n[01:05.32]Todoita sono egao nukumori wo shitta\n[01:12.25]Itsudatte koko ni aru takanari wo shinjite\n[01:18.67]yukou\n[01:19.36]Sou yatte umareteku asu ni naritain da\n[01:28.16] \n[01:46.38]Tatoeba hitorikiri de sora wo miageru hi\n[01:53.04]mo\n[01:53.58]Kokoro no keshiki wa kimi wo egaku kara\n[02:00.55]Tsuyogari mo zenbu oite tobikonde miyou\n[02:06.77]ka na\n[02:07.79]Dekiru koto wo hitotsu mitsukete yukou\n[02:15.29]Ameagari no konekuto omoidasu kioku\n[02:21.69]Yasashiisa ni tsutsumarete ita\n[02:28.93]Aitakute fureta no wa namae wo yobu sono\n[02:35.22]koe\n[02:35.82]Nandomo hibiku no wa setsunasa no sei\n[02:42.77]Itsuka wa sou itsuka wa... negai wo\n[02:48.08]dakishimetara\n[02:49.95]Shunkan wo kakenukeyou omoi no supiido de\n[02:58.37] \n[03:11.40]Zenryoku de susumu michi hikari no ko wo\n[03:17.31]egaku you ni\n[03:18.46]Todoita sono egao tada ureshikute\n[03:25.52]Itsudatte koko ni aru takanari wo shinjite\n[03:32.08]yukou\n[03:32.57]Sou yatte tsunagatteku mirai ni narou\n[03:41.40] \n	/audio/Kokoro Connect OP2 「Kimi Rhythm」.mp3	Kimi Rhythm	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253605/covers/Kokoro_Connect_OP2_Kimi_Rhythm.jpg	1
501	501	500	197	[00:00.00] \r\n[00:08.68]Furimuke ba yama bakari\r\n[00:16.48]Sonna kono machi ga\r\n[00:24.28]Anna ni mo iya datta no ni\r\n[00:32.11]Ima tada omoi wa masu bakari\r\n[00:38.94] \r\n[00:42.10]Hisashi-buri tte koe kaketa\r\n[00:49.90]Michibata no o jizō-san\r\n[00:57.73]Sukoshi dake tachidomari\r\n[01:05.72]Fukaku iki o sutte mata aruku\r\n[01:12.27] \r\n[01:15.76]Modorenai to wa wakatteru\r\n[01:23.39]Ima dake chotto ano koro ni\r\n[01:30.99]Yama ni mamorarete kawa de asonda\r\n[01:38.87]Karappo ni nattara ba chanto kaeru yo\r\n[01:45.80] \r\n[02:20.82]Ie no mae no kakine-goshi\r\n[02:28.27]Kawaranu koe kīta toki\r\n[02:35.71]Nayandeta koto ga chīsaku omoeta\r\n[02:43.64]Koko made kite mita kedo kyō wa kaeru yo\r\n[02:51.90]Chanto kaeru yo mata kondo ne\r\n[02:58.41] \r\n	/audio/Konosuba movie ED Theme 「My Home Town」.mp3	My Home Town	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773252388/covers/Konosuba_movie_ED_Theme_My_Home_Town.jpg	1
505	447	505	254	[ti:Land of the Lustrous ED 「Kirameku Hamabe」]\r\n[ar:Yuiko Ohara]\r\n[al:Land of the Lustrous]\r\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\r\n[ve:22.5.26]\r\n[length:04:14.04]\r\n[00:00.00]\r\n[00:15.55]Shiawase na toki ni me wo samasou\r\n[00:27.98]Asa ni kizukanu sukima de ne\r\n[00:37.78]Tsuki wa itsu no hi mo sugata kaete\r\n[00:44.69]Yami mo keshite shimau kara ne\r\n[00:51.74]Ariamaru mirai wa shiawase ka dou ka wa wakaranai\r\n[00:58.74]Kagiri aru kako yori ima wo erande okiagarou ka\r\n[01:11.77]Kokoro ga dokoka ni ukanderu yo\r\n[01:23.82]Warui yume kamo shirenai ne\r\n[01:33.38]Kioku wa itsudemo katachi kaete\r\n[01:40.26]Umi ni hisomi sora wo mau ne\r\n[01:47.30]Kagiri nai inochi wa nani wo tsutaeyou to shiteiru no\r\n[01:54.39]Kakeru tsuki to tomo ni susumu ka modoru dochira darou ka\r\n[02:05.93]Shio to suna ga uzumaku tokoro\r\n[02:12.55]Kako to mirai ga te wo futte\r\n[02:20.33]Mizu to tsuchi ga kasanatte\r\n[02:26.56]Kirameku hamabe de ima issho ni iru to tanoshii darou ne\r\n[03:09.18]Yasumi naku tsukihi wa saki ni susumou to shiteiru nara\r\n[03:15.96]Kieta kako wo ima no tomo ni erande sukoshi nemurou\r\n[03:27.44]Shio to suna ga koe wo awasete\r\n[03:34.85]Kako to mirai ga te wo totte\r\n[03:42.07]Mizu to tsuchi ni yorisotte\r\n[03:48.62]Kirameku hamabe de ima issho ni utau to tanoshii darou ne\r\n[04:02.45]	/audio/Land of the Lustrous ED 「Kirameku Hamabe」.mp3	Kirameku Hamabe	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254162/covers/Land_of_the_Lustrous_ED_Kirameku_Hamabe.jpg	1
523	523	523	290	[ti:Log Horizon ED 「Your song」]\n[ar:Yun*chi]\n[al:Log Horizon]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:50.11]\n[00:00.00]\n[00:14.46]Zutto zutto zutto\n[00:29.81]Hajimete kimi ni fureta hi sugoku dokidoki shita\n[00:37.31]Dakara tsuiteyukou tte kokoro ni kimeta\n[00:44.79]Hana ya kaze no kaori mo\n[00:48.51]Kono SUUPU no nioi mo\n[00:52.21]Kiechattemo issho ni iraretara ii ya\n[00:59.47]Chiisana omoi ga fukuramu oto ga shita\n[01:14.37]Kikoeru ai no uta motto soba ni isasete\n[01:21.66]Iro ya katachi wo kaemamotte ageru wa\n[01:29.14]Kikoeru ai no uta mitsumete irareru nara\n[01:36.50]Boyaketa hibi de sae itoshiku naru wa\n[01:43.21]Zutto zutto zutto\n[01:58.97]Kizutsuiteiru kimi ni koe mo kakerenai no\n[02:06.61]Semete sono senaka wo dakishimetai yo\n[02:13.80]Chiisana omoi ga hajikeru oto ga shita\n[02:28.98]Kikoeru ai no uta motto soba ni isasete\n[02:36.40]Iro ya katachi wo kaemamotte ageru wa\n[02:43.82]Kikoeru ai no uta mitsumete irareru nara\n[02:51.08]Fuwafuwa uita mama mo ii no kamo ne\n[02:57.58]Zutto zutto zutto\n[03:13.38]Kimi no kimochi ya tadashii kotae\n[03:20.69]Wakaranai mama dakedo\n[03:28.10]Mou sukoshi dake sunao ni nareba\n[03:35.48]Omoi tsutawaru ki ga shita\n[03:42.93]Kikoeru ai no uta motto soba ni isasete\n[03:50.10]Iro ya katachi wo kaemamotte ageru wa\n[03:57.73]Hontou wa kidzuiteta kidzukanai furi shiteta\n[04:04.67]Mamorareteiru no wa watashi dattanda\n[04:11.00]Zutto zutto zutto\n[04:26.54]La la la la la la la la la La la la la\n[04:37.26]la la la la la....\n[04:42.47]	/audio/Log Horizon ED 「Your song」.mp3	Your song	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252415/covers/Log_Horizon_ED_Your_song.jpg	1
526	526	523	216		/audio/Log Horizon S3 ED 「Blue Horizon」.mp3	Blue Horizon	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252667/covers/Log_Horizon_S3_ED_Blue_Horizon.jpg	3
532	532	532	263	[00:00.00] \r\n[00:02.25]INSIDE IDENTITY\r\n[00:04.69]Ibasho wa doko?\r\n[00:07.69] \r\n[00:17.65]Kanchigai ga hajida toka\r\n[00:20.04]Sunaosa ga itai toka\r\n[00:22.59]Dare ga nanto iou to\r\n[00:24.89]Tadashisa nante wakannaize\r\n[00:27.88]Futsuu ni nagarete iku nichijou ni\r\n[00:30.51]Murishite najimaseta\r\n[00:33.05]Shizunjimatta koseitachi wo\r\n[00:35.70]Kande nonde haite warau\r\n[00:38.68]Konna boku wo wakatte hoshii\r\n[00:42.83]Iitaikedo ienakutte\r\n[00:47.97]Nande dare mo wakatte kunnai no to\r\n[00:52.94]Omou no wa zeitakuna no ka na? Na no ka naa?\r\n[00:58.19]Kanjoutekina taiyou wa\r\n[01:03.43]Netsu wo age sugite dounika narisou\r\n[01:08.48]Sakebitakute shouganai\r\n[01:13.70]Gamushara ni motome teru IDENTITY\r\n[01:19.64]aa (INSIDE MY FEELING INSIDE MY JUSTICE\r\n[01:24.61]Jamashinaide ibasho wa doko?)\r\n[01:29.75] \r\n[01:40.10]"Kawaii~"tte dareka ga itte\r\n[01:42.92]Tonari de kodamashite\r\n[01:45.17]Atama ni "hatena" Ukabe\r\n[01:47.77]Nete okite kyou mo seiten\r\n[01:50.37]Kazatta dekoreeshon ga\r\n[01:52.89]Nigatena boku ga iru yo\r\n[01:55.49]Boku ni shika dekinai koto ga\r\n[01:58.06]Arutte no mo shittendakedo\r\n[02:00.59]Dou mirareteru ka ga shinpaina no?\r\n[02:05.55]Unazuku koto wa tadashii no?\r\n[02:10.78]"Hontou wa douna no ka" ga ki ni naru yo\r\n[02:15.76]Kotae wo sagasu no mitsuketai mitsumetai\r\n[02:20.78]Kodoku wo shitte ai wo shiru\r\n[02:25.97]Warikireru hodo otona janain daga\r\n[02:31.17]Sabishiikeredo yuzurenai\r\n[02:36.05]Boku dake no burenai IDENTITY aa\r\n[02:45.15] \r\n[03:02.98]Ikinokoru dake jadamesa\r\n[03:08.14]Nanika wo nokoshitaikara koko ni iru wake sa\r\n[03:13.18]Dareka ni moratta kairaku ga\r\n[03:18.42]Boku no shiawase to wa kagiranaize\r\n[03:23.83] \r\n[03:24.21]Namonai mainichidakedo\r\n[03:29.44]Imi wo kakuritsu dekiru hi wa kuru yo\r\n[03:34.23]Chuunibyou to yobarete mo\r\n[03:39.43]Moratoriamu no uzu no naka\r\n[03:44.57]Kanjoutekina taiyou wa\r\n[03:49.72]Netsu wo age sugite donika narisou\r\n[03:54.94]Sakebitakute shouganai\r\n[04:00.16]Gamushara ni motometeru IDENTITY\r\n[04:05.90]aa (INSIDE MY FEELING INSIDE MY JUSTICE\r\n[04:11.06]Jamashinaide ibasho wa doko?)\r\n[04:15.95]	/audio/Love Chunibyou and Other Delusions ED 「INSIDE I.mp3	INSIDE IDENTITY	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253889/covers/Love_Chunibyou_and_Other_Delusions_ED_INSIDE_IDENTITY.jpg	1
554	554	546	233	[ti:Maison Ikkoku OP4 「Sunny Shining Morning」]\n[ar:Kiyonori Matsuo]\n[al:Maison Ikkoku]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:23.4.20]\n[length:03:52.50]\n[00:00.00]\n[00:21.88]Mou sugu soko made\n[00:25.16]The Sunny, Shiny Morning\n[00:27.55]Tsugi no asa ga\n[00:31.63]Suigara-darake no\n[00:34.58]Yogoreta heya\n[00:36.63]Nozoku darou\n[00:39.70]Tell me why\n[00:41.70]Maria-sama\n[00:43.79]Yasashisa ni ueteru\n[00:48.83]Tell me why\n[00:50.60]Doushite itsumo ronrinesu\n[00:54.69]Yoru wa nagai\n[00:58.99]Jiinzu no hiza o\n[01:02.22]Kudaketa yume\n[01:04.37]Aoku nurasu\n[01:08.63]Burarusu no mune ga\n[01:11.39]Mabushisugiru\n[01:13.37]Kimi ga suki sa\n[01:26.49]Shawaa no kawari ni\n[01:29.98]Ame no machi [kanji: tokai] o\n[01:32.29]Samayou no sa\n[01:36.21]Ningen yametai\n[01:38.94]Toki sae arukedo\n[01:41.28]Yamerarenai\n[01:44.26]Show me how\n[01:46.22]Otoko nara\n[01:48.27]Isagiyoku ikina yo\n[01:53.40]Show me how\n[01:55.17]Ichidokiri no ai\n[01:59.32]Sotto daite\n[02:03.66]Hush Baby, U... U...\n[02:08.41]Nakanaide Sleep Tight\n[02:13.36]Sabishisa o\n[02:15.39]Moyashitekure\n[02:19.15]Oh! My burning heart\n[02:40.16]Can't you see\n[02:41.61]Sasakureta\n[02:43.77]Omoide ga\n[02:46.56]Itai yo\n[02:48.99]Can't you see\n[02:50.56]Namida dore kurai\n[02:54.50]Taereba ii\n[02:58.47]Itsuka biru no machi\n[03:02.36]Fushigisou sakasete\n[03:07.23]Show me how\n[03:09.00]Oresouna kimi o\n[03:12.99]Daite ageru\n[03:17.78]Mou sugu soko made\n[03:20.41]The Sunny, Shiny Morning\n[03:22.73]Tsugi no asa ga\n[03:26.68]Suigara-darake no\n[03:29.74]Yogoreta heya\n[03:32.17]Nozoku darou\n[03:37.15]	/audio/Maison Ikkoku OP4 「Sunny Shining Morning」.mp3	Sunny Shining Morning	OP4	https://res.cloudinary.com/ddc6silap/image/upload/v1773253795/covers/Maison_Ikkoku_OP4_Sunny_Shining_Morning.jpg	1
585	414	414	177	[ti:ID:Invaded OST Theme「Samurai 45」]\n[ar:Miyavi]\n[al:ID: Invaded]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:02:56.95]\n[00:00.00]\n[00:00.52]We can go, we can go like a Samurai\n[00:04.20]We can go, we can go like a Samurai\n[00:07.49]Iza mairō iza mairō like a 45\n[00:11.21]Oh oh oh oh\n[00:12.48]Do it like a Samurai\n[00:20.77]I'm on a mission\n[00:22.71]Shinjiru wa my decision\n[00:26.59]This is my moment Imma take it\n[00:29.74]Ichido shika nai kono butai hade ni chiritai\n[00:34.70]Listen\n[00:36.81]Atonihikenai reason\n[00:40.27]It's all or nothing, till I make it\n[00:43.63]Nigeru kurainara\n[00:46.34]I would die like a Samurai\n[00:49.00]We can go, we can go like a Samurai\n[00:52.53]We can go, we can go like a Samurai\n[00:55.97]Iza mairō iza mairō like a 45\n[00:59.55]Oh oh oh oh\n[01:00.84]Do it like a Samurai\n[01:15.97]I have a vision\n[01:18.12]Kogeru hodo no ambition\n[01:21.67]I scream it loud so you can hear me\n[01:24.40]Mō yuraganai\n[01:26.55]This is do or die like a Samurai\n[01:29.98]We can go, we can go like a Samurai\n[01:33.38]We can go, we can go like a Samurai\n[01:36.70]Iza mairō iza mairō like a 45\n[01:39.98]Oh oh oh oh\n[01:41.50]Do it like a Samurai\n[01:57.41]We can go, we can go like a Samurai\n[02:01.14]We can go, we can go like a Samurai\n[02:04.42]Iza mairō iza mairō like a 45\n[02:07.70]Oh oh oh oh\n[02:09.29]Do it like a Samurai\n[02:11.41]We can go, we can go like a Samurai\n[02:14.72]We can go, we can go like a Samurai\n[02:17.91]Iza mairō iza mairō like a 45\n[02:21.38]Oh oh oh oh\n[02:22.86]Do it like a Samurai\n[02:25.13]We can go, we can go like a Samurai\n[02:28.29]We can go, we can go like a Samurai\n[02:31.70]Iza mairō iza mairō like a 45\n[02:35.22]Oh oh oh oh\n[02:36.78]Do it like a Samurai\n[02:38.46]	/audio/ID_Invaded OST Theme「Samurai 45」.mp3	Samurai 45	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253883/covers/IDInvaded_OST_Theme_Samurai_45.jpg	1
593	593	546	165		/audio/Maison Ikkoku OP3 「Suki sa」.mp3	Suki sa	OP3	https://res.cloudinary.com/ddc6silap/image/upload/v1773252772/covers/Maison_Ikkoku_OP3_Suki_sa.jpg	1
601	596	595	189	[00:00.00] \r\n[00:03.50]Get ready, wake your psyche up, MOB!\r\n[00:06.26]Get ready, dig your anger up, MOB!\r\n[00:09.32]Get ready, wake your psyche up, MOB!\r\n[00:12.19]Get ready!\r\n[00:14.11]Coming down\r\n[00:15.70]Could you feel your satisfaction?\r\n[00:19.81]You’re a MOB\r\n[00:21.23]Can’t you feel your own frustration?\r\n[00:25.69]Coming down\r\n[00:27.15]Could you feel your satisfaction?\r\n[00:31.30]You’re a MOB\r\n[00:32.69]What you want to be ima?\r\n[00:35.04]Hansha shiteku kanjou wa mi ni matotte break it down\r\n[00:42.79]Genkai koe mieru keshiki wa\r\n[00:46.46]99.9! 99.9!\r\n[00:49.20]Shoutai fumei no paasenteeji\r\n[00:53.86]Kurai my life\r\n[00:55.27]Kurai my psyche\r\n[00:56.67]Kurai my heart in such commonplaces!\r\n[00:59.62]Is that your ideal?\r\n[01:01.00]Is that your mind?\r\n[01:02.27]Gyaku ni naru toki hajimaru\r\n[01:05.24]The MOB is alive\r\n[01:06.67]The MOB is high\r\n[01:08.09]The MOB is staying frustrated, aren't you?\r\n[01:10.95]Is that your ideal?\r\n[01:12.23]Is that your mind?\r\n[01:13.86]Ima sugu Your life is your own\r\n[01:17.86]Get ready, wake your psyche up, MOB!\r\n[01:20.58]Get ready, dig your anger up, MOB!\r\n[01:23.45]Get ready, wake your psyche up, MOB!\r\n[01:26.36]Get ready!\r\n[01:28.49]Coming down\r\n[01:29.92]Could you feel your satisfaction?\r\n[01:34.24]You’re a MOB\r\n[01:35.66]Can’t you feel your own frustration?\r\n[01:40.20]Coming down\r\n[01:41.29]Could you feel your satisfaction?\r\n[01:45.62]You’re a MOB\r\n[01:47.01]What you want to be, kono butai no shuyaku wa boku da\r\n[01:54.68] \r\n[02:02.27]Kurai my life\r\n[02:03.93]Kurai my psyche\r\n[02:05.24]Kurai my heart in such commonplaces!\r\n[02:08.21]Is this my ideal?\r\n[02:09.62]Is this my mind?\r\n[02:10.86]Aa, kotae wo sagashiteru\r\n[02:13.83]The MOB is alive\r\n[02:15.24]The MOB is high\r\n[02:16.77]The MOB is staying frustrated, aren't you?\r\n[02:19.59]Is this the day?\r\n[02:20.94]Is this the time?\r\n[02:22.39]Ah, desperately\r\n[02:25.36]Kurai my life\r\n[02:26.69]Kurai my psyche\r\n[02:28.20]Kurai my heart in such commonplaces!\r\n[02:31.10]Is that your ideal?\r\n[02:32.44]Is that your mind?\r\n[02:33.80]Gyaku ni naru toki hajimaru\r\n[02:36.65]The MOB is alive\r\n[02:38.12]The MOB is high\r\n[02:39.56]The MOB is staying frustrated, aren't you?\r\n[02:42.43]Is that your duty?\r\n[02:43.80]Is that your why?\r\n[02:45.30]Ima sugu Your life is your own\r\n[02:49.40]Get ready, wake your psyche up, MOB!\r\n[02:52.18]Get ready, dig your anger up, MOB!\r\n[02:55.07]Get ready, wake your psyche up, MOB!\r\n[02:58.00]Get ready!\r\n[03:00.35] \r\n	/audio/Mob Psycho 100 Season 2 OP「99.9」.mp3	99.9	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253829/covers/Mob_Psycho_100_Season_2_OP_99.9.jpg	1
668	668	627	190		/audio/Naruto Shippuden ED27 「Black Night Town」.mp3	Black Night Town	ED27	https://res.cloudinary.com/ddc6silap/image/upload/v1773252883/covers/Naruto_Shippuden_ED27_Black_Night_Town.jpg	1
705	665	627	228	[ti:Naruto Shippuden OP9 「Lovers」]\n[ar:7!!]\n[al:Naruto]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:48.40]\n[00:00.00]\n[00:06.95]Kimi wa ima namida nagashita\n[00:09.63]Nakijakuru kodomo no you ni\n[00:12.73]Tatoe asu ga mienakunattemo mamoru yo\n[00:19.05]Natsu no sora miagete niran da\n[00:28.27]Tsuyogatte bakari de namida wa misenai\n[00:33.88]Hontou wa kowai kuse ni\n[00:39.54]Taisetsu na mono wo ushinawanu you ni\n[00:45.77]Hisshi de hashirinukete kita\n[00:51.86]Itsudatte nagai yoru wo futari de norikoeta\n[00:57.37]Kono mama issho ni iru kara tsuyogattenaide iin da yo\n[01:05.25]Kimi wa ima namida nagashita\n[01:08.27]Nakijakuru kodomo no you ni\n[01:11.27]Tatoe asu ga mienakunattemo susumu yo\n[01:17.44]Natsu no sora miagete saken da\n[01:26.42]Dareka ga tsubuyaita kotoba no wana ni\n[01:32.64]Odoru you ni madowasarete\n[01:38.28]Taisetsu na mono wa kokoro no naka ni\n[01:44.23]Wakatteta kimi na no ni\n[01:49.60]Shinjiru koto ga kowakute namida wo wasureta\n[01:55.90]Kaze ga senaka wo oshita futari nara kitto yukeru yo\n[02:03.86]Kimi no te wo tsuyoku nigitta\n[02:06.98]Mujaki na kodomo no you ni\n[02:09.88]Tatoe toki ga ima wo ubattemo susumu yo\n[02:16.07]Natsu no sora mezashite hashitta\n[02:21.96]Natsu no sora mezashite hashitta\n[02:38.95]Konna ni mo hiroi sekai de\n[02:42.36]Hitori ni natte yuku no darou\n[02:45.32]Afuresou na omoi uketomete ageru yo\n[02:51.28]Kimi wa ima namida nagashita\n[02:54.01]Nakijakuru kodomo no you ni\n[02:56.91]Tatoe asu ga mienakunattemo mamoru yo\n[03:03.21]Natsu no sora miagete saken da\n[03:09.17]Natsu no sora miagete niran da\n[03:14.97]	/audio/Naruto Shippuden OP9 「Lovers」.mp3	Lovers	OP9	https://res.cloudinary.com/ddc6silap/image/upload/v1773253654/covers/Naruto_Shippuden_OP9_Lovers.jpg	1
723	723	723	233		/audio/Nisekoi ED 「Heart Pattern」.mp3	Heart Pattern	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252937/covers/Nisekoi_ED_Heart_Pattern.jpg	1
743	743	743	243	[ti:Nodame Cantabile ED 「Konna ni Chikaku de」]\n[ar:Crystal Kay]\n[al:Nodame Cantabile]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:02.13]\n[00:00.00]\n[00:25.49]Koi ga setsunai to\n[00:29.38]Sugu soba de kizuita ano yoru\n[00:35.21]Datte hoka no dare yori\n[00:39.17]Anata no koto wo shitteru kara\n[00:44.54]Itsumo no sarigenai\n[00:47.80]Yasashisa sae kono mune wo shimetsuketeku\n[00:53.87]Konna ni konna ni chikaku de mitsumete mo\n[00:58.56]Doushite doushite tada no tomodachi na no?\n[01:03.09]Donna ni donna ni tsuyoku omotte itemo\n[01:07.99]Tsutaerarenai you don't understand\n[01:13.35]I'm so in love with you\n[01:19.79]"Genki nai yo ne?" to\n[01:23.50]Anata kara iwareta shunkan\n[01:29.50]Namida kakusu AKUBI de\n[01:33.33]"Nebusoku ka na?" tte ii wake shita\n[01:38.61]Ichiban taisetsu na\n[01:42.43]Hito ni uso wo kasaneteku... ima no watashi\n[01:47.99]Mainichi mainichi mune ga kurushii kara\n[01:52.61]Ikutsumo ikutsumo nemurenu yoru wo koe\n[01:57.25]Hajimete hajimete deatta ano hi ni mata\n[02:01.85]Modoreru no nara ii no ni...\n[02:07.50]I'm so in love with you\n[02:27.80]"AISHITERU" to tsugetara kitto\n[02:32.11]Mou nidoto egao ni wa modorenai kamo shirenai\n[02:37.65]Keredo mo tomodachi no mama tsukuriwarai wa\n[02:42.80]Kore ijyou, watashi dekinai kara\n[02:54.21]HONTO wa HONTO wa zutto suki datta no\n[02:58.78]Itsudemo itsudemo aishi tsuzuketa no\n[03:03.44]Anata ni anata ni todoketai kimochi wo\n[03:08.32]Aoi sora he to sasayaita\n[03:13.74]I'm so in love with you\n[03:15.40]Konna ni konna ni chikaku de mitsumete mo\n[03:19.95]Doushite doushite tada no tomodachi na no?\n[03:24.58]Donna ni donna ni tsuyoku omotte ite mo\n[03:29.32]Tsutaerarenai you don't understand\n[03:34.60]I'm so in love with you\n[03:36.76]	/audio/Nodame Cantabile ED 「Konna ni Chikaku de」.mp3	Konna ni Chikaku de	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252750/covers/Nodame_Cantabile_ED_Konna_ni_Chikaku_de.jpg	1
746	746	746	256		/audio/Non Non Biyori ED 「Non Non Biyori」.mp3	Non Non Biyori	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252989/covers/Non_Non_Biyori_ED_Non_Non_Biyori.jpg	1
759	759	759	214	[ti:Odd Taxi ED 「Sugarless Kiss」]\n[ar:Suzuko Mimori]\n[al:Odd Taxi]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:34.20]\n[00:00.00]\n[00:18.70]Saa Party\n[00:19.62]Shanpan ni\n[00:20.57]Tsurette tte yo Take me\n[00:22.50]Amai dake ja tsumannai desho\n[00:24.69]More shigeki You & Me\n[00:26.47]Koukishin?\n[00:27.32]Kore banku shii?\n[00:28.41]Motto choudai supaishii\n[00:30.06]Uwattsura no serifu\n[00:32.00]Kimochi wa mou aimai ni\n[00:36.12]Dancing Dancing with the Star\n[00:39.34]Kimi no hitomi\n[00:41.67]Nazomeita kissu\n[00:43.70]Dancing Dancing please don’t stop\n[00:46.89]Yoru ni tokeru\n[00:49.48]Koi mitai na Feeling\n[00:51.40]Yurayura yurareteru\n[00:55.72]Konya wa mou kaeritakunai wa\n[00:59.49]Yasashii furi wo shite\n[01:02.40]Haato wa himitsu Distance\n[01:06.74]Supeeshii\n[01:07.63]No beeshisuto\n[01:08.67]Marude mujuuryoku de\n[01:10.59]Furikaettemo shou ga nai shi\n[01:12.72]Back to the Future\n[01:14.45]Magic is purasuchikku\n[01:16.26]Wakattenai ne nansensu\n[01:18.19]Ronrii onrii\n[01:19.31]Yakimochi tarinai\n[01:21.03]Really? Love me…?\n[01:23.62]Nee hontou no kimochi\n[01:28.16]Oshiete Tell me\n[01:31.89]Mou sugu rootarii\n[01:34.75]Um… kore de owari?\n[01:39.93]Dreaming Dreaming with the Star\n[01:43.03]Sugu ni tokeru\n[01:45.73]Mahou no kissu\n[01:47.57]Dreaming Dreaming please don’t stop\n[01:50.81]Wasuresasete\n[01:53.21]Wagamama Weekend\n[01:55.39]Fuwafuwa ukanderu\n[01:59.56]Romanchikku janai keredo\n[02:03.27]Ijiwaru na egao de\n[02:06.15]Kakushite iru True Heart\n[02:14.24](Sugar Sugar me)\n[02:21.86](Show me your love)\n[02:44.55]Dreaming Dreaming with the Star\n[02:48.07]Yume no naka ni\n[02:50.64]Kieteku shiikuretto\n[02:52.51]Dreaming Dreaming please don’t stop\n[02:56.01]Sukoshi setsunai\n[02:58.62]Shugaaresu kissu\n[03:00.61]Dancing Dancing with the Star\n[03:03.64]Ochiteku hikari\n[03:06.19]Sayonara kissu\n[03:08.19]Dancing Dancing please don’t stop\n[03:11.37]Endo rooru\n[03:13.97]Mou sukoshi Don’t stop\n[03:15.94]Kirakira de owaritai\n[03:20.11]Amai uso wa iranai wa\n[03:23.93]Namida wa ato ni shite\n[03:26.64]Haato wa himitsu Distance\n[03:30.29]	/audio/Odd Taxi ED 「Sugarless Kiss」.mp3	Sugarless Kiss	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253972/covers/Odd_Taxi_ED_Sugarless_Kiss.jpg	1
776	776	775	243		/audio/Ore Monogatari OP 「Miraikei Answer」.mp3	Miraikei Answer	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253068/covers/Ore_Monogatari_OP_Miraikei_Answer.jpg	1
832	831	828	210	[ti:Overlord S3 ED 「Silent Solitude」]\n[ar:OxT]\n[al:Overlord]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:28.44]\n[00:00.00]\n[00:08.36]It's a deep and silent night\n[00:10.84]Nani mo kikoenai towa ni nemure\n[00:27.80]Nageki ikari uzu o makitodoroita sakebi mo\n[00:36.16]Yami ni mayoi koe mo naku kiete itta\n[00:44.04]Damashiai mo uragiri sae\n[00:48.45]Mu imi datta nani mo nokosazu\n[00:54.24]It's a deep and silent night\n[00:56.27]Nani mo kikoenai subete ga nemutta\n[01:02.85]Soshite sekai wa mata kurikaesu\n[01:07.30]Mu jihi na yume\n[01:21.60]Nan do kuyamiaganae ba yurusarerudaro\n[01:30.55]Yurushiatau sono hito wa dare na no daro\n[01:38.73]Zen mo nikumo kami mo kanjo mo\n[01:43.04]Itsu no aida ni ka sutete shimatta\n[01:48.66]In the dark and dirty light\n[01:50.78]Abakarete yukukegareta jibun ga\n[01:57.36]Kono seijaku wa mata tsukitsukeru\n[02:01.87]Kodoku no batsu\n[02:24.62]Damashiai mo ubaiai mo\n[02:28.86]Kizutsukeai arasoi sae\n[02:33.59]Hito wa itsu mo motomete ita\n[02:38.28]Sono muko no hidai shita yume\n[02:43.86]Ano hi no koe ga mada kodama suru\n[02:48.18]Kioku no kanata de\n[02:52.50]Kokoro tozashite koe naki koe de\n[02:56.94]Kakikeshiteru\n[03:01.36]It's a deep and silent night\n[03:03.37]Nani mo kikoenai subete ga nemutta\n[03:09.91]Soshite sekai wa mata kurikaesu\n[03:14.41]Mu jihi na yume\n[03:19.63]	/audio/Overlord S3 ED 「Silent Solitude」.mp3	Silent Solitude	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253724/covers/Overlord_S3_ED_Silent_Solitude.jpg	3
835	831	828	223	[ti:Overlord S4 OP 「HOLLOW HUNGER」]\n[ar:OxT]\n[al:Overlord]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:23.4.20]\n[length:03:43.15]\n[00:01.48](Oh) La ta ta samenai yume yo\n[00:11.05]Wonder why I can't satisfy\n[00:14.04]Overnight, feeling like dying\n[00:17.06]Kono yo no subete nigiru kono te\n[00:20.05]I've got, I've got, only my bones!\n[00:23.19]Oh, I'm crying to the darkest sky\n[00:26.02]There's no light in this lonely night\n[00:29.10]Hoshii mono wa mou naku tomo naze\n[00:32.11]Can't stop getting all (oh)\n[00:35.16]Eikou to kyokou no\n[00:38.07]Jousai no choujou de mayou mirai\n[00:41.06]Tsuietemo negau kibou\n[00:44.09]Shikabane no you ni\n[00:46.53]Just give me more power\n[00:48.33]Sai wo furutte odorimashou\n[00:54.16]Akumu ni kuruwasareru mama ni\n[01:00.18]Zaika tsukushite odorimashou\n[01:06.11]Munashisa ni nomaretemo la, ta, la, li, la, li\n[01:12.34]La, ta, ta, ta, la samenai yume yo\n[01:15.33]La, ta, ta, ta, la Get away, hurry! hurry!\n[01:18.25]La, ta, ta, ta, la hatenaki yamiyo\n[01:21.21]La, ta, ta, ta, la kowareru you ni\n[01:24.18]Oh no! I'm falling down\n[01:29.10]In my site, I can't see no life\n[01:32.23]Hold me tight. I won't be alright\n[01:35.33]Nozomu mono dake kanawanu nara\n[01:38.41]Can't stop getting mad , oh\n[01:41.31]Ouza no jiyuu wo moteamashi samayou sekai\n[01:47.08]Nemuttemo sasou yabou\n[01:50.30]Sekitateru you ni\n[01:52.68]Don't give me more power\n[01:54.37]Hai wo fusaide oboremashou\n[02:00.17]Shouki made ubawareru mama ni\n[02:06.27]Saigen naku oboremashou\n[02:12.22]Yokubou ni nomaretemo la, ta, la, li, la, li\n[02:31.29]Kasuka na kibou de sae mo\n[02:33.88]Ano hoshi no you ni tooku\n[02:36.89]Todokanai to shiri nagara\n[02:39.92]Te wo nobasu\n[02:44.52]Just give me more power\n[02:45.98]Itsu made mo odorimashou\n[02:51.63]Kuukyo na katsubou wo aa, oikakete\n[02:57.60]Sai wo furutte odorimashou\n[03:03.72]Akumu ni kuruwasareru mama ni\n[03:09.77]Zaika tsukushite odorimashou\n[03:15.71]Munashisa ni nomaretemo la, ta, la, li, la, li\n[03:21.95]La, ta, ta, ta, la samenai yume yo\n[03:25.02]La, ta, ta, ta, la Get away, hurry! hurry!\n[03:27.89]La, ta, ta, ta, la hatenaki yamiyo\n[03:31.02]La, ta, ta, ta, la kowareru you ni\n[03:34.11]Oh no! I'm falling down\n[03:37.96]	/audio/Overlord S4 OP 「HOLLOW HUNGER」.mp3	HOLLOW HUNGER	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254173/covers/Overlord_S4_OP_HOLLOW_HUNGER.jpg	4
869	603	869	260	[ti:Redo of Healer ED 「Yume de Sekai wo Kaeru nara」]\n[ar:ARCANA PROJECT]\n[al:Redo of Healer]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:19.68]\n[00:00.00]\n[00:12.58]Sekai o kaetai to omotteru minna omotteru\n[00:19.84]Erabu no wa jibun ga hontōni nozonderu koto\n[00:26.98]Nayaminagara kyō mo kyō toiu hi o tanoshindara\n[00:34.58]Shiawase to fukō wa uraomote chigau ki ga shite\n[00:41.86]Zutto yasashī jikan dake o oyoideitai\n[00:47.73]Yurari yurari yurari to\n[00:49.46]Mō nani mo kamo o yurushite shimae\n[00:52.67]Muri kana muridana dōdarō\n[00:55.15]Itsuka motto jiyūna kokoro\n[00:59.36]Aitai hito ni ai ni yukō\n[01:02.93]Donna hoshi ni negaeba zenbu kanau no kana\n[01:09.61]Yume de sekai o kaeta toki wa\n[01:13.61]Aitai hito ni ai ni yukō\n[01:17.19]Demo mada nemurenaikara ā akubi hitotsu\n[01:38.57]Mawari o kaetai to omotte mo hitori omotte mo\n[01:46.03]Dekiru no wa jibun ga kawaru koto hito wa kawannai\n[01:53.12]Iyada wa kagami dane reiseina bunseki kekka ga\n[02:00.29]Iyana yatsu no tansho uraomote watashi no yowa sa\n[02:07.57]Kitto tanoshī jikan datte sugisatteshimau\n[02:13.45]Kirari kirari kirari to\n[02:14.93]ā nanimokamo ga eien janai\n[02:18.37]Soredemo sorenara dō shiyō\n[02:21.37]Ima o motto daiji ni shitai\n[02:25.27]Aenai nante usodesho\n[02:28.97]Donna hoshi ni negau yori kōdō shichaeba kanau\n[02:35.48]Yumeminagara mō shiteru ndayo\n[02:39.47]Aenai nante usodesho\n[02:43.19]Hora hontōni nozonderu koto nē sunao ni nare\n[03:10.89]Sā soko no soko e moguttemitara\n[03:18.92]Jibun ga nozomu no wa shinken ni nozomu no wa\n[03:22.70]Mada michi no mirai suimenka no misuterī\n[03:26.40]Nazo mada omoi wa nazodane\n[03:30.15]Nazodane dakara omoshiroi no kana\n[03:35.84]Itsuka motto jiyūna kokoro\n[03:40.22]Aitai hito ni ai ni yukō\n[03:43.77]Donna hoshi ni negaeba zenbu kanau no kana\n[03:50.16]Yume de sekai o kaeta toki wa\n[03:54.46]Aitai hito ni ai ni yukō\n[03:58.13]Demo mada nemurenaikara ā akubi hitotsu\n[04:06.59]	/audio/Redo of Healer ED 「Yume de Sekai wo Kaeru nara」.mp3	Yume de Sekai wo Kaeru nara	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253994/covers/Redo_of_Healer_ED_Yume_de_Sekai_wo_Kaeru_nara.jpg	1
878	878	871	205		/audio/Relife ED5 「Kore ga Watashi no Ikiru Michi」.mp3	Kore ga Watashi no Ikiru Michi	ED5	https://res.cloudinary.com/ddc6silap/image/upload/v1773253240/covers/Relife_ED5_Kore_ga_Watashi_no_Ikiru_Michi.jpg	1
967	967	966	268	[ti:Senryu Girl OP 「Kotonoha no Omoi」]\n[ar:Sonoko Inoue]\n[al:Senryu Girl]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:28.00]\n[00:00.50]Kotoba harari kimochi fuwari noseru omoitachi\n[00:27.61]Ima kokoro wo hirotta no wa dare deshou\n[00:33.26]Irodoru ao ga haretemo kanjita keshiki kitto chigau\n[00:39.47]De wa hanashitakunaru no wa naze deshou\n[00:45.27]Tatta hitokoto sae mo nayami eranderu wake wa\n[00:52.11]Katachi aru mono dake ja kimi wa katarenai\n[00:58.35]Hibiku kodou ya sugoshita jikan\n[01:02.01]Setsunaku naru kurai kagayaite\n[01:08.74]Koi ni somatteku\n[01:11.17]Kimi to itara ame no naka mo chigatta shizuku ni naru\n[01:17.59]Donna moji wo tsuzuttara iroasezu ni nokoru no desho?\n[01:23.79]Shitterunda ima no futari ga tooi ano hi ni naru koto\n[01:33.47]Sou deshou kamisama\n[01:36.70]Marumaru mizu mo konai densha mo motto kono shunkan ga\n[01:42.91]Douka eien ni tsuzuite nante muri ka na?\n[02:02.74]Madamada iu beki toki wo sagutteru\n[02:08.11]Kimi no tonari ni iru tabi jidanda tomadou bakari de\n[02:14.62]Ikioi dake de sono te wo tsukamaeta\n[02:20.50]Hayamaru kodou to shigusa ni shikou kairo ga tomaru\n[02:27.66]Tada hitori kimi ni shika ienai koto ga aru\n[02:37.78]Imi wo motanai kotoba ga\n[03:08.48]Fusagikonda hi mo atta kedo watashi wa waratteru yo\n[03:14.41]Kimi ga kureta kikkake de zenbu zenbu kawaridashita\n[03:23.74]Soshite koi ni somatteku\n[03:26.87]Kimi to itara ame no naka mo chigatta shizuku ni naru\n[03:33.24]Donna moji wo tsuzuttara iroasezu ni nokoru no desho?\n[03:39.74]Wasurenai yo ima no futari ga tooi ano hi ni nattemo\n[03:49.68]Sou deshou kamisama\n[03:53.21]Marumaru mizu mo konai densha mo motto kono shunkan wo\n[03:59.23]Kimi to ikitetai tte omou yo itsu made datte\n[04:05.93]	/audio/Senryu Girl OP 「Kotonoha no Omoi」.mp3	Kotonoha no Omoi	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253943/covers/Senryu_Girl_OP_Kotonoha_no_Omoi.jpg	1
975	975	974	136		/audio/Shadows House OP 「a hollow shadow」.mp3	a hollow shadow	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253438/covers/Shadows_House_OP_a_hollow_shadow.jpg	1
1007	1007	1007	231	[00:00.00] \n[00:01.86]Arasoiatte koware kakatta\n[00:04.73]Kono ochame na hoshi de\n[00:08.03]Umareochita hi kara yosomono\n[00:13.65]Namida kare hateta\n[00:17.80]Kaeri yuku basho wa yume no naka\n[00:24.31]Koboreochita saki de deatta\n[00:26.65]Tada himitsu wo kakae\n[00:29.73]Futsuu no furi wo shita anata to\n[00:35.38]Sagashi akirameta\n[00:39.31]Watashi no ibasho wa tsukuru mono datta\n[00:48.26]Ano hi kawashita\n[00:50.56]Chi ni masaru mono\n[00:53.02]Kokoro tachi no keiyaku wo\n[00:58.19]Te wo tsunagi kaerou ka\n[01:00.59]Kyou wa nani tabeyou ka\n[01:03.04]"konna koto ga atta" tte\n[01:05.92]Kimi to hanashitakattan da\n[01:09.40]Itsu no hi mo\n[01:11.69]Kimi to nara kigeki yo\n[01:13.91]Odoru kishimu beddo de\n[01:16.90]Waraikorogeta mama de\n[01:21.27]Fuzaketa seikatsu wa tsuzuku sa\n[01:31.17]Ototteru to iware sodatta\n[01:33.44]Kono ikareta hoshi de\n[01:36.73]Futsuu no furi wo shite kizuita\n[01:42.29]Dare ga kimetsuketa\n[01:46.51]Watashi no hikari wa tada koko ni atta\n[01:55.20]Ano hi hodoketa\n[01:57.50]Awai noroi ni\n[01:59.53]Kokoro kara no sayonara wo\n[02:05.26]Kao agete kaerou ka\n[02:07.43]Sakihokoru hanabana\n[02:10.15]"konna kirei nan da" tte\n[02:12.94]Kimi to hanashitakattan da\n[02:16.45]Donna hi mo\n[02:18.37]Kimi to iru kiseki wo\n[02:20.99]Inochi tsunagu kicchin de\n[02:23.77]Tsutae kirenai mama de\n[02:28.60]Fuzaketa seikatsu wa tsuzuku\n[02:33.44]Shigoto ake ni\n[02:36.45]Ayumu tomo ni\n[02:39.07]Asahi ga noboru wa aa\n[02:44.25]Arigatou de wa\n[02:47.50]Tarinai kara\n[02:50.03]Te wo tsunagi\n[02:55.60]Saa uchi ni kaerou ka\n[02:57.96]Kyou wa nani tabeyou ka\n[03:00.64]"konna koto ga atta" tte\n[03:03.41]Kimi to hanashitakattan da\n[03:06.83]Itsu no hi mo\n[03:08.89]Kimi to nara kigeki yo\n[03:11.55]Odoru kishimu beddo de\n[03:14.23]Waraikorogeta mama de\n[03:18.21]Eien wo sagasou ka\n[03:19.79]Dekiru dake kurasou ka\n[03:22.38]Donna koto ga attatte\n[03:25.16]Kimi to hanashitakattan da\n[03:28.66]Itsu made mo\n[03:30.56]Kimi to nara kigeki yo\n[03:33.36]Wakachiaeta hibi ni\n[03:36.12]Waraikorogeta saki ni\n[03:40.82]Fuzaketa seikatsu wa tsuzuku sa\n[03:47.21]	/audio/Spy x Family ED 「Kigeki」.mp3	Kigeki	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253631/covers/Spy_x_Family_ED_Kigeki.jpg	1
1098	1098	1098	209	[00:00.00] \n[00:47.58]Sono yubisaki de tashikamete mite\n[00:55.17]Sekai no katachi sono utsukushisa\n[01:03.46]Sono me ni wa ima nani ga utsutteiru\n[01:11.12]Ikiru kibou ni michiteru?\n[01:19.39]Bokura ga mezashita kumo wa toosugita\n[01:26.42]Sore demo muchuu de otta\n[01:33.92]Ano natsu kara koboreru\n[01:41.11]Kirakira shita omoide wo\n[01:48.36]Koko kara isoide kimi ni todoke ni yuku kara\n[02:02.73]Zutto kakuretenaide\n[02:10.04]Asobitsukaretara oide\n[02:17.30]Hitori wa samishii sore wa kami-sama mo onaji\n[02:32.85] \n[02:35.22]Sono hanasaki de tashikamete mite\n[02:42.88]Hito no nukumori sono nioi made\n[02:51.44]Ironna koto ga atta kedo tsumari\n[02:59.50]Onegai douka ikite\n[03:07.50] \n[03:08.51]Bokura ga mezashita yume wa toosugita\n[03:15.35]Sore demo tadoritsuketa\n[03:24.58] \n	/audio/The Day I Become a God ED2 「Takaramono ni Natta.mp3	Takaramono ni Natta Hi	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773252134/covers/The_Day_I_Become_a_God_ED2_Takaramono_ni_Natta_Hi.jpg	1
1143	1143	1140	266		/audio/The Petgirl of Sakurasou OP 「Kimi ga Yume wo Ts.mp3	Kimi ga Yume wo Tsuretekita	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253346/covers/The_Petgirl_of_Sakurasou_OP_Kimi_ga_Yume_wo_Tsuretekita.jpg	1
1180	1176	1175	263	[00:00.00] \n[00:07.72]Tatoeba me ga samete subete wa maboroshi da tte\n[00:14.23]Kisekimeita mousou wo kanaete hoshiin da\n[00:20.29]Oh boku ga egaita tsumi de\n[00:26.92]Oh ketsumatsu wo midasanaide\n[00:34.13] \n[00:47.77]Itsuka kimi to miteita kono keshiki wa\n[00:54.37]Dare ni mo watasanai to chikatta no ni Oh\n[01:03.57] \n[01:07.75]Kowashi tsuzuketa boku wa nanika wo sukuu kedo\n[01:14.51]Kawarihateta ima ni kakumei no naifu\n[01:20.58]Sasageta you ni sashite hikari ni michita sayonara wo\n[01:28.44]I'll miss you I'll miss you\n[01:31.54]Tsumi wa itsuka horobiru\n[01:34.86]Boku wo nosete kodomo no mama datte ikou\n[01:39.95]Kuzureru afureru kanawanai mousou\n[01:48.09] \n[02:20.27]Tatoeba me ga samete subete wa shinjitsu datte\n[02:26.91]Higekiteki na sairen wo narasanaide\n[02:32.91]Oh sekai no kizuato ni\n[02:39.47]Oh mirai wo hanashite hoshii no\n[02:45.96] \n[02:48.06]Hodokeru you ni sashite hikari ni michita sayonara wo\n[02:55.69]I'll miss you I'll miss you\n[02:58.95]Batsu wo boku ni atae yo\n[03:07.39]Atae yo\n[03:09.30] \n[03:14.79]Subete no kokoromi wa boku ga eranda sadame dakara\n[03:22.44]Oikakete oikakete\n[03:25.76]Itsu no ma ni ka torawaretemo\n[03:29.11]Kimi wa mada boku wo kai shite wa kureru no?\n[03:35.70]Boku janakya boku ja dame da\n[03:38.92]Boku janakya Collapse it\n[03:42.11] \n[03:48.82]Tsumi mo batsu mo boku mo kimi mo\n[03:51.04]Horobosezu ni nokosarete sutatta\n[03:55.62]Kizukanai yo fukkaketa shinario\n[03:57.94]Kagayaku mirai wo kimi ni tadayou\n[04:02.23]Koko wo sashita naifu sae mo\n[04:05.64]Itsuka kitto hikari wo sasu kara\n[04:08.90] \n	/audio/Tokyo Ghoul Re_ OP2 「Katharsis」.mp3	Katharsis	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253416/covers/Tokyo_Ghoul_Re_OP2_Katharsis.jpg	1
919	919	919	311	[ti:Rising of The Shield Hero ED 「Kimi no Namae」]\n[ar:Chiai Fujikawa]\n[al:Rising of The Shield Hero]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:05:00.27]\n[00:00.00]\n[00:13.29]Nukegara mitai na sora ni\n[00:16.68]Nani wo miteita\n[00:19.01]Mezameta riyuu de sura\n[00:22.54]Wakaranakatta\n[00:25.16]Shinjiru koto ni hidoku obieteita\n[00:30.99]Datte zenbu sutetan da\n[00:36.91]Konna sekai nara mou\n[00:42.97]Kiete shimae to\n[00:48.82]Nikundeitan da\n[00:51.73]Harisakesou da yo\n[00:54.49]Shinjitemo?\n[00:58.98]Hora kimi no koe ga\n[01:02.60]Boku wo sukuu yo\n[01:05.48]Nandomo yobisamasu yo\n[01:12.43]Kimi ga oshiete kureta omoi\n[01:17.39]Sou nando datte\n[01:20.37]Kimi no namae wo sakebu yo\n[01:26.27]Tsuyoku sono te wo nigitte\n[01:30.23]Mou hanasanai kesshite\n[01:33.69]Donna mirai mo\n[01:36.36]Kimi to nara nigenai\n[01:51.32]Nagareru kumo ni ano hi\n[01:54.48]Kasaneteita\n[01:56.84]Mamorenakatta yakusoku\n[02:00.32]Kamishimete wa\n[02:02.85]Utagau koto de jibun gomakashiteta\n[02:08.65]Namida mo mou\n[02:11.85]Karehatete\n[02:14.65]Kurikaesareru warui\n[02:20.67]Yume ni oborete\n[02:26.53]Mayoikonda mama\n[02:29.80]Miushinaisou da yo\n[02:32.61]Boku ni ima\n[02:36.89]Sou kimi no uta ga\n[02:40.54]Yoake no you ni jinwari\n[02:47.97]Hikari wo kureta\n[02:50.55]Fusagi konda mune no oku ni\n[02:55.49]Chippoke da keredo\n[02:58.25]Tashika na kibou tashika na kibou\n[03:05.74]Boku ni kureta kara\n[03:08.47]Mou mayowanai nido to\n[03:11.80]Donna mirai mo\n[03:14.33]Kimi to nara nigenai\n[03:41.22]Doko ni itemo nando datte\n[03:46.93]Kimi no namae wo koe ga kareru made\n[03:52.76]Yoake mae ni niji wo mita yo\n[03:58.75]Uso no nai sekai de kimi ni motto motto ai wo\n[04:10.15]Hora kimi no koe ga\n[04:14.06]Boku wo sukuu yo nandomo\n[04:21.28]Yobisamasu yo\n[04:23.86]Kimi ga oshiete kureta omoi\n[04:28.82]Sou nando datte\n[04:31.62]Kimi no namae wo sakebu yo tsuyoku\n[04:39.15]Sono te wo nigitte\n[04:41.87]Mou hanasanai kesshite\n[04:45.07]Donna mirai mo\n[04:47.61]Kimi to nara nigenai\n[04:52.50]	/audio/Rising of The Shield Hero ED 「Kimi no Namae」.mp3	Kimi no Namae	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253560/covers/Rising_of_The_Shield_Hero_ED_Kimi_no_Namae.jpg	1
922	921	919	215	[00:00.00] \r\n[00:21.47]Hikari mitsuketa kuuhaku no jikan\r\n[00:24.39]Mayoikonda chuuzuri no sekai\r\n[00:27.28]Shinjirareru kotae sagashimotomete\r\n[00:30.71]Tada samayotteru\r\n[00:32.88]Yubi no sukima nigeru light\r\n[00:34.43]Yosomi shiteru hima mo nai\r\n[00:35.83]Uketa kizuna ato sae kate ni\r\n[00:37.35]Seijaku kirisaiteku\r\n[00:38.89]Dare mo kare mo Dead or alive\r\n[00:40.37]Mamoru dake ja can’t survive\r\n[00:41.81]I don’t want to lie to myself\r\n[00:44.48]Keep on the fight, get right\r\n[00:46.25]I’ll never lose and cry\r\n[00:47.36]Keep run up day and night\r\n[00:49.10]Time to rewrite\r\n[00:50.15]No matter what anyone say\r\n[00:52.11]I find my way\r\n[00:54.86]Never go away\r\n[00:57.35]Now, Nobody can’t stop me no way\r\n[01:00.01]Wasurete shimau koto no nai you ni\r\n[01:02.77]Nakushita mono subete torimodosu tame\r\n[01:06.16]Rise suddenly in this world\r\n[01:08.16](I don’t look back yeah)\r\n[01:09.15]Kurikaesu tabi no hate\r\n[01:11.81]Nouri ni nokotta shippai nante\r\n[01:14.60]Zenbu torikaese ima Turn over\r\n[01:17.65]Rise suddenly in this world\r\n[01:19.52](I don’t look back yeah)\r\n[01:21.31] \r\n[01:32.49]Now, I know subeki koto meihaku daro\r\n[01:34.47]Baransu ushinatta My world\r\n[01:35.69]Kurayami no naka sagasu answer\r\n[01:37.28]Daremo ga umu iwasezu\r\n[01:38.63]Tatakatteru hontou no koto wa mimuki mo sezu\r\n[01:40.55]Mijikai life ore nara nani ni tsukaou\r\n[01:42.67]Sekai kaeru tame Fight my war\r\n[01:44.17]Keep on the fight get right\r\n[01:46.02]I’ll never lose and cry\r\n[01:47.36]Keep run up day and night\r\n[01:48.87]Time to rewrite\r\n[01:49.71]No matter what anyone say\r\n[01:51.57]I find my way\r\n[01:54.17]Never go away\r\n[01:56.89]Now, Nobody can’t stop me no way\r\n[01:59.67]Jibun jishin wo miushinawanai you ni\r\n[02:02.67]Nanimo kamo subete tokihanatte\r\n[02:05.68]Rise suddenly in this world\r\n[02:07.55](I don’t look back yeah)\r\n[02:08.72]Tachiagaru nando datte\r\n[02:11.40]Risuku osorezu hikari otte\r\n[02:14.29]Me wo somuketatte kesenai true heart\r\n[02:17.40]Rise suddenly in this world\r\n[02:19.55](I don’t look back yeah)\r\n[02:21.09] \r\n[02:26.29]I gotta go\r\n[02:27.88]Keep defend everything in myself\r\n[02:32.28]I gotta go\r\n[02:33.54]Keep defend everything in myself\r\n[02:36.48]Feel so good ya\r\n[02:38.05]Maboroshi madowasarezu kasuka na light wo sagashidashi\r\n[02:40.87]Katachi no nai daiji na mono mamoreru ka wa kekkyoku wa jibun shidai\r\n[02:43.81]Tate no hyouri dilemma\r\n[02:45.34]Zenbu guards shite become vanguard\r\n[02:46.71]Stay hungry. Stay foolish\r\n[02:48.26]Nani ga attemo run (esskeetit)\r\n[02:49.77](Never go away)\r\n[02:50.76]Now, Nobody can’t stop me no way\r\n[02:53.38]Wasurete shimau koto no nai you ni\r\n[02:56.45]Nakushita mono subete torimodosu tame\r\n[02:59.52]Rise suddenly in this world\r\n[03:01.77](I don’t look back yeah)\r\n[03:02.58]Kurikaesu tabi no hate\r\n[03:05.26]Nouri ni nokotta shippai nante\r\n[03:08.15]Zenbu torikaese ima Turn over\r\n[03:11.18]Rise suddenly in this world\r\n[03:12.81](I don’t look back yeah)\r\n[03:26.65] \r\n	/audio/Rising of the Shield Hero OP「RISE」.mp3	RISE	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253980/covers/Rising_of_the_Shield_Hero_OP_RISE.jpg	1
1251	1250	1249	247	[00:00.00] \n[00:17.16]PINKU no yuuwaku yoru no chou yottoide hora yottoide\n[00:25.14]Shoutai fumei no onii-san aa ayashii onii-san\n[00:41.03]NEON no fuyajou muhou chitai tare nagashittara tare nagashi\n[00:49.07]Yokubou uzumaku hankagai aa yamiyo no hankagai\n[00:57.04]Kuroi kage ga shinobiyoru\n[01:05.08]Watashi somosomo seijun ha\n[01:09.18]Konna tokoro wa niawanai\n[01:15.10]Kaerou kaerou kaerou yo\n[01:23.11]Denguri kaeshi de mata ashita\n[01:27.03]Amakute kiken na fuku maden\n[01:35.08]Yoru no tobari yo sayounara sayounara\n[01:49.04]Yoidore FURAFURA chidoriashi yoi no kuchi mada yoi no kuchi\n[01:57.23]KAOSU ka ikikau kousaten aa tokai no kousaten\n[02:04.67]Aku no soukutsu surinukete\n[02:13.09]Kiyoku tadashiku utsukushiku sonna kurashi ga matteiru\n[02:23.19]Kaerou kaerou kaerou yo\n[02:31.58]Yuuyake koyake de hi ga kurete\n[02:35.56]Muzan de munashii esoragoto\n[02:43.57]Hitoyo no yume yo sayounara sayounara\n[02:57.62]Sayounara… Sayounara… Sayounara…\n[03:07.29]IRASHAIMASE\n[03:09.47]II MISE ARU YO\n[03:12.30]O-HITORI-SAMA DESU KA ?\n[03:14.68]CHOTTO SOKO NO KANOJO !\n[03:15.76]SOKO SHIOJI KAI ARU MAZU GA ?\n[03:18.78]KESHITE AYASHII MON JA ARIMASEN YO !\n[03:23.12]Kaerou kaerou kaerou yo\n[03:31.22]Denguri kaeshi de mata ashita\n[03:34.83]HEY !\n[03:35.67]Amakute kiken na fuku maden\n[03:43.56]Yoru no tobari yo sayounara yoru no tobari yo sayounara\n[03:51.57]Sa-yo-u-na-ra\n[03:58.34]	/audio/Watamote ED3 「Yoru no Tobari yo, Sayounara」.mp3	Yoru no Tobari yo, Sayounara	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253976/covers/Watamote_ED3_Yoru_no_Tobari_yo_Sayounara.jpg	1
941	941	939	253	[00:00.00] \r\n[00:11.46]zutto hikari no naka\r\n[00:13.97]kinou made wa nakatta\r\n[00:17.04]ashiato wo tadotte kita hodo\r\n[00:21.15]gooru no mienai meiro\r\n[00:23.68]ame ni utareta chizu\r\n[00:26.91]koukai mo nani mo nai kedo\r\n[00:30.84]sakenda koe wa\r\n[00:35.64]kitto todoku kara\r\n[00:40.31]kono monogatari no hajimaru kane no ne ga\r\n[00:46.44]tsunagu tabi no tochuu de\r\n[00:49.53]kimi ga egaita mirai no sekai wa\r\n[00:54.45]itsuka no sora ni michibikarete\r\n[00:59.58]donna yume kasanete itsuwaru koto no nai ano hikari wo\r\n[01:07.14]ah on give for my way\r\n[01:10.69] \r\n[01:20.09]motto saki ni mieru\r\n[01:22.61]kibou dake nokoshita\r\n[01:25.70]kizuato ga ieru koto wa nai\r\n[01:29.71]saitei nanika hitotsu\r\n[01:32.16]te ni hairu mono ga attara\r\n[01:35.66]sore dake de nani mo iranai\r\n[01:39.42]todoketa sora ga\r\n[01:44.29]mada kodoku nara\r\n[01:49.00]kono monogatari no owari o tsugeru oto\r\n[01:54.92]kikasete\r\n[01:58.34]sotto yuruyaka ni\r\n[02:00.88]tachikomeru kaze\r\n[02:03.16]itsu no hi ga owaru tabi no tochuu de\r\n[02:07.98]kimi ga egaita mirai no sekai wa\r\n[02:13.01]ima mo dokoka ni iki tsudzukete\r\n[02:17.69]hontou no jibun wo uke iretekureta ano hikari wo\r\n[02:25.36]ah on give for my way\r\n[02:29.06] \r\n[02:48.34]dokomade mo yukou\r\n[02:50.48]tsunaida sono te ga\r\n[02:53.08]itsuka hanare sou demo\r\n[02:56.96]itsumademo shinjite koko de matsu kara\r\n[03:01.75]mou sukoshi dake koko ni ite\r\n[03:06.89]kimi ga egaita mirai no sekai wa\r\n[03:11.69]itsuka no sora ni michibikarete\r\n[03:16.47]futatsu no omoi wo hitotsu zutsu katachi ni shite kiseki wo\r\n[03:24.30]motto koete\r\n[03:26.40]kimi ga egaita mirai no sekai wa\r\n[03:31.62]ima mo dokoka de ikitsudzukete\r\n[03:36.37]donna yume kasanete itsuwaru koto no nai ano hikari wo\r\n[03:44.19]todokete on give for my way\r\n[03:50.44] \r\n	/audio/SAO 2 OP 2 「Courage」.mp3	Courage	2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253598/covers/SAO_2_OP_2_Courage.jpg	1
959	959	956	185		/audio/School Rumble S2 ED 「Kono Namida ga Arukara Tsu.mp3	Kono Namida ga Arukara Tsugi no Ippo to Naru	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773252993/covers/School_Rumble_S2_ED_Kono_Namida_ga_Arukara_Tsugi_no_Ippo_to_Naru.jpg	2
973	973	972	205	[ti:Serial Experiments Lain OP 「Duvet」]\n[ar:BOA]\n[al:Serial Experiments Lain]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:25.05]\n[00:00.10]And you don't seem to understand\n[00:06.48]A shame you seemed an honest man\n[00:11.52]And all the fears you hold so dear\n[00:16.61]Will turn to whisper in your ear\n[00:21.89]And you know what they say might hurt you\n[00:24.45]And you know that it means so much\n[00:26.98]And you don't even feel a thing\n[00:32.15]I am falling, I am fading\n[00:37.42]I have lost it all\n[00:42.58]And you don't seem the lying kind\n[00:47.64]A shame then I can read your mind\n[00:53.01]And all the things that I read there\n[00:58.09]Candle lit smile that we both share\n[01:02.98]And you know I don't mean to hurt you\n[01:05.58]But you know that it means so much\n[01:08.25]And you don't even feel a thing\n[01:13.55]I am falling, I am fading, I am drowning\n[01:21.55]Help me to breathe\n[01:24.44]I am hurting, I have lost it all\n[01:29.44]I am losing\n[01:30.72]Help me to breathe\n[01:35.39]\n[02:15.59]I am falling, I am fading, I am drowning\n[02:22.60]Help me to breathe\n[02:25.34]I am hurting, I have lost it all\n[02:30.48]I am losing\n[02:33.00]Help me to breathe\n[02:56.72]I am falling, I am fading, I am drowning\n[03:03.97]Help me to breathe\n[03:06.41]I am hurting, I have lost it all\n[03:11.70]I am losing\n[03:14.17]Help me to breathe\n[03:19.96]	/audio/Serial Experiments Lain OP 「Duvet」.mp3	Duvet	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253788/covers/Serial_Experiments_Lain_OP_Duvet.jpg	1
1003	1003	1002	291	[00:00.00] \n[00:26.69]Tada hitori\n[00:28.86]Mayoikomu tabi no naka de\n[00:35.14]Kokoro dake samayotte tachitsukushita\n[00:43.57]Demo ima wa tooku made\n[00:48.25]Arukidaseru\n[00:51.86]Sou kimi to kono michi de\n[00:56.76]Deatte kara\n[01:00.99]Tabibito tachi ga utau\n[01:04.98]Mishiranu uta mo\n[01:08.69]Natsukashiku kikoete kuru yo\n[01:13.25]Tada kimi to iru to\n[01:19.21]Yumemita sekai ga\n[01:23.27]Dokoka ni aru nara\n[01:27.45]Sagashi ni yukou ka\n[01:31.68]Kaze no mukou e\n[01:36.04]Itetsuku yoake no\n[01:40.02]Kawaita mahiru no\n[01:44.49]Furueru yamiyo no\n[01:48.44]Hate o mi ni yukou\n[01:53.94] \n[02:09.16]Sabishisa o shitte iru\n[02:14.19]Kimi no hitomi\n[02:17.91]Mabataite sono iro o\n[02:22.26]Utsusu kara\n[02:26.76]Takaku sora made tonde\n[02:30.66]Mikazuki ni naru\n[02:34.34]Hakka-iro no hoshi wa kitto\n[02:39.17]Namida no kakera\n[02:45.43]Higashi no kuni no minato nishi no umibe\n[02:54.01]Kurai mori de minami no machi kin no tou\n[03:02.01]Kita no oka mizu ni yureteta onaji tsuki ga\n[03:16.09] \n[03:18.29]Sashidasu sono te o\n[03:22.55]Tsunaide ii nara\n[03:26.83]Doko made yukou ka\n[03:31.11]Kimi to futari de\n[03:35.30]Doko e mo yukeru yo\n[03:39.48]Mada minu sekai no\n[03:43.52]Zawameki kaori o\n[03:47.70]Dakishime ni yukou\n[03:52.22]La la lai la\n[03:54.20]La la lai la\n[03:56.15]La la lai la\n[03:58.17]La la lai la\n[04:00.28]La la lai la\n[04:02.44]La la lai la\n[04:04.57]La la lai la lai la la\n[04:08.83]La la lai la\n[04:11.05]La la lai la\n[04:12.98]La la lai la\n[04:14.96]La la lai la\n[04:16.77]La la lai la\n[04:19.02]La la lai la\n[04:21.12]La la lai la lai la la\n[04:27.86] \n	/audio/Spice and Wolf OP 「Tabi no Tochuu」.mp3	Tabi no Tochuu	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253955/covers/Spice_and_Wolf_OP_Tabi_no_Tochuu.jpg	1
1009	926	1009	282	[00:00.00] \n[00:12.31]Come to me\n[00:15.06]Embrace my tears\n[00:18.30]Let me guide you down into my soul\n[00:24.71]And let us pray for the world to realize\n[00:30.84]There is peace, the truth within us\n[00:37.21]Emptiness erodes your heart\n[00:43.59]Coz you're free from pain and sorrow\n[00:49.81]Future is just too bright to show you ways\n[00:56.10]Wake up now...it's time to lead new souls\n[01:03.31]Orbit of photon and universe\n[01:09.59]I am just the part of its plan\n[01:15.92]Me ni wa mienai yuganda sora\n[01:22.29]Hito wa doko e to aruite yuku no?\n[01:30.78]The last game\n[01:35.02] \n[01:43.71]Hold my hand\n[01:46.70]Melt my heart\n[01:49.46]Feel like I've been caught up in\n[01:53.89]somewhere cold\n[01:56.26]Like the moon and stars hidden in the dark\n[02:02.51]Finally I found myself in your eyes\n[02:08.93]If we were\n[02:11.98]Meant to be, my love\n[02:15.02]Why do we keep making mistakes\n[02:21.33]Nothing can fulfill us in this world\n[02:27.84]Give me hopes to believe in our fate\n[02:34.60]Orbit of photon and universe\n[02:41.05]I will follow you all the way\n[02:47.31]Kidzuki-yō no nai gokan no shikhai\n[02:53.95]Ikiruimi sae shirasa renu mama\n[03:02.38]The last game\n[03:07.27] \n[03:28.98]Orbit of photon and universe\n[03:35.01]I am just the part of its plan\n[03:41.28]Me ni wa mienai yuganda sora\n[03:47.52]Hito wa doko e to aruite yuku no?\n[03:54.48] \n[03:55.64]Orbit of photon and universe\n[04:01.66]I will follow you all the way\n[04:07.99]Kidzuki-yō no nai gokan no shikhai\n[04:14.38]Ikiruimi sae shirasa renu mama\n[04:22.81]The last game\n[04:28.46] \n	/audio/Steins Gate 0 ED「LAST GAME」.mp3	LAST GAME	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253842/covers/Steins_Gate_0_ED_LAST_GAME.jpg	1
1189	1189	1189	266	[ti:Tonikaku Kawaii ED 「Tsuki to Hoshizora」]\n[ar:KanoeRana]\n[al:Tonikaku Kawaii]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:26.16]\n[00:00.00]\n[00:10.33]Terete dokidoki dekiru no mo\n[00:15.14]Sunete soppo o mukeru no mo\n[00:20.18]Suki to ii aeru no mo ano hi\n[00:25.36]Ukkari unmei to deaetakara\n[00:30.13]Nani ga atte mo maemuki de\n[00:34.89]Tama ni daitandattarine\n[00:40.04]Ironna hajimete bakkaride\n[00:45.01]Kyou mo hatsukoi mitai\n[00:49.61]Futari te o tsunaide\n[00:54.37]Aruku hibi no naka nando demo\n[00:59.57]Kimi ni koishite kimi o aishite\n[01:04.25]Motto fueteku omoide\n[01:09.70]Kawaii kimi no shigusa ni\n[01:14.12]Omowazu akaku natte miageta\n[01:19.08]Yasashiku kagayaku tsuki to hoshizora\n[01:44.30]Are ga nigatede kore ga sukide\n[01:49.04]Sonna jakuten mo attarine\n[01:53.97]Dore mo itoshiku omoeru no wa\n[01:58.86]Yappari kimi ga sukidakara\n[02:03.84]Ate mo naku samayotteta\n[02:08.43]Nagai yoru ga akete\n[02:13.61]Kyou kara wa onaji michi o\n[02:18.58]Issho ni arukundane\n[02:23.45]Kimi to dakiau tabi ni\n[02:27.94]Nanigenai shiawase o kasanete\n[02:33.09]Meguru kisetsu o ikutsu mo kazoe\n[02:38.03]Zutto zenbu wake aeru\n[02:43.15]Kagiri aru inochi demo\n[02:47.49]Kono ai no eien o shinjite\n[02:52.50]Tsuki no kagayaku hoshizora ni chikauyo\n[03:22.74]Futari te o tsunaide\n[03:26.85]Shinji aeru hibi korekara mo\n[03:32.01]Kimi ni koishite kimi o aishite\n[03:36.61]Motto kimi o suki ni naru\n[03:41.93]Kawaiikimi no shigusa ni\n[03:46.23]Omowazu dakishimete miageta\n[03:51.66]Itsu made mo yorisou tsuki to hoshizora\n[03:59.24]	/audio/Tonikaku Kawaii ED 「Tsuki to Hoshizora」.mp3	Tsuki to Hoshizora	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773254046/covers/Tonikaku_Kawaii_ED_Tsuki_to_Hoshizora.jpg	1
1190	1190	1189	210	[00:00.00] \n[00:12.03]Ato dore kurai no kyori o tsuki e aruitara\n[00:17.90]Ato dore kurai no samui yoru o kasanetara\n[00:23.92]Ato dore kurai no sayonara o nagashitara\n[00:30.11]Mabuta no oku no izumi ga kare hateru, toka\n[00:36.45]Sennen go mo kitto tsuzukudarou\n[00:39.40]Sou omotteta kuudou o\n[00:42.26]Mitashite afureteshimau hodo no\n[00:45.84]Kono kimochi wa nanda?\n[00:48.95] \n[01:00.01]Atarashii kaze o haru wa hakondekurerudarou\n[01:05.87]Aa, kaze ga fuku no ga kitto kaeru bashonandarou\n[01:12.03]Kawaranaideshou, natsu no atsu sa mo, kingyo mo\n[01:17.94]Hanabi ga kietara hoshi o yodoushi kazoeyou\n[01:24.27]Iroaseru kigi, itetsuku yubisaki\n[01:27.44]Kasaneta hibi no tomoshibi\n[01:30.26]Furitsumoru yuki ni\n[01:31.90]Umorenai youna kienai ato o nokoshi ni\n[01:36.57] \n[01:48.36]Kamikire ichi mai, te o nobashita doa\n[01:51.53]Tatta hitokoto no "hai" ya, chippokena ishikoro\n[01:56.19]Sonna mono de kantan ni kawaru, mirai wa\n[02:00.34]Tanjundayo maiasa no "ohayou"\n[02:02.07]Eiga mitai ni aoi natsu, no umi o mite\n[02:04.53]Toui tokoro de ibasho o shiri\n[02:05.61]Ima to ima o kasaneteku, firumu no you ni\n[02:08.09]Nankai mo torinaoshida\n[02:09.48]Iroaseru yori, irodoru yori\n[02:10.81]Kimi no iru keshiki ga koina\n[02:12.46]Chokkan de mo tossa de mo ii\n[02:13.80]Sou omottanda, tada mayoi naku\n[02:15.50]Shinjite mo ii ka to kikareta\n[02:16.70]Tatta soredake no toida\n[02:18.37]Kangaеterunda, donna toki mo\n[02:19.81]Ano koe ga tsukimatoinagara\n[02:21.62]Oshiteru, zutto sеnaka o\n[02:22.72]Sou ka, kono kimochi ga koida\n[02:24.65] \n[02:48.50]Tanjundayo maiasa no "ohayou"\n[02:50.03]Eiga mitai ni aoi natsu, no umi o mite\n[02:52.07]Toui tokoro de ibasho o shiri\n[02:53.70]Ima to ima o kasaneteku, firumu no you ni\n[02:56.12]Nankai mo torinaoshida\n[02:57.50]Iroaseru yori, irodoru yori\n[02:58.67]Kimi no iru keshiki ga koina\n[03:00.43]Sennen mae no tomoshibi ni nobashita nihon no yubi ga\n[03:03.42]Sennen go mo zutto mukou de kagayaiteruto ii na\n[03:06.47]"Shinjite mo ii" sou kikoeta\n[03:08.02]Manmaruna tsuki, aoida\n[03:09.36]Terashiteta, itsu no yo mo\n[03:10.75]Sou ka, kono kimochi ga koida\n[03:12.62] \n	/audio/Tonikaku Kawaii OP 「Koi no Uta」.mp3	Koi no Uta	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254009/covers/Tonikaku_Kawaii_OP_Koi_no_Uta.jpg	1
1193	1193	1191	204	[00:00.00] \n[00:02.26]PURE! PUREPARAATO!\n[00:05.15]tsuyoku nanka nai kedo\n[00:08.42]PURE! PURE PAREEDO!\n[00:11.15]itsuka kimi wo tsukamaeru!\n[00:14.32]PU.RE.PUREPA PU.RE.PUREPA PU.RE.PUREPA WARETE BARIBARI\n[00:20.47]PU.RE.PUREPA PU.RE.PUREPA PU.RE.PUREPA\n[00:26.13]yudan shitara sono yubi CHIKUCHIKUATAKKU kakugo shite\n[00:32.03]chiisai kedo hasamu no mijinko mitai na anata\n[00:38.40]hoshii no wa purasuchikku na HAATO (PURASU PURASU dakedo MAINASU)\n[00:44.39]demo sore ja tsumaranai soko ni kidzuita mono gachi\n[00:54.59]koi wa amakute nigai mono\n[00:57.49]tanjun meikai fukuzatsu kaiki na shiromono\n[01:00.56]dou demo ii koto bakkari ki ni shitari suru no\n[01:03.45]donna kanji? son na kanji\n[01:06.57]onkou tokujitsu EKISENTORIKKU na anata\n[01:09.53]tsuyogaru soburi wo zenshin matotte tachiuchi\n[01:12.49]sunao na dake da to shigeki ga tsuyokute kurakura\n[01:15.27]kizutsuichau no kizutsukechau no junjou PUREPARAATO\n[01:21.83]PU.RE.PUREPA PU.RE.PUREPA PU.RE.PUREPA WARETE BARIBARI\n[01:28.09]PU.RE.PUREPA PU.RE.PUREPA PU.RE.PUREPA\n[01:33.73]migakeba mada kagayaku genkai nante arienai\n[01:39.64]chiisakute mo dare ni mo makenai nanika ga aru no\n[01:45.89]watashi kara chikadzuku made taete yo (taete taete konki ga daiji)\n[01:51.93]anata kara sore ijou chikadzu karetara warechau\n[01:59.59] \n[02:02.00]hito wa yasashiku shigeki teki\n[02:05.07]kibun soukai nangyoukugyou no shiromono\n[02:08.09]nakitai toki ni mo nikoniko warattari suru no\n[02:10.93]donna kanji? son na kanji\n[02:14.03]saiki kanpatsu akutibu zenkai na anata\n[02:17.02]tsuyoki na taido de kishuu wo shikakete kataki uchi\n[02:20.04]chokushin dake da to fuan ni kararete sowasowa\n[02:22.79]atama no naka wa itsumo hitori no junjou PURE PAREEDO\n[02:28.54] \n[02:45.67]koi wa amakute nigai mono\n[02:48.52]tanjun meikai fukuzatsu kaiki na shiromono\n[02:51.52]dou demo ii koto bakkari ki ni shitari suru no\n[02:54.51]donna kanji? son na kanji\n[02:57.58]onkou tokujitsu EKISENTORIKKU na anata\n[03:00.55]tsuyogaru soburi wo zenshin matotte tachiuchi\n[03:03.49]sunao na dake da to shigeki ga tsuyokute kurakura\n[03:06.37]kizutsuichau no kizutsukechau no junjou PUREPARAATO\n[03:12.51]atama no naka wa itsumo hitori no junjou PURE PAREEDO\n[03:18.36] \n	/audio/Toradora OP 「Pre-Parade」.mp3	Pre-Parade	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253726/covers/Toradora_OP_Pre-Parade.jpg	1
1196	1195	1195	191	[00:00.00] \n[00:11.08]Can you tell it? Doko made oretachi ga ikerukatte\n[00:14.45]Daremoga shiranai reberu mezashite iku\n[00:16.92]Kotaenara kono mi de shoumei noboritsume zenshin\n[00:20.10]Hade ni mata chousen shite koeru tsukaten\n[00:22.94]Yeah, norikoete iku dake\n[00:25.21]Tagaini tetori kaeru fukano sae\n[00:27.61]Tatoe do natte mo tomaranai\n[00:29.83]Uh, ready for fight! I'll be last one that standing, wha!\n[00:32.36]Ten takaku haruka kanatae\n[00:35.27]Sobietatsu kaidan wo mia gei daku kono omoi yo\n[00:40.43]Sakerarenai destiny\n[00:42.58]Kono mi hateru made subete wo kakete\n[00:47.13]Never let you go, never let you go\n[00:49.36]Saranaru hikari ga terasu made I go\n[00:51.90]No turning back\n[00:53.69]Go up\n[00:58.44]Furikaerazu\n[01:01.51]Look up in the sky keep up\n[01:03.59]Go up\n[01:09.07]Never let you go, never let you go\n[01:11.36](Saranaru hikari ga terasu made I go)\n[01:17.97]Mo kamawanai nani nandatte\n[01:20.50]I don't even care fuan nante\n[01:22.70]Tatoe nani ga jama shiyou to kankei wanaku\n[01:25.29]Susume mata yume no tame ni ue, mezashi tsuzukeru\n[01:28.60](Hoo!) toki ga tatsu ni tsurewakaridasu, I know it's so hard\n[01:32.63]Mata donna koto okitatoe nanika ga, hit me down\n[01:35.69]Sore demo ii I know that I can win\n[01:37.63]Ten takaku haruka kanatae\n[01:41.61]Sobietatsu kaidan wo miageidaku kono omoi o\n[01:46.52]Sakerarenai destiny\n[01:48.86]Kono mi hateru made subete wo kakete\n[01:53.26]Never let you go, never let you go\n[01:55.53]Saranaru hikari ga terasu made I go\n[01:58.02]No turning back\n[01:59.85]Go up\n[02:04.44]Furikaerazu\n[02:07.55]Look up in the sky keep up\n[02:09.66]Go up\n[02:15.12]Never let you go, never let you go\n[02:17.60](Saranaru hikari ga terasu made I go)\n[02:20.38]Koronde mo tachiagari\n[02:22.87]Donna konnan mo, I'll solve and get what I need\n[02:25.30]Saki mienai to no naka\n[02:27.15]Nigirishimeta kagi de tobira akeru sarani\n[02:30.05]Tachinarabu kabe kezureru seishin\n[02:32.39]Madowasare tari sezu ni jibun ni bet shi\n[02:34.74]Noboru hodo kurushiku naru kono stage\n[02:36.92]Atama ni mezashita yume dake nokoru\n[02:39.73]No turning back\n[02:41.26]Don't let go\n[02:46.06]Furikaerazu\n[02:49.09]Look up in the sky keep up\n[02:51.03]Don't let go\n[02:52.71]Narifuri kamawazuhashire saki wo mitsume, woah\n[02:56.87]Never let you go, never let you go\n[02:59.08](Tsuyoku hikari ga terasu made I go)\n[03:02.08] \n	/audio/Tower of God OP 「TOP」.mp3	TOP	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253767/covers/Tower_of_God_OP_TOP.jpg	1
1206	1206	1147	261	[00:00.00] \n[00:01.75]FIRE\n[00:09.19]Ato ikutsu no jiyuu wo\n[00:28.52]Saa ore no ban da sentou battaa\n[00:31.20]Nani ga shippai ka nante mada shiru mae ni\n[00:34.31]Doukasen mitsukete\n[00:36.47]Soko ni FIRE\n[00:38.15]Ogamu kami nante inai ya hoshi mo nai ya\n[00:40.68]Demo negau koto wa yamenakatta\n[00:43.40]Koukai osore tachidomaru ashimoto\n[00:45.94]Soko ni FIRE\n[00:47.08]Wasuretai koto wa wasurerarenai koto\n[00:51.92]Tengoku e no michi wa jigoku kara tsunagatteru\n[00:56.64]Wazuka na hibana ga honou ni kawatteku\n[01:01.46]Togatta mama de oi tsuzuketeku\n[01:04.74]Go to future\n[01:07.13]Wazuka suusenchi datte negatta basho ni mukatte\n[01:11.81]Susunde yuku tomaru nante No, No, No…\n[01:16.63]Kokoro ni aganatte satoshite wa akirameru\n[01:21.36]Sore de mirai de nani ga ieru No, No, No…\n[01:26.31]Susunde yuku tomaru nante No, No, No…\n[01:35.82]Saa omae no ban da man wa jishita\n[01:38.17]Sono utsuwa wa man pan da\n[01:40.74]Afure nenryou mamire no tamashii ni\n[01:43.57]Soko ni FIRE\n[01:44.85]Genson kake wan raundo\n[01:46.62]Shinu ka ikiru ka sore mo fukume omae no jiyuu da\n[01:50.33]Bannin no shiru koto sae utagae\n[01:53.06]Soko ni FIRE\n[01:54.33]Koko kara bokura ato ikutsu no jiyuu wo ikite ikeru no darou\n[02:03.52]Ichinen ni ichido janaku ichibyou zutsu toshi wo kasanete yuku\n[02:10.67]Taimu rimitto nai de\n[02:14.09]Wazuka suusenchi datte negatta basho ni mukatte\n[02:19.03]Susunde yuku tomaru nante No, No, No…\n[02:23.86]Todokanu basho datte kanata sendatte\n[02:28.68]Susunde yuku tomaru nante No, No, No…\n[02:33.37]Susunde yuku tomaru nante No, No, No…\n[02:38.95] \n[02:50.70]Super (FIRE)\n[02:51.91]Seishin no (FIRE)\n[02:53.12]Kousoku de (FIRE)\n[02:54.31]One. two (FIRE)\n[02:55.42]Tamashii no kaihou\n[02:57.29]We gotta freedom\n[02:58.19]I’m show you how to\n[03:00.30]Super (FIRE)\n[03:01.49]Seishin no (FIRE)\n[03:02.66]Kousoku de (FIRE)\n[03:03.85]One. two (FIRE)\n[03:04.94]Tamashii no kaihou\n[03:06.46]We gotta freedom\n[03:08.43]Koko kara bokura ato ikutsumo no jiyuu wo ikite ikeru hazu darou\n[03:18.04]Akirameru hi wa nagai tabi no owari janaku\n[03:22.79]Saiaku no mirai no hajimari darou\n[03:28.87]Wazuka suusenchi datte negatta basho ni mukatte\n[03:33.35]Susunde yuku tomaru nante No, No, No…\n[03:38.24]Kokoro ni aganatte satoshite wa akirameru\n[03:43.16]Sore de mirai de nani ga ieru No, No, No…\n[03:48.54]Sore wo dore dake nagaku\n[03:49.72]Souzouteki ni kangaeru koto ga dekiru ka\n[03:51.75]Yukkuri to chakujitsu ni isogu\n[03:53.27]Sonna mujun wo kakae tsuzuke\n[03:54.83]Nanika wo matsu dake no jikan nante mijikai hou ga ii\n[03:57.20]Koko ni kite saidai no buki wa\n[03:58.82]Subete no nigai omoide to kaita haji\n[04:01.17]Hontou no jiyuu nado nai\n[04:02.40]Naraba kore wa sore wo hitei suru tame no tabi\n[04:04.69]No, no, no .....\n[04:07.60] \n	/audio/The Promised Neverland OP 「Touch off」.mp3	Touch off	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253731/covers/The_Promised_Neverland_OP_Touch_off.jpg	1
1229	1229	1228	425	[00:00.00] \n[00:05.01]Kimi no hitomi ni utsuru watashi wa nani-iro desu ka\n[00:18.05]Aka fukaki nozomu nara watasou hi no hikari wo\n[00:57.21]Kanashimi ga afure mabuta tojimashita\n[01:08.53]Koboreta shizuku wa kokoro ni shimi yuku\n[01:21.16]Yukiwataru nami wa yowaku majie masu\n[01:32.68]Todokeshi yurikago nemuri wo sasou\n[01:44.86]Yume ni natsukashi omokage wo sagasu\n[01:56.85]Te wo nobashi tsuyoku dakishime taku naru ha-\n[02:11.92]Kimi no hitomi ni utsuru watashi wa nani-iro desu ka\n[02:23.79]Ai fukaki nozomu nara watasou takaki sora wo\n[02:48.11]Yorokobi ga afure meguri aimashita\n[03:00.18]Koboreotsu emi wa wakare wo kakusu\n[03:12.22]Hito wa itsushika kuchihateru keredo\n[03:24.00]Uta tonari katari tsugarete yuku deshou ha-\n[03:39.15]Kimi no hitomi ni utsuru watashi wa nani-iro desu ka\n[03:51.01]Ryoku fukaki nozomu nara watasou kono daichi wo\n[04:27.34]Moroku hakanage na mono yo tsuyoku utsukushiki mono yo aru ga mama ha-\n[04:53.75]Kimi no hitomi ni utsuru watashi wa nani-iro desu ka\n[05:05.69]Yasuragi wo oboeta nara soko ni watashi wa iru\n[05:17.81]Kimi no hitomi ni utsuru watashi wa nani-iro desu ka\n[05:29.71]Ura fukaki nozomu nara watasou kono omoi wo\n[05:42.53]Watasou kono subete wo\n[05:50.76] 	/audio/Utawarerumono ED2 「Kimi ga Tame」.mp3	Kimi ga Tame	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253511/covers/Utawarerumono_ED2_Kimi_ga_Tame.jpg	1
1232	1229	1228	294	[00:00.00] \n[00:02.70]Chiisai donna koto mo wasureru koto nai\n[00:17.32]Ima demo mune ni nokosu kimi ga kureta nukumori\n[00:32.92]Mou tsutaerarenai kono nakisou na omoi wo\n[00:47.55]Hoshi furu sora aogimite kimi wo egaku\n[00:56.83]Tsukameru ki ga shita ude wo nobaseba\n[01:04.09]Kanawanu yume demo shinjirareta\n[01:11.03]Osanai kokoro wa doko ni yuku no itsu kara otona ni naru no\n[01:43.74]Futari ga sugoshita hibi kimi ga wasuretemo\n[01:58.12]Shiawase de iru naraba omoidasanakute ii\n[02:13.73]Doko nimo ikiba nai kono nakisou na omoi wo\n[02:28.32]Hoshi furu sora aogimite kimi no koe ga\n[02:37.74]Kikoeru ki ga shita mimi wo sumaseba\n[02:44.81]Yume wa egaku koto ni imi ga aru\n[02:52.03]Osanai kokoro wo nugisutete wa otona ni natteyuku darou\n[03:36.18]Kimi ni deatta hi ni kokoro wa sarawareta mama\n[03:54.18]Hoshi furu sora aogimite kimi wo omou\n[04:04.11]Tsukameru ki ga shita ude wo nobaseba\n[04:11.33]Kanawanu yume demo shinjirareta\n[04:18.27]Osanai kokoro wa doko ni yuku no itsu kara otona ni naru no\n[04:38.46]Itsu kara\n[04:45.06]	/audio/Utawarerumono S2 ED2 「Hoshi Furu Sora Aogi Mite.mp3	Hoshi Furu Sora Aogi Mite	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253644/covers/Utawarerumono_S2_ED2_Hoshi_Furu_Sora_Aogi_Mite.jpg	2
1248	170	1211	244	[ti:Wandering Son ED 「For You」]\n[ar:Rie Fu]\n[al:Wandering Son]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:03.98]\n[00:00.00]\n[00:17.01]"Subete kimi no tame ni"\n[00:19.67]mata sonna koto itteru\n[00:21.91]joudan no furi wa raku ne? watashi mo shitteru\n[00:26.86]sou iu jibun ni yotteru dake\n[00:31.21]hontou wa nani mo kamo jibun no tame\n[00:41.08]"Yo no naka tame ni nanika yakudatteru?"\n[00:45.99]hitori koto no you ni toikakete miru\n[00:50.90]hito to deau koto ga sono KIKKAKE naraba\n[00:56.16]anata to koko kara hajimerareru\n[00:59.29]chotto dake kono machi no ondo ni narete kita koro\n[01:08.81]I wanna cry for you\n[01:11.58]anata to wakeau megumi no shizuku wo\n[01:18.31]I wanna smile for you\n[01:21.15]jibun no tame ja nai ai no uta wo mitsuketai\n[01:33.36]yokubari sugichatta na hoshigatte bakari\n[01:38.52]sonna zaiakukan wo magirawasu tame ni\n[01:43.19]ano hito mitai ni ii kao suru nante\n[01:48.02]sunao ni ii to omoenai no ga fushigi\n[01:52.54]IMEEJI bakari tsukurikomarete shizen de areba ii no ni\n[02:01.49]I wanna cry for you\n[02:04.31]anata to wakeaeba kokoro mo hareteku\n[02:10.88]I wanna dream for you\n[02:13.75]yume kara samete mo wasurenai uta wo mitsuketai\n[02:22.45]All for you=All for me\n[02:27.67]itsudemo anata no tame ni suru koto wa jibun no tame ni natteru\n[02:41.15]hito to deau tabi ni sono wa ga hirogatteku\n[02:46.31]joudan wa hodo hodo ni honne de katattara\n[02:50.96]dareka no tame ni naru to shinjiteru\n[02:56.00]sou iu no ga ichiban ii no kamoshirenai\n[03:00.03]I wanna live for you\n[03:02.68]anata to wakeau inochi no shizuku wo\n[03:09.50]Oh I wanna sing for you\n[03:12.47]yume kara samete mo wasurenai uta ga kikoeru\n[03:19.49]I wanna cry for you\n[03:21.97]anata to waraetara kokoro mo hareteku\n[03:28.46]I wanna dream for you\n[03:31.57]yume kara samete mo wasurenai uta ga kikoeru\n[03:47.92]I wanna cry for you\n[03:51.45]smile for you...\n[03:56.19]dream for you\n[03:59.37]	/audio/Wandering Son ED 「For You」.mp3	For You	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253856/covers/Wandering_Son_ED_For_You.jpg	1
1254	1254	1254	339	[00:00.00] \r\n[00:26.44]Sora tobu hane to hikikae ni\r\n[00:33.17]Tsunagiau te wo eranda bokura\r\n[00:39.77]Sore demo sora ni miserarete\r\n[00:46.32]Yume wo kasaneru no wa tsumi ka\r\n[00:52.02] \r\n[00:57.91]Natsu wa aki no senaka wo mite\r\n[01:04.37]Sono kao wo omoiukaberu\r\n[01:10.97]Akogare na no ka koi na no ka\r\n[01:17.27]Kanawanu to shitteinagara\r\n[01:23.25] \r\n[01:28.99]Touriame ga touriame to\r\n[01:35.52]Komorebi tachi ga komorebi to\r\n[01:42.13]Nanoru zuttozutto zuttomaekara\r\n[01:48.68]Anata wa anata de itandarou?\r\n[01:54.68] \r\n[02:00.19]Juuryoku ga nemuri ni tsuku sennen ni ichido no kyou\r\n[02:06.76]Taiyou no shikaku ni tachi bokura kono hoshi wo deyou\r\n[02:13.26]Kare ga me wo samashita toki tsuremodosarenai basho e\r\n[02:19.64]“See no” de daichi wo kette koko de wa nai hoshi e\r\n[02:25.55]Ikou\r\n[02:27.05] \r\n[02:32.08]Ikou\r\n[02:33.73] \r\n[02:38.46]Ikou\r\n[02:40.76] \r\n[02:52.78]Natsu kaze ni aseru kokoro ga\r\n[02:59.31]Natsu wo sarani haya okuru yo\r\n[03:05.94]Memagurushii keshiki no naka\r\n[03:12.54]Kimi dake ga tomatte mieta\r\n[03:19.20]Kimi to deatta ano hi kara\r\n[03:25.75]Patari to yoru, yume wa yanda yo\r\n[03:32.35]Tsuchi no naka de machikogareta\r\n[03:38.72]Kanaeru sonotoki wa imada\r\n[03:45.35] \r\n[03:47.10]Juuryoku ga nemuri ni tsuku sennen ni ichido no kyou\r\n[03:53.76]Hanabi no oto ni nose bokura kono hoshi wo deyou\r\n[04:00.14]Kare ga me wo samashita toki tsuremodosarenai basho e\r\n[04:06.77]“See no” de daichi wo kette koko de wa nai hoshi e\r\n[04:12.18] \r\n[04:15.74]Ikou\r\n[04:16.59]Mou sukoshi de unmei no mukou\r\n[04:19.96]Mou sukoshi de bunmei no mukou (Ikou)\r\n[04:23.29]Mou sukoshi de unmei no mukou\r\n[04:26.34]Mou sukoshi de-\r\n[04:28.80]Ikou\r\n[04:29.65]Mou sukoshi de unmei no mukou\r\n[04:33.02]Mou sukoshi de bunmei no mukou (Ikou)\r\n[04:36.39]Mou sukoshi de unmei no mukou\r\n[04:39.36]Mou sukoshi de-\r\n[04:40.80] \r\n[04:42.86]Yume ni bokura de ho wo hatte\r\n[04:45.93]Kitaru beki hi no tame ni yoru wo koe\r\n[04:49.37]Iza kitai dake mantan de\r\n[04:52.55]Ato wa dou ni ka naru sa to kata wo kunda\r\n[04:56.65]Kowakunai wake nai demo tomaranai\r\n[05:01.57]Pinchi no sakimawari shitatte bokura ja shou ga nai\r\n[05:08.00]Bokura no koi ga iu koe ga iu\r\n[05:14.58]“Ike” to iu\r\n[05:16.50] \r\n	/audio/Weathering with you 「Grand Escape」.mp3	Grand Escape	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253881/covers/Weathering_with_you_Grand_Escape.jpg	1
1258	1126	1257	262	[ti:Welcome to the NHK ED2 「Modokashii Sekai no Ue de」]\n[ar:Yui Makino]\n[al:Welcome to the NHK]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:04:21.91]\n[00:00.00]\n[00:19.88]Moshimo ashita kono sekai ga\n[00:24.54]Owaru toshitemo kimi no koto dakara\n[00:28.96]"Sore nara sore demo ii ka"\n[00:32.91]Sokkenai taido toru no kana ?\n[00:37.71]Murisuru koto wa nai kedo\n[00:41.98]Tamani demo ii kara kao wo agete\n[00:46.61]Kocchi wo mite yo\n[00:51.66]Watashi wo mite\n[00:54.20]Chippoke na sekai nanoni naze darou\n[00:59.14]Kono ryoute ni wa ooki sugiru\n[01:02.70]Hateshinai sekai nanoni naze darou\n[01:07.64]Kono ryoute ni wa chiisa sugiru\n[01:11.15]Nee modokashii asa no hikari no\n[01:15.46]Naka de kimi to waraitai\n[01:29.00]Itsukara darou jibun ni\n[01:33.18]Usotsuitemo jishin ga motenakute\n[01:37.43]Nigemichi wo tsukutteta hazu nanoni\n[01:41.60]Kizuitara meiro wo tsukutteta\n[01:46.17]Kimi no nageku sugata wa egao e\n[01:50.61]Tsuzuite yukundayo ne ?\n[01:54.54]Shinjite mitai\n[01:58.75]Watashi wo mite\n[02:01.14]Chippoke na sekai nanoni doushite\n[02:05.61]Kitai ni mune ga fukuramu no ?\n[02:09.68]Hateshinai sekai nanoni doushite\n[02:14.64]Nanimo kitai ga motenai no ?\n[02:18.04]Nee modokashii tsuki no hikari no\n[02:22.36]Shita de kimi to waraitai\n[02:30.38]Tomadoi no kisetsu ga meguru\n[02:52.08]Naze darou\n[02:53.66]Chippoke na sekai nanoni…\n[03:02.16]Chippoke na sekai nanoni…\n[03:09.92]Sore nanoni\n[03:11.55]Chippoke na sekai nanoni naze darou\n[03:16.34]Kono ryoute ni wa ooki sugiru\n[03:20.21]Hateshinai sekai nanoni naze darou\n[03:25.08]Kono ryoute ni wa chiisa sugiru\n[03:29.01]Chippoke na sekai nanoni doushite\n[03:33.77]Kitai ni mune ga fukuramu no ?\n[03:37.65]Chippoke na sekai dakara mou sukoshi\n[03:42.88]Saki made aruite miyou ka\n[03:46.35]Modokashii sekai no ue de\n[03:50.44]Kimi to waratte itai yo\n[04:01.60]	/audio/Welcome to the NHK ED2 「Modokashii Sekai no Ue .mp3	Modokashii Sekai no Ue de	ED2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253550/covers/Welcome_to_the_NHK_ED2_Modokashii_Sekai_no_Ue_de.jpg	1
1270	298	1268	182	[ti:WorldEnd ED3 「Ever be my love」]\n[ar:Tamaru Yamada]\n[al:WorldEnd]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:02.07]\n[00:00.00]\n[00:20.90]To the point of access you,I'll always be ahead\n[00:26.15]If you go without your joy,I'll chase you with my hands\n[00:31.42]Through the window you have been, you've always been in love\n[00:36.65]If you go without no tears sad\n[00:42.71]Why we're born to this life\n[00:51.55]When the dawn is close inside\n[00:55.86]we never say good-bye and never see again\n[01:02.43]so that mourning I'll live with\n[01:06.16]As ever, been my love, you've ever been the one\n[01:11.63]I'll love you more\n[01:23.27]To avoid a joy that something gives you in your time\n[01:28.12]If you lived,if you decided to compromise your dreams\n[01:33.44]To the wind blows you have been,I'll always send you love.\n[01:38.32]Even if I cannot reach it you at last...\n[01:44.90]Why we're come to this life\n[01:53.60]When we've done it all, Besides,\n[01:57.89]we've ever given all each other heart and faith\n[02:04.22]All the morning we will see\n[02:08.27]As ever. be my love. you'll ever be the one forevermore\n[02:14.51]When the dawn is close inside\n[02:19.10]we never say good-bye and never see again\n[02:24.51]so that mourning I'll live with\n[02:28.98]As ever,been my love,you've ever been the one\n[02:33.95]I'll love you more\n[02:39.84]	/audio/WorldEnd ED3 「Ever be my love」.mp3	Ever be my love	ED3	https://res.cloudinary.com/ddc6silap/image/upload/v1773253798/covers/WorldEnd_ED3_Ever_be_my_love.jpg	1
1271	298	1268	152	[ti:WorldEnd OP 「Scarborough Fair」]\n[ar:Tamaru Yamada]\n[al:WorldEnd]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:02:31.82]\n[00:00.00]\n[00:14.70]Are you going to Scarborough Fair?\n[00:22.10]Parsley, sage, rosemary, and thyme\n[00:29.53]Remember me to one who lives there\n[00:37.60]He once was a true love of mine\n[00:47.42]Tell him to make me a cambric shirt\n[00:54.64]Parsley, sage, rosemary, and thyme\n[01:03.87]Without no seams nor needlework\n[01:11.58]Then he'll be a true love of mine\n[01:47.57]Tell him to find me an acre of land\n[01:55.22]Parsley, sage, rosemary, and thyme\n[02:02.62]Between the salt water and the sea strand\n[02:09.85]Then he'll be a true love of mine\n[02:18.79]Are you going to Scarborough Fair?\n[02:27.48]	/audio/WorldEnd OP 「Scarborough Fair」.mp3	Scarborough Fair	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773253877/covers/WorldEnd_OP_Scarborough_Fair.jpg	1
1272	1272	1268	302	[00:00.00] \r\n[00:00.33]Dō shi tara\r\n[00:02.56]anata ni ai o kizameru n daro u\r\n[00:10.67] \r\n[00:19.85]shira nai kimochi bakari oboe ta yo\r\n[00:23.25]wasure kata mo oshie te\r\n[00:26.51]kotoba dake ja naku te sa\r\n[00:29.67]furueru yubi no ondo kara\r\n[00:32.86]sore wa dare no kibō?\r\n[00:35.46]watashi kara afuredashi ta\r\n[00:37.87]negai no Drop\r\n[00:39.62]kie te mo kie te mo\r\n[00:41.14]umare te kuru kedo\r\n[00:42.99]kotae naki hidoi mirai\r\n[00:46.24]nan kai me no ashita ga kuru no ka\r\n[00:49.47]wakara nai yoru nara\r\n[00:52.08]namae o yobare tai\r\n[00:54.58]datte mune ga itai\r\n[00:56.84]itaku te harisake sō da\r\n[01:01.07]dō shi tara\r\n[01:03.52]anata ni ai o kizameru n daro u?\r\n[01:08.49]watashi ga itsuka\r\n[01:10.92]sora ni toke saru mae ni\r\n[01:14.26]tsuyoi omoi de ima o\r\n[01:18.79]mamori taku natta riyū wa\r\n[01:23.16]anata o motto mi te i tai kara\r\n[01:31.05] \r\n[01:48.45]hodoyoi egao nante ira nai yo amai uso de\r\n[01:53.81]kakushi ta\r\n[01:55.32]kizu o wakachiae tara nageki nomikomu imi\r\n[02:00.67]ga aru\r\n[02:01.66]soshite yume ni kaware anata e to tsutae\r\n[02:06.05]tai chikai no DROP\r\n[02:08.32]kanawa nai kanawa nai kizuiteru\r\n[02:10.76]dakedo ne sasageru n da inori o\r\n[02:15.09]eien ja nai sonzai demo\r\n[02:17.51]tashika na hikari o hoshi garu\r\n[02:20.76]ayaui unmei da yo\r\n[02:23.05]motto issho ni i te yo sekai ga koware te mo\r\n[02:28.35]itsu datte\r\n[02:30.40]kokoro wa ai o tomerare nai\r\n[02:35.55]anata wa itsumo\r\n[02:37.98]nani o sagashi te iru no\r\n[02:41.39]kurai yami e to\r\n[02:44.87]ima wa mukau beki da keredo\r\n[02:48.83]sore made anata o\r\n[02:51.92]soba de mitsume te iyo u\r\n[02:56.78] \r\n[03:20.81]moshimo to iikake te\r\n[03:26.84]koe wa kaze no naka chīsaku natte iku\r\n[03:33.97]subete o hanashi te yo\r\n[03:39.78]soreto dakishime te age tai no\r\n[03:46.57]na noni nagareru jikan ga shimesu no wa\r\n[03:53.14]surechigai nagara tōzakaru ni nin\r\n[04:01.00] \r\n[04:03.67]dō shi tara\r\n[04:05.99]anata ni ai o kizameru no?\r\n[04:10.79]itsu datte\r\n[04:12.55]kokoro wa ai o tomerare nai\r\n[04:17.37]anata wa itsumo\r\n[04:19.99]nani o sagashi te iru no?\r\n[04:23.28]tsuyoi omoi de\r\n[04:26.87]ima o mamori taku natta riyū wa\r\n[04:31.95]anata o motto mi te i taku te\r\n[04:36.54]ā sora ni tokesaru made wa\r\n[04:43.63] \r\n	/audio/WorldEnd OP2 「DEAREST DROP」.mp3	DEAREST DROP	OP2	https://res.cloudinary.com/ddc6silap/image/upload/v1773253902/covers/WorldEnd_OP2_DEAREST_DROP.jpg	1
1275	158	1273	231	[ti:Wotakoi OP 「Fiction」]\n[ar:Sumika]\n[al:Wotakoi: Love is hard for Otaku]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:22.5.26]\n[length:03:50.78]\n[00:00.00]\n[00:17.63]Saa, kyou mo hajimemashou ka?\n[00:20.27]Kinou hasanda shiori no tsudzuki kara\n[00:25.10]Raku areba ku mo ari sutoorii wa\n[00:28.71]Nami no manimani\n[00:32.48]Fukai umi wo nuke sora tobu\n[00:35.90]Machi ni kuridashi soko kara orirenaku nari\n[00:40.81]Myakuraku no nai you na tenkai mo\n[00:43.96]Kitto onri na sutoorii\n[00:47.89]Takanaru toko ni wa wasurezu fusen wo\n[00:51.88]Tokidoki kuru mainasu na men ni sonaete choho shite\n[00:57.86]Hirari hirari mekuri mekuru\n[01:00.86]Sutoorii sutoorii\n[01:03.09]Kidoairaku sewashii\n[01:05.56]Hirari hirari mekuri mekuru\n[01:08.78]Sutoorii sutoorii\n[01:10.75]Sewashinai Never Ending\n[01:13.46]Itsu ni nareba owarun da\n[01:19.17]Kaimoku kentou mo tsukanai\n[01:22.54]Oainiku kentou mo tsukanai\n[01:42.46]Saa kyou mo hajimemashou ka\n[01:45.24]Shiori hasanda peeji namida no ato\n[01:50.21]Kurushikute omowazu tojita riyuu wa wasurezu ni\n[01:57.08]Yomi susumeru hodo hakushi no peeji ga oki ni mesu mama ni\n[02:03.29]Kishoutenketsu wo koshiraete\n[02:09.18]Hirari hirari mekuri mekuru\n[02:12.21]Sutoorii sutoorii\n[02:14.31]Kidoairaku sewashii\n[02:16.84]Norari kurari meguru meguru\n[02:20.22]Sutoorii sutoorii\n[02:22.03]Jikou sekinin kewashii\n[02:25.47]Yaburi sutetai toki wa mou ikkai\n[02:29.92]Fusen no basho yomikaeshi\n[02:32.79]Soko ni atta sutoorii\n[02:35.32]Irodoru kyara wa imashita ka\n[02:38.74]Saa, omoidashite\n[02:56.45]Hirari hirari\n[02:58.51]Hirari hirari mekuri mekuru\n[03:01.54]Sutoorii sutoorii\n[03:03.56]Kidoairaku sewashi\n[03:06.14]Hirari hirari mekuri mekuru\n[03:09.57]Sutoorii sutoorii\n[03:11.38]Takanareba Never Ending\n[03:13.95]Itsu ni nareba owaru nda\n[03:19.79]Kaimoku kentou mo tsukanai\n[03:23.22]Oainiku kentou wa tsukenai\n[03:42.56]Saa kyou mo hajimemashou ka\n[03:47.06]	/audio/Wotakoi OP 「Fiction」.mp3	Fiction	OP	https://res.cloudinary.com/ddc6silap/image/upload/v1773254123/covers/Wotakoi_OP_Fiction.jpg	1
1280	485	1213	262	[ti:Yamada Kun and the Seven Witches OVA ED 「Oddloop」]\n[ar:Frederic]\n[al:Yamada Kun and the Seven Witches]\n[re:Created by Synced Lyrics Editor app at https://play.google.com/store/apps/details?id=lyriceditor.lyricsearch.embedlyrictomp3.syncedlyriceditor]\n[ve:23.4.20]\n[length:04:22.07]\n[00:00.00]\n[00:22.72]Odotteru dake de taijou\n[00:24.98]Sore wo sokka sokka tte itte\n[00:28.08]Oshiawase ni tsuite touron\n[00:30.64]Nani ga seigi nanka tte omou\n[00:33.45]Namaiki sou ni gamu kande\n[00:36.19]Sore mo ii na ii na tte omou\n[00:39.03]Teresukoopu goshi no kanjou\n[00:41.70]Rokkaa ni zenbu tsumekonda\n[00:45.04]Odottenai yoru so shiranai\n[00:47.76]Odottenai yoru ga ki ni iranai\n[00:50.45]Odottenai yoru wo shiranai\n[00:53.23]Odottenai yoru ga ki ni iranai yo\n[00:57.59]Ki ni iranai yoru nante mou boku wa shiranai\n[01:01.74]Odottenai yoru ga nai yoru nante\n[01:04.60]Tottemo tottemo taikutsu desu\n[01:18.59]Odotteru dake de koudou\n[01:20.92]Kitto night ongaku mo odoru\n[01:24.14]Tansu de dansu suru genjou\n[01:26.44]Kore wa chansu nanka tte omou\n[01:29.69]Kasutanetto ga hora tantan\n[01:31.94]Ta ta ta tan ta tan tan ta tan tan\n[01:35.13]Odottenai yoru wo shiranai hito to ka\n[01:37.83]Kono yo ni hitori mo gozaimasen\n[01:40.83]Odottenai yoru so shiranai\n[01:43.54]Odottenai yoru ga ki ni iranai\n[01:46.26]Odottenai yoru so shiranai\n[01:49.04]Odottenai yoru ga ki ni iranai yo\n[01:53.00]Ki ni iranai yoru nante mou boku wa shiranai\n[01:57.45]Odottenai yoru ga nai yoru nante\n[02:00.28]Tottemo tottemo taikutsu desu\n[02:04.11]Itsumo matteru dansuhooru wa matteru\n[02:09.02]Kawatteku kawatteku kizu darake demo matteru\n[02:15.06]Hora odotteru dansuhooru no mirai ni\n[02:20.30]Iro wo nutte ikiru no wa anata anata\n[02:25.63]“Dansu wa egao de matteru”\n[02:50.81]Odottenai yoru wo shiranai\n[02:53.35]Odottenai yoru ga ki ni iranai\n[02:56.15]Odottenai yoru wo shiranai\n[02:58.77]Odottenai yoru ga ki ni iranai yo\n[03:03.23]Ki ni iranai nante mou boku wa shiranai\n[03:07.36]Odottenai yoru ga nai yoru nante?\n[03:13.10]Odottetai yoru wo shiritai\n[03:15.47]Odottetai yoru wo ki ni iritai\n[03:18.34]Odottetai yoru wo shiritai\n[03:21.18]Odottenai yoru ga ki ni iranai yo\n[03:25.17]Ki ni iranai yoru nante mou boku wa shiranai\n[03:29.49]Odottetai yoru ni naiteru nante\n[03:32.43]Tottemo tottemo taikutsu desu\n[03:35.33]Odottetai yoru ga taisetsu nan desu\n[03:38.13]Tottemo tottemo tottemo taisetsu desu\n[03:43.01]	/audio/Yamada Kun and the Seven Witches OVA ED 「Oddloop」.mp3	Oddloop	ED	https://res.cloudinary.com/ddc6silap/image/upload/v1773253843/covers/Yamada_Kun_and_the_Seven_Witches_OVA_ED_Oddloop.jpg	1
1290	1254	1288	344	[00:00.00] \r\n[00:00.70]Futari no aida toorisugita kaze wa doko kara sabishisa o hakondekita no\r\n[00:12.41]Naitari shita sono ato no sora wa yake ni sukitootteitari shitanda\r\n[00:23.40] \r\n[00:35.20]Itsumo wa togatteta chichi no kotoba ga kyou wa atatakaku kanjimashita\r\n[00:46.39]Yasashisa mo egao mo yume no katarikata mo shiranakute zenbu kimi o maneta yo\r\n[00:57.53]Mou sukoshi dake de ii ato sukoshi dake de ii mou sukoshi dake de ii kara\r\n[01:09.20]Mou sukoshi dake de ii ato sukoshi dake de ii\r\n[01:14.87]Mou sukoshi dake kuttsuiteiyou ka\r\n[01:18.85] \r\n[01:23.80]Bokura taimufuraiyaa toki o kakeagaru kuraimaa\r\n[01:28.84]Toki no kakurenbo hagurekko wa mou iya nanda\r\n[01:35.65]Ureshikute naku nowa kanashikute warau nowa\r\n[01:39.84]Kimi no kokoro ga kimi o oikoshitanda yo\r\n[01:44.78] \r\n[02:06.43]Hoshi ni made negatte te ni ireta omocha mo heya no sumikko ni ima korogatteru\r\n[02:17.85]Kanaetai yume mo kyou de hyakko dekita yo tatta hitotsu to itsuka koukanko shiyou\r\n[02:29.06] \r\n[02:35.01]Itsumo wa shaberanai ano ko ni kyou wa houkago "mata ashita" to koe o kaketa\r\n[02:46.43]Narenai koto mo tama ni nara ii ne toku ni anata ga tonari ni itara\r\n[02:57.43] \r\n[02:57.63]Mousukoshi dake de ii ato sukoshi dake de ii mousukoshi dake de ii kara\r\n[03:09.14]Mousukoshi dake de ii ato sukoshi dake de ii\r\n[03:14.86]Mousukoshi dake kuttsuiteiyou yo\r\n[03:23.74]Bokura taimufuraiyaa kimi o shitteitanda\r\n[03:28.86]Boku ga boku no namae o oboeru yori zutto mae ni\r\n[03:39.34] \r\n[03:41.52]Kimi no inai sekai ni mo nanika no imi wa kitto atte\r\n[03:46.94]Demo kimi no inai sekai nado natsuyasumi no nai hachigatsu no you\r\n[03:53.24]Kimi no inai sekai nado warau koto nai santa no you\r\n[03:58.62]Kimi no inai sekai nado\r\n[04:08.17] \r\n[04:32.34]Bokura taimufuraiyaa toki o kakeagaru kuraimaa\r\n[04:37.44]Toki no kakurenbo hagurekko wa mou iya nanda\r\n[04:44.12]Nandemo nai ya yappari nandemo nai ya\r\n[04:48.46]Ima kara iku yo\r\n[04:50.76] \r\n[04:53.17]Bokura taimufuraiyaa toki o kakeagaru kuraimaa\r\n[04:58.06]Toki no kakurenbo hagurekko wa mou ii yo\r\n[05:04.53]Kimi wa hade na kuraiyaa sono namida tometemitai na\r\n[05:09.53]Dakedo kimi wa kobanda koboreru mama no namida o mite wakatta\r\n[05:16.29]Ureshikute naku nowa kanashikute warau nowa\r\n[05:20.52]Boku no kokoro ga boku o oikoshitanda yo\r\n[05:25.28] \r\n	/audio/Your Name 「Nandemonaiya」.mp3	Nandemonaiya	\N	https://res.cloudinary.com/ddc6silap/image/upload/v1773253906/covers/Your_Name_Nandemonaiya.jpg	1
\.


--
-- Data for Name: user_recommendations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_recommendations (id, user_id, song_id, affinity_score, created_at) FROM stdin;
5656	12	1064	10	2026-04-26 03:00:00.201307
5657	12	1065	10	2026-04-26 03:00:00.211039
5658	12	1070	10	2026-04-26 03:00:00.21287
5659	12	1077	10	2026-04-26 03:00:00.214616
5660	12	1081	10	2026-04-26 03:00:00.224393
5661	12	1078	10	2026-04-26 03:00:00.226543
5662	12	1082	10	2026-04-26 03:00:00.228384
5663	12	1201	10	2026-04-26 03:00:00.229911
5664	12	390	10	2026-04-26 03:00:00.231588
5665	12	394	10	2026-04-26 03:00:00.233065
5666	16	284	10	2026-04-26 03:00:00.238628
5667	16	283	10	2026-04-26 03:00:00.240179
5668	16	459	10	2026-04-26 03:00:00.241686
5669	16	1036	10	2026-04-26 03:00:00.243852
5670	16	1040	10	2026-04-26 03:00:00.245273
5671	16	1042	10	2026-04-26 03:00:00.246632
5672	16	1085	10	2026-04-26 03:00:00.248127
5673	16	944	10	2026-04-26 03:00:00.249567
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, first_name, last_name, username, email, password_hash, created_at, user_image, banner_image, role) FROM stdin;
10	Shubham	\N	shubham	shubham@dev.com	$2b$10$3mKI9f5Q2hGcle8QwBZi/utIdQ02acZlYH0qToQW6GY993VLTOidK	2026-02-23 19:13:01.62848	\N	\N	user
11	nero		Nero95	nero@camelot.fate	$2b$10$iil4n9neorC0ZURwA3CvVeF.H0fdYg9PqX.qAt3tcDnGzHy2pA5GS	2026-02-23 19:13:06.364524	\N	\N	user
14	Shivam 	Singh 	Shivam@10	shivamsinghup830@gmail.com	$2b$10$.89YBDeb4CSrLLNC4bJ3AOX010yFRrUZzBTePoBk0/q67ELctB/Oa	2026-03-12 15:55:40.325033	\N	\N	moderator
13	Weeaboo	Maestro	Weeaboo45	weeaboomaestro@gmail.com	$2b$10$CEWJ7b2gSpXmlqCJUlBELeISJMItj0UAlvrQkPMR27M4pUcTAKSM6	2026-03-12 14:12:30.07154	\N	\N	user
12	Fafnir		fafnir100	fafnir@flame.bb	$2b$10$GwH.VB8Px3mKt.aRLUCUXub8.zmaVwRGnvlrqHzcSPjoZyxu9svkK	2026-02-24 19:34:24.127356	https://res.cloudinary.com/ddc6silap/image/upload/v1773346951/users/zp0uccfybashfblhdygx.webp	https://res.cloudinary.com/ddc6silap/image/upload/v1773336109/users/mgxgp6sxdw3ogv5tf4p1.png	moderator
17	Praveen	Nayak	Praveen27	graninja78@gmail.com	$2b$10$LsUQfHwM8XCGvvEBOzxRROF.tjEf7W7Tmpwwi3gzpSpBEERb8mk5.	2026-03-13 03:49:24.289858	\N	\N	moderator
18	Namit	Pareek	namiit	pareeknamit8@gmail.com	$2b$10$4nGj27mgS1MRBLRY3Q2Ni.VeFSdLNXVAJJbYEZZPK.VzxduoX7Xba	2026-03-14 09:56:39.80838	\N	\N	user
16	Yume	Tunes	Yume28	yumetunes9@gmail.com	$2b$10$iXGG1kU3XRRtAm8biO/hoe7e6ZBoh6kA/dnCedWkvDaGYMZzzc7rC	2026-03-12 20:27:35.727535	https://res.cloudinary.com/ddc6silap/image/upload/v1773376777/users/qmrqkjcgcxlxthqaegxc.webp	https://res.cloudinary.com/ddc6silap/image/upload/v1775029512/banners/dxp8cycvqziwuz799yjg.webp	admin
\.


--
-- Name: albums_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.albums_id_seq', 1311, true);


--
-- Name: artists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.artists_id_seq', 1311, true);


--
-- Name: genres_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.genres_id_seq', 1356, true);


--
-- Name: hero_banners_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hero_banners_id_seq', 16, true);


--
-- Name: listening_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.listening_history_id_seq', 478, true);


--
-- Name: playlists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.playlists_id_seq', 9, true);


--
-- Name: quotes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.quotes_id_seq', 214, true);


--
-- Name: songs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.songs_id_seq', 1300, true);


--
-- Name: user_recommendations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_recommendations_id_seq', 5673, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 18, true);


--
-- Name: animes albums_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.animes
    ADD CONSTRAINT albums_pkey PRIMARY KEY (id);


--
-- Name: animes albums_title_artist_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.animes
    ADD CONSTRAINT albums_title_artist_id_key UNIQUE (title, artist_id);


--
-- Name: animes animes_title_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.animes
    ADD CONSTRAINT animes_title_key UNIQUE (title);


--
-- Name: artists artists_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artists
    ADD CONSTRAINT artists_name_key UNIQUE (name);


--
-- Name: artists artists_name_key1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artists
    ADD CONSTRAINT artists_name_key1 UNIQUE (name);


--
-- Name: artists artists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artists
    ADD CONSTRAINT artists_pkey PRIMARY KEY (id);


--
-- Name: genres genres_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genres
    ADD CONSTRAINT genres_name_key UNIQUE (name);


--
-- Name: genres genres_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genres
    ADD CONSTRAINT genres_pkey PRIMARY KEY (id);


--
-- Name: hero_banners hero_banners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hero_banners
    ADD CONSTRAINT hero_banners_pkey PRIMARY KEY (id);


--
-- Name: liked_songs liked_songs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liked_songs
    ADD CONSTRAINT liked_songs_pkey PRIMARY KEY (user_id, song_id);


--
-- Name: listening_history listening_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listening_history
    ADD CONSTRAINT listening_history_pkey PRIMARY KEY (id);


--
-- Name: playlist_songs playlist_songs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playlist_songs
    ADD CONSTRAINT playlist_songs_pkey PRIMARY KEY (playlist_id, song_id);


--
-- Name: playlists playlists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playlists
    ADD CONSTRAINT playlists_pkey PRIMARY KEY (id);


--
-- Name: quotes quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_pkey PRIMARY KEY (id);


--
-- Name: song_genres song_genres_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.song_genres
    ADD CONSTRAINT song_genres_pkey PRIMARY KEY (song_id, genre_id);


--
-- Name: songs songs_file_path_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.songs
    ADD CONSTRAINT songs_file_path_key UNIQUE (file_path);


--
-- Name: songs songs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.songs
    ADD CONSTRAINT songs_pkey PRIMARY KEY (id);


--
-- Name: animes unique_anime_per_artist; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.animes
    ADD CONSTRAINT unique_anime_per_artist UNIQUE (title, artist_id);


--
-- Name: user_recommendations user_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_recommendations
    ADD CONSTRAINT user_recommendations_pkey PRIMARY KEY (id);


--
-- Name: user_recommendations user_recommendations_user_id_song_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_recommendations
    ADD CONSTRAINT user_recommendations_user_id_song_id_key UNIQUE (user_id, song_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_listening_history_user_song; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_listening_history_user_song ON public.listening_history USING btree (user_id, song_id);


--
-- Name: animes albums_artist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.animes
    ADD CONSTRAINT albums_artist_id_fkey FOREIGN KEY (artist_id) REFERENCES public.artists(id) ON DELETE CASCADE;


--
-- Name: liked_songs liked_songs_song_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liked_songs
    ADD CONSTRAINT liked_songs_song_id_fkey FOREIGN KEY (song_id) REFERENCES public.songs(id) ON DELETE CASCADE;


--
-- Name: liked_songs liked_songs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liked_songs
    ADD CONSTRAINT liked_songs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: listening_history listening_history_song_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listening_history
    ADD CONSTRAINT listening_history_song_id_fkey FOREIGN KEY (song_id) REFERENCES public.songs(id) ON DELETE CASCADE;


--
-- Name: listening_history listening_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listening_history
    ADD CONSTRAINT listening_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: playlist_songs playlist_songs_playlist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playlist_songs
    ADD CONSTRAINT playlist_songs_playlist_id_fkey FOREIGN KEY (playlist_id) REFERENCES public.playlists(id) ON DELETE CASCADE;


--
-- Name: playlist_songs playlist_songs_song_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playlist_songs
    ADD CONSTRAINT playlist_songs_song_id_fkey FOREIGN KEY (song_id) REFERENCES public.songs(id) ON DELETE CASCADE;


--
-- Name: playlists playlists_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playlists
    ADD CONSTRAINT playlists_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: song_genres song_genres_genre_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.song_genres
    ADD CONSTRAINT song_genres_genre_id_fkey FOREIGN KEY (genre_id) REFERENCES public.genres(id) ON DELETE CASCADE;


--
-- Name: song_genres song_genres_song_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.song_genres
    ADD CONSTRAINT song_genres_song_id_fkey FOREIGN KEY (song_id) REFERENCES public.songs(id) ON DELETE CASCADE;


--
-- Name: songs songs_anime_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.songs
    ADD CONSTRAINT songs_anime_id_fkey FOREIGN KEY (anime_id) REFERENCES public.animes(id) ON DELETE CASCADE;


--
-- Name: songs songs_artist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.songs
    ADD CONSTRAINT songs_artist_id_fkey FOREIGN KEY (artist_id) REFERENCES public.artists(id) ON DELETE CASCADE;


--
-- Name: user_recommendations user_recommendations_song_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_recommendations
    ADD CONSTRAINT user_recommendations_song_id_fkey FOREIGN KEY (song_id) REFERENCES public.songs(id) ON DELETE CASCADE;


--
-- Name: user_recommendations user_recommendations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_recommendations
    ADD CONSTRAINT user_recommendations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict Dyx7ZtOp0fgiAEadWukXSubQTRwaQ4EExf0wf9xJeRaYms9deKodXTxLzDsd7in

